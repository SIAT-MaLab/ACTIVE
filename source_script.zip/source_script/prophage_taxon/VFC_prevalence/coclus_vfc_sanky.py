import pandas as pd
import numpy as np
import re
from collections import Counter

JOINT_TAX_FILE = "viral_with_vfc_taxonomy.csv"
VFC_META_FILE = "/home/huangyan/experiment/SPA/3/gut_isolate/prophage/analysis/3_prophage_stats/sig_act_prevalence/VFC_cluster/clustering_results/vfc_votu.tsv"
VFAM_STATS_FILE = "../../../activity/1_sataxon/stats_baseline_vFAM.tsv"
OLD_TAXONOMY_FILE = "../../higher_tax/clustering_results/viral_taxonomy.csv"

OUTPUT_BREAKDOWN = "vfc_full_flow_breakdown_exact.tsv"
OUTPUT_SANKEY = "sankey_links_with_pct.tsv"


def load_inputs():
    df_vfc_meta = pd.read_csv(VFC_META_FILE, sep='\t')
    vfc_id_map = pd.Series(df_vfc_meta.VFC.values,
                           index=df_vfc_meta.votu_id.astype(str)).to_dict()
    vfc_ids_set = set(df_vfc_meta.votu_id.astype(str))

    df_vfam_stats = pd.read_csv(VFAM_STATS_FILE, sep='\t')
    df_vfam_stats['vFAM'] = df_vfam_stats['vFAM'].astype(str).str.strip()
    vfam_info = df_vfam_stats.set_index('vFAM')[['Significance_Type', 'Count_Active']].to_dict('index')

    df_old_tax = pd.read_csv(OLD_TAXONOMY_FILE)
    genome_to_old_vfam = pd.Series(df_old_tax.vFAM.values,
                                   index=df_old_tax.genome_id.astype(str).str.strip()).to_dict()

    df_joint = pd.read_csv(JOINT_TAX_FILE)

    return (df_joint, vfc_id_map, vfc_ids_set,
            vfam_info, genome_to_old_vfam)


def preprocess_joint(df_joint, vfc_id_map, vfc_ids_set, genome_to_old_vfam):
    processed_rows = []

    for _, row in df_joint.iterrows():
        genome_id = str(row['genome_id']).strip()
        new_vfam = row['vFAM']

        source_type = "Unknown"
        vfc_origin = None
        user_old_fam = None

        base_id = genome_id.split('_provirus')[0]
        if genome_id in vfc_ids_set:
            source_type = "VFC"
            vfc_origin = vfc_id_map.get(genome_id)
        elif base_id in vfc_ids_set:
            source_type = "VFC"
            vfc_origin = vfc_id_map.get(base_id)

        if source_type == "Unknown":
            user_old_fam = genome_to_old_vfam.get(genome_id)
            if user_old_fam:
                source_type = "User"

        processed_rows.append({
            'new_vfam': new_vfam,
            'type': source_type,
            'vfc_origin': vfc_origin,
            'user_old_fam': user_old_fam
        })

    return pd.DataFrame(processed_rows)


def calc_vfc_flow(df_proc):
    df_only_vfc = df_proc[df_proc['type'] == 'VFC']
    vfc_flow = df_only_vfc.groupby(['vfc_origin', 'new_vfam']).size().reset_index(name='count')

    vfc_totals = df_only_vfc.groupby('vfc_origin').size().to_dict()
    vfc_flow['total_in_vfc'] = vfc_flow['vfc_origin'].map(vfc_totals)
    vfc_flow['percentage'] = (vfc_flow['count'] / vfc_flow['total_in_vfc']) * 100
    vfc_flow = vfc_flow.sort_values(by=['vfc_origin', 'percentage'],
                                    ascending=[True, False])
    return vfc_flow


def annotate_active_families(old_fams, vfam_info):
    if not old_fams:
        return "None"

    old_fam_counts = Counter(old_fams).most_common(3)
    annotated = []
    for fam, cnt in old_fam_counts:
        info = vfam_info.get(fam)
        if info is None:
            tag = "manual check"
        else:
            sig = info.get('Significance_Type')
            count_active = info.get('Count_Active')

            if sig is not None and not pd.isna(sig) and str(sig).strip() == "Significant":
                tag = "SA"
            else:
                if count_active is not None and not pd.isna(count_active) and count_active >= 1:
                    tag = "A"
                else:
                    tag = "I"
        annotated.append(f"{fam}({cnt})|{tag}")

    return "; ".join(annotated)


def summarize_active_stats(df_proc, vfc_flow, vfam_info):
    final_results = []

    for _, row in vfc_flow.iterrows():
        vfc_source = row['vfc_origin']
        target_vfam = row['new_vfam']
        count_vfc = row['count']
        total_vfc = row['total_in_vfc']
        pct = row['percentage']

        user_rows = df_proc[(df_proc['new_vfam'] == target_vfam) & (df_proc['type'] == 'User')]

        old_fams = user_rows['user_old_fam'].dropna().tolist()
        old_fams = [f for f in old_fams if f != 'Unknown']

        active_fam_str = annotate_active_families(old_fams, vfam_info)

        final_results.append({
            'VFC_Source': vfc_source,
            'Target_vFAM': target_vfam,
            'Flow_Count': count_vfc,
            'Total_In_VFC': total_vfc,
            'Flow_Percentage': round(pct, 2),
            'ACTIVE_Original_Families': active_fam_str
        })

    return pd.DataFrame(final_results)


def build_sankey_links(df_final):
    links_dict = {}

    for _, row in df_final.iterrows():
        vfc_source = row['VFC_Source']
        if pd.isna(vfc_source):
            continue
        vfc_node = f"VFC_{int(float(vfc_source))}"
        target_node = f"New_{row['Target_vFAM']}"
        vfc_count = int(row['Flow_Count'])

        links_dict[(vfc_node, target_node)] = \
            links_dict.get((vfc_node, target_node), 0) + vfc_count

        active_fams_str = str(row['ACTIVE_Original_Families'])
        if active_fams_str not in ("None", "nan"):
            items = active_fams_str.split(';')
            for item in items:
                match = re.match(r'\s*(.+?)\((\d+)\)', item)
                if match:
                    old_fam_name = match.group(1).strip()
                    user_count = int(match.group(2))
                    old_fam_node = f"Old_{old_fam_name}"
                    links_dict[(target_node, old_fam_node)] = user_count

    sankey_data = [{'source': s, 'target': t, 'value': v}
                   for (s, t), v in links_dict.items()]
    df_sankey = pd.DataFrame(sankey_data)

    if df_sankey.empty:
        df_sankey['sumofsource'] = []
        df_sankey['%'] = []
        return df_sankey[['source', 'target', 'value', 'sumofsource', '%']]

    source_sums = df_sankey.groupby('source')['value'].sum().reset_index(name='sumofsource')
    df_sankey = pd.merge(df_sankey, source_sums, on='source', how='left')
    df_sankey['%'] = df_sankey['value'] / df_sankey['sumofsource']

    df_sankey = df_sankey[['source', 'target', 'value', 'sumofsource', '%']]
    df_sankey = df_sankey.sort_values(by=['source', '%'], ascending=[True, False])
    return df_sankey


def main():
    (df_joint, vfc_id_map, vfc_ids_set,
     vfam_info, genome_to_old_vfam) = load_inputs()

    df_proc = preprocess_joint(df_joint, vfc_id_map, vfc_ids_set,
                               genome_to_old_vfam)

    vfc_flow = calc_vfc_flow(df_proc)

    df_final = summarize_active_stats(df_proc, vfc_flow, vfam_info)
    df_final.to_csv(OUTPUT_BREAKDOWN, sep='\t', index=False)

    df_sankey = build_sankey_links(df_final)
    df_sankey.to_csv(OUTPUT_SANKEY, sep='\t', index=False)


if __name__ == "__main__":
    main()