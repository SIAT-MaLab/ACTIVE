bindash sketch --listfname=vOTU.txt --outfname=vOTU_sketch
#find $(pwd)/uhgv_vOTU/uhgv_vOTU.fna.split/ -maxdepth 1 -type f > uhgv_votu.txt
bindash sketch --listfname=uhgv_votu.txt --outfname=uhgv_votu_sketch
bindash dist --outfname=vOTU-uhgv_votu_dist.txt vOTU_sketch uhgv_votu_sketch

#find $(pwd)/prophagedb/prophagedb.fa.split/ -maxdepth 1 -type f > prophagedb.txt
bindash sketch --listfname=prophagedb.txt --outfname=prophagedb_sketch
bindash dist --outfname=vOTU-prophagedb_dist.txt vOTU_sketch prophagedb_sketch

