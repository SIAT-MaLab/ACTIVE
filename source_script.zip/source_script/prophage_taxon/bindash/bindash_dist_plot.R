library(data.table)
library(tidyverse)
library(ggplot2)

dist_dir <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/genome_similarity/bindash"

metadata_path <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
genome_to_votu_path <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/taxonomy/vOTU/genome_to_vOTU.tsv"

dist_files <- list(
  inphared   = file.path(dist_dir, "vOTU-inphared_dist.txt"),
  prophagedb = file.path(dist_dir, "vOTU-prophagedb_dist.txt"),
  uhgv       = file.path(dist_dir, "vOTU-uhgv_votu_dist.txt")
)


normalize_phage_id <- function(x) {
  x <- as.character(x)
  x <- basename(x)
  x <- gsub("^allpp\\.part_|^activepp\\.part_|^phage_depth_", "", x)
  x <- gsub("\\.fasta$|\\.fa$|\\.fna$|\\.txt$", "", x)
  x <- gsub("\\s.*$", "", x)  
  x <- gsub("-", "_", x)
  x
}
message("Loading metadata...")
metadata <- fread(metadata_path)

message("Columns: ", paste(names(metadata), collapse = ", "))
stopifnot("Activity_Score" %in% names(metadata))
stopifnot("vOTU" %in% names(metadata))

active_records <- metadata[!is.na(Activity_Score) & Activity_Score >= 0.8]
message("Active prophage records: ", nrow(active_records))
active_votus <- unique(active_records$vOTU)
active_votus <- active_votus[!is.na(active_votus) & active_votus != ""]
message("Active vOTUs (union rule): ", length(active_votus))
message("Example active vOTUs: ", paste(head(active_votus, 5), collapse = ", "))
# genome_to_vOTU.tsv: Genome_Contig, vOTU, Rep_Contig
g2v <- fread(genome_to_votu_path, header = FALSE,
             col.names = c("Genome_Contig", "vOTU", "Rep_Contig"))

message("Example g2v vOTU: ", paste(head(unique(g2v$vOTU), 5), collapse = ", "))
message("Example Rep_Contig: ", paste(head(g2v$Rep_Contig, 3), collapse = ", "))

rep_map <- unique(g2v[vOTU %in% active_votus, .(vOTU, Rep_Contig)])
rep_map[, rep_id_norm := normalize_phage_id(Rep_Contig)]

active_rep_ids <- unique(rep_map$rep_id_norm)
message("Active vOTU representative IDs: ", length(active_rep_ids))
message("Example active rep IDs: ", paste(head(active_rep_ids, 5), collapse = ", "))

fwrite(rep_map, file.path(dist_dir, "active_vOTU_representatives.tsv"), sep = "\t")
process_dist_file <- function(filepath, db_name) {
  message("Processing: ", db_name)
  dt <- fread(filepath, header = FALSE,
              select = c(1, 3),
              col.names = c("query_path", "distance"))
  dt[, query_id := normalize_phage_id(query_path)]
  min_dt <- dt[, .(min_dist = min(distance, na.rm = TRUE)), by = query_id]
  setnames(min_dt, "min_dist", db_name)
  min_dt
}

dist_list <- lapply(names(dist_files), function(db) process_dist_file(dist_files[[db]], db))
merged_dist <- Reduce(function(x, y) merge(x, y, by = "query_id", all = TRUE), dist_list)

message("Total vOTUs in distance matrix: ", nrow(merged_dist))
message("Example distance query_id: ", paste(head(merged_dist$query_id, 5), collapse = ", "))
melt_data <- function(dt) {
  long <- melt(dt,
               id.vars = "query_id",
               measure.vars = c("inphared", "prophagedb", "uhgv"),
               variable.name = "Database",
               value.name = "Genetic_Distance")
  long <- long[!is.na(Genetic_Distance)]
  long[, Database_fct := factor(Database, levels = c("inphared", "prophagedb", "uhgv"))]
  long[, x_num := as.numeric(Database_fct)]
  long
}


all_long <- melt_data(merged_dist)
all_long[, Group := "All vOTUs"]

active_dist <- merged_dist[query_id %in% active_rep_ids]
message("Active vOTUs matched in distance matrix: ", nrow(active_dist))

active_long <- melt_data(active_dist)
active_long[, Group := "Active vOTUs"]

plot_df <- rbindlist(list(all_long, active_long), use.names = TRUE)
plot_df[, Group := factor(Group, levels = c("All vOTUs", "Active vOTUs"))]
plot_df[, Database_fct := factor(Database, levels = c("inphared", "prophagedb", "uhgv"))]

n_all    <- uniqueN(all_long$query_id)
n_active <- uniqueN(active_long$query_id)

p <- ggplot(plot_df, aes(x = Database_fct, y = Genetic_Distance, fill = Group)) +
  geom_point(
    position = position_jitterdodge(jitter.width = 0.12, dodge.width = 0.75),
    size = 0.45, alpha = 0.18, color = "grey35",
    show.legend = FALSE
  ) +
  geom_boxplot(
    position = position_dodge(width = 0.75),
    width = 0.55, alpha = 0.85,
    outlier.shape = NA, color = "black", lwd = 0.55
  ) +
  scale_x_discrete(labels = c(
    "inphared" = "INPHARED",
    "prophagedb" = "ProphageDB",
    "uhgv" = "UHGV"
  )) +
  scale_fill_manual(values = c("All vOTUs" = "#8D99AE", "Active vOTUs" = "#E71D36")) +
  theme_bw() +
  labs(
    title = "Minimum Genetic Distance to Reference Databases",
    subtitle = paste0(
      "All vOTUs (n = ", n_all,
      ") vs Active vOTUs (n = ", n_active,
      "; any member Activity_Score ≥ 0.8)"
    ),
    x = "Reference Database",
    y = "Min Mash Distance",
    fill = NULL
  ) +
  theme(
    axis.text.x = element_text(size = 12, face = "bold"),
    axis.text.y = element_text(size = 11),
    axis.title  = element_text(size = 13, face = "bold"),
    plot.title  = element_text(size = 13, face = "bold"),
    plot.subtitle = element_text(size = 10, color = "grey30"),
    legend.position = "top",
    legend.text = element_text(size = 11),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank()
  )

ggsave("all_vs_active_vOTU_mindist.pdf", p, width = 8, height = 5.5, dpi = 300)
message("Saved: all_vs_active_vOTU_mindist.pdf")
message("Done.")
