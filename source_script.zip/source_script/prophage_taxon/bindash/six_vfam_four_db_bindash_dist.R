library(data.table)
library(ggplot2)

setDTthreads(threads = 20)

base_dir <- path.expand(
  "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage"
)
dist_dir <- file.path(base_dir, "genome_similarity", "bindash")
tbpgd_dir <- file.path(base_dir, "genome_similarity", "transposase")
metadata_path <- file.path(base_dir, "metadata", "allpp_metadata.tsv")
genome_to_votu_path <- file.path(
  base_dir, "taxonomy", "vOTU", "genome_to_vOTU.tsv"
)

target_vfams <- c(
  "vFAM_1", "vFAM_84", "vFAM_152",
  "vFAM_257", "vFAM_76", "vFAM_89"
)
db_levels <- c("INPHARED", "ProphageDB", "UHGV", "TBPGD")

vfam_colors <- c(
  vFAM_1   = "#D55E00",
  vFAM_84  = "#0072B2",
  vFAM_152 = "#009E73",
  vFAM_257 = "#CC79A7",
  vFAM_76  = "#E69F00",
  vFAM_89  = "#56B4E9"
)

resolve_dist_file <- function(filepath) {
  candidates <- c(filepath, paste0(filepath, ".gz"))
  existing <- candidates[file.exists(candidates)]
  if (length(existing) == 0L) {
    stop("Distance file not found:\n", paste(candidates, collapse = "\n"))
  }
  existing[1L]
}

dist_files <- c(
  INPHARED   = resolve_dist_file(file.path(dist_dir, "vOTU-inphared_dist.txt")),
  ProphageDB = resolve_dist_file(file.path(dist_dir, "vOTU-prophagedb_dist.txt")),
  UHGV       = resolve_dist_file(file.path(dist_dir, "vOTU-uhgv_votu_dist.txt")),
  TBPGD      = resolve_dist_file(file.path(tbpgd_dir, "vOTU-tbpgd_dist.txt"))
)

normalize_phage_id <- function(x) {
  x <- trimws(as.character(x))
  x <- basename(x)
  x <- gsub("\\s.*$", "", x)
  x <- gsub("^allpp\\.part_|^activepp\\.part_|^phage_depth_", "", x)
  x <- gsub("\\.(fasta|fa|fna|txt)$", "", x, ignore.case = TRUE)
  gsub("-", "_", x)
}

normalize_votu <- function(x) {
  gsub("-", "_", trimws(as.character(x)))
}

metadata <- fread(metadata_path, sep = "\t", quote = "")
stopifnot(all(c("vOTU", "vFAM") %in% names(metadata)))

metadata[, vOTU_norm := normalize_votu(vOTU)]
metadata[, vFAM_norm := trimws(as.character(vFAM))]

votu_to_vfam <- unique(metadata[
  vOTU_norm != "" & vFAM_norm %in% target_vfams,
  .(vOTU_norm, vFAM = vFAM_norm)
])

g2v <- fread(
  genome_to_votu_path,
  header = FALSE,
  col.names = c("Genome_Contig", "vOTU", "Rep_Contig")
)
g2v[, vOTU_norm := normalize_votu(vOTU)]
g2v[, query_id := normalize_phage_id(Rep_Contig)]

rep_to_vfam <- unique(merge(
  votu_to_vfam,
  g2v[query_id != "", .(vOTU_norm, query_id)],
  by = "vOTU_norm"
))

process_dist_file <- function(filepath, db_name, target_ids) {
  dt <- fread(
    filepath,
    header = FALSE,
    select = c(1, 3),
    col.names = c("query_path", "distance")
  )
  dt[, query_id := normalize_phage_id(query_path)]
  dt <- dt[query_id %in% target_ids]
  dt[, distance := suppressWarnings(as.numeric(distance))]
  dt <- dt[is.finite(distance)]
  dt[, .(min_dist = min(distance)), by = query_id][, Database := db_name]
}

plot_df <- rbindlist(
  lapply(db_levels, function(db) {
    process_dist_file(dist_files[[db]], db, unique(rep_to_vfam$query_id))
  })
)
plot_df <- merge(plot_df, rep_to_vfam, by = "query_id")
plot_df[, vFAM := factor(vFAM, levels = target_vfams)]
plot_df[, Database := factor(Database, levels = db_levels)]

summary_df <- plot_df[, .(
  n = uniqueN(query_id),
  median = median(min_dist),
  q25 = as.numeric(quantile(min_dist, 0.25)),
  q75 = as.numeric(quantile(min_dist, 0.75)),
  min = min(min_dist),
  max = max(min_dist)
), by = .(Database, vFAM)]

prefix <- file.path(dist_dir, "six_vFAM_fourDB_bindash_box_byDB")
fwrite(summary_df, paste0(prefix, "_summary.tsv"), sep = "\t")
fwrite(
  plot_df[, .(vOTU_norm, query_id, vFAM, Database, min_dist)],
  paste0(prefix, "_long.tsv"),
  sep = "\t"
)

p <- ggplot(plot_df, aes(x = Database, y = min_dist, fill = vFAM)) +
  geom_boxplot(
    width = 0.72,
    position = position_dodge2(
      width = 0.78,
      preserve = "single",
      padding = 0.12
    ),
    outlier.shape = NA,
    color = "black",
    linewidth = 0.4,
    alpha = 0.92
  ) +
  scale_x_discrete(drop = FALSE) +
  scale_fill_manual(
    values = vfam_colors,
    breaks = target_vfams,
    drop = FALSE,
    name = "vFAM"
  ) +
  scale_y_continuous(expand = expansion(mult = c(0.03, 0.06))) +
  labs(
    title = "Minimum BinDash distance across four reference databases",
    subtitle = "vOTU representatives; six vFAMs per database",
    x = "Reference database",
    y = "Minimum BinDash distance"
  ) +
  theme_bw(base_size = 12) +
  theme(
    legend.position = "top",
    legend.title = element_text(face = "bold"),
    axis.text.x = element_text(size = 12, face = "bold"),
    axis.title = element_text(face = "bold"),
    plot.title = element_text(face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank()
  ) +
  guides(fill = guide_legend(nrow = 1))

ggsave(paste0(prefix, ".pdf"), p, width = 12, height = 6)
ggsave(paste0(prefix, ".png"), p, width = 12, height = 6, dpi = 300)
