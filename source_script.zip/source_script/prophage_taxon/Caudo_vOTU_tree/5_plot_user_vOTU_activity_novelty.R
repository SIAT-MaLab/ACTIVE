library(tidyverse)

annotation_path <- "terL_tree_metadata_annotation.tsv"
user_fasta <- "vOTU_terL_for_tree.faa"

use_all_user_tree_nodes <- TRUE

user_tree_ids <- readLines(user_fasta) %>%
  keep(~ str_starts(.x, ">")) %>%
  str_remove("^>") %>%
  str_extract("^[^[:space:]]+") %>%
  unique()

annotation <- read_tsv(
  annotation_path,
  show_col_types = FALSE,
  na = c("", "NA", "na", "NULL")
) %>%
  mutate(node_id = as.character(node_id)) %>%
  distinct(node_id, .keep_all = TRUE)

user_nodes <- tibble(node_id = user_tree_ids) %>%
  left_join(annotation, by = "node_id")

n_unmatched <- user_nodes %>%
  summarise(
    n = sum(is.na(Source) | Source == "Unknown")
  ) %>%
  pull(n)

if (!use_all_user_tree_nodes) {
  user_nodes <- user_nodes %>%
    filter(Source == "User_vOTU")
}

if (nrow(user_nodes) == 0) {
  stop("No user vOTUs")
}

user_nodes <- user_nodes %>%
  mutate(
    is_active = replace_na(as.character(is_active), "dormant"),
    is_new = replace_na(as.character(is_new), "No"),
    Activity = if_else(
      is_active == "active",
      "Active",
      "Dormant"
    ),
    Novelty = if_else(
      is_new == "Yes",
      "New",
      "Known"
    )
  )

write_tsv(
  user_nodes %>%
    select(node_id, Source, Activity, Novelty, everything()),
  "user_vOTU_activity_novelty_status.tsv"
)

activity_counts <- user_nodes %>%
  count(Activity, name = "n") %>%
  rename(Status = Activity) %>%
  complete(
    Status = c("Dormant", "Active"),
    fill = list(n = 0)
  ) %>%
  mutate(Feature = "Activity")

novelty_counts <- user_nodes %>%
  count(Novelty, name = "n") %>%
  rename(Status = Novelty) %>%
  complete(
    Status = c("Known", "New"),
    fill = list(n = 0)
  ) %>%
  mutate(Feature = "Novelty")

plot_df <- bind_rows(
  activity_counts,
  novelty_counts
) %>%
  group_by(Feature) %>%
  mutate(
    prop = n / sum(n),
    label = if_else(
      n > 0 & prop >= 0.03,
      paste0(
        scales::percent(prop, accuracy = 0.1),
        "\n(n = ", n, ")"
      ),
      ""
    )
  ) %>%
  ungroup() %>%
  mutate(
    Feature = factor(
      Feature,
      levels = c("Activity", "Novelty")
    ),
    Status = factor(
      Status,
      levels = c("Dormant", "Active", "Known", "New")
    )
  )

write_tsv(
  plot_df %>%
    mutate(
      Feature = as.character(Feature),
      Status = as.character(Status)
    ),
  "user_vOTU_activity_novelty_proportions.tsv"
)

status_colors <- c(
  "Dormant" = "#A6A6A6",
  "Active"  = "#D95F02",
  "Known"   = "#80B1D3",
  "New"     = "#1B9E77"
)

p_marginal <- ggplot(
  plot_df,
  aes(x = Feature, y = prop, fill = Status)
) +
  geom_col(
    width = 0.65,
    colour = "white",
    linewidth = 0.3
  ) +
  geom_text(
    data = plot_df %>% filter(n > 0 & prop >= 0.03),
    aes(label = label),
    position = position_stack(vjust = 0.5),
    size = 3.8,
    lineheight = 0.9
  ) +
  scale_y_continuous(
    labels = scales::label_percent(accuracy = 1),
    limits = c(0, 1),
    expand = c(0, 0)
  ) +
  scale_fill_manual(
    values = status_colors,
    drop = TRUE
  ) +
  labs(
    x = NULL,
    y = "Proportion of user vOTUs",
    fill = NULL,
    caption = paste0(
      "N = ", nrow(user_nodes),
      " user vOTUs"
    )
  ) +
  theme_classic(base_size = 14) +
  theme(
    legend.position = "top",
    plot.caption = element_text(
      hjust = 1,
      colour = "grey30"
    ),
    axis.text.x = element_text(
      colour = "black"
    )
  )

ggsave(
  "user_vOTU_activity_novelty_stacked.pdf",
  p_marginal,
  width = 5.5,
  height = 5,
  units = "in"
)

ggsave(
  "user_vOTU_activity_novelty_stacked.png",
  p_marginal,
  width = 5.5,
  height = 5,
  units = "in",
  dpi = 300
)

joint_levels <- c(
  "Dormant & Known",
  "Dormant & New",
  "Active & Known",
  "Active & New"
)

joint_counts <- user_nodes %>%
  mutate(
    Joint_status = case_when(
      Activity == "Dormant" & Novelty == "Known" ~ "Dormant & Known",
      Activity == "Dormant" & Novelty == "New"   ~ "Dormant & New",
      Activity == "Active"  & Novelty == "Known" ~ "Active & Known",
      Activity == "Active"  & Novelty == "New"   ~ "Active & New"
    )
  ) %>%
  count(Joint_status, name = "n") %>%
  complete(
    Joint_status = joint_levels,
    fill = list(n = 0)
  ) %>%
  mutate(
    Joint_status = factor(
      Joint_status,
      levels = joint_levels
    ),
    prop = n / sum(n),
    Group = "User vOTUs",
    label = if_else(
      n > 0 & prop >= 0.03,
      paste0(
        scales::percent(prop, accuracy = 0.1),
        "\n(n = ", n, ")"
      ),
      ""
    )
  )

write_tsv(
  joint_counts %>%
    mutate(Joint_status = as.character(Joint_status)),
  "user_vOTU_joint_activity_novelty_proportions.tsv"
)

joint_colors <- c(
  "Dormant & Known" = "#BDBDBD",
  "Dormant & New"   = "#80B1D3",
  "Active & Known"  = "#D95F02",
  "Active & New"    = "#1B9E77"
)

p_joint <- ggplot(
  joint_counts,
  aes(x = Group, y = prop, fill = Joint_status)
) +
  geom_col(
    width = 0.65,
    colour = "white",
    linewidth = 0.3
  ) +
  geom_text(
    data = joint_counts %>% filter(n > 0 & prop >= 0.03),
    aes(label = label),
    position = position_stack(vjust = 0.5),
    size = 3.6,
    lineheight = 0.9
  ) +
  scale_y_continuous(
    labels = scales::label_percent(accuracy = 1),
    limits = c(0, 1),
    expand = c(0, 0)
  ) +
  scale_fill_manual(
    values = joint_colors,
    drop = FALSE
  ) +
  labs(
    x = NULL,
    y = "Proportion of user vOTUs",
    fill = NULL,
    caption = paste0(
      "N = ", nrow(user_nodes),
      " user vOTUs"
    )
  ) +
  theme_classic(base_size = 14) +
  theme(
    legend.position = "top",
    plot.caption = element_text(
      hjust = 1,
      colour = "grey30"
    )
  )

ggsave(
  "user_vOTU_joint_activity_novelty_stacked.pdf",
  p_joint,
  width = 5.5,
  height = 5,
  units = "in"
)

ggsave(
  "user_vOTU_joint_activity_novelty_stacked.png",
  p_joint,
  width = 5.5,
  height = 5,
  units = "in",
  dpi = 300
)