install.packages(c("writexl"))
library(readxl)
library(dplyr)
library(stringr)
library(writexl)

fasta_file <- "votu_refseq_terL.faa"
excel_file <- "VMR_annot.xlsx"
output_csv <- "VMR_annot_filtered.csv"     
output_missing <- "missing_ids.txt"         #lines <- readLines(fasta_file)


header_lines <- lines[str_detect(lines, "^>")]
target_lines <- header_lines[!str_detect(header_lines, "vOTU")]

target_ids <- str_replace(target_lines, "^>", "") %>% str_trim()
target_ids <- unique(target_ids)
metadata <- read_excel(excel_file)
target_col_name <- "Virus GENBANK accession"


filtered_df <- metadata %>%
  filter(.data[[target_col_name]] %in% target_ids)

ids_in_excel <- unique(metadata[[target_col_name]])
missing_ids <- setdiff(target_ids, ids_in_excel)


write.csv(filtered_df, output_csv, row.names = FALSE, quote = TRUE)


