library(tidyverse)
library(data.table)

map_file <- "../vOTU/genome_to_vOTU.tsv"
annot_file <- "../../metadata/allpharokka_annot.tsv"
class_file <- "../../metadata/uhgv_allpp_yaxon_info.tsv"

df_map <- fread(map_file, header = FALSE, select = c(1, 2), col.names = c("Genome", "vOTU"))
df_annot_raw <- fread(annot_file, header = TRUE, select = c("contig", "annot"))
df_class_raw <- fread(class_file, header = TRUE)

df_class_caudoviricetes <- df_class_raw %>%
  filter(grepl("Caudoviricetes", ictv_lineage)) %>%
  mutate(Contig_ID = genome_id)

df_map_caudoviricetes <- df_map %>%
  semi_join(df_class_caudoviricetes, by = c("Genome" = "Contig_ID"))

target_genes <- c("terminase large", "portal", "major capsid|major head")
pattern_regex <- regex(paste(target_genes, collapse = "|"), ignore_case = TRUE)

df_annot_filtered <- df_annot_raw %>%
  filter(str_detect(annot, pattern_regex)) %>%
  mutate(
    is_terL = str_detect(annot, regex("terminase large", ignore_case = TRUE)),
    is_portal = str_detect(annot, regex("portal", ignore_case = TRUE)),
    is_head = str_detect(annot, regex("major head|major capsid", ignore_case = TRUE))
  ) %>%
  rename(Genome = contig)

df_merged <- df_map_caudoviricetes %>%
  left_join(df_annot_filtered, by = "Genome")

total_genomes <- n_distinct(df_merged$Genome)
total_votus <- n_distinct(df_merged$vOTU)

count_genome_terL <- n_distinct(df_merged$Genome[which(df_merged$is_terL)])
count_genome_portal <- n_distinct(df_merged$Genome[which(df_merged$is_portal)])
count_genome_head <- n_distinct(df_merged$Genome[which(df_merged$is_head)])

votu_stats <- df_merged %>%
  group_by(vOTU) %>%
  summarise(
    has_terL = any(is_terL, na.rm = TRUE),
    has_portal = any(is_portal, na.rm = TRUE),
    has_head = any(is_head, na.rm = TRUE)
  )

count_votu_terL <- sum(votu_stats$has_terL)
count_votu_portal <- sum(votu_stats$has_portal)
count_votu_head <- sum(votu_stats$has_head)

plot_data <- data.frame(
  Gene = rep(c("Terminase Large", "Portal", "Major Head"), 2),
  Level = c(rep("Genome Level", 3), rep("vOTU Level", 3)),
  Count = c(count_genome_terL, count_genome_portal, count_genome_head,
            count_votu_terL, count_votu_portal, count_votu_head),
  Total = c(rep(total_genomes, 3), rep(total_votus, 3))
) %>%
  mutate(
    Percentage = (Count / Total) * 100,
    Gene = factor(Gene, levels = c("Terminase Large", "Portal", "Major Head"))
  )

p <- ggplot(plot_data, aes(x = Gene, y = Percentage, fill = Level)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_text(aes(label = sprintf("%.1f%%", Percentage)),
            position = position_dodge(width = 0.8),
            vjust = -0.5, size = 4) +
  scale_fill_manual(values = c("Genome Level" = "#4E84C4", "vOTU Level" = "#D16103")) +
  scale_y_continuous(limits = c(0, 110), expand = c(0, 0)) +
  labs(
    title = "Annotation Rate in Caudoviricetes: Genome vs vOTU Level",
    subtitle = paste0("Total Caudoviricetes Genomes: ", total_genomes, " | Total Caudoviricetes vOTUs: ", total_votus),
    y = "Annotation Rate (%)",
    x = "Structural Proteins"
  ) +
  theme_classic() +
  theme(
    axis.text.x = element_text(size = 12, face = "bold", color = "black"),
    axis.text.y = element_text(size = 12, color = "black"),
    legend.position = "top",
    legend.title = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    plot.subtitle = element_text(hjust = 0.5, color = "gray40")
  )

ggsave("caudoviricetes_annotation_rate_comparison.pdf", p, width = 8, height = 6)
ggsave("caudoviricetes_annotation_rate_comparison.png", p, width = 8, height = 6)