grep '>' vOTU_terL_for_tree.faa > vOTU_genome_tree.log
sed '/^>/ s/ .*//' vOTU_terL_for_tree.faa > tmp_terL.faa
cat tmp_terL.faa refseq_viral_terL_detected.faa > votu_refseq_terL.faa
mafft --thread 26 --auto votu_refseq_terL.faa > terL_aligned.fasta
echo "!!!!!!!!!!mafft done !!!!!!!!!"
fasttree -wag terL_aligned.fasta > votu_refseq_terL_fasttree.tree
echo "!!!!!!!!!!fasttree done !!!!!!!!!"
rm tmp_terL.faa votu_refseq_terL.faa terL_aligned.fasta
