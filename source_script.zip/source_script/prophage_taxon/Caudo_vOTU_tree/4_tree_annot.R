library(tidyverse)

user_metadata_path <- "../../metadata/allpp_metadata.tsv"
ictv_metadata_path <- "/home/huangyan/experiment/SPA/3/gut_isolate/prophage/analysis/3_prophage_stats/allpp_taxonomy/votu_marker_tree/VMR_annot_filtered.csv"

user_fasta <- "vOTU_terL_for_tree.faa"
ictv_fasta <- "refseq_viral_terL_detected.faa"

user_tree_ids <- readLines(user_fasta) %>% 
  keep(~str_starts(.x, ">")) %>% 
  str_remove("^>") %>% 
  str_split(" ") %>% 
  map_chr(1) 

ictv_tree_ids <- readLines(ictv_fasta) %>% 
  keep(~str_starts(.x, ">")) %>% 
  str_remove("^>")

user_meta <- read_tsv(user_metadata_path, na = c("", "NA", "na", "Unclassified", "NULL"))
ictv_meta <- read_csv(ictv_metadata_path, na = c("", "NA", "na", "Unclassified", "NULL"))

user_meta <- user_meta %>%
  mutate(vOTU_clean = str_replace_all(vOTU, "-", "_"))

user_annot <- user_meta %>%
  filter(vOTU_clean %in% user_tree_ids) %>%
  group_by(vOTU_clean) %>%
  summarise(
    Order = first(na.omit(ictv_Order)),
    Family = first(na.omit(ictv_Family)),
    Subfamily = first(na.omit(ictv_Subfamily)),
    Genus = first(na.omit(ictv_Genus)),
    
    Total_Genomes = n(),
    Log10_Genomes = log10(Total_Genomes),
    
    is_active = if_else(any(!is.na(Activity_Score) & Activity_Score >= 0.8), "active", "dormant"),
    .groups = 'drop'
  ) %>%
  mutate(
    across(c(Order, Family, Subfamily, Genus), ~replace_na(.x, "Unclassified")),
    is_new = if_else(
      Order == "Unclassified" & Family == "Unclassified" & 
      Subfamily == "Unclassified" & Genus == "Unclassified",
      "Yes", "No"
    ),
    Source = "User_vOTU"
  ) %>%
  rename(node_id = vOTU_clean)

ictv_annot <- ictv_meta %>%
  filter(`Virus GENBANK accession` %in% ictv_tree_ids) %>%
  select(
    node_id = `Virus GENBANK accession`,
    Order, Family, Subfamily, Genus
  ) %>%
  distinct(node_id, .keep_all = TRUE) %>%
  mutate(
    across(c(Order, Family, Subfamily, Genus), ~replace_na(as.character(.x), "Unclassified")),
    Total_Genomes = 1,
    Log10_Genomes = log10(1), 
    is_active = "dormant", 
    is_new = "No",
    Source = "ICTV"
  )

all_tree_nodes <- data.frame(node_id = c(user_tree_ids, ictv_tree_ids))

final_annotation <- all_tree_nodes %>%
  left_join(bind_rows(user_annot, ictv_annot), by = "node_id") %>%
  mutate(
    Source = replace_na(Source, "Unknown"),
    across(c(Order, Family, Subfamily, Genus), ~replace_na(.x, "Unclassified")),
    is_new = replace_na(is_new, "No"),
    Log10_Genomes = replace_na(Log10_Genomes, 0),
    is_active = replace_na(is_active, "dormant")   ) %>%
 
  mutate(is_active = factor(is_active, levels = c("dormant", "active")))

write_tsv(final_annotation, "terL_tree_metadata_annotation.tsv")
