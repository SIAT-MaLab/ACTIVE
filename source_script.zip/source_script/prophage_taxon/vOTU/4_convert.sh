awk -F'\t' 'NR>1 {print $3 "\t" $1 "\t" $2}' vOTU_clusters_uhgv_final.tsv > genome_to_vOTU.tsv

awk '{print $3}' genome_to_vOTU.tsv | sort -u > rep_genome_ids.txt
seqkit grep -f rep_genome_ids.txt ../../metadata/allpp.fasta -o vOTU.fasta

awk '!seen[$3]++ {print $3 "\t" $2}' genome_to_vOTU.tsv > id_mapping.txt
seqkit grep -f rep_genome_ids.txt ../../metadata/allpp.fasta -o temp_rep_seqs.fasta
seqkit replace -p '(.+)' -r '{vOTU}_rep={old}' -k id_mapping.txt -i temp_rep_seqs.fasta > vOTU_named.fasta 
rm temp_rep_seqs.fasta rep_genome_ids.txt
