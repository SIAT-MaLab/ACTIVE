in="/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp.fasta"
makeblastdb -in $in -dbtype nucl -out virus_db

blastn \
    -query $in\
    -db virus_db \
    -task megablast \
    -outfmt '6 std qlen slen' \
    -max_target_seqs 2000 \
    -num_threads 24 \
    -out blast_output.tsv
