#!/bin/bash
mkdir -p 04.Skani_results

for list_file in 03.Primary_clusters/*.list; do
    cluster_name=$(basename "$list_file" .list)
    
    # 如果列表里只有1个文件，就不跑 skani 了 (后续脚本会处理)
    count=$(wc -l < "$list_file")
    if [ "$count" -gt 1 ]; then
        # 这里的计算量非常小，可以适当减少线程以防 I/O 冲突
        skani triangle -l "$list_file" -t 26 -E -o "04.Skani_results/${cluster_name}.tsv"
    fi
done
echo "Skani step finished!"
