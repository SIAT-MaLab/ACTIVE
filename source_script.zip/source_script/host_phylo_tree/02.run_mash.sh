#!/bin/bash
mkdir -p 02.Mash_results

# 遍历每个 Order 列表
for list_file in 01.Order_lists/*.list; do
    order=$(basename "$list_file" .list)
    echo "Running Mash for Order: $order"
    
    sketch_file="02.Mash_results/${order}"
    result_file="02.Mash_results/${order}.result"
    
    # 1. Sketch (注意修改 -p 线程数)
    mash sketch -p 26 -s 10000 -o "$sketch_file" -l "$list_file"
    
    # 2. Dist
    mash dist -p 26 "${sketch_file}.msh" "${sketch_file}.msh" > "$result_file"
done
echo "Mash step finished!"
