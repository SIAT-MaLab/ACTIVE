import pandas as pd
import os
import pickle
import fastcluster
from scipy.cluster.hierarchy import cut_tree

def comb2(N):
    return int(N*(N-1)/2)

list_dir = "03.Primary_clusters"
skani_dir = "04.Skani_results"
out_file = "all_species_clusters.tsv"

cutoff = 0.05
cov_threshold = 0.60
with open("genome_s_scores.pkl", "rb") as f:
    score_dict = pickle.load(f)

f_out = open(out_file, "w")
f_out.write("Species_Cluster_ID\tPrimary_Cluster\tRepresentative_Genome\tGenome_Count\tGenome_List\n")

global_species_id = 1

for list_file in os.listdir(list_dir):
    if not list_file.endswith(".list"): continue
    pri_cluster = list_file.replace('.list', '')

    with open(os.path.join(list_dir, list_file), 'r') as f:
        genomes = [line.strip().split('/')[-1].replace('.fasta', '') for line in f if line.strip()]
        
    n = len(genomes)
    if n == 0: continue
    if n == 1:
        rep = genomes[0]
        f_out.write(f"Species_Cluster_{global_species_id}\t{pri_cluster}\t{rep}\t1\t{rep}\n")
        global_species_id += 1
        continue
        
    g2index = {g: i for i, g in enumerate(genomes)}
    distance_array = [1.0] * comb2(n)
    skani_path = os.path.join(skani_dir, f"{pri_cluster}.tsv")
    if os.path.exists(skani_path) and os.path.getsize(skani_path) > 0:
        skani_df = pd.read_csv(skani_path, sep='\t')
        q_col = 'Query_file' if 'Query_file' in skani_df.columns else 'Query'
        r_col = 'Ref_file' if 'Ref_file' in skani_df.columns else 'Reference'
        af_r_col = 'Align_fraction_ref' if 'Align_fraction_ref' in skani_df.columns else 'Align_fraction_reference'
        af_q_col = 'Align_fraction_query'
        
        for _, row in skani_df.iterrows():
            g1 = row[q_col].split('/')[-1].replace('.fasta', '')
            g2 = row[r_col].split('/')[-1].replace('.fasta', '')
            ani = row['ANI'] / 100.0
            af_q = row[af_q_col] / 100.0
            af_r = row[af_r_col] / 100.0
            cover = max(af_q, af_r)
            if cover < cov_threshold:
                ani = 0.0
            distance = 1.0 - ani
            i = g2index.get(g1)
            j = g2index.get(g2)
            if i is not None and j is not None:
                if i > j: i, j = j, i
                if i != j:
                    idx = comb2(n) - comb2(n-i) + (j-i-1)
                    distance_array[idx] = distance
    z = fastcluster.linkage(distance_array, method='average', preserve_input=True)
    cutree = cut_tree(z, height=cutoff)
    
    species_clusters = {}
    for idx in range(n):
        c_id = cutree[idx][0]
        species_clusters.setdefault(c_id, []).append(genomes[idx])

    for c_id, g_list in species_clusters.items():
        rep_genome = g_list[0]
        max_score = score_dict.get(rep_genome, 0.0)
        
        for g in g_list[1:]:
            s = score_dict.get(g, 0.0)
            if s > max_score:
                max_score = s
                rep_genome = g
                
        f_out.write(f"Species_Cluster_{global_species_id}\t{pri_cluster}\t{rep_genome}\t{len(g_list)}\t{';'.join(g_list)}\n")
        global_species_id += 1
f_out.close()
