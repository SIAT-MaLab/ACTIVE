import os
import shutil
import pandas as pd
tsv_file = "all_species_clusters.tsv"
source_dir = "/home/huangyan/experiment/SPA/3/gut_isolate/allgenome"
output_dir = "species_rep_genome"
os.makedirs(output_dir, exist_ok=True)
df = pd.read_csv(tsv_file, sep='\t')
success_count = 0
fail_count = 0
for index, row in df.iterrows():
    cluster_id = row['Species_Cluster_ID']
    rep_genome = row['Representative_Genome']
     src_file = os.path.join(source_dir, f"{rep_genome}.fasta")
    dst_file = os.path.join(output_dir, f"{rep_genome}.fasta")
    
    if os.path.exists(src_file):
        shutil.copy(src_file, dst_file)
        success_count += 1
    else:
        fail_count += 1