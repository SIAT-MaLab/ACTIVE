import os
import fastcluster
from scipy.cluster.hierarchy import cut_tree

def comb2(N):
    return int(N*(N-1)/2)

mash_dir = "02.Mash_results"
list_dir = "01.Order_lists"
out_dir = "03.Primary_clusters"
os.makedirs(out_dir, exist_ok=True)

cutoff = 0.1
global_pri_id = 1

for order_file in os.listdir(list_dir):
    if not order_file.endswith(".list"): continue
    order = order_file.replace('.list', '')
    genomes = []
    g2index = {}
    with open(os.path.join(list_dir, order_file), 'r') as f:
        for i, line in enumerate(f):
            path = line.strip()
            if not path: continue
            genomes.append(path)
            gname = path.split('/')[-1].replace('.fasta', '')
            g2index[gname] = i
            
    n = len(genomes)
    if n == 0: continue
    if n == 1:
        with open(os.path.join(out_dir, f"pri_cluster_{global_pri_id}.list"), 'w') as f_out:
            f_out.write(genomes[0] + "\n")
        global_pri_id += 1
        continue
    distance_array = [1.0] * comb2(n)
    result_file = os.path.join(mash_dir, f"{order}.result")
    
    with open(result_file, 'r') as f:
        for line in f:
            parts = line.strip().split("\t")
            g1 = parts[0].split("/")[-1].replace(".fasta", "")
            g2 = parts[1].split("/")[-1].replace(".fasta", "")
            dist = float(parts[2])
            
            i, j = g2index[g1], g2index[g2]
            if i >= j: continue 
            
            idx = comb2(n) - comb2(n-i) + (j-i-1)
            distance_array[idx] = dist
    z = fastcluster.linkage(distance_array, method='average', preserve_input=True)
    cutree = cut_tree(z, height=cutoff)
    
    cluster2genomes = {}
    for idx in range(n):
        c_id = cutree[idx][0]
        cluster2genomes.setdefault(c_id, []).append(genomes[idx])
    for c_id, g_list in cluster2genomes.items():
        with open(os.path.join(out_dir, f"pri_cluster_{global_pri_id}.list"), 'w') as f_out:
            for g_path in g_list:
                f_out.write(g_path + "\n")
        global_pri_id += 1
        
