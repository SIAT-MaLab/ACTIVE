import pandas as pd
import os
import math
import pickle
gtdb_file = "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/host/phylo_new_202605/first_gtdbtk/all_gtdbtk_phylo_first.tsv"
checkm2_file = "allcheckm2.tsv"
genome_dir = "/home/huangyan/experiment/SPA/3/gut_isolate/allgenome"
out_list_dir = "01.Order_lists"

os.makedirs(out_list_dir, exist_ok=True)
df_checkm2 = pd.read_csv(checkm2_file, sep='\t')
score_dict = {}
for _, row in df_checkm2.iterrows():
    genome_name = str(row['Name'])
    comp = float(row['Completeness'])
    cont = float(row['Contamination'])
    n50 = float(row['Contig_N50'])
    s_score = comp - 5 * cont + 0.5 * math.log10(max(1, n50))
    score_dict[genome_name] = s_score
df_gtdb = pd.read_csv(gtdb_file, sep='\t')
valid_genomes_count = 0
order_dict = {}

for _, row in df_gtdb.iterrows():
    genome_name = str(row['user_genome'])
    fasta_path = os.path.join(genome_dir, f"{genome_name}.fasta")
        if not os.path.exists(fasta_path):
        continue
    if genome_name not in score_dict:
        score_dict[genome_name] = 0.0
        
    valid_genomes_count += 1
    taxonomy = str(row['classification'])
    try:
        order_name = taxonomy.split(';')[3].replace('o__', '')
        if not order_name: order_name = "Unclassified"
    except IndexError:
        order_name = "Unclassified"
        
    order_dict.setdefault(order_name, []).append(genome_name)

with open("genome_s_scores.pkl", "wb") as f:
    pickle.dump(score_dict, f)
for order_name, genomes in order_dict.items():
    list_path = os.path.join(out_list_dir, f"{order_name}.list")
    with open(list_path, "w") as f:
        for g in genomes:
            f.write(os.path.join(genome_dir, f"{g}.fasta\n"))
