export GTDBTK_DATA_PATH=/home/huangyan/anaconda3/envs/binning/share/gtdbtk-2.4.0/db/release220/
#gtdbtk identify --genome_dir "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/host/phylo_new_202605/species_cluster/species_rep_genome/" --out_dir 07_species_tree/gtdb_identify --cpus 20 -x fasta
#gtdbtk align --identify_dir 07_species_tree/gtdb_identify --out_dir  07_species_tree/gtdb_output --cpus 20 --skip_gtdb_refs
gunzip -kd 07_species_tree/gtdb_output/align/gtdbtk.bac120.user_msa.fasta.gz
fasttree -wag 07_species_tree/gtdb_output/align/gtdbtk.bac120.user_msa.fasta > fasttree_species.tree

