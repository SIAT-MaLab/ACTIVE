#!/usr/bin/env python3
import sys
import re

def load_hq_phage_ids(metadata_file):
    hq_ids = set()
    with open(metadata_file, 'r') as f:
        header = f.readline().strip().split('\t')
        try:
            phage_id_idx = header.index('phage_id')
        except ValueError:
            print("Error: 'phage_id' column not found in metadata!", file=sys.stderr)
            sys.exit(1)
            
        for line in f:
            cols = line.strip().split('\t')
            if len(cols) > phage_id_idx:
                hq_ids.add(cols[phage_id_idx].strip())
    return hq_ids

def parse_protein_header(header):
    header_clean = header.strip().lstrip('>').split()[0]
    prefix_coords = re.sub(r'_CDS_\d+$', '', header_clean)
    parts = prefix_coords.rsplit('_', 2)
    if len(parts) == 3:
        reconstructed_phage_id = f"{parts[0]}_{parts[1]}-{parts[2]}"
        return reconstructed_phage_id
    return None

def extract_proteins(faa_file, hq_ids, out_file):
    matched_count = 0
    total_count = 0
    write_seq = False
    
    with open(faa_file, 'r') as infile, open(out_file, 'w') as outfile:
        for line in infile:
            if line.startswith('>'):
                total_count += 1
                header = line.strip()
                phage_id = parse_protein_header(header)
                
                if phage_id and phage_id in hq_ids:
                    write_seq = True
                    matched_count += 1
                    outfile.write(line)
                else:
                    write_seq = False
            else:
                if write_seq:
                    outfile.write(line)
                    
    print(f"Extraction Summary:")
    print(f"  - Total proteins in database: {total_count}")
    print(f"  - Extracted HQ proteins: {matched_count}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python3 extract_hq_proteins.py <hq_metadata.tsv> <allpp_proteins.faa> <out_hq_proteins.faa>")
        sys.exit(1)
    
    meta_path = sys.argv[1]
    faa_path = sys.argv[2]
    out_path = sys.argv[3]
    
    print(f"Loading HQ Phage IDs from {meta_path}...")
    hq_phages = load_hq_phage_ids(meta_path)
    print(f"Found {len(hq_phages)} high-quality Caudoviricetes prophages in metadata.")
    
    print(f"Filtering proteins from {faa_path}...")
    extract_proteins(faa_path, hq_phages, out_path)
    print("Done!")
