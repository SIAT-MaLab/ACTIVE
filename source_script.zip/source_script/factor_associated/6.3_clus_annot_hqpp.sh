#!/bin/bash
set -e

METADATA_FILE="../metadata/hqphage_metadata.tsv"
ALL_PROTEINS="/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_proteins.faa"
HQ_PROTEINS="6_genetic_factor/hqpp_proteins.faa"

MMSEQS_OUT="mmseqs_out"
TMP_DIR="tmp_dir"
PC_MAP_OUT="allpp_PC_map.tsv"
CERBERUS_OUT="mmseqs_repseq_annot"


echo "=== Step 2: Running MMseqs2 Clustering ==="
mkdir -p $TMP_DIR
mmseqs easy-cluster $HQ_PROTEINS $MMSEQS_OUT $TMP_DIR \
    --min-seq-id 0.3 \
    -c 0.7 \
    --cov-mode 0 \
    --threads 24

echo "=== Step 3: Generating Protein Cluster (PC) Mapping Table ==="
cut -f1 ${MMSEQS_OUT}_cluster.tsv | sort | uniq | \
    awk '{printf("%s\tPC_%05d\n", $0, NR)}' > temp_rep_to_id.tsv

awk 'NR==FNR{map[$1]=$2; next} {print $2"\t"map[$1]"\t"$1}' \
    temp_rep_to_id.tsv ${MMSEQS_OUT}_cluster.tsv > $PC_MAP_OUT

sed -i '1i protein_id\tpc_id\trep_seq_id' $PC_MAP_OUT
rm temp_rep_to_id.tsv
echo "Saved PC Map to $PC_MAP_OUT"

echo "=== Step 4: Running MetaCerberus Annotation on Rep Seqs ==="

if [ -f "${MMSEQS_OUT}_rep_seq.fasta" ]; then
    REP_SEQ_FILE="${MMSEQS_OUT}_rep_seq.fasta"
elif [ -f "${MMSEQS_OUT}_rep_seq.faa" ]; then
    REP_SEQ_FILE="${MMSEQS_OUT}_rep_seq.faa"
else
    echo "Error: Representative sequence file from MMseqs2 not found!"
    exit 1
fi

echo "Using representative sequences: $REP_SEQ_FILE"

metacerberus.py \
    --protein $REP_SEQ_FILE \
    --hmm COG PFAM PHROG \
    --dir_out $CERBERUS_OUT \
    --cpus 28 \
    --replace

echo "=== Pipeline Finished Successfully ==="
