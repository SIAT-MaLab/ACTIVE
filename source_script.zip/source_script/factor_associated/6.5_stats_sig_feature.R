#!/usr/bin/env Rscript
library(tidyverse)
library(data.table)
library(lme4)
library(lmerTest)

META_FILE    <- "../metadata/hqphage_metadata.tsv"
PC_MAP_FILE  <- "6_genetic_factor/allpp_PC_map.tsv"
ANNOT_FILE   <- "6_genetic_factor/mmseqs_repseq_annot/final/annotations-Protein_mmseqs_out_rep_seq/final_annotation_summary.tsv"
OUT_DIR      <- "6_genetic_factor"
OUT_PREFIX   <- file.path(OUT_DIR, "Final_Analysis_BestHit_")

dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

meta    <- fread(META_FILE)
pc_map  <- fread(PC_MAP_FILE)
annot   <- fread(ANNOT_FILE)

get_mode <- function(x) {
  ux <- unique(na.omit(x))
  if (length(ux) == 0) return("Unknown")
  ux[which.max(tabulate(match(x, ux)))]
}

meta_clean <- meta %>%
  filter(grepl("Caudoviricetes", ictv_Class)) %>%
  mutate(
    is_active     = if_else(!is.na(Activity_Score) & Activity_Score >= 0.8, 1, 0),
    phage_id_norm = gsub("-", "_", phage_id)
  )

otu_stats <- meta_clean %>%
  group_by(vOTU) %>%
  summarise(
    total_genomes  = n(),
    active_count   = sum(is_active),
    inactive_count = n() - sum(is_active),
    activity_rate  = sum(is_active) / n(),
    host_phylum    = get_mode(host_Phylum),
    host_class     = get_mode(host_Class),
    vFAM           = get_mode(vFAM),
    vGENUS         = get_mode(vGENUS),
    location_type  = get_mode(Phage_Location_Type),
    .groups        = "drop"
  ) %>%
  filter(total_genomes >= 5)

target_taxa_col <- "host_phylum"
top_taxa <- names(sort(table(otu_stats[[target_taxa_col]]), decreasing = TRUE))[1:15]

otu_stats <- otu_stats %>%
  mutate(host_taxa_reg = if_else(.data[[target_taxa_col]] %in% top_taxa,
                                 .data[[target_taxa_col]], "Other")) %>%
  mutate(across(c(host_taxa_reg, location_type, vFAM, vGENUS), as.factor))

RANDOM_EFF <- "vFAM"

besthit_dict <- annot %>%
  filter(best_hit != "") %>%
  group_by(best_hit) %>% slice(1) %>% ungroup() %>%
  select(Feature = best_hit, Product = product)

pc_map_linked <- pc_map %>%
  mutate(
    phage_id_raw  = str_remove(protein_id, "_CDS_[0-9]+$"),
    phage_id_norm = gsub("-", "_", phage_id_raw)
  ) %>%
  inner_join(meta_clean %>% select(phage_id_norm, vOTU), by = "phage_id_norm")

get_prev_matrix <- function(link_df, otu_df) {
  link_df %>%
    distinct(vOTU, Feature, phage_id_norm) %>%
    count(vOTU, Feature, name = "hits") %>%
    inner_join(otu_df %>% select(vOTU, total_genomes), by = "vOTU") %>%
    mutate(prev = hits / total_genomes) %>%
    mutate(prev = if_else(prev > 1, 1, prev)) %>%
    group_by(Feature) %>%
    filter(sum(prev >= 0.4) >= 5) %>%
    ungroup() %>%
    select(vOTU, Feature, prev) %>%
    pivot_wider(names_from = Feature, values_from = prev, values_fill = 0)
}

link_annot <- pc_map_linked %>%
  inner_join(annot, by = c("rep_seq_id" = "target")) %>%
  filter(best_hit != "" & !grepl("hypothetical", product, ignore.case = TRUE)) %>%
  select(vOTU, Feature = best_hit, phage_id_norm)

mat_annot <- get_prev_matrix(link_annot, otu_stats)

run_two_step_analysis <- function(feature_mat, otu_df) {
  df <- otu_df %>% inner_join(feature_mat, by = "vOTU")
  features <- setdiff(names(feature_mat), "vOTU")
  fixed_f <- "host_taxa_reg + location_type + log10(total_genomes)"

  message(paste("Starting analysis for", length(features), "features..."))

  glm_res <- data.frame()
  for (f in features) {
    form <- paste0("cbind(active_count, inactive_count) ~ `", f, "` + ", fixed_f)
    try({
      m <- glm(as.formula(form), data = df, family = quasibinomial)
      coef <- summary(m)$coefficients
      glm_res <- rbind(glm_res, data.frame(
        Feature = f,
        GLM_Est = coef[2, 1],
        GLM_SE  = coef[2, 2],
        GLM_Z   = coef[2, 3],
        GLM_P   = coef[2, 4]
      ))
    }, silent = TRUE)
  }

  if (nrow(glm_res) == 0) return(NULL)

  glm_res$GLM_FDR <- p.adjust(glm_res$GLM_P, method = "BH")
  candidates <- glm_res %>% filter(GLM_FDR <= 0.05) %>% pull(Feature)
  message(paste("GLM screened", length(candidates), "candidates for GLMM..."))

  glmm_res <- data.frame()
  if (length(candidates) > 0) {
    for (f in candidates) {
      form <- paste0("cbind(active_count, inactive_count) ~ `", f, "` + ",
                     fixed_f, " + (1 | ", RANDOM_EFF, ")")
      try({
        m <- glmer(as.formula(form), data = df, family = binomial,
                   control = glmerControl(optimizer = "bobyqa",
                                          optCtrl = list(maxfun = 1e5)))
        coef <- summary(m)$coefficients
        row_idx <- which(grepl(f, rownames(coef), fixed = TRUE))
        if (length(row_idx) == 0) row_idx <- 2
        glmm_res <- rbind(glmm_res, data.frame(
          Feature  = f,
          GLMM_Est = coef[row_idx, 1],
          GLMM_SE  = coef[row_idx, 2],
          GLMM_Z   = coef[row_idx, 3],
          GLMM_P   = coef[row_idx, 4],
          Singular = isSingular(m)
        ))
      }, silent = TRUE)
    }
  }

  if (nrow(glmm_res) > 0) {
    glmm_res$GLMM_FDR <- p.adjust(glmm_res$GLMM_P, method = "BH")
    final_res <- glm_res %>% left_join(glmm_res, by = "Feature")
  } else {
    final_res <- glm_res %>%
      mutate(GLMM_Est = NA_real_, GLMM_SE = NA_real_, GLMM_Z = NA_real_,
             GLMM_P = NA_real_, GLMM_FDR = NA_real_, Singular = NA)
  }

  final_res %>% arrange(GLMM_FDR, GLM_FDR)
}

res_annot <- run_two_step_analysis(mat_annot, otu_stats)
if (is.null(res_annot) || nrow(res_annot) == 0) stop("No statistical features processed.")

res_df <- res_annot %>% left_join(besthit_dict, by = "Feature")
write.csv(res_df, paste0(OUT_PREFIX, "Statistical_Results.csv"), row.names = FALSE)
message("==> 已保存 Statistical_Results.csv（含 SE/Z）")

valid_votus <- otu_stats$vOTU

all_sig_features <- res_df %>%
  filter(!is.na(GLMM_FDR) & GLMM_FDR <= 0.05) %>%
  pull(Feature)

if (length(all_sig_features) == 0) {
  message("==> no GLMM_FDR<=0.05 features")
} else {

  votus_per_feature <- link_annot %>%
    filter(Feature %in% all_sig_features) %>%
    group_by(Feature) %>%
    summarise(votu_count = n_distinct(vOTU), .groups = "drop") %>%
    left_join(res_df %>% select(Feature, GLMM_Est, GLMM_SE, GLMM_Z,
                                GLMM_P, GLMM_FDR, Product),
              by = "Feature")

  genomes_per_feature <- link_annot %>%
    filter(Feature %in% all_sig_features) %>%
    group_by(Feature) %>%
    summarise(genome_count = n_distinct(phage_id_norm), .groups = "drop") %>%
    left_join(res_df %>% select(Feature, GLMM_Est, GLMM_SE, GLMM_Z,
                                GLMM_P, GLMM_FDR, Product),
              by = "Feature")

  prev_per_votu_feature <- link_annot %>%
    filter(Feature %in% all_sig_features) %>%
    distinct(Feature, vOTU, phage_id_norm) %>%
    count(Feature, vOTU, name = "hits") %>%
    inner_join(otu_stats %>% select(vOTU, total_genomes), by = "vOTU") %>%
    mutate(prev = hits / total_genomes) %>%
    mutate(prev = if_else(prev > 1, 1, prev)) %>%
    left_join(res_df %>% select(Feature, GLMM_Est, GLMM_SE, GLMM_Z,
                                GLMM_P, GLMM_FDR, Product),
              by = "Feature")

  write.csv(votus_per_feature,
            paste0(OUT_PREFIX, "SigFeat_vOTU_Count.csv"), row.names = FALSE)
  write.csv(genomes_per_feature,
            paste0(OUT_PREFIX, "SigFeat_Genome_Count.csv"), row.names = FALSE)
  write.csv(prev_per_votu_feature,
            paste0(OUT_PREFIX, "SigFeat_Intra_vOTU_Prevalence.csv"), row.names = FALSE)


  feat_map <- pc_map %>%
    mutate(
      phage_id_raw  = str_remove(protein_id, "_CDS_[0-9]+$"),
      phage_id_norm = gsub("-", "_", phage_id_raw)
    ) %>%
    inner_join(meta_clean %>% select(phage_id_norm, vOTU), by = "phage_id_norm") %>%
    filter(vOTU %in% valid_votus) %>%
    inner_join(annot, by = c("rep_seq_id" = "target")) %>%
    filter(best_hit %in% all_sig_features) %>%
    distinct(vOTU, Feature = best_hit)

  detail_raw_list <- list()
  for (f in all_sig_features) {
    curr_prod <- res_df %>% filter(Feature == f) %>% pull(Product) %>% .[[1]]
    votus_with <- feat_map %>% filter(Feature == f) %>% pull(vOTU)
    detail_raw_list[[f]] <- otu_stats %>%
      mutate(
        Feature = f,
        Product = curr_prod,
        Group   = if_else(vOTU %in% votus_with, "With", "Without")
      ) %>%
      select(Feature, Product, vOTU, Group, activity_rate, total_genomes, active_count)
  }

  all_details <- bind_rows(detail_raw_list) %>%
    arrange(factor(Feature, levels = all_sig_features),
            desc(Group), desc(activity_rate))

  write.csv(all_details,
            paste0(OUT_PREFIX, "Detail_Statistics.csv"),
            row.names = FALSE)


  context_summary <- res_df %>%
    filter(Feature %in% all_sig_features) %>%
    select(Feature, Product, GLMM_Est, GLMM_SE, GLMM_Z,
           GLMM_P, GLMM_FDR) %>%
    mutate(Effect_Type = ifelse(GLMM_Est > 0, "Pro-Active", "Anti-Active")) %>%
    left_join(votus_per_feature %>% select(Feature, votu_count), by = "Feature") %>%
    left_join(genomes_per_feature %>% select(Feature, genome_count), by = "Feature") %>%
    arrange(GLMM_FDR)

  write.csv(context_summary,
            paste0(OUT_PREFIX, "Prevalence_Context_Summary.csv"),
            row.names = FALSE)
  }

