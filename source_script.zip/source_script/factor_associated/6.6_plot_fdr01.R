#!/usr/bin/env Rscript
library(tidyverse)
library(data.table)
library(scales)
library(patchwork)

FDR_CUTOFF <- 0.01
OUT_DIR    <- "6_genetic_factor"
IN_PREFIX  <- file.path(OUT_DIR, "Final_Analysis_BestHit_")
OUT_PREFIX <- file.path(OUT_DIR, "Final_Analysis_BestHit_FDR01_")

STAT_FILE    <- paste0(IN_PREFIX, "Statistical_Results.csv")
DETAIL_FILE  <- paste0(IN_PREFIX, "Detail_Statistics.csv")
VOTU_FILE    <- paste0(IN_PREFIX, "SigFeat_vOTU_Count.csv")
GENOME_FILE  <- paste0(IN_PREFIX, "SigFeat_Genome_Count.csv")
PREV_FILE    <- paste0(IN_PREFIX, "SigFeat_Intra_vOTU_Prevalence.csv")

need <- c(STAT_FILE, DETAIL_FILE, VOTU_FILE, GENOME_FILE, PREV_FILE)
miss <- need[!file.exists(need)]


col_pro  <- "#e41a1c"
col_anti <- "#377eb8"
col_wo   <- "grey60"
fill_dir <- c("Pro-Active" = col_pro, "Anti-Active" = col_anti)


res_df <- fread(STAT_FILE)

sig <- res_df %>%
  filter(!is.na(GLMM_FDR), GLMM_FDR <= FDR_CUTOFF, !is.na(GLMM_Est)) %>%
  mutate(
    Effect_Type   = if_else(GLMM_Est > 0, "Pro-Active", "Anti-Active"),
    Product       = if_else(is.na(Product) | Product == "", Feature, as.character(Product)),
    Clean_Product = str_trunc(Product, 48, "right"),
    Label         = paste0(Clean_Product, " (", Feature, ")"),
    FDR_lab       = if_else(GLMM_FDR < 0.001, "<0.001",
                            sprintf("%.3f", GLMM_FDR))
  ) %>%
  arrange(GLMM_Est) %>%
  mutate(Label = factor(Label, levels = Label))

n_feat <- nrow(sig)

n_pro  <- sum(sig$Effect_Type == "Pro-Active")
n_anti <- sum(sig$Effect_Type == "Anti-Active")
message("==> FDR≤", FDR_CUTOFF, " 特征 ", n_feat,
        " 个（Pro-Active ", n_pro, " / Anti-Active ", n_anti, "）")

sig_ids <- sig$Feature
label_map <- sig %>% select(Feature, Label, Effect_Type)

details <- fread(DETAIL_FILE) %>% filter(Feature %in% sig_ids)

plot_df_wide <- details %>%
  group_by(Feature, Group) %>%
  summarise(
    mean_rate = sum(active_count) / sum(total_genomes),
    n         = n(),
    .groups   = "drop"
  ) %>%
  pivot_wider(names_from = Group, values_from = c(mean_rate, n)) %>%
  left_join(label_map, by = "Feature") %>%
  left_join(sig %>% select(Feature, GLMM_Est, GLMM_SE, GLMM_FDR), by = "Feature") %>%
  mutate(Label = factor(Label, levels = levels(sig$Label)))

votu_df <- fread(VOTU_FILE) %>%
  filter(Feature %in% sig_ids) %>%
  left_join(label_map, by = "Feature") %>%
  mutate(Label = factor(Label, levels = levels(sig$Label)))

genome_df <- fread(GENOME_FILE) %>%
  filter(Feature %in% sig_ids) %>%
  left_join(label_map, by = "Feature") %>%
  mutate(Label = factor(Label, levels = levels(sig$Label)))

prev_df <- fread(PREV_FILE) %>%
  filter(Feature %in% sig_ids) %>%
  left_join(label_map, by = "Feature") %>%
  mutate(Label = factor(Label, levels = levels(sig$Label)))

plot_export <- sig %>%
  select(Feature, Product, Label, Effect_Type,
         GLMM_Est, GLMM_SE, GLMM_Z, GLMM_P, GLMM_FDR) %>%
  left_join(plot_df_wide %>% select(Feature, mean_rate_With, mean_rate_Without,
                                   n_With, n_Without), by = "Feature") %>%
  left_join(votu_df %>% select(Feature, votu_count), by = "Feature") %>%
  left_join(genome_df %>% select(Feature, genome_count), by = "Feature")

write.csv(plot_export, paste0(OUT_PREFIX, "PlotData.csv"), row.names = FALSE)

base_sz <- if (n_feat > 28) 9 else if (n_feat > 18) 11 else 13
fig_h   <- max(7, min(24, 1.8 + n_feat * 0.42))
fig_w1  <- 16
fig_w2  <- 17

theme_row <- function(show_y = TRUE) {
  theme_minimal(base_size = base_sz) +
    theme(
      axis.title.y       = element_blank(),
      axis.text.y        = if (show_y) element_text() else element_blank(),
      panel.grid.major.y = element_blank(),
      panel.grid.minor   = element_blank(),
      legend.position    = "bottom",
      plot.title         = element_text(face = "bold", size = base_sz + 1),
      plot.subtitle      = element_text(color = "grey30", size = base_sz - 1)
    )
}


x_forest_min <- min(sig$GLMM_Est - sig$GLMM_SE, na.rm = TRUE)
x_forest_max <- max(sig$GLMM_Est + sig$GLMM_SE, na.rm = TRUE)
x_pad <- diff(c(x_forest_min, x_forest_max)) * 0.08
if (!is.finite(x_pad) || x_pad == 0) x_pad <- 0.2

p_left <- ggplot(plot_df_wide, aes(y = Label)) +
  geom_segment(aes(x = mean_rate_Without, xend = mean_rate_With, yend = Label),
               color = "grey80", linewidth = 1.4) +
  geom_point(aes(x = mean_rate_Without), size = 4.5, color = col_wo) +
  geom_point(aes(x = mean_rate_With, color = Effect_Type), size = 6.5) +
  scale_color_manual(values = fill_dir, name = NULL) +
  scale_x_continuous(labels = percent_format(accuracy = 1),
                     name   = "Mean Activity Rate of vOTUs",
                     limits = c(0, NA),
                     expand = expansion(mult = c(0.02, 0.08))) +
  labs(title    = "Observed Activity",
       subtitle = "Grey: Without feature  |  Colored: With feature") +
  theme_row(show_y = TRUE) +
  theme(plot.margin = margin(r = 12))

p_right <- ggplot(sig, aes(y = Label, x = GLMM_Est, color = Effect_Type)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey50") +
  geom_errorbarh(aes(xmin = GLMM_Est - GLMM_SE, xmax = GLMM_Est + GLMM_SE),
                 height = 0.22, linewidth = 0.6) +
  geom_point(size = 5) +
  scale_color_manual(values = fill_dir, name = NULL) +
  scale_x_continuous(name   = "GLMM Estimate (Log-Odds)",
                     limits = c(x_forest_min - x_pad, x_forest_max + x_pad)) +
  labs(title    = "Model Effect Size",
       subtitle = "Positive = Pro-Active  |  Negative = Anti-Active  |  Bars = ± SE") +
  theme_row(show_y = FALSE) +
  theme(plot.margin = margin(l = 4))

fig1 <- p_left + p_right +
  plot_layout(widths = c(1.35, 1), guides = "collect") &
  theme(legend.position = "bottom")

ggsave(paste0(OUT_PREFIX, "ForestDumbbell.pdf"),
       fig1, width = fig_w1, height = fig_h)

p_votu <- ggplot(votu_df, aes(y = Label, x = votu_count, fill = Effect_Type)) +
  geom_col(width = 0.62, color = NA) +
  geom_text(aes(label = votu_count), hjust = -0.15, size = max(2.6, base_sz * 0.32)) +
  scale_fill_manual(values = fill_dir, name = NULL) +
  scale_x_continuous(expand = expansion(mult = c(0, 0.18))) +
  labs(title = "vOTU Prevalence",
       x     = "Number of vOTUs encoding feature") +
  theme_row(show_y = TRUE)

p_genome <- ggplot(genome_df, aes(y = Label, x = genome_count, fill = Effect_Type)) +
  geom_col(width = 0.62, color = NA) +
  geom_text(aes(label = genome_count), hjust = -0.15, size = max(2.6, base_sz * 0.32)) +
  scale_fill_manual(values = fill_dir, name = NULL) +
  scale_x_continuous(expand = expansion(mult = c(0, 0.18))) +
  labs(title = "Genome Prevalence",
       x     = "Total genomes encoding feature") +
  theme_row(show_y = FALSE)

p_prev <- ggplot(prev_df, aes(y = Label, x = prev, fill = Effect_Type, color = Effect_Type)) +
  geom_boxplot(outlier.shape = NA, width = 0.55, alpha = 0.18, color = "grey35") +
  geom_jitter(height = 0.12, alpha = 0.55, size = 1.6, width = 0.02) +
  scale_fill_manual(values = fill_dir, name = NULL) +
  scale_color_manual(values = fill_dir, name = NULL) +
  scale_x_continuous(labels = percent_format(accuracy = 1), limits = c(0, 1.05)) +
  labs(title = "Intra-vOTU Distribution",
       x     = "Feature prevalence within each vOTU") +
  theme_row(show_y = FALSE)

fig2 <- p_votu + p_genome + p_prev +
  plot_layout(widths = c(1.45, 1, 1.1), guides = "collect") &
  theme(legend.position = "bottom")

ggsave(paste0(OUT_PREFIX, "Prevalence_Context.pdf"),
       fig2, width = fig_w2, height = fig_h)
