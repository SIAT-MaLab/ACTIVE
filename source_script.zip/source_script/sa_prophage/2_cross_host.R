#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(tidygraph)
  library(ggraph)
  library(scales)
  library(ggsci)
  library(igraph)
})

options(stringsAsFactors = FALSE)

METADATA_PATH <- "../metadata/allpp_metadata.tsv"
STATS_PATH    <- "1_sataxon/Detailed_Cross_Host_vOTUs.csv"

PHYLUM_COLORS <- c(
  "Bacillota_A"       = "#dce8ef",
  "Bacillota_C"       = "#add2e5",
  "Bacillota_I"       = "#34666b",
  "Bacillota"         = "#7abbce",
  "Bacillota_B"       = "#769499",
  "Actinomycetota"    = "#f5cfa6",
  "Bacteroidota"      = "#efe3ef",
  "Verrucomicrobiota" = "#d4d68a",
  "Pseudomonadota"    = "#e68f9f",
  "Desulfobacterota"  = "#d5d5d6",
  "Fusobacteriota"    = "#b7a3c9",
  "Synergistota"      = "#414141"
)

CROSS_HOST_COLORS <- c(
  "Non-crossing"  = "grey80",
  "Cross-Species" = "#C0EBFF",
  "Cross-Genus"   = "#709DC5",
  "Cross-Family"  = "#E77C8E",
  "Cross-Order"   = "#D62828",
  "Cross-Class"   = "#9D0208",
  "Cross-Phylum"  = "#510014"
)

BORDER_VIRUS_SIG    <- "#861A0E"
BORDER_VIRUS_NONSIG <- "grey80"
BORDER_HOST         <- "black"
NODE_STROKE_WIDTH_SIG <- 0.8
NODE_STROKE_WIDTH_REG <- 0.4


if(!file.exists(METADATA_PATH)) stop("Error: Metadata file not found: ", METADATA_PATH)
if(!file.exists(STATS_PATH))    stop("Error: Statistical test file not found: ", STATS_PATH)

full_meta <- read_tsv(METADATA_PATH, show_col_types = FALSE) %>%
  rename(
    Phylum  = host_Phylum,
    Class   = host_Class,
    Order   = host_Order,
    Family  = host_Family,
    Genus   = host_Genus,
    Species = host_Species
  ) %>%
  mutate(Activity_Score = as.numeric(as.character(Activity_Score)))

stats_exact <- read_csv(STATS_PATH, show_col_types = FALSE)

active_votu_list <- full_meta %>%
  filter(Activity_Score >= 0.8) %>%
  filter(!is.na(vOTU) & vOTU != "") %>%
  pull(vOTU) %>%
  unique()

votu_cross_full <- full_meta %>%
  filter(vOTU %in% active_votu_list) %>%
  group_by(vOTU) %>%
  summarise(
    n_phylum  = n_distinct(Phylum, na.rm = TRUE),
    n_class   = n_distinct(Class, na.rm = TRUE),
    n_order   = n_distinct(Order, na.rm = TRUE),
    n_family  = n_distinct(Family, na.rm = TRUE),
    n_genus   = n_distinct(Genus, na.rm = TRUE),
    n_species = n_distinct(Species, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  mutate(
    Cross_Category = case_when(
      n_phylum > 1  ~ "Cross-Phylum",
      n_class > 1   ~ "Cross-Class",
      n_order > 1   ~ "Cross-Order",
      n_family > 1  ~ "Cross-Family",
      n_genus > 1   ~ "Cross-Genus",
      n_species > 1 ~ "Cross-Species",
      TRUE          ~ "Non-crossing"
    )
  )

votu_sig_map <- stats_exact %>%
  select(vOTU, Significance_Type, Max_Activity) %>%
  distinct() %>%
  mutate(Is_Significant = (Significance_Type == "Significant"))

active_votu_info <- tibble(vOTU = active_votu_list) %>%
  left_join(votu_cross_full, by = "vOTU") %>%
  left_join(votu_sig_map, by = "vOTU") %>%
  mutate(
    Cross_Category = replace_na(Cross_Category, "Non-crossing"),
    Is_Significant = replace_na(Is_Significant, FALSE),
    Max_Activity   = replace_na(Max_Activity, 0)
  )

edges_active <- full_meta %>%
  filter(vOTU %in% active_votu_list) %>%
  filter(!is.na(Family) & Family != "None" & Family != "") %>%
  select(vOTU, Host = Family) %>%
  distinct()

host_colors_map <- full_meta %>%
  filter(!is.na(Family) & Family != "None" & Family != "") %>%
  select(Family, Phylum) %>%
  distinct(Family, .keep_all = TRUE)

graph_active <- as_tbl_graph(edges_active, directed = FALSE) %>%
  activate(nodes) %>%
  mutate(
    node_type = ifelse(name %in% active_votu_list, "Virus", "Host"),
    degree = centrality_degree()
  ) %>%
  left_join(host_colors_map, by = c("name" = "Family")) %>%
  left_join(active_votu_info, by = c("name" = "vOTU")) %>%
  mutate(
    color_group = case_when(
      node_type == "Host" ~ Phylum,
      node_type == "Virus" ~ as.character(Cross_Category)
    ),
    border_group = case_when(
      node_type == "Host" ~ "Host",
      node_type == "Virus" & Is_Significant == TRUE ~ "Virus_Sig",
      TRUE ~ "Virus_NonSig"
    ),
    stroke_width = ifelse(border_group == "Virus_Sig", NODE_STROKE_WIDTH_SIG, NODE_STROKE_WIDTH_REG)
  ) %>%
  mutate(
    host_rank = ifelse(node_type == "Host", rank(-degree, ties.method = "first", na.last = "keep"), NA),
    virus_rank = ifelse(node_type == "Virus" & Is_Significant == TRUE, rank(-Max_Activity, ties.method = "first", na.last = "keep"), NA),
    show_label = case_when(
      node_type == "Host" & host_rank <= 10 ~ TRUE,
      node_type == "Virus" & virus_rank <= 10 ~ TRUE,
      TRUE ~ FALSE
    ),
    node_label = ifelse(show_label, name, "")
  )

fill_palette_active <- c(PHYLUM_COLORS, CROSS_HOST_COLORS)
border_palette <- c("Host" = BORDER_HOST, "Virus_Sig" = BORDER_VIRUS_SIG, "Virus_NonSig" = BORDER_VIRUS_NONSIG)

p_active_net <- ggraph(graph_active, layout = 'stress') +
  geom_edge_link(color = "grey40", width = 0.4, alpha = 0.4) +
  geom_node_point(
    data = function(x) filter(x, node_type == "Host"),
    aes(fill = color_group, size = degree, shape = node_type, color = border_group, stroke = stroke_width)
  ) +
  geom_node_point(
    data = function(x) filter(x, node_type == "Virus"),
    aes(fill = color_group, shape = node_type, color = border_group, stroke = stroke_width),
    size = 2.5
  ) +
  geom_node_text(aes(label = node_label), repel = TRUE, size = 3.5, color = "black", fontface = "bold",
                 min.segment.length = 0, segment.color = "grey40", segment.size = 0.4, max.overlaps = Inf) +
  scale_shape_manual(name = "Node Type", values = c("Host" = 22, "Virus" = 21)) +
  scale_size_continuous(range = c(3, 15), name = "Host Degree") +
  scale_fill_manual(values = fill_palette_active, name = "Phylum / True Cross-Category") +
  scale_color_manual(values = border_palette, name = "Significance (Border)") +
  scale_discrete_identity(aesthetics = "stroke") +
  theme_graph(base_family = "sans") +
  labs(
    title = "True Potential Network of Active vOTUs (Host = Family)",
    subtitle = "Edges: Full host range. Viruses: Red border = SAvOTU. Labels: Top 10 Host Families & Top 10 SAvOTUs."
  ) +
  theme(
    legend.position = "right",
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 10),
    plot.title = element_text(size = 15, face = "bold")
  ) +
  guides(
    fill = guide_legend(override.aes = list(size = 5, shape = 21, color = "black", stroke = 0.2)),
    shape = guide_legend(override.aes = list(size = 5, fill = "grey50", color = "black")),
    color = guide_legend(override.aes = list(size = 5, shape = 21, fill = "white", stroke = 1.5))
  )

ggsave("Step2_Active_vOTU_Network_Exact_Family_Level.pdf", p_active_net, width = 18, height = 14, bg = "white", device = cairo_pdf)

votu_broad_status <- full_meta %>%
  filter(!is.na(vOTU), !is.na(Species), Species != "None") %>%
  group_by(vOTU) %>%
  summarise(total_species_count = n_distinct(Species), .groups = 'drop') %>%
  mutate(is_broad = ifelse(total_species_count >= 10, "Broad", "Narrow"))

host_taxonomy <- full_meta %>%
  select(Species, Family, Phylum) %>%
  distinct(Species, .keep_all = TRUE)

shared_votus_species <- full_meta %>%
  filter(!is.na(Species), Species != "None") %>%
  group_by(vOTU) %>%
  summarise(n_targets = n_distinct(Species), .groups = 'drop') %>%
  filter(n_targets > 1) %>% 
  pull(vOTU)

if(length(shared_votus_species) > 0) {
  edges_species <- full_meta %>%
    filter(vOTU %in% shared_votus_species) %>%
    select(vOTU, Species) %>%
    distinct()

  graph_species <- as_tbl_graph(edges_species, directed = FALSE) %>%
    activate(nodes) %>%
    left_join(votu_broad_status, by = c("name" = "vOTU")) %>%
    left_join(host_taxonomy, by = c("name" = "Species")) %>%
    mutate(
      degree = centrality_degree(),
      node_class = case_when(
        !is.na(total_species_count) & is_broad == "Broad"  ~ "Virus_Broad",
        !is.na(total_species_count) & is_broad == "Narrow" ~ "Virus_Shared",
        TRUE                                               ~ "Host"
      ),
      color_group = ifelse(node_class == "Host", Phylum, node_class),
      show_label = case_when(
        node_class == "Virus_Broad" ~ TRUE,
        node_class == "Host" & rank(-degree) <= 20 ~ TRUE,
        TRUE ~ FALSE
      )
    )

  all_groups_species <- graph_species %>% as_tibble() %>% pull(color_group) %>% unique()
  host_groups_species <- setdiff(all_groups_species, c("Virus_Broad", "Virus_Shared", "Other_Hosts"))
  
  host_colors_species <- ifelse(host_groups_species %in% names(PHYLUM_COLORS),
                                PHYLUM_COLORS[host_groups_species],
                                "#e0e0e0")
  names(host_colors_species) <- host_groups_species
  
  species_palette <- c(
    host_colors_species,
    "Virus_Broad"  = "black",
    "Virus_Shared" = "grey60",
    "Other_Hosts"  = "grey85"
  )

  p_species_net <- ggraph(graph_species, layout = 'stress') +
    geom_edge_link(color = "grey40", width = 0.6, alpha = 0.4) +
    geom_node_point(aes(shape = node_class, color = color_group, size = node_class)) +
    geom_node_text(aes(label = ifelse(show_label, name, "")),
                   repel = TRUE, size = 3, family = "sans", fontface = "italic", max.overlaps = 50) +
    scale_shape_manual(values = c("Host" = 15, "Virus_Broad" = 16, "Virus_Shared" = 16)) +
    scale_size_manual(values = c("Host" = 3, "Virus_Broad" = 3, "Virus_Shared" = 1.5)) +
    scale_color_manual(values = species_palette, name = "Classification") +
    theme_graph(base_family = "sans") +
    labs(title = "Species Network - Color by Phylum (Custom Palette)",
         subtitle = "Visualizing species-level sharing. Black = Broad Host Range, Grey = Shared.")

  ggsave("Step3_Shared_vOTU_Network_Species_CustomPhylum.pdf", p_species_net, width = 14, height = 12, bg = "white", device = cairo_pdf)
}

df_family_clean <- full_meta %>%
  filter(!is.na(vOTU) & vOTU != "") %>%
  filter(!is.na(Family) & Family != "" & Family != "None") %>%
  select(vOTU, Family, Phylum) %>%
  distinct()

votu_counts_family <- df_family_clean %>%
  count(vOTU) %>%
  filter(n > 1)

cross_family_df <- df_family_clean %>%
  filter(vOTU %in% votu_counts_family$vOTU)

host_phage_mat_fam <- table(cross_family_df$Family, cross_family_df$vOTU)
host_co_mat_fam <- as.matrix(host_phage_mat_fam %*% t(host_phage_mat_fam))
diag(host_co_mat_fam) <- 0 

edge_list_fam <- as.data.frame(as.table(host_co_mat_fam)) %>%
  filter(Freq > 0) %>%
  rename(From = Var1, To = Var2, Weight = Freq) %>%
  filter(as.character(From) < as.character(To)) %>%
  mutate(From = as.character(From), To = as.character(To))

node_info_fam <- df_family_clean %>%
  select(Family, Phylum) %>%
  distinct(Family, .keep_all = TRUE) %>%
  mutate(Family = as.character(Family))

graph_fam <- as_tbl_graph(edge_list_fam, directed = FALSE) %>%
  activate(nodes) %>%
  left_join(node_info_fam, by = c("name" = "Family")) %>%
  mutate(degree = centrality_degree(weights = Weight)) %>%
  filter(!node_is_isolated())

pdf("Step4_Host_Family_Connectivity_Network.pdf", width = 12, height = 10)
set.seed(123)
p_fam <- ggraph(graph_fam, layout = "graphopt", charge = 0.05, spring.length = 100) +
  geom_edge_link(aes(width = Weight, alpha = Weight), color = "black") +
  scale_edge_width(range = c(0.5, 5), name = "Shared vOTUs") +
  scale_edge_alpha(range = c(0.2, 0.95), guide = "none") +
  geom_node_point(aes(size = degree, fill = Phylum), shape = 21, color = "black", stroke = 0.5) +
  scale_size(range = c(2, 20), name = "Connectivity (Weighted Degree)") +
  scale_fill_manual(values = PHYLUM_COLORS, name = "Host Phylum") +
  geom_node_text(aes(label = ifelse(degree > quantile(degree, 0.8, na.rm=TRUE), name, "")),
                 repel = TRUE, size = 3.5, fontface = "bold", bg.color = "white", bg.r = 0.15) +
  theme_graph(base_family = "sans") +
  labs(
    title = "Host Family Connectivity Network",
    subtitle = paste0("Nodes: ", length(unique(c(edge_list_fam$From, edge_list_fam$To))),
                      " Families | Edges: ", nrow(edge_list_fam), " Connections"),
    caption = "Edge width correlates with number of shared vOTUs"
  )
print(p_fam)
dev.off()

df_genus_clean <- full_meta %>%
  filter(!is.na(vOTU) & vOTU != "") %>%
  filter(!is.na(Genus) & Genus != "" & Genus != "None") %>%
  select(vOTU, Genus, Phylum) %>%
  distinct()

votu_counts_genus <- df_genus_clean %>%
  count(vOTU) %>%
  filter(n > 1)

cross_genus_df <- df_genus_clean %>%
  filter(vOTU %in% votu_counts_genus$vOTU)

host_phage_mat_gen <- table(cross_genus_df$Genus, cross_genus_df$vOTU)
host_co_mat_gen <- as.matrix(host_phage_mat_gen %*% t(host_phage_mat_gen))
diag(host_co_mat_gen) <- 0

edge_list_gen <- as.data.frame(as.table(host_co_mat_gen)) %>%
  filter(Freq > 0) %>%
  rename(From = Var1, To = Var2, Weight = Freq) %>%
  filter(as.character(From) < as.character(To)) %>%
  mutate(From = as.character(From), To = as.character(To))

node_info_gen <- df_genus_clean %>%
  select(Genus, Phylum) %>%
  distinct(Genus, .keep_all = TRUE) %>%
  mutate(Genus = as.character(Genus))

graph_gen <- as_tbl_graph(edge_list_gen, directed = FALSE) %>%
  activate(nodes) %>%
  left_join(node_info_gen, by = c("name" = "Genus")) %>%
  mutate(degree = centrality_degree(weights = Weight)) %>%
  filter(!node_is_isolated())

pdf("Step5_Host_Genus_Connectivity_Network.pdf", width = 12, height = 10)
set.seed(123)
p_gen <- ggraph(graph_gen, layout = "graphopt", charge = 0.05, spring.length = 100) +
  geom_edge_link(aes(width = Weight, alpha = Weight), color = "black") +
  scale_edge_width(range = c(0.5, 5), name = "Shared vOTUs") +
  scale_edge_alpha(range = c(0.2, 0.95), guide = "none") +
  geom_node_point(aes(size = degree, fill = Phylum), shape = 21, color = "black", stroke = 0.5) +
  scale_size(range = c(2, 20), name = "Connectivity (Weighted Degree)") +
  scale_fill_manual(values = PHYLUM_COLORS, name = "Host Phylum") +
  geom_node_text(aes(label = ifelse(degree > quantile(degree, 0.8, na.rm=TRUE), name, "")),
                 repel = TRUE, size = 3.5, fontface = "bold", bg.color = "white", bg.r = 0.15) +
  theme_graph(base_family = "sans") +
  labs(
    title = "Host Genus Connectivity Network",
    subtitle = paste0("Nodes: ", length(unique(c(edge_list_gen$From, edge_list_gen$To))),
                      " Genera | Edges: ", nrow(edge_list_gen), " Connections"),
    caption = "Edge width correlates with number of shared vOTUs"
  )
print(p_gen)
dev.off()