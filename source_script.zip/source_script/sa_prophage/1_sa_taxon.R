#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(patchwork)
  library(ggrepel)
  library(scales)
  library(parallel)
  library(ggpubr)
})

# ==============================================================================
# 0. Global Configuration
# ==============================================================================
ACTIVE_THRESHOLD <- 0.8
MIN_GENOME_COUNT <- 5
THREADS <- min(20, parallel::detectCores() - 1)
OUT_DIR <- "sa_prophage_results"

dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

PHYLUM_COLORS <- c(
  "Bacillota_A"       = "#dce8ef", 
  "Bacillota_C"       = "#add2e5", 
  "Bacillota_I"       = "#34666b", 
  "Bacillota"         = "#7abbce", 
  "Bacillota_B"       = "#769499", 
  "Actinomycetota"    = "#f5cfa6", 
  "Bacteroidota"      = "#efe3ef", 
  "Verrucomicrobiota" = "#d4d68a", 
  "Pseudomonadota"    = "#e68f9f", 
  "Desulfobacterota"  = "#d5d5d6", 
  "Fusobacteriota"    = "#b7a3c9", 
  "Synergistota"      = "#414141"
)

cross_colors <- c(
  "Non-crossing"  = "grey80",
  "Cross-Species" = "#A8DADC",
  "Cross-Genus"   = "#457B9D",
  "Cross-Family"  = "#E63946",
  "Cross-Order"   = "#D62828",
  "Cross-Class"   = "#9D0208",
  "Cross-Phylum"  = "#000000"
)
level_order <- c("Non-crossing", "Cross-Species", "Cross-Genus", "Cross-Family",
                 "Cross-Order", "Cross-Class", "Cross-Phylum")
group_colors <- c("Inactive vOTU" = "#BDC3C7", "Other Active vOTU" = "#3498DB", "SAvOTU" = "#E74C3C")
group_levels <- c("Inactive vOTU", "Other Active vOTU", "SAvOTU")

STROKE_WIDTH <- 0.8
STROKE_COLOR_DEFAULT <- "darkgray"
STROKE_COLOR_CROSS <- "black"

cat("========================================================================\n")
cat(">>> Starting Integrated Prophage Activity Analysis Pipeline...\n")
cat(sprintf(">>> Active Threshold: %.2f\n", ACTIVE_THRESHOLD))
cat(sprintf(">>> Output Directory: %s/\n", OUT_DIR))
cat("========================================================================\n")

# ==============================================================================
# 1. Data Loading and Cleaning
# ==============================================================================
cat("\n>>> [1/4] Loading and cleaning metadata...\n")

metadata_path <- "../metadata/allpp_metadata.tsv"
if (!file.exists(metadata_path)) {
  stop(sprintf("Fatal Error: Metadata file not found at: %s", metadata_path))
}

raw_meta <- read_tsv(metadata_path, show_col_types = FALSE)

# Rename host taxonomy columns if needed
if ("host_Phylum" %in% names(raw_meta) && !"Phylum" %in% names(raw_meta)) {
  raw_meta <- raw_meta %>% rename(Phylum = host_Phylum)
}
if ("host_Genus" %in% names(raw_meta) && !"Genus" %in% names(raw_meta)) {
  raw_meta <- raw_meta %>% rename(Genus = host_Genus)
}
if ("host_Species" %in% names(raw_meta) && !"Species" %in% names(raw_meta)) {
  raw_meta <- raw_meta %>% rename(Species = host_Species)
}
if ("host_Family" %in% names(raw_meta) && !"Family" %in% names(raw_meta)) {
  raw_meta <- raw_meta %>% rename(Family = host_Family)
}
if ("host_Order" %in% names(raw_meta) && !"Order" %in% names(raw_meta)) {
  raw_meta <- raw_meta %>% rename(Order = host_Order)
}
if ("host_Class" %in% names(raw_meta) && !"Class" %in% names(raw_meta)) {
  raw_meta <- raw_meta %>% rename(Class = host_Class)
}
if ("host_source" %in% names(raw_meta) && !"source" %in% names(raw_meta)) {
  raw_meta <- raw_meta %>% rename(source = host_source)
}

df_clean <- raw_meta %>%
  filter(!is.na(Genome) & !is.na(vOTU)) %>%
  mutate(Activity_Score = suppressWarnings(as.numeric(as.character(Activity_Score)))) %>%
  mutate(Activity_Score = replace_na(Activity_Score, 0)) %>%
  mutate(Is_Active = ifelse(Activity_Score >= ACTIVE_THRESHOLD, "Yes", "No")) %>%
  mutate(Active_Binary = ifelse(Is_Active == "Yes", 1, 0)) %>%
  mutate(across(c(Species, Genus, Family, Order, Class, Phylum),
                ~ na_if(str_trim(.), "") %>%
                  na_if("s__") %>% na_if("g__") %>% na_if("f__") %>%
                  na_if("o__") %>% na_if("c__") %>% na_if("p__") %>%
                  na_if("Unclassified") %>% na_if("unknown") %>% na_if("NA"))) %>%
  filter(!is.na(source) & source != "")

get_mode <- function(x) {
  x <- x[!is.na(x) & x != ""]
  if (length(x) == 0) return(NA)
  names(table(x))[which.max(table(x))]
}

# ==============================================================================
# 2. Statistical Engine (CMH + Exact Tests) & Activity Landscapes
# ==============================================================================
cat("\n>>> [2/4] Running Statistical Engine for vOTU and vFAM...\n")

run_stats_analysis <- function(data, level_name) {
  data_lvl <- data %>% filter(!is.na(!!sym(level_name)) & !!sym(level_name) != "")

  global_bg <- data_lvl %>%
    group_by(source) %>%
    summarise(Total_Active = sum(Active_Binary), Total_Count = n(),
              Total_Inactive = Total_Count - Total_Active, .groups = "drop")

  taxon_summary <- data_lvl %>%
    group_by(!!sym(level_name)) %>%
    summarise(
      Genome_Count = n(), Count_Active = sum(Active_Binary), Num_Sources = n_distinct(source),
      Max_Intensity = max(Activity_Score), Phylum = get_mode(Phylum), .groups = "drop"
    ) %>% filter(Genome_Count >= MIN_GENOME_COUNT)

  taxa_list <- taxon_summary[[level_name]]

  results_list <- mclapply(taxa_list, function(taxon) {
    taxon_df <- data_lvl %>% filter(!!sym(level_name) == taxon)

    combined <- taxon_df %>%
      group_by(source) %>%
      summarise(a = sum(Active_Binary), c = n() - sum(Active_Binary), .groups = "drop") %>%
      left_join(global_bg, by = "source") %>%
      mutate(b = Total_Active - a, d = Total_Inactive - c) %>%
      filter((a + c) > 0 & (b + d) > 0)

    if (nrow(combined) == 0) {
      return(tibble(!!sym(level_name) := taxon, OR = 0.01, CI_Lower = 0.01,
                    CI_Upper = 0.01, p_value = 0.99, Test_Method = "No_Data"))
    }

    has_zero <- any(combined$a == 0 | combined$b == 0 | combined$c == 0 | combined$d == 0)
    adj_comb <- combined
    if (has_zero) {
      adj_comb <- adj_comb %>% mutate(a = a + 0.5, b = b + 0.5, c = c + 0.5, d = d + 0.5)
    }

    a_adj <- adj_comb$a; b_adj <- adj_comb$b; c_adj <- adj_comb$c; d_adj <- adj_comb$d
    n_adj <- a_adj + b_adj + c_adj + d_adj

    or_num <- sum((a_adj * d_adj) / n_adj)
    or_den <- sum((b_adj * c_adj) / n_adj)
    mh_or  <- or_num / or_den

    R <- (a_adj * d_adj) / n_adj
    S <- (b_adj * c_adj) / n_adj
    var_logor <- sum((a_adj + d_adj) * R / n_adj^2) / (2 * sum(R)^2) +
                 sum((a_adj + d_adj) * S + (c_adj + b_adj) * R) / (2 * sum(R) * sum(S)) +
                 sum((c_adj + b_adj) * S / n_adj^2) / (2 * sum(S)^2)
    se_logor <- sqrt(var_logor)
    ci_low <- exp(log(mh_or) - 1.96 * se_logor)
    ci_up  <- exp(log(mh_or) + 1.96 * se_logor)

    num_strata <- nrow(combined)
    p_val <- NA

    if (num_strata == 1) {
      mat <- matrix(c(combined$a, combined$b, combined$c, combined$d), nrow = 2)
      test_res <- tryCatch(fisher.test(mat), error = function(e) NULL)
      if (!is.null(test_res)) p_val <- test_res$p.value
    } else {
      arr <- array(NA, dim = c(2, 2, num_strata))
      for (i in 1:num_strata) {
        arr[, , i] <- matrix(c(combined$a[i], combined$b[i], combined$c[i], combined$d[i]), nrow = 2)
      }
      test_res <- tryCatch(mantelhaen.test(arr, exact = TRUE),
                           error = function(e) tryCatch(mantelhaen.test(arr, exact = FALSE),
                                                       error = function(e) NULL))
      if (!is.null(test_res)) p_val <- test_res$p.value
    }

    if (is.na(p_val)) p_val <- 0.99

    tibble(!!sym(level_name) := taxon, Test_Method = "exact", OR = mh_or,
           CI_Lower = ci_low, CI_Upper = ci_up, p_value = p_val)
  }, mc.cores = THREADS)

  stats_results <- bind_rows(results_list)

  final_df <- taxon_summary %>%
    left_join(stats_results, by = level_name) %>%
    filter(!is.na(p_value)) %>%
    mutate(
      Prevalence_Pct = (Count_Active / Genome_Count) * 100,
      log2_OR = log2(OR),
      p.adj = p.adjust(p_value, method = "fdr"),
      Significance_Type = case_when(p.adj < 0.05 & OR > 1 ~ "Significant", TRUE ~ "Not Significant")
    ) %>% arrange(desc(Significance_Type), p.adj)

  return(final_df)
}

stats_votu <- run_stats_analysis(df_clean, "vOTU")
stats_vfam <- run_stats_analysis(df_clean, "vFAM")

write_tsv(stats_votu, file.path(OUT_DIR, "stats_baseline_vOTU.tsv"))
write_tsv(stats_vfam, file.path(OUT_DIR, "stats_baseline_vFAM.tsv"))

# ---- Cross-host capability computation ----
votu_cross_stats <- df_clean %>%
  filter(!is.na(vOTU) & vOTU != "") %>%
  group_by(vOTU) %>%
  summarise(
    Member_Count = n(),
    n_Species = n_distinct(Species, na.rm = TRUE),
    n_Genus = n_distinct(Genus, na.rm = TRUE),
    n_Family = n_distinct(Family, na.rm = TRUE),
    n_Order = n_distinct(Order, na.rm = TRUE),
    n_Class = n_distinct(Class, na.rm = TRUE),
    n_Phylum = n_distinct(Phylum, na.rm = TRUE),
    Max_Activity = max(Activity_Score, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    Cross_Category = case_when(
      n_Phylum > 1 ~ "Cross-Phylum",
      n_Class > 1 ~ "Cross-Class",
      n_Order > 1 ~ "Cross-Order",
      n_Family > 1 ~ "Cross-Family",
      n_Genus > 1 ~ "Cross-Genus",
      n_Species > 1 ~ "Cross-Species",
      TRUE ~ "Non-crossing"
    ),
    Cross_Category = factor(Cross_Category, levels = level_order),
    Is_Generalist = if_else(n_Species > 1, "Generalist", "Specialist")
  )

df_unified <- votu_cross_stats %>%
  left_join(stats_votu %>% select(vOTU, Significance_Type, Phylum), by = "vOTU") %>%
  mutate(
    Significance_Type = replace_na(Significance_Type, "Not Significant"),
    Analysis_Group = case_when(
      Significance_Type == "Significant" ~ "SAvOTU",
      Max_Activity >= ACTIVE_THRESHOLD ~ "Other Active vOTU",
      TRUE ~ "Inactive vOTU"
    ),
    Analysis_Group = factor(Analysis_Group, levels = group_levels)
  )

df_full_detailed <- df_unified %>%
  select(vOTU, Phylum, Member_Count, Cross_Category, Is_Generalist,
         Significance_Type, Analysis_Group, Max_Activity, n_Phylum:n_Species) %>%
  arrange(desc(Cross_Category), desc(Member_Count))
write_csv(df_full_detailed, file.path(OUT_DIR, "Detailed_Cross_Host_vOTUs.csv"))

# Helper for labeling
build_label_hits <- function(plot_df, level_name) {
  top_hits <- plot_df %>%
    filter(Significance_Type == "Significant") %>%
    arrange(p.adj) %>%
    head(10)

  if (level_name == "vFAM") {
    forced_ids <- c("vFAM_1", "vFAM_9", "vFAM_7")
    forced_hits <- plot_df %>% filter(!!sym(level_name) %in% forced_ids)
    top_hits <- bind_rows(top_hits, forced_hits) %>%
      distinct(!!sym(level_name), .keep_all = TRUE)
  }
  return(top_hits)
}

prep_bubble_data <- function(stats_data, level_name) {
  if (level_name == "vOTU") {
    plot_df <- stats_data %>%
      left_join(df_full_detailed %>% select(vOTU, Cross_Category), by = "vOTU") %>%
      mutate(
        Is_Cross_Host = !is.na(Cross_Category) & Cross_Category != "Non-crossing",
        Cross_Label = case_when(
          Significance_Type == "Not Significant" ~ "No Cross / Not Sig",
          Is_Cross_Host ~ "Cross-Host",
          TRUE ~ "No Cross / Not Sig"
        )
      )
  } else {
    plot_df <- stats_data %>% mutate(Cross_Label = "No Cross / Not Sig")
  }

  plot_df %>% mutate(
    Color_Group = ifelse(Significance_Type == "Significant", Phylum, "Not Significant"),
    Plot_Order = ifelse(Significance_Type == "Significant", 1, 0),
    log_FDR = -log10(ifelse(p.adj == 0, .Machine$double.xmin, p.adj))
  ) %>% arrange(Plot_Order)
}

# Plots with alpha = 1 for points
draw_prevalence_bubble <- function(stats_data, level_name) {
  plot_df <- prep_bubble_data(stats_data, level_name)
  actual_phyla <- unique(plot_df$Phylum[plot_df$Significance_Type == "Significant"])
  actual_phyla <- actual_phyla[!is.na(actual_phyla)]
  current_palette <- setNames(rep("#bdbdbd", length(actual_phyla)), actual_phyla)
  for (p in actual_phyla) {
    if (p %in% names(PHYLUM_COLORS)) current_palette[p] <- PHYLUM_COLORS[p]
  }
  final_colors <- c(current_palette, "Not Significant" = "grey95")
  top_hits <- build_label_hits(plot_df, level_name)

  p <- ggplot(plot_df, aes(x = log_FDR, y = Prevalence_Pct)) +
    geom_vline(xintercept = -log10(0.05), linetype = "dashed", color = "red", alpha = 0.6) +
    geom_point(aes(size = Genome_Count, fill = Color_Group, color = Cross_Label),
               stroke = STROKE_WIDTH, shape = 21, alpha = 1) +
    scale_fill_manual(values = final_colors, name = "Host Phylum") +
    scale_color_manual(name = "Cross-Host Status",
                       values = c("Cross-Host" = STROKE_COLOR_CROSS,
                                  "No Cross / Not Sig" = STROKE_COLOR_DEFAULT)) +
    scale_size_continuous(range = c(2, 12), name = "Genome Count") +
    labs(title = paste0("Activity Landscape: ", level_name),
         subtitle = paste0("Significantly Active: n=", sum(plot_df$Significance_Type == "Significant")),
         x = "-log10(FDR)", y = "% of Genome Active (Prevalence)") +
    theme_minimal() +
    theme(aspect.ratio = 0.75, plot.title = element_text(size = 16, face = "bold"),
          panel.border = element_rect(colour = "black", fill = NA)) +
    guides(fill = guide_legend(override.aes = list(shape = 21, size = 5, color = STROKE_COLOR_DEFAULT, alpha = 1)))

  if (nrow(top_hits) > 0) {
    p <- p + geom_text_repel(data = top_hits, aes(label = !!sym(level_name)),
                             size = 4.5, fontface = "bold", min.segment.length = 0,
                             segment.color = "black", box.padding = 0.8, max.overlaps = Inf)
  }
  return(p)
}

draw_classic_volcano <- function(stats_data, level_name) {
  plot_df <- prep_bubble_data(stats_data, level_name)
  actual_phyla <- unique(plot_df$Phylum[plot_df$Significance_Type == "Significant"])
  actual_phyla <- actual_phyla[!is.na(actual_phyla)]
  current_palette <- setNames(rep("#bdbdbd", length(actual_phyla)), actual_phyla)
  for (p in actual_phyla) {
    if (p %in% names(PHYLUM_COLORS)) current_palette[p] <- PHYLUM_COLORS[p]
  }
  final_colors <- c(current_palette, "Not Significant" = "grey95")
  top_hits <- build_label_hits(plot_df, level_name)

  p <- ggplot(plot_df, aes(x = log2_OR, y = log_FDR)) +
    geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "red", alpha = 0.6) +
    geom_vline(xintercept = 0, linetype = "dashed", color = "black", alpha = 0.6) +
    geom_point(aes(size = Genome_Count, fill = Color_Group, color = Cross_Label),
               stroke = STROKE_WIDTH, shape = 21, alpha = 1) +
    scale_fill_manual(values = final_colors, name = "Host Phylum") +
    scale_color_manual(name = "Cross-Host Status",
                       values = c("Cross-Host" = STROKE_COLOR_CROSS,
                                  "No Cross / Not Sig" = STROKE_COLOR_DEFAULT)) +
    scale_size_continuous(range = c(2, 12), name = "Genome Count") +
    labs(title = paste0("Classic Volcano: ", level_name),
         subtitle = paste0("Significantly Active: n=", sum(plot_df$Significance_Type == "Significant")),
         x = "Effect Size: log2 (Mantel-Haenszel OR)", y = "-log10(FDR)") +
    theme_minimal() +
    theme(aspect.ratio = 0.75, plot.title = element_text(size = 16, face = "bold"),
          panel.border = element_rect(colour = "black", fill = NA)) +
    guides(fill = guide_legend(override.aes = list(shape = 21, size = 5, color = STROKE_COLOR_DEFAULT, alpha = 1)))

  if (nrow(top_hits) > 0) {
    p <- p + geom_text_repel(data = top_hits, aes(label = !!sym(level_name)),
                             size = 4.5, fontface = "bold", min.segment.length = 0,
                             segment.color = "black", box.padding = 0.8, max.overlaps = Inf)
  }
  return(p)
}

bubble_plot1 <- draw_prevalence_bubble(stats_votu, "vOTU") /
                draw_prevalence_bubble(stats_vfam, "vFAM") +
                plot_annotation(tag_levels = 'A')
ggsave(file.path(OUT_DIR, "Combined_Activity_Landscape.pdf"), bubble_plot1, width = 12, height = 18, bg = "white")

bubble_plot2 <- draw_classic_volcano(stats_votu, "vOTU") /
                draw_classic_volcano(stats_vfam, "vFAM") +
                plot_annotation(tag_levels = 'A')
ggsave(file.path(OUT_DIR, "Combined_Classic_Volcano.pdf"), bubble_plot2, width = 12, height = 18, bg = "white")

# ---- Comprehensive 2-in-1 Analysis Plot ----
df_A <- df_unified %>% filter(Analysis_Group == "SAvOTU") %>%
  count(Cross_Category) %>% mutate(Prop = n / sum(n))

if (nrow(df_A) > 0) {
  pA <- ggplot(df_A, aes(x = Cross_Category, y = n, fill = Cross_Category)) +
    geom_bar(stat = "identity", width = 0.7, color = "black") +
    geom_text(aes(label = sprintf("%d\n(%.1f%%)", n, Prop * 100)), vjust = -0.2, size = 3.5) +
    scale_fill_manual(values = cross_colors) +
    scale_y_continuous(expand = expansion(mult = c(0, 0.2))) +
    labs(title = "A. Cross-Host Distribution of SAvOTUs", x = "", y = "Number of SAvOTUs") +
    theme_classic() +
    theme(legend.position = "none",
          axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"))
} else {
  pA <- ggplot() + theme_void() + labs(title = "A. No SAvOTUs Found")
}

df_B <- df_unified %>% group_by(Analysis_Group) %>%
  summarise(Total_vOTU = n(),
            Generalists = sum(Is_Generalist == "Generalist"),
            Prop_Generalist = Generalists / Total_vOTU,
            .groups = "drop")

calc_fisher <- function(g1, g2) {
  dat <- df_unified %>% filter(Analysis_Group %in% c(g1, g2))
  if (length(unique(dat$Analysis_Group)) < 2) return(1)
  fisher.test(table(dat$Analysis_Group, dat$Is_Generalist))$p.value
}

raw_pval_S_O <- calc_fisher("SAvOTU", "Other Active vOTU")
raw_pval_S_I <- calc_fisher("SAvOTU", "Inactive vOTU")
adj_pvals <- p.adjust(c(raw_pval_S_O, raw_pval_S_I), method = "fdr")
pval_S_O <- adj_pvals[1]
pval_S_I <- adj_pvals[2]

format_pval <- function(p) {
  if (p < 0.0001) return("****")
  if (p < 0.001) return("***")
  if (p < 0.01) return("**")
  if (p < 0.05) return("*")
  return("ns")
}
ymax <- max(df_B$Prop_Generalist, na.rm = TRUE)

if (ymax > 0 && "SAvOTU" %in% df_B$Analysis_Group) {
  pB <- ggplot(df_B, aes(x = Analysis_Group, y = Prop_Generalist, fill = Analysis_Group)) +
    geom_bar(stat = "identity", width = 0.6, color = "black") +
    geom_text(aes(label = percent(Prop_Generalist, accuracy = 0.1)), vjust = -0.5, size = 4) +
    geom_segment(aes(x = 2, xend = 3, y = ymax * 1.15, yend = ymax * 1.15)) +
    geom_text(aes(x = 2.5, y = ymax * 1.18),
              label = sprintf("%s\n(p=%.2e)", format_pval(pval_S_O), pval_S_O), size = 3) +
    geom_segment(aes(x = 1, xend = 3, y = ymax * 1.35, yend = ymax * 1.35)) +
    geom_text(aes(x = 2, y = ymax * 1.38),
              label = sprintf("%s\n(p=%.2e)", format_pval(pval_S_I), pval_S_I), size = 3) +
    scale_fill_manual(values = group_colors) +
    scale_y_continuous(labels = percent, limits = c(0, ymax * 1.5)) +
    labs(title = "B. Proportion of Generalists", x = "", y = "Generalist Proportion (%)") +
    theme_classic() +
    theme(legend.position = "none",
          axis.text.x = element_text(angle = 15, hjust = 1, face = "bold"))
} else {
  pB <- ggplot(df_B, aes(x = Analysis_Group, y = Prop_Generalist, fill = Analysis_Group)) +
    geom_bar(stat = "identity", width = 0.6, color = "black") +
    theme_classic() +
    labs(title = "B. Proportion of Generalists (Insufficient Data)")
}

comprehensive_plot <- pA / pB + plot_annotation(title = "SAvOTU Analysis")
ggsave(file.path(OUT_DIR, "Fig_Comprehensive_2Groups.pdf"), comprehensive_plot, width = 8, height = 9, bg = "white")

# ==============================================================================
# 3. Saturation Curves Analysis
# ==============================================================================
cat("\n>>> [3/4] Calculating Sampling Saturation Curves...\n")

list_active_votu <- df_clean %>% filter(Activity_Score >= ACTIVE_THRESHOLD) %>% pull(vOTU) %>% unique()
list_active_vfam <- df_clean %>% filter(Activity_Score >= ACTIVE_THRESHOLD) %>% pull(vFAM) %>% unique()

list_sig_votu <- stats_votu %>% filter(Significance_Type == "Significant") %>% pull(vOTU) %>% unique()
list_sig_vfam <- stats_vfam %>% filter(Significance_Type == "Significant") %>% pull(vFAM) %>% unique()

processed_sat_df <- df_clean %>%
  select(Genome, Phylum, vOTU, vFAM) %>%
  mutate(
    Is_Active_vOTU = vOTU %in% list_active_votu,
    Is_Significant_vOTU = vOTU %in% list_sig_votu,
    Is_Active_vFAM = vFAM %in% list_active_vfam,
    Is_Significant_vFAM = vFAM %in% list_sig_vfam
  ) %>%
  filter(!is.na(Phylum) & Phylum != "")

calculate_accumulation <- function(data, entity_col, metric_col = NULL, steps = 30, iterations = 10) {
  all_genomes <- unique(data$Genome)
  n_total <- length(all_genomes)

  if (n_total < steps) {
    sample_sizes <- 1:n_total
  } else {
    sample_sizes <- unique(round(seq(1, n_total, length.out = steps)))
    if (tail(sample_sizes, 1) != n_total) sample_sizes <- c(sample_sizes, n_total)
  }

  target_data <- data %>% filter(!is.na(.data[[entity_col]]) & .data[[entity_col]] != "")
  if (!is.null(metric_col)) {
    target_data <- target_data %>% filter(.data[[metric_col]] == TRUE)
  }

  results <- data.frame(Sample_Depth = integer(), Mean_Count = numeric(), SD_Count = numeric())

  for (size in sample_sizes) {
    counts <- numeric(iterations)
    for (i in 1:iterations) {
      picked_genomes <- sample(all_genomes, size)
      n_unique <- target_data %>%
        filter(Genome %in% picked_genomes) %>%
        pull(.data[[entity_col]]) %>%
        unique() %>%
        length()
      counts[i] <- n_unique
    }
    results <- rbind(results, data.frame(
      Sample_Depth = size,
      Mean_Count = mean(counts),
      SD_Count = sd(counts)
    ))
  }
  return(results)
}

phylum_stats <- processed_sat_df %>%
  group_by(Phylum) %>%
  summarise(n_genomes = n_distinct(Genome)) %>%
  arrange(desc(n_genomes)) %>%
  filter(n_genomes >= 5)

target_phyla <- phylum_stats$Phylum

res_list <- list(
  vOTU_total = list(), vOTU_active = list(), vOTU_sig = list(),
  vFAM_total = list(), vFAM_active = list(), vFAM_sig = list()
)

for (i in seq_along(target_phyla)) {
  p_name <- target_phyla[i]
  sub_df <- processed_sat_df %>% filter(Phylum == p_name)

  tmp <- calculate_accumulation(sub_df, "vOTU", NULL); tmp$Phylum <- p_name; res_list$vOTU_total[[i]] <- tmp
  tmp <- calculate_accumulation(sub_df, "vOTU", "Is_Active_vOTU"); tmp$Phylum <- p_name; res_list$vOTU_active[[i]] <- tmp
  tmp <- calculate_accumulation(sub_df, "vOTU", "Is_Significant_vOTU"); tmp$Phylum <- p_name; res_list$vOTU_sig[[i]] <- tmp

  tmp <- calculate_accumulation(sub_df, "vFAM", NULL); tmp$Phylum <- p_name; res_list$vFAM_total[[i]] <- tmp
  tmp <- calculate_accumulation(sub_df, "vFAM", "Is_Active_vFAM"); tmp$Phylum <- p_name; res_list$vFAM_active[[i]] <- tmp
  tmp <- calculate_accumulation(sub_df, "vFAM", "Is_Significant_vFAM"); tmp$Phylum <- p_name; res_list$vFAM_sig[[i]] <- tmp
}

normalize_curve_data <- function(df) {
  df %>%
    group_by(Phylum) %>%
    mutate(
      Norm_Sample_Depth = Sample_Depth / max(Sample_Depth, na.rm = TRUE),
      Norm_Mean_Count = Mean_Count / max(Mean_Count, na.rm = TRUE)
    ) %>%
    ungroup() %>%
    mutate(Norm_Mean_Count = ifelse(is.nan(Norm_Mean_Count), 0, Norm_Mean_Count))
}

df_votu_total  <- normalize_curve_data(bind_rows(res_list$vOTU_total))
df_votu_active <- normalize_curve_data(bind_rows(res_list$vOTU_active))
df_votu_sig    <- normalize_curve_data(bind_rows(res_list$vOTU_sig))
df_vfam_total  <- normalize_curve_data(bind_rows(res_list$vFAM_total))
df_vfam_active <- normalize_curve_data(bind_rows(res_list$vFAM_active))
df_vfam_sig    <- normalize_curve_data(bind_rows(res_list$vFAM_sig))

plot_saturation <- function(data, title_str, y_label_str, file_name) {
  p <- ggplot(data, aes(x = Norm_Sample_Depth, y = Norm_Mean_Count, color = Phylum, group = Phylum)) +
    geom_smooth(method = "loess", se = FALSE, linewidth = 1) +
    scale_color_manual(values = PHYLUM_COLORS, drop = FALSE, na.value = "grey30") +
    scale_x_continuous(labels = percent_format(accuracy = 1)) +
    scale_y_continuous(labels = percent_format(accuracy = 1)) +
    labs(
      title = title_str,
      subtitle = "Normalized Saturation Curve (Fitted Smooth Lines)",
      x = "Normalized Host Genomes Sampled (%)",
      y = y_label_str
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(face = "bold", size = 14),
      legend.position = "right",
      legend.text = element_text(size = 10),
      panel.grid = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1),
      axis.line = element_line(color = "black")
    )

  ggsave(file.path(OUT_DIR, file_name), p, width = 10, height = 7)
}

plot_saturation(df_votu_total,  "Saturation Curve: Total vOTUs by Phylum",              "Normalized Cumulative vOTUs (%)", "Curve_1_Total_vOTU.pdf")
plot_saturation(df_votu_active, "Saturation Curve: Active vOTUs by Phylum",             "Normalized Cumulative vOTUs (%)", "Curve_2_Active_vOTU.pdf")
plot_saturation(df_votu_sig,    "Saturation Curve: Exact Significant vOTUs by Phylum",  "Normalized Cumulative vOTUs (%)", "Curve_3_Significant_vOTU.pdf")
plot_saturation(df_vfam_total,  "Saturation Curve: Total vFAMs by Phylum",              "Normalized Cumulative vFAMs (%)", "Curve_4_Total_vFAM.pdf")
plot_saturation(df_vfam_active, "Saturation Curve: Active vFAMs by Phylum",             "Normalized Cumulative vFAMs (%)", "Curve_5_Active_vFAM.pdf")
plot_saturation(df_vfam_sig,    "Saturation Curve: Exact Significant vFAMs by Phylum",  "Normalized Cumulative vFAMs (%)", "Curve_6_Significant_vFAM.pdf")

# ==============================================================================
# 4. Host Phylum Level Prevalence Boxplots
# ==============================================================================
cat("\n>>> [4/4] Generating Host Phylum Prevalence Boxplots...\n")

generate_prevalence_boxplot <- function(stats_df, level_name, out_file) {
  sig_df <- stats_df %>%
    filter(Significance_Type == "Significant") %>%
    group_by(Phylum) %>%
    mutate(Phylum_Count = n()) %>%
    ungroup() %>%
    mutate(Phylum_Label = paste0(Phylum, "\n(n=", Phylum_Count, ")")) %>%
    mutate(Phylum_Label = fct_reorder(Phylum_Label, Prevalence_Pct, .fun = median, .desc = TRUE))

  if (nrow(sig_df) == 0) {
    message("No significant entities found. Skipping boxplot for ", level_name)
    return(NULL)
  }

  actual_phyla_box <- unique(sig_df$Phylum)
  current_palette_box <- c()
  for(phylum in actual_phyla_box) {
    if(phylum %in% names(PHYLUM_COLORS)) current_palette_box[phylum] <- PHYLUM_COLORS[phylum]
    else current_palette_box[phylum] <- "#bdbdbd"
  }

  p_box <- ggplot(sig_df, aes(x = Phylum_Label, y = Prevalence_Pct, fill = Phylum)) +
    geom_boxplot(alpha = 1, outlier.shape = NA, width = 0.6, color = "black") +
    geom_jitter(aes(size = Genome_Count),
                width = 0.2, alpha = 1, shape = 21, color = "black", stroke = 0.6) +
    scale_fill_manual(values = current_palette_box) +
    scale_size_continuous(range = c(2, 8), name = "Genome Count") +
    scale_y_continuous(limits = c(0, 110), breaks = seq(0, 100, by = 20)) +
    labs(
      title = paste0("Prevalence Distribution of Significantly Active ", level_name, "s"),
      subtitle = paste0("Total Exact-Significant ", level_name, "s: ", nrow(sig_df)),
      x = "Host Phylum",
      y = "Active Prevalence (%)"
    ) +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1, size = 12, face = "bold", color = "black"),
      axis.text.y = element_text(size = 12, color = "black"),
      axis.title = element_text(size = 14, face = "bold", color = "black"),
      plot.title = element_text(size = 16, face = "bold", color = "black"),
      legend.position = "right",
      legend.title = element_text(face = "bold"),
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.8),
      panel.grid.minor = element_blank()
    ) +
    guides(fill = "none", size = guide_legend(override.aes = list(fill = "gray50", alpha = 1))) +
    stat_compare_means(method = "kruskal.test", label.y = 105, size = 4.5, color = "red3", fontface = "italic")

  ggsave(out_file, p_box, width = 9, height = 7, bg = "white")
}

generate_prevalence_boxplot(
  stats_df = stats_votu,
  level_name = "vOTU",
  out_file   = file.path(OUT_DIR, "Prevalence_Boxplot_Significant_vOTU.pdf")
)

generate_prevalence_boxplot(
  stats_df = stats_vfam,
  level_name = "vFAM",
  out_file   = file.path(OUT_DIR, "Prevalence_Boxplot_Significant_vFAM.pdf")
)

cat("\n========================================================================\n")
cat(sprintf(">>> Integrated Pipeline Completed Successfully!\n>>> All outputs stored in: %s/\n", OUT_DIR))
cat("========================================================================\n")
