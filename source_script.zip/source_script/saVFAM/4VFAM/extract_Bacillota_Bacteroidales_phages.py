#!/usr/bin/env python3

import os
import re
import sys
import html
from pathlib import Path
from urllib.parse import unquote

import pandas as pd
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord


META = Path(os.path.expanduser(
    "~/databaseHY/inphared_202504/26_JAN/"
    "7Apr2026_millardlab_website_table.txt"
))

FASTA = Path(os.path.expanduser(
    "~/databaseHY/inphared_202504/26_JAN/"
    "7Apr2026_genomes.fa"
))

GTDB_TAX = Path(os.path.expanduser(
    "~/anaconda3/envs/binning/share/"
    "gtdbtk-2.4.0/db/release220/taxonomy/"
    "bac120_taxonomy_r220_reps.tsv"
))


OUT_FASTA = Path("INPHARED_GTDBr220_Bacillota_Bacteroidales.fa")
OUT_TABLE = Path("INPHARED_GTDBr220_Bacillota_Bacteroidales.tsv")


def clean_accession(x):
    x = html.unescape(str(x)).strip()

    m = re.search(
        r"/nuccore/([^\"'<>/?#]+)",
        x,
        flags=re.IGNORECASE
    )

    if m:
        return unquote(m.group(1)).strip()

    x = re.sub(r"<[^>]+>", "", x).strip()

    if not x:
        return ""

    return x.split()[0]


def host_from_description(description):
    description = html.unescape(str(description)).strip()

    m = re.match(
        r"^\s*([A-Za-z][A-Za-z0-9_.-]*)\s+phage\b",
        description,
        flags=re.IGNORECASE
    )

    if m:
        return m.group(1)

    return None


def clean_host_genus(host):
    if host is None or pd.isna(host):
        return None

    host = html.unescape(str(host)).strip()

    host = re.sub(
        r"^(unclassified|unknown)\s*",
        "",
        host,
        flags=re.IGNORECASE
    ).strip()

    if not host:
        return None

    invalid = {
        "unclassified",
        "unknown",
        "uncultured",
        "na",
        "n/a",
        "-"
    }

    if host.lower() in invalid:
        return None

    host = re.split(r"[;,|/]", host)[0].strip()

    genus = host.split()[0]

    genus = re.sub(r"[^A-Za-z0-9_.-]", "", genus)

    return genus if genus else None


def genus_key(x):
    if x is None or pd.isna(x):
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(x).strip()
    ).casefold()


def unique_join(values):
    values = [
        str(x).strip()
        for x in values
        if x is not None
        and not pd.isna(x)
        and str(x).strip()
    ]

    return "|".join(sorted(set(values)))


def read_inphared_metadata(path):
    records = []

    with open(path, encoding="utf-8-sig") as f:
        header = f.readline()

        if "\t" not in header:
            raise ValueError("Metadata file is not tab-delimited.")

        for line_no, line in enumerate(f, start=2):
            if not line.strip():
                continue

            fields = line.rstrip("\r\n").split("\t")

            if len(fields) < 7:
                continue

            accession = clean_accession(fields[0])
            description = fields[1].strip()

            if not accession:
                continue

            description_host = host_from_description(description)

            if len(fields) >= 8:
                genome_length_kb = fields[2].strip()
                molGC_percent = fields[3].strip()
                inphared_genus = fields[4].strip()
                inphared_subfamily = fields[5].strip()
                inphared_family = fields[6].strip()
                inphared_host_raw = "\t".join(fields[7:]).strip()

            else:
                genome_length_kb = fields[2].strip()
                molGC_percent = fields[3].strip()
                inphared_genus = fields[4].strip()
                inphared_subfamily = fields[5].strip()

                family_host_combined = fields[6].strip()
                inphared_family = family_host_combined
                inphared_host_raw = description_host or ""

                if (
                    description_host
                    and family_host_combined.casefold().endswith(
                        description_host.casefold()
                    )
                ):
                    inphared_family = family_host_combined[
                        :len(family_host_combined) -
                        len(description_host)
                    ].strip()

                    inphared_host_raw = description_host

            host_from_column = clean_host_genus(
                inphared_host_raw
            )

            host_genus = host_from_column or description_host

            records.append({
                "phage_id": accession,
                "description": description,
                "genome_length_kb": genome_length_kb,
                "molGC_percent": molGC_percent,
                "inphared_genus": inphared_genus,
                "inphared_subfamily": inphared_subfamily,
                "inphared_family": inphared_family,
                "inphared_host_raw": inphared_host_raw,
                "host_genus": host_genus,
                "host_key": genus_key(host_genus),
            })

    return pd.DataFrame(records)


metadata = read_inphared_metadata(META)

if not GTDB_TAX.exists():
    raise FileNotFoundError(
        f"GTDB taxonomy file not found:\n{GTDB_TAX}"
    )


RANK_PREFIX = {
    "d": "domain",
    "p": "phylum",
    "c": "class",
    "o": "order",
    "f": "family",
    "g": "genus",
    "s": "species",
}


def parse_gtdb_taxonomy(taxonomy_string):
    result = {
        rank: None
        for rank in RANK_PREFIX.values()
    }

    for item in str(taxonomy_string).split(";"):
        if "__" not in item:
            continue

        prefix, value = item.split("__", 1)

        if prefix in RANK_PREFIX:
            rank = RANK_PREFIX[prefix]
            value = value.strip()

            if value:
                result[rank] = value

    return result


gtdb = pd.read_csv(
    GTDB_TAX,
    sep="\t",
    header=None,
    names=["gtdb_reference", "taxonomy"],
    dtype=str,
    keep_default_na=False
)


tax_by_genus = {}

for row in gtdb.itertuples(index=False):
    parsed = parse_gtdb_taxonomy(row.taxonomy)

    genus = parsed.get("genus")

    if not genus:
        continue

    key = genus_key(genus)

    parsed["gtdb_reference"] = row.gtdb_reference
    parsed["taxonomy"] = row.taxonomy

    tax_by_genus.setdefault(key, []).append(parsed)


tax_rows = []

for host_key, entries in tax_by_genus.items():

    tax_row = {
        "host_key": host_key,
        "gtdb_reference_count": len(entries),
    }

    for rank in RANK_PREFIX.values():
        tax_row[f"gtdb_{rank}"] = unique_join(
            [x.get(rank) for x in entries]
        )

    tax_row["gtdb_taxonomy"] = " || ".join(
        sorted(
            set(
                x["taxonomy"]
                for x in entries
                if x.get("taxonomy")
            )
        )
    )

    phylum_values = [
        x.get("phylum")
        for x in entries
        if x.get("phylum")
    ]

    order_values = [
        x.get("order")
        for x in entries
        if x.get("order")
    ]

    target_groups = []

    if (
        len(phylum_values) == len(entries)
        and set(phylum_values) == {"Bacillota"}
    ):
        target_groups.append("Bacillota")

    if (
        len(phylum_values) == len(entries)
        and len(order_values) == len(entries)
        and set(phylum_values) == {"Bacteroidota"}
        and set(order_values) == {"Bacteroidales"}
    ):
        target_groups.append(
            "Bacteroidota_Bacteroidales"
        )

    tax_row["target_group"] = ";".join(target_groups)

    tax_rows.append(tax_row)


gtdb_map = pd.DataFrame(tax_rows)


annotated = metadata.merge(
    gtdb_map,
    on="host_key",
    how="left"
)

annotated["target_group"] = annotated[
    "target_group"
].fillna("")


selected = annotated[
    annotated["target_group"] != ""
].copy()


selected = selected.drop_duplicates(
    subset=["phage_id"],
    keep="first"
).reset_index(drop=True)


if not FASTA.exists():
    raise FileNotFoundError(
        f"FASTA file not found:\n{FASTA}"
    )


seq_by_id = {}
source_header_by_id = {}
duplicate_fasta_ids = set()

for record in SeqIO.parse(str(FASTA), "fasta"):

    fasta_id = record.id.strip()

    if fasta_id in seq_by_id:
        duplicate_fasta_ids.add(fasta_id)
        continue

    seq_by_id[fasta_id] = record.seq
    source_header_by_id[fasta_id] = record.description


missing_ids = sorted(
    set(selected["phage_id"]) - set(seq_by_id)
)


extracted = selected[
    selected["phage_id"].isin(seq_by_id)
].copy()

extracted = extracted.reset_index(drop=True)


if len(extracted) == 0:
    raise RuntimeError(
        "No target accessions matched the FASTA."
    )


extracted["sequence_length_bp"] = extracted[
    "phage_id"
].map(
    lambda x: len(seq_by_id[x])
)

extracted["source_fasta_header"] = extracted[
    "phage_id"
].map(
    lambda x: source_header_by_id[x]
)

extracted[
    "n_extracted_phages_same_host_genus"
] = (
    extracted
    .groupby("host_genus")["phage_id"]
    .transform("nunique")
    .astype(int)
)

extracted[
    "n_extracted_phages_same_target_group"
] = (
    extracted
    .groupby("target_group")["phage_id"]
    .transform("nunique")
    .astype(int)
)


with open(OUT_FASTA, "w") as out_fasta:

    for row in extracted.itertuples(index=False):

        phage_id = row.phage_id
        description = row.description

        output_record = SeqRecord(
            seq_by_id[phage_id],
            id=phage_id,
            description=description
        )

        SeqIO.write(
            output_record,
            out_fasta,
            "fasta"
        )


rank_rename = {
    f"gtdb_{rank}": f"host_gtdb_{rank}"
    for rank in RANK_PREFIX.values()
}

rank_rename["gtdb_taxonomy"] = "host_gtdb_taxonomy"
rank_rename[
    "gtdb_reference_count"
] = "host_gtdb_reference_count"

output_table = extracted.rename(
    columns=rank_rename
)


table_columns = [
    "phage_id",
    "description",
    "genome_length_kb",
    "molGC_percent",
    "inphared_genus",
    "inphared_subfamily",
    "inphared_family",
    "inphared_host_raw",
    "host_genus",
    "target_group",
    "host_gtdb_domain",
    "host_gtdb_phylum",
    "host_gtdb_class",
    "host_gtdb_order",
    "host_gtdb_family",
    "host_gtdb_genus",
    "host_gtdb_species",
    "host_gtdb_taxonomy",
    "host_gtdb_reference_count",
    "sequence_length_bp",
    "source_fasta_header",
    "n_extracted_phages_same_host_genus",
    "n_extracted_phages_same_target_group",
]


output_table[table_columns].to_csv(
    OUT_TABLE,
    sep="\t",
    index=False
)