#!/usr/bin/env Rscript

library(tidyverse)
library(ggpubr)
library(scales)

tax_file <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
map_file <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/taxonomy/vOTU/genome_to_vOTU.tsv"

if (!file.exists(tax_file)) {
  tax_file <- "../../../metadata/allpp_metadata.tsv"
}

tax_df <- read_tsv(tax_file, show_col_types = FALSE)

processed_df <- tax_df %>%
  filter(!is.na(vOTU), !is.na(vFAM), !is.na(phage_id)) %>%
  mutate(
    phage_id_clean = gsub("-", "_", phage_id),
    start = as.numeric(sub(".*_(\\d+)_(\\d+)$", "\\1", phage_id_clean)),
    end   = as.numeric(sub(".*_(\\d+)_(\\d+)$", "\\2", phage_id_clean)),
    Length_bp = abs(end - start) + 1,
    Activity_Score = as.numeric(Activity_Score),
    ictv_Class = ifelse(is.na(ictv_Class) | ictv_Class == "", NA, ictv_Class)
  ) %>%
  filter(!is.na(Length_bp), Length_bp > 0)

votu_summary <- processed_df %>%
  group_by(vOTU, vFAM) %>%
  summarise(
    Is_Active   = any(!is.na(Activity_Score) & Activity_Score >= 0.8),
    Mean_Length = mean(Length_bp, na.rm = TRUE),
    ictv_Class  = first(ictv_Class[!is.na(ictv_Class)]),
    .groups     = "drop"
  ) %>%
  mutate(
    vfam_clean = gsub("_", "", vFAM),
    is_caudo   = grepl("Caudoviricetes", ictv_Class, ignore.case = TRUE)
  )

vfam9_active   <- votu_summary %>% filter(vfam_clean == "vFAM9" & Is_Active) %>% mutate(Group = "vFAM9 (Active)")
vfam9_inactive <- votu_summary %>% filter(vfam_clean == "vFAM9" & !Is_Active) %>% mutate(Group = "vFAM9 (Inactive)")
vfam9_all      <- votu_summary %>% filter(vfam_clean == "vFAM9") %>% mutate(Group = "vFAM9 (All)")
other_caudo    <- votu_summary %>% filter(vfam_clean != "vFAM9" & is_caudo) %>% mutate(Group = "Other Caudoviricetes")

plot_data <- bind_rows(vfam9_active, vfam9_inactive, vfam9_all, other_caudo) %>%
  mutate(
    Group = factor(Group, levels = c("vFAM9 (Active)", "vFAM9 (Inactive)", "vFAM9 (All)", "Other Caudoviricetes"))
  )

my_comparisons <- list(
  c("vFAM9 (Active)", "vFAM9 (Inactive)"),
  c("vFAM9 (All)", "Other Caudoviricetes"),
  c("vFAM9 (Active)", "Other Caudoviricetes")
)

stat_results <- ggpubr::compare_means(
  Mean_Length ~ Group,
  data = plot_data,
  comparisons = my_comparisons,
  method = "wilcox.test",
  exact = FALSE,
  p.adjust.method = "none"
) %>%
  mutate(
    p_label = case_when(
      is.na(p) ~ "P = NA",
      p < 0.001 ~ "P < 0.001",
      TRUE ~ paste0("P = ", formatC(p, format = "f", digits = 3))
    ),
    comparison_key = paste(group1, group2, sep = "__")
  )

whisker_info <- plot_data %>%
  filter(!is.na(Mean_Length)) %>%
  group_by(Group) %>%
  summarise(
    q3 = quantile(
      Mean_Length,
      probs = 0.75,
      na.rm = TRUE,
      names = FALSE
    ),
    iqr = IQR(Mean_Length, na.rm = TRUE),
    data_max = max(Mean_Length, na.rm = TRUE),
    upper_whisker = min(data_max, q3 + 1.5 * iqr),
    .groups = "drop"
  )

max_whisker <- max(
  whisker_info$upper_whisker,
  na.rm = TRUE
)

if (!is.finite(max_whisker) || max_whisker <= 0) {
  stop("Invalid Mean_Length data.")
}

label_step <- max(max_whisker * 0.12, 5000)
label_start <- max_whisker * 1.05

comparison_order <- c(
  "vFAM9 (Active)__vFAM9 (Inactive)",
  "vFAM9 (All)__Other Caudoviricetes",
  "vFAM9 (Active)__Other Caudoviricetes"
)

stat_results <- stat_results %>%
  arrange(match(comparison_key, comparison_order)) %>%
  mutate(
    y.position = label_start +
      (row_number() - 1) * label_step
  )

annotation_top <- max(stat_results$y.position) + label_step * 0.8

y_limit_max <- ceiling(
  annotation_top / 10000
) * 10000

y_break_step <- ifelse(
  y_limit_max > 120000,
  20000,
  10000
)

y_breaks <- seq(
  0,
  y_limit_max,
  by = y_break_step
)

p <- ggplot(
  plot_data,
  aes(
    x = Group,
    y = Mean_Length,
    fill = Group
  )
) +

  geom_boxplot(
    alpha = 0.6,
    width = 0.5,
    outlier.shape = NA
  ) +

  scale_fill_manual(
    values = c(
      "vFAM9 (Active)"       = "#e31a1c",
      "vFAM9 (Inactive)"     = "#1f78b4",
      "vFAM9 (All)"          = "#33a02c",
      "Other Caudoviricetes" = "#ff7f00"
    )
  ) +

  scale_y_continuous(
    breaks = y_breaks,
    labels = scales::label_number(
      scale = 1 / 1000,
      suffix = "kbp",
      accuracy = 1
    )
  ) +

  coord_cartesian(
    ylim = c(0, y_limit_max)
  ) +

  labs(
    title = "Comparison of Mean vOTU Lengths: vFAM_9 vs Other Caudoviricetes",
    subtitle = paste(
      "Active: Activity_Score >= 0.8;",
      "two-sided Wilcoxon rank-sum test; raw P values"
    ),
    x = NULL,
    y = "Mean Genome Length within vOTU (kbp)"
  ) +

  theme_minimal(base_size = 12) +

  theme(
    legend.position = "none",
    axis.title = element_text(face = "bold"),
    axis.text.x = element_text(
      face = "bold",
      size = 10
    ),
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      size = 13
    ),
    plot.subtitle = element_text(
      hjust = 0.5,
      color = "grey30",
      size = 10
    ),
    panel.grid.minor = element_blank()
  ) +

  ggpubr::stat_pvalue_manual(
    stat_results,
    label = "p_label",
    xmin = "group1",
    xmax = "group2",
    y.position = "y.position",
    tip.length = 0.01,
    bracket.size = 0.4,
    size = 3.5,
    inherit.aes = FALSE
  )

out_img <- "vFAM9_Mean_Length_Comparison.pdf"

ggsave(
  out_img,
  p,
  width = 8,
  height = 6
)