#!/usr/bin/env python3

from pathlib import Path
from copy import deepcopy
import subprocess
import sys
import shutil
import pandas as pd
from Bio import SeqIO

METADATA_FILE = Path("../../../metadata/allpp_metadata.tsv")
OUTDIR = Path("example_vfam_rep_out")
OUTDIR.mkdir(parents=True, exist_ok=True)

BY_VFAM_DIR = OUTDIR / "by_vFAM"
BY_VFAM_DIR.mkdir(parents=True, exist_ok=True)

ANNOT_DIR = OUTDIR / "annot"
ANNOT_DIR.mkdir(parents=True, exist_ok=True)

PHAROKKA_DB = Path("/home/huangyan/databaseHY/pharokka_v1.8.0_databases/")
PHAROKKA_THREADS = 18

def normalize_id(value):
    if pd.isna(value) or not value:
        return ""
    return str(value).strip().split()[0].replace("-", "_")

fasta_files = list(Path(".").glob("*vfam/*vOTU*.fasta"))

if not fasta_files:
    sys.exit(1)

vfam_votu_seqs = {}

for fpath in fasta_files:
    for record in SeqIO.parse(str(fpath), "fasta"):
        norm_id = normalize_id(record.id)
        vfam_name = fpath.parent.name.split("_")[0]
        vfam_id = f"vFAM_{vfam_name}" if not vfam_name.startswith("vFAM") else vfam_name

        vfam_clean = fpath.stem.split("_")[0]

        vfam_votu_seqs[norm_id] = {
            "record": record,
            "vfam": vfam_clean,
            "length": len(record.seq)
        }

df_meta = pd.read_csv(METADATA_FILE, sep="\t", dtype=str)

for col in ["vFAM", "vOTU", "phage_id", "completeness"]:
    df_meta[col] = df_meta[col].fillna("").astype(str).str.strip()

df_meta["norm_phage"] = df_meta["phage_id"].map(normalize_id)

target_norm_ids = set(vfam_votu_seqs.keys())

df_target = df_meta[df_meta["norm_phage"].isin(target_norm_ids)].copy()

if df_target.empty:
    df_target = df_meta[df_meta["vFAM"].isin([v["vfam"] for v in vfam_votu_seqs.values()])].copy()

df_target["completeness_num"] = pd.to_numeric(df_target["completeness"], errors="coerce").fillna(0)

candidates = []

for norm_id, info in vfam_votu_seqs.items():
    rec = info["record"]
    vfam = info["vfam"]
    seq_len = info["length"]

    sub = df_target[df_target["norm_phage"] == norm_id]

    if not sub.empty:
        votu = sub["vOTU"].iloc[0]
        completeness = sub["completeness_num"].max()
        member_count = len(df_meta[df_meta["vOTU"] == votu]["norm_phage"].unique())
    else:
        votu = "Unknown_vOTU"
        completeness = 0.0
        member_count = 1

    candidates.append({
        "vFAM": vfam,
        "vOTU": votu,
        "norm_id": norm_id,
        "completeness": completeness,
        "member_count": member_count,
        "seq_length": seq_len,
        "record": rec
    })

df_cand = pd.DataFrame(candidates)

df_cand = df_cand.sort_values(
    by=["vFAM", "completeness", "member_count", "seq_length"],
    ascending=[True, False, False, False]
)

df_selected = df_cand.groupby("vFAM").first().reset_index()

summary_tsv = OUTDIR / "selected_4_vfam_representatives.tsv"
df_selected.drop(columns=["record"]).to_csv(summary_tsv, sep="\t", index=False)

combined_records = []

for _, row in df_selected.iterrows():
    vfam = row["vFAM"]
    votu = row["vOTU"]
    rec = deepcopy(row["record"])

    new_id = f"{vfam}__{votu}__{row['norm_id']}"
    rec.id = new_id
    rec.name = new_id
    rec.description = f"vFAM={vfam} vOTU={votu} completeness={row['completeness']} members={row['member_count']} length={row['seq_length']}"

    combined_records.append(rec)

    single_fasta = BY_VFAM_DIR / f"{vfam}_rep.fasta"
    SeqIO.write([rec], str(single_fasta), "fasta")

combined_fasta = OUTDIR / "example_4_vfam_rep.fasta"
SeqIO.write(combined_records, str(combined_fasta), "fasta")

if not shutil.which("pharokka.py"):
    sys.exit(1)

cmd = [
    "pharokka.py",
    "-i", str(combined_fasta),
    "-o", str(ANNOT_DIR),
    "-t", str(PHAROKKA_THREADS),
    "-p", "example_4_vfam",
    "-m",
    "-s",
    "--meta_hmm",
    "--skip_mash",
    "-f"
]

if PHAROKKA_DB and PHAROKKA_DB.exists():
    cmd.extend(["-d", str(PHAROKKA_DB)])

try:
    res = subprocess.run(cmd, check=False, capture_output=True, text=True)
except Exception:
    pass