library(tidyverse)

out_dir <- "4_hanky-like"
if (!dir.exists(out_dir)) {
  dir.create(out_dir, recursive = TRUE)
}

allpp_path <- "../../../metadata/allpp_metadata.tsv"
allpp <- read_delim(allpp_path, delim = "\t", show_col_types = FALSE)

hanky_hits_path <- "4_hanky-like/hankyphage_like_hits.tsv"
hanky_hits <- read_delim(hanky_hits_path, delim = "\t", col_names = FALSE, show_col_types = FALSE)
hanky_ids <- hanky_hits$X2

host_stats_path <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/host/metadata/prophage_stats_final.tsv"
host_stats <- read_delim(host_stats_path, delim = "\t", show_col_types = FALSE)

norm_hanky_ids <- gsub("-", "_", hanky_ids)

vfam1_metadata <- allpp %>%
  filter(vFAM == "vFAM_1") %>%
  mutate(norm_phage_id = gsub("-", "_", phage_id)) %>%
  mutate(hanky_blastn = if_else(norm_phage_id %in% norm_hanky_ids, "yes", "no")) %>%
  left_join(
    host_stats %>% select(Genome_ID, host_source_from_stats = source),
    by = c("Genome" = "Genome_ID")
  ) %>%
  mutate(source = if_else(!is.na(host_source_from_stats), host_source_from_stats, host_source)) %>%
  mutate(Genus = host_Genus) %>%
  select(-norm_phage_id, -host_source_from_stats)

output_meta_file <- file.path(out_dir, "vFAM1_metadata_annotated_with_source.tsv")
write_delim(vfam1_metadata, output_meta_file, delim = "\t")

df_clean <- vfam1_metadata %>%
  select(Activity_Score, source, Genus, hanky_blastn) %>%
  mutate(
    is_active = if_else(!is.na(Activity_Score) & Activity_Score >= 0.8, 1, 0),
    is_hanky = if_else(tolower(hanky_blastn) == "no" | is.na(hanky_blastn), "Non-Hanky", "Hankyphage")
  )

create_plot <- function(stats_data, x_var, y_limit, title_str, subtitle_str) {
  x_sym <- sym(x_var)

  stats_data <- stats_data %>% arrange(desc(rate))
  stats_data[[x_var]] <- factor(stats_data[[x_var]], levels = stats_data[[x_var]])

  ggplot(stats_data, aes(x = !!x_sym, y = rate)) +
    geom_col(fill = "skyblue", color = "white", linewidth = 0.2) +
    geom_text(aes(label = paste0("n=", count)), vjust = -0.5, size = 3, angle = 45, hjust = 0) +
    labs(title = title_str, subtitle = subtitle_str, x = NULL, y = "Activity Rate") +
    coord_cartesian(ylim = c(0, y_limit)) +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1, size = 9),
      panel.grid.minor = element_blank(),
      plot.margin = margin(10, 20, 10, 10)
    )
}

stats_1_2 <- bind_rows(
  df_clean %>% summarise(Group = "Overall", rate = mean(is_active), count = n()),
  df_clean %>% group_by(Group = is_hanky) %>% summarise(rate = mean(is_active), count = n(), .groups = 'drop')
)

p1_2 <- create_plot(stats_1_2, "Group", 0.2,
                   "Plot 1&2: Activity Rate (Overall & Hanky Status)",
                   "Y-axis limited to 0.2")
ggsave(file.path(out_dir, "plot_1_overall_hanky.pdf"), p1_2, width = 7, height = 6)

stats_3 <- df_clean %>%
  filter(!is.na(Genus)) %>%
  group_by(Genus) %>%
  summarise(rate = mean(is_active), count = n(), .groups = 'drop') %>%
  filter(count >= 5)

p3 <- create_plot(stats_3, "Genus", 0.6,
                 "Plot 3: Activity Rate by Genus (All, n >= 5)",
                 "Y-axis limited to 0.6")
ggsave(file.path(out_dir, "plot_2_genus_all_n5.pdf"), p3, width = max(8, nrow(stats_3)*0.3), height = 7)

stats_4 <- df_clean %>%
  filter(is_hanky == "Hankyphage" & !is.na(Genus)) %>%
  group_by(Genus) %>%
  summarise(rate = mean(is_active), count = n(), .groups = 'drop')

p4 <- create_plot(stats_4, "Genus", 0.2,
                 "Plot 4: Activity Rate by Genus (Hankyphage Only)",
                 "Y-axis limited to 0.2 | No n-count filter")
ggsave(file.path(out_dir, "plot_3_genus_hanky_all.pdf"), p4, width = max(8, nrow(stats_4)*0.3), height = 7)