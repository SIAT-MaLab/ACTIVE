library(data.table)
library(ggplot2)

setDTthreads(threads = 20)

dist_dir <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/genome_similarity/bindash"
metadata_path <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
genome_to_votu_path <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/taxonomy/vOTU/genome_to_vOTU.tsv"

target_vfam_col <- "vFAM"
target_vfam     <- "vFAM_1"

votu_dist_files <- list(
  inphared   = file.path(dist_dir, "vOTU-inphared_dist.txt"),
  prophagedb = file.path(dist_dir, "vOTU-prophagedb_dist.txt"),
  uhgv       = file.path(dist_dir, "vOTU-uhgv_votu_dist.txt")
)

normalize_phage_id <- function(x) {
  x <- as.character(x)
  x <- basename(x)
  x <- gsub("^allpp\\.part_|^activepp\\.part_|^phage_depth_", "", x)
  x <- gsub("\\.fasta$|\\.fa$|\\.fna$|\\.txt$", "", x, ignore.case = TRUE)
  x <- gsub("\\s.*$", "", x)
  x <- gsub("-", "_", x)
  x
}

normalize_votu <- function(x) {
  x <- as.character(x)
  x <- trimws(x)
  x <- gsub("-", "_", x)
  x
}

metadata <- fread(metadata_path, sep = "\t", quote = "")
stopifnot(all(c("vOTU", target_vfam_col) %in% names(metadata)))

metadata[, vOTU_norm := normalize_votu(vOTU)]
metadata[, vFAM_norm := trimws(as.character(get(target_vfam_col)))]

vfam_votus <- unique(metadata[
  !is.na(vFAM_norm) & vFAM_norm == target_vfam &
    !is.na(vOTU_norm) & vOTU_norm != "",
  vOTU_norm
])
if (length(vfam_votus) == 0) {
  stop("No vOTUs found for ", target_vfam, ". Check column `", target_vfam_col, "` and its values.")
}

g2v <- fread(genome_to_votu_path, header = FALSE, col.names = c("Genome_Contig", "vOTU", "Rep_Contig"))
g2v[, vOTU_norm   := normalize_votu(vOTU)]
g2v[, rep_id_norm := normalize_phage_id(Rep_Contig)]

vfam_rep_ids <- unique(g2v[vOTU_norm %in% vfam_votus & !is.na(rep_id_norm) & rep_id_norm != "", rep_id_norm])
if (length(vfam_rep_ids) == 0) {
  stop("No representative genome IDs found for ", target_vfam, ".")
}

process_dist_file <- function(filepath, db_name) {
  if (!file.exists(filepath)) stop("File not found: ", filepath)
  dt <- fread(filepath, header = FALSE, select = c(1, 3), col.names = c("query_path", "distance"))
  dt[, query_id := normalize_phage_id(query_path)]
  dt[, distance := suppressWarnings(as.numeric(distance))]
  dt <- dt[!is.na(query_id) & query_id != "" & !is.na(distance) & is.finite(distance)]
  min_dt <- dt[, .(min_dist = min(distance)), by = query_id]
  setnames(min_dt, "min_dist", db_name)
  min_dt
}

votu_dist <- Reduce(
  function(x, y) merge(x, y, by = "query_id", all = TRUE),
  lapply(names(votu_dist_files), function(db) process_dist_file(votu_dist_files[[db]], db))
)

plot_df <- melt(
  votu_dist[query_id %in% vfam_rep_ids],
  id.vars = "query_id",
  measure.vars = c("inphared", "prophagedb", "uhgv"),
  variable.name = "Database",
  value.name = "Genetic_Distance"
)
plot_df <- plot_df[!is.na(Genetic_Distance) & is.finite(Genetic_Distance)]
plot_df[, Database_fct := factor(Database, levels = c("inphared", "prophagedb", "uhgv"))]

n_vfam <- uniqueN(plot_df$query_id)
if (n_vfam == 0) stop("No finite Mash distances retained for ", target_vfam, ".")

summary_df <- plot_df[, .(
  n      = uniqueN(query_id),
  median = median(Genetic_Distance),
  q25    = quantile(Genetic_Distance, 0.25),
  q75    = quantile(Genetic_Distance, 0.75),
  min    = min(Genetic_Distance),
  max    = max(Genetic_Distance)
), by = .(Database)]
summary_df[, Database := factor(Database, levels = c("inphared", "prophagedb", "uhgv"))]
setorder(summary_df, Database)

fwrite(summary_df, file.path(dist_dir, "vFAM1_mindist_summary.tsv"), sep = "\t")
fwrite(plot_df[, .(query_id, Database, Genetic_Distance)], file.path(dist_dir, "vFAM1_mindist_long.tsv"), sep = "\t")

annot_df <- plot_df[, .(y_pos = max(Genetic_Distance), median_dist = median(Genetic_Distance)), by = Database_fct]
annot_df[, label := paste0("median = ", formatC(median_dist, format = "f", digits = 3))]

p <- ggplot(plot_df, aes(x = Database_fct, y = Genetic_Distance)) +
  geom_boxplot(
    fill = "#2A9D8F",
    width = 0.55,
    alpha = 0.85,
    outlier.shape = NA,
    color = "black",
    linewidth = 0.55
  ) +
  geom_jitter(
    width = 0.12,
    height = 0,
    size = 1.1,
    alpha = 0.35,
    color = "#1D3557"
  ) +
  geom_text(
    data = annot_df,
    aes(x = Database_fct, y = y_pos, label = label),
    inherit.aes = FALSE,
    vjust = -0.6,
    size = 3.2,
    fontface = "bold.italic"
  ) +
  scale_x_discrete(labels = c(
    "inphared"   = "INPHARED",
    "prophagedb" = "ProphageDB",
    "uhgv"       = "UHGV"
  )) +
  scale_y_continuous(expand = expansion(mult = c(0.04, 0.14))) +
  theme_bw(base_size = 12) +
  labs(
    title = paste0(target_vfam, " Reference Database Genetic Distance"),
    subtitle = paste0(
      "vOTU representatives of ", target_vfam, " (n = ", n_vfam, ")\n",
      "Y-axis: minimum Mash distance to each reference database"
    ),
    x = "Reference Database",
    y = "Min Mash Distance"
  ) +
  theme(
    axis.text.x        = element_text(size = 12, face = "bold"),
    axis.text.y        = element_text(size = 11),
    axis.title         = element_text(size = 13, face = "bold"),
    plot.title         = element_text(size = 14, face = "bold"),
    plot.subtitle      = element_text(size = 9.5, color = "grey25", lineheight = 1.1),
    panel.grid.major.x = element_blank(),
    panel.grid.minor   = element_blank()
  )

out_pdf <- file.path(dist_dir, "vFAM1_bindash_mindist.pdf")
ggsave(filename = out_pdf, plot = p, width = 7.2, height = 5.6, dpi = 300)