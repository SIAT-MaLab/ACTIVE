#!/usr/bin/env python3
"""Annotate vContact2 genome_by_genome table for vFAM1.

vFAM1 genomes: vSUBFAM / vGENUS / is_active / is_SAvOTU / is_hanky_like
INPHARED genomes: all new columns = REF
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

# --- paths ---
VC_FILE = Path("3_vcontact2/genome_by_genome_overview.csv")
METADATA_FILE = Path("4_hanky-like/vFAM1_metadata_annotated_with_source.tsv")
SA_FILE = Path("../../sa_prophage_results/stats_baseline_vOTU.tsv")
VFAM_FA = Path("vFAM_1_genomes.fasta")
REF_FA = Path("INPHARED_GTDBr220_Bacteroidales.fa")
OUT_FILE = Path("3_vcontact2/genome_by_genome_annotated.csv")

NA_VALS = ["", "NA", "na", "Unclassified", "NULL", "None"]
NEW_COLS = ["Source", "vOTU", "vSUBFAM", "vGENUS", "is_active", "is_SAvOTU", "is_hanky_like"]


def log(msg: str) -> None:
    print(msg, flush=True)


def die(msg: str) -> None:
    sys.exit(f"ERROR: {msg}")


def norm_id(x) -> str:
    if pd.isna(x):
        return ""
    return str(x).replace("-", "_")


def file_key(x) -> str:
    s = "" if pd.isna(x) else str(x)
    if s.startswith("phage_depth_"):
        s = s[len("phage_depth_") :]
    if s.endswith(".txt"):
        s = s[:-4]
    return norm_id(s)


def read_fasta_ids(path: Path) -> list[str]:
    if not path.exists():
        die(f"missing fasta: {path}")
    ids = []
    with path.open() as f:
        for line in f:
            if line.startswith(">"):
                ids.append(line[1:].split()[0])
    return ids


def fill_by_source(source: pd.Series, value: pd.Series, user_default: str, empty_as_unclassified: bool = False) -> pd.Series:
    out = value.astype("string")
    if empty_as_unclassified:
        out = out.where(out.notna() & (out != ""), "Unclassified")
    else:
        out = out.fillna(user_default)
    return pd.Series(
        ["REF" if s == "REF" else "Unknown" if s == "Unknown" else v for s, v in zip(source, out)],
        index=source.index,
        dtype="string",
    )


def main() -> None:
    for p in (VC_FILE, METADATA_FILE, SA_FILE, VFAM_FA, REF_FA):
        if not p.exists():
            die(f"missing file: {p}")

    log("[1/5] reading fasta headers (streaming)...")
    vfam_ids = read_fasta_ids(VFAM_FA)
    ref_ids = read_fasta_ids(REF_FA)
    vfam_key = set(map(norm_id, vfam_ids))
    ref_key = set(map(norm_id, ref_ids))
    log(f"    vFAM1 fasta: {len(vfam_ids):,}  INPHARED fasta: {len(ref_ids):,}")

    log("[2/5] reading tables...")
    vc = pd.read_csv(VC_FILE)
    if "Genome" not in vc.columns:
        die(f"no Genome column in {VC_FILE}; columns={list(vc.columns)}")
    log(f"    VC genomes: {len(vc):,}")

    meta = pd.read_csv(METADATA_FILE, sep="\t", na_values=NA_VALS, keep_default_na=True)
    need = {"phage_id", "File", "vOTU", "vSUBFAM", "vGENUS", "Activity_Score", "hanky_blastn"}
    missing = need - set(meta.columns)
    if missing:
        die(f"metadata missing columns: {missing}")

    meta = meta.copy()
    meta["vOTU"] = meta["vOTU"].map(norm_id)
    meta["Activity_Score"] = pd.to_numeric(meta["Activity_Score"], errors="coerce")
    meta["hanky_blastn"] = meta["hanky_blastn"].astype("string").str.lower()
    meta["vGENUS"] = meta["vGENUS"].astype("string").fillna("Unclassified")
    meta["vSUBFAM"] = meta["vSUBFAM"].astype("string").fillna("Unclassified")
    meta["key_phage"] = meta["phage_id"].map(norm_id)
    meta["key_file"] = meta["File"].map(file_key)
    meta["is_active"] = (meta["Activity_Score"].notna() & (meta["Activity_Score"] >= 0.8)).map({True: "Yes", False: "No"})
    meta["is_hanky_like"] = (meta["hanky_blastn"] == "yes").map({True: "Yes", False: "No"})

    sa = pd.read_csv(SA_FILE, sep="\t", na_values=NA_VALS)
    sa["vOTU"] = sa["vOTU"].map(norm_id)
    sa["is_SAvOTU"] = (sa["Significance_Type"] == "Significant").map({True: "Yes", False: "No"})
    sa = sa.drop_duplicates("vOTU")[["vOTU", "is_SAvOTU"]]

    genome = meta.merge(sa, on="vOTU", how="left")
    genome["is_SAvOTU"] = genome["is_SAvOTU"].fillna("No")
    keep = ["vOTU", "vSUBFAM", "vGENUS", "is_active", "is_SAvOTU", "is_hanky_like"]

    by_phage = (
        genome.loc[genome["key_phage"] != "", ["key_phage", *keep]]
        .drop_duplicates("key_phage")
        .rename(columns={"key_phage": "genome_key"})
    )
    by_file = (
        genome.loc[genome["key_file"] != "", ["key_file", *keep]]
        .drop_duplicates("key_file")
        .rename(columns={"key_file": "genome_key"})
        .rename(columns={c: f"{c}_file" for c in keep})
    )

    log("[3/5] joining onto vContact2 table...")
    out = vc.copy()
    out["genome_key"] = out["Genome"].map(norm_id)
    out = out.merge(by_phage, on="genome_key", how="left")
    out = out.merge(by_file, on="genome_key", how="left")

    for c in keep:
        out[c] = out[c].combine_first(out[f"{c}_file"])

    in_vfam = out["genome_key"].isin(vfam_key)
    in_ref = out["genome_key"].isin(ref_key)
    out["Source"] = "Unknown"
    out.loc[in_vfam, "Source"] = "vFAM1"
    out.loc[in_ref & ~in_vfam, "Source"] = "REF"

    out["vOTU"] = fill_by_source(out["Source"], out["vOTU"], "Unclassified", empty_as_unclassified=True)
    out["vSUBFAM"] = fill_by_source(out["Source"], out["vSUBFAM"], "Unclassified", empty_as_unclassified=True)
    out["vGENUS"] = fill_by_source(out["Source"], out["vGENUS"], "Unclassified", empty_as_unclassified=True)
    out["is_active"] = fill_by_source(out["Source"], out["is_active"], "No")
    out["is_SAvOTU"] = fill_by_source(out["Source"], out["is_SAvOTU"], "No")
    out["is_hanky_like"] = fill_by_source(out["Source"], out["is_hanky_like"], "No")

    drop = ["genome_key", *[c for c in out.columns if c.endswith("_file")]]
    out = out.drop(columns=drop)
    rest = [c for c in out.columns if c not in (["Genome"] + NEW_COLS)]
    out = out[["Genome"] + NEW_COLS + rest]

    log(f"[4/5] writing {OUT_FILE} ...")
    OUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(OUT_FILE, index=False)

    vfam = out[out["Source"] == "vFAM1"]
    unknown = out[out["Source"] == "Unknown"]
    unmatched = vfam[vfam["vOTU"] == "Unclassified"]

    log("[5/5] QC")
    log("=" * 48)
    log("vFAM1 vContact2 genome annotation QC")
    log("-" * 48)
    log(f"{'genomes in VC table':<28} {len(out)}")
    log(f"{'vFAM1 fasta':<28} {len(vfam_ids)}")
    log(f"{'INPHARED fasta':<28} {len(ref_ids)}")
    log(f"{'Source = vFAM1':<28} {len(vfam)}")
    log(f"{'Source = REF':<28} {(out['Source'] == 'REF').sum()}")
    log(f"{'Source = Unknown':<28} {len(unknown)}")
    log(f"{'vFAM1 unmatched to meta':<28} {len(unmatched)} / {len(vfam)}")
    log(f"{'active genomes':<28} {(vfam['is_active'] == 'Yes').sum()} / {len(vfam)}")
    log(f"{'SAvOTU members':<28} {(vfam['is_SAvOTU'] == 'Yes').sum()} / {len(vfam)}")
    log(f"{'hanky-like genomes':<28} {(vfam['is_hanky_like'] == 'Yes').sum()} / {len(vfam)}")
    log("=" * 48)
    log(f"written: {OUT_FILE}")

    if len(unknown):
        log("Unmapped Genome IDs:")
        for g in unknown["Genome"].head(50):
            log(f"  {g}")
        if len(unknown) > 50:
            log(f"  ... {len(unknown) - 50} more")
    if len(unmatched):
        log("vFAM1 genomes with no metadata hit:")
        for g in unmatched["Genome"].head(50):
            log(f"  {g}")
        if len(unmatched) > 50:
            log(f"  ... {len(unmatched) - 50} more")


if __name__ == "__main__":
    main()
