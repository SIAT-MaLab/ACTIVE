mkdir -p 3_vcontact2

vcontact2_gene2genome --proteins 2_genomad_annot/allvirus_annotate/allvirus_proteins.faa --output 3_vcontact2/allout_map.csv --source-type Prodigal-FAA

vcontact2 -r 2_genomad_annot/allvirus_annotate/allvirus_proteins.faa -p 3_vcontact2/allout_map.csv --output-dir 3_vcontact2 -t 20 --db None

