#!/bin/bash

cat 5_vOTU_tree/BK010464_terL.fasta 5_vOTU_tree/vFAM1_All_vOTU_TerL_sequences.faa > combined_terL.faa

awk -F'\t' '
NR==FNR {
    if (FNR > 1) {
        clean_id = $5;
        gsub(/-/, "_", clean_id);
        map[clean_id] = $1;
    }
    next;
}
{
    if ($0 ~ /^>/) {
        full_id = $1;
        sub(/^>/, "", full_id);
        if (full_id in map) {
            sub(/^>[^ ]+/, ">" map[full_id], $0);
        }
    }
    print $0;
}
' 5_vOTU_tree/TerL_All_vOTU_Table.tsv combined_terL.faa > tmp_terL.faa

mafft --thread 20 --auto tmp_terL.faa > terL_aligned.fasta

fasttree -wag terL_aligned.fasta > 5_vOTU_tree/vFAM1_votu_terL.tree

rm combined_terL.faa tmp_terL.faa terL_aligned.fasta
