makeblastdb -in "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/rep_sataxon/1_vfam/vFAM_1_genomes.fasta" -dbtype nucl -out virus_db
blastn \
  -query BK010646.fna \
  -db virus_db \
  -evalue 1e-5 \
  -max_hsps 1 \
  -max_target_seqs 50000 \
  -outfmt 6 -num_threads 10 \
  > hankyphage_vs_allphage.blastn.tsv
awk '$4 >= 4283' hankyphage_vs_allphage.blastn.tsv > 4_hanky-like/hankyphage_like_hits.tsv
rm hankyphage_vs_allphage.blastn.tsv virus_db*

