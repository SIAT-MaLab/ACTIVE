cat vFAM_1_genomes.fasta INPHARED_GTDBr220_Bacteroidales.fa > allvirus.fna
genomad annotate --threads 28 --use-minimal-db allvirus.fna 2_genomad_annot "/home/malab/databases_of_malab/genomad_db/genomad_db/"
