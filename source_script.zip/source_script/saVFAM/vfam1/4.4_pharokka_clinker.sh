mkdir -p 4_hanky-like/annot 4_hanky-like/clinker_output
#cat "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/rep_sataxon/1_vfam/BK010646.fna" 4_hanky-like/compare/vFAM1_active_reps.fasta > 4_hanky-like/compare/all_reps.fasta
#seqkit stats 4_hanky-like/compare/all_reps.fasta
#pharokka.py -i 4_hanky-like/compare/all_reps.fasta -o 4_hanky-like/annot -t 26 -f -m -s --meta_hmm --skip_mash -g prodigal-gv -d "/home/huangyan/databaseHY/pharokka_v1.8.0_databases/"

clinker 4_hanky-like/annot/single*gbk*/*.gbk -o 4_hanky-like/clinker_output/vFAM1.txt -dl "\t" -j 15 -p 4_hanky-like/clinker_output/vFAM1.html
