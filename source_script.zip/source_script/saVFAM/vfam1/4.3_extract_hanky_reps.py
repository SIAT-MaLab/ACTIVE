import os
import sys
import csv
import subprocess
from collections import Counter

STATS_FILE = "../../1_sataxon/stats_baseline_vOTU.tsv"
VOTU_MAP_FILE = "../../../taxonomy/vOTU/genome_to_vOTU.tsv"
METADATA_FILE = "../../../metadata/allpp_metadata.tsv"
FASTA_FILE = "../../../metadata/allpp.fasta"
HANKY_HITS_FILE = "4_hanky-like/hankyphage_like_hits.tsv"

VFAM_TARGET = "vFAM_1"

OUT_DIR = "4_hanky-like/compare"
OUT_TSV = os.path.join(OUT_DIR, "vFAM1_active_reps_taxonomy.tsv")
OUT_FASTA = os.path.join(OUT_DIR, "vFAM1_active_reps.fasta")
TEMP_ID_LIST = os.path.join(OUT_DIR, "temp_seqkit_ids.txt")

def norm_id(raw_id):
    if not raw_id or raw_id == "NA": 
        return "NA"
    return str(raw_id).replace('-', '_').strip().upper()

def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    fasta_id_map = {}
    if not os.path.exists(FASTA_FILE):
        sys.exit(1)
        
    with open(FASTA_FILE, 'r') as f:
        for line in f:
            if line.startswith('>'):
                original_id = line[1:].strip().split()[0]
                fasta_id_map[norm_id(original_id)] = original_id

    vfam1_genomes = set()
    votu_to_meta = {}
    
    with open(METADATA_FILE, 'r') as f:
        reader = csv.DictReader(f, delimiter='\t')
        for row in reader:
            vfam = norm_id(row.get('vFAM', ''))
            if vfam == norm_id(VFAM_TARGET):
                p_id = norm_id(row.get('phage_id', ''))
                votu = norm_id(row.get('vOTU', ''))
                vfam1_genomes.add(p_id)
                if votu not in votu_to_meta:
                    votu_to_meta[votu] = row
    
    vfam1_vOTUs = set(votu_to_meta.keys())

    significant_votus = set()
    with open(STATS_FILE, 'r') as f:
        reader = csv.DictReader(f, delimiter='\t')
        for row in reader:
            if row.get('Significance_Type', '') == 'Significant':
                votu = norm_id(row.get('vOTU', ''))
                if votu != "NA":
                    significant_votus.add(votu)

    target_votus = vfam1_vOTUs.intersection(significant_votus)

    if not target_votus:
        return

    votu_to_rep = {}
    
    with open(VOTU_MAP_FILE, 'r') as f:
        for row in csv.reader(f, delimiter='\t'):
            if len(row) >= 3:
                votu_id = norm_id(row[1])
                rep_id = norm_id(row[2])
                votu_to_rep[votu_id] = rep_id
                
    hanky_hit_genomes = set()
    with open(HANKY_HITS_FILE, 'r') as f:
        for row in csv.reader(f, delimiter='\t'):
            if len(row) >= 2:
                hanky_hit_genomes.add(norm_id(row[1]))

    votu_hanky_count = Counter()
    with open(VOTU_MAP_FILE, 'r') as f:
        for row in csv.reader(f, delimiter='\t'):
            if len(row) >= 3:
                member_id = norm_id(row[0])
                votu_id = norm_id(row[1])
                if member_id in hanky_hit_genomes:
                    votu_hanky_count[votu_id] += 1

    out_rows = []
    exact_ids_to_extract = []

    for votu in sorted(list(target_votus)):
        norm_rep = votu_to_rep.get(votu)
        if not norm_rep:
            continue
            
        exact_rep_id = fasta_id_map.get(norm_rep)
        if not exact_rep_id:
            exact_rep_id = norm_rep 
            
        exact_ids_to_extract.append(exact_rep_id)

        meta_row = votu_to_meta.get(votu, {})
        
        hanky_count = votu_hanky_count.get(votu, 0)
        has_hanky_str = "Yes" if hanky_count > 0 else "No"
        
        out_rows.append({
            'Rep_Genome_ID': exact_rep_id,
            'vOTU_ID': meta_row.get('vOTU', votu),
            'vFAM': meta_row.get('vFAM', 'NA'),
            'vSUBFAM': meta_row.get('vSUBFAM', 'NA'),
            'host_Phylum': meta_row.get('host_Phylum', 'NA'),
            'host_Class': meta_row.get('host_Class', 'NA'),
            'host_Order': meta_row.get('host_Order', 'NA'),
            'host_Family': meta_row.get('host_Family', 'NA'),
            'host_Genus': meta_row.get('host_Genus', 'NA'),
            'host_Species': meta_row.get('host_Species', 'NA'),
            'Activity_Score': meta_row.get('Activity_Score', 'NA'),
            'Has_Hanky_In_vOTU': has_hanky_str,
            'Hanky_Count_In_vOTU': hanky_count
        })

    headers = [
        'Rep_Genome_ID', 'vOTU_ID', 'vFAM', 'vSUBFAM', 
        'host_Phylum', 'host_Class', 'host_Order', 'host_Family', 'host_Genus', 'host_Species', 
        'Activity_Score', 'Has_Hanky_In_vOTU', 'Hanky_Count_In_vOTU'
    ]
    with open(OUT_TSV, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers, delimiter='\t')
        writer.writeheader()
        writer.writerows(out_rows)

    with open(TEMP_ID_LIST, 'w') as f:
        for eid in exact_ids_to_extract:
            f.write(eid + '\n')

    try:
        cmd = ['seqkit', 'grep', '-f', TEMP_ID_LIST, FASTA_FILE, '-o', OUT_FASTA]
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError:
        pass
    except FileNotFoundError:
        pass
    finally:
        if os.path.exists(TEMP_ID_LIST):
            os.remove(TEMP_ID_LIST)

if __name__ == "__main__":
    main()