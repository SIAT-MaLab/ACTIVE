cat Heliusvirales_1032_genomes.fna VFC1.fasta vFAM_7_genomes.fasta > allvirus.fna
genomad annotate --threads 28 --use-minimal-db allvirus.fna 1_genomad_annot "/home/malab/databases_of_malab/genomad_db/genomad_db/"
