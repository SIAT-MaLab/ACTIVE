mkdir -p 2_vcontact2

vcontact2_gene2genome --proteins 1_genomad_annot/allvirus_annotate/allvirus_proteins.faa --output 2_vcontact2/allout_map.csv --source-type Prodigal-FAA

vcontact2 -r 1_genomad_annot/allvirus_annotate/allvirus_proteins.faa -p 2_vcontact2/allout_map.csv --output-dir 2_vcontact2 -t 22 --db None

