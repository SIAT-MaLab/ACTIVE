#!/bin/bash
set -e

# 帮助信息
usage() {
    echo "Usage: $0 -f <vFAM_fasta> -m <genome_to_vOTU.tsv> -d <database_fasta> -o <output_fasta>"
    echo "  -f : 输入的 vFAM FASTA 文件 (例如: vFAM_9_genomes.fasta)"
    echo "  -m : genome_to_vOTU.tsv 对应表"
    echo "  -d : 包含所有基因组序列的母数据库 FASTA"
    echo "  -o : 输出的代表基因组 FASTA 文件"
    exit 1
}

while getopts "f:m:d:o:h" opt; do
    case $opt in
        f) VFAM_FASTA=$OPTARG ;;
        m) MAP_TSV=$OPTARG ;;
        d) DB_FASTA=$OPTARG ;;
        o) OUTPUT_FASTA=$OPTARG ;;
        h) usage ;;
        *) usage ;;
    esac
done

if [ -z "$VFAM_FASTA" ] || [ -z "$MAP_TSV" ] || [ -z "$DB_FASTA" ] || [ -z "$OUTPUT_FASTA" ]; then
    usage
fi

echo "[1/3] Extracting query IDs from $VFAM_FASTA..."

grep '^>' "$VFAM_FASTA" | awk '{print $1}' | sed 's/>//' > .tmp_vfam_ids.txt

echo "[2/3] Mapping to representative genomes in $MAP_TSV..."

awk 'FNR==NR {vfam[$1]; next} ($1 in vfam) {print $3}' .tmp_vfam_ids.txt "$MAP_TSV" | sort -u > .tmp_rep_ids.txt

NUM_REPS=$(wc -l < .tmp_rep_ids.txt)
echo "Found $NUM_REPS unique representative genomes."

echo "[3/3] Extracting sequences using seqkit..."
seqkit grep -f .tmp_rep_ids.txt "$DB_FASTA" -o "$OUTPUT_FASTA"


rm -f .tmp_vfam_ids.txt .tmp_rep_ids.txt

echo "Done! Output saved to $OUTPUT_FASTA"
