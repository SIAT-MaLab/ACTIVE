
mkdir -p 5_rep_compare/clinker_output
clinker 5_rep_compare/*.gbk -o 5_rep_compare/clinker_output/vFAM7.txt -dl "\t" -j 15 -p 5_rep_compare/clinker_output/vFAM7.html

