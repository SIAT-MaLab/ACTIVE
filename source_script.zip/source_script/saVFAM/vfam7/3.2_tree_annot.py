#!/usr/bin/env python3
import os
import pandas as pd
import numpy as np

HELIUS_META_PATH = "Helius_metadata.csv"
USER_PP_META_PATH = "../../../metadata/allpp_metadata.tsv"
USER_FASTA_PATH = "vFAM_7_genomes.fasta"
SIGNIFICANCE_PATH = "../../1_sataxon/stats_baseline_vOTU.tsv"
OUTPUT_PATH = "3_phylo_tree/unified_tree_metadata.tsv"

def transform_id(original_id):
    if pd.isna(original_id):
        return np.nan
    cleaned = str(original_id).split("_CDS")[0]
    cleaned = cleaned.replace("-", "_")
    return cleaned

vfam7_ids = []
if os.path.exists(USER_FASTA_PATH):
    with open(USER_FASTA_PATH, "r") as f:
        for line in f:
            if line.startswith(">"):
                seq_id = line.strip().split()[0][1:]
                vfam7_ids.append(transform_id(seq_id))
    vfam7_ids = list(set(vfam7_ids))
else:
    raise FileNotFoundError(USER_FASTA_PATH)

df_helius = pd.read_csv(HELIUS_META_PATH, skiprows=1)
df_helius['tree_id'] = df_helius['contigName'].apply(transform_id)

family_counts = df_helius['Family'].value_counts()
subfamily_counts = df_helius['Subfamily'].value_counts()

df_helius['Family_grouped'] = df_helius['Family'].apply(
    lambda x: x if pd.notna(x) and family_counts[x] > 10 else "other_family_helius"
)
df_helius['Subfamily_grouped'] = df_helius['Subfamily'].apply(
    lambda x: x if pd.notna(x) and subfamily_counts[x] > 10 else "other_subfamily_helius"
)

helius_final = pd.DataFrame({
    'tree_id': df_helius['tree_id'],
    'Source': 'helius',
    'Family': df_helius['Family_grouped'],
    'Subfamily': df_helius['Subfamily_grouped'],
    'vSUBFAM': 'helius_non_user',
    'vGENUS': 'helius_non_user',
    'host_Phylum': 'Unknown_Helius_Host',
    'Activity': 'Non-active_Helius',
    'vOTU_Significance': 'Non-significant_Helius'
})

df_user = pd.read_csv(USER_PP_META_PATH, sep='\t', low_memory=False)
df_user['tree_id'] = df_user['phage_id'].apply(transform_id)

df_user_filtered = df_user[df_user['tree_id'].isin(vfam7_ids)].copy()
matched_user_ids = set(df_user_filtered['tree_id'].tolist())

missing_ids = [idx for idx in vfam7_ids if idx not in matched_user_ids]
if len(missing_ids) > 0:
    df_missing = pd.DataFrame({
        'tree_id': missing_ids,
        'Source': 'user_pp',
        'Family': 'user_non_helius',
        'Subfamily': 'user_non_helius',
        'vSUBFAM': 'unclassified_user_vSUBFAM',
        'vGENUS': 'unclassified_user_vGENUS',
        'host_Phylum': 'Unknown_Host',
        'Activity': 'Inactive',
        'vOTU_Significance': 'Non-significant'
    })
else:
    df_missing = pd.DataFrame()

if len(df_user_filtered) > 0:
    df_user_filtered['Activity_Score'] = pd.to_numeric(df_user_filtered['Activity_Score'], errors='coerce')

    top5_vsubfam = df_user_filtered['vSUBFAM'].dropna().value_counts().nlargest(5).index.tolist()
    top5_vgenus = df_user_filtered['vGENUS'].dropna().value_counts().nlargest(5).index.tolist()

    df_user_filtered['vSUBFAM_grouped'] = df_user_filtered['vSUBFAM'].apply(
        lambda x: x if pd.notna(x) and x in top5_vsubfam else "other_vSUBFAM"
    )
    df_user_filtered['vGENUS_grouped'] = df_user_filtered['vGENUS'].apply(
        lambda x: x if pd.notna(x) and x in top5_vgenus else "other_vGENUS"
    )

    df_user_filtered['Activity_Status'] = df_user_filtered['Activity_Score'].apply(
        lambda x: 'Active' if pd.notna(x) and x >= 0.8 else 'Inactive'
    )

    df_sig = pd.read_csv(SIGNIFICANCE_PATH, sep='\t')
    significant_votus = set(df_sig[df_sig['Significance_Type'] == 'Significant']['vOTU'].dropna().tolist())

    df_user_filtered['vOTU_Sig_Status'] = df_user_filtered['vOTU'].apply(
        lambda x: 'Significant' if x in significant_votus else 'Non-significant'
    )

    def determine_source(row):
        if row['vOTU_Sig_Status'] == 'Significant':
            votuid = str(row['vOTU']).strip()
            return f"savotu_{votuid}"
        else:
            return 'user_pp'

    df_user_filtered['Source_refined'] = df_user_filtered.apply(determine_source, axis=1)

    user_final = pd.DataFrame({
        'tree_id': df_user_filtered['tree_id'],
        'Source': df_user_filtered['Source_refined'],
        'Family': 'user_non_helius',
        'Subfamily': 'user_non_helius',
        'vSUBFAM': df_user_filtered['vSUBFAM_grouped'],
        'vGENUS': df_user_filtered['vGENUS_grouped'],
        'host_Phylum': df_user_filtered['host_Phylum'].fillna('Unknown_Host'),
        'Activity': df_user_filtered['Activity_Status'],
        'vOTU_Significance': df_user_filtered['vOTU_Sig_Status']
    })
else:
    user_final = pd.DataFrame()

combined_metadata = pd.concat([helius_final, user_final, df_missing], ignore_index=True)
combined_metadata = combined_metadata.drop_duplicates(subset=['tree_id'], keep='first')

os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
combined_metadata.to_csv(OUTPUT_PATH, sep='\t', index=False)