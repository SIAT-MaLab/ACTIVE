annotdir=3_phylo_tree/pharokka_annot
phylodir=3_phylo_tree/fasttree
mkdir -p $annotdir $phylodir

sed -e 's/_CDS.*//' -e 's/\(.*\)-\([^-]*\)$/\1_\2/' $annotdir/terL.faa > tmp_terL.faa
sed -e 's/_CDS.*//' -e 's/\(.*\)-\([^-]*\)$/\1_\2/' "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/rep_sataxon/tree_ref_lambda/lambda_annot/terL.faa" > tmp_lambda_terL.faa
grep "^>" tmp_terL.faa | sort | uniq -d > dups.txt
awk 'NR==FNR{bad[$1]=1; next} /^>/{flag=0; if($1 in bad) flag=1} !flag' dups.txt tmp_terL.faa > new_terL.faa
cat new_terL.faa tmp_lambda_terL.faa > $phylodir/all_terL.faa
grep '>' $phylodir/all_terL.faa | wc -l
grep 'YHLY' $phylodir/all_terL.faa
mafft --thread 20 --auto $phylodir/all_terL.faa > terL_aligned.fasta
fasttree -wag terL_aligned.fasta > $phylodir/terL_fasttree.tree
rm terL_aligned.fasta new_terL.faa tmp_lambda_terL.faa tmp_terL.faa 
mv dups.txt $phylodir/

cat "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/rep_sataxon/tree_ref_lambda/lambda_annot/pharokka_cds_final_merged_output.tsv" $annotdir/pharokka_cds_final_merged_output.tsv > all_annot.tsv
cat "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/rep_sataxon/tree_ref_lambda/lambda_annot/prodigal-gv.faa" $annotdir/prodigal-gv.faa > allprotein.faa
grep -i "portal" all_annot.tsv | cut -f1 > $phylodir/id_portal.txt
grep -i "major head" all_annot.tsv | cut -f1 > $phylodir/id_mcp.txt
awk 'NR==FNR{ids[$1]; next} /^>/{id=$1; sub(/^>/, "", id); flag=(id in ids)} flag' $phylodir/id_portal.txt allprotein.faa > $phylodir/portal_proteins.faa
awk 'NR==FNR{ids[$1]; next} /^>/{id=$1; sub(/^>/, "", id); flag=(id in ids)} flag' $phylodir/id_mcp.txt allprotein.faa > $phylodir/mcp_proteins.faa
sed -e 's/_CDS.*//' -e 's/\(.*\)-\([^-]*\)$/\1_\2/' $phylodir/mcp_proteins.faa > tmp.faa
grep "^>" tmp.faa | sort | uniq -d > $phylodir/dups_mcp.txt
awk 'NR==FNR{bad[$1]=1; next} /^>/{flag=0; if($1 in bad) flag=1} !flag' $phylodir/dups_mcp.txt tmp.faa > new_mcp.faa
mafft --thread 20 --auto new_mcp.faa > mcp_aligned.fasta
fasttree -wag mcp_aligned.fasta > $phylodir/mcp_fasttree.tree
rm mcp_aligned.fasta new_mcp.faa tmp.faa
sed -e 's/_CDS.*//' -e 's/\(.*\)-\([^-]*\)$/\1_\2/' $phylodir/portal_proteins.faa > tmp.faa
grep "^>" tmp.faa | sort | uniq -d > $phylodir/dups_portal.txt
awk 'NR==FNR{bad[$1]=1; next} /^>/{flag=0; if($1 in bad) flag=1} !flag' $phylodir/dups_portal.txt tmp.faa > new_portal.faa
mafft --thread 20 --auto new_portal.faa > portal_aligned.fasta
fasttree -wag portal_aligned.fasta > $phylodir/portal_fasttree.tree
rm tmp.faa portal_aligned.fasta new_portal.faa 
rm all_annot.tsv allprotein.faa