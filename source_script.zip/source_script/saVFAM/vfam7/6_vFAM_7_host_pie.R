input_file <- "../../../metadata/allpp_metadata.tsv"
output_image <- paste0("vFAM_7_host_pie.pdf")
target_vfam <- "vFAM_7"

PHYLUM_COLORS <- c(
  "Bacillota_A"      = "#dce8ef",
  "Bacillota_C"      = "#add2e5",
  "Bacillota_I"      = "#34666b",
  "Bacillota"        = "#7abbce",
  "Bacillota_B"      = "#769499",
  "Actinomycetota"   = "#f5cfa6",
  "Bacteroidota"     = "#efe3ef",
  "Verrucomicrobiota"= "#d4d68a",
  "Pseudomonadota"   = "#e68f9f",
  "Desulfobacterota" = "#d5d5d6",
  "Fusobacteriota"   = "#b7a3c9",
  "Synergistota"     = "#414141"
)

metadata <- read.delim(input_file, sep = "\t", stringsAsFactors = FALSE, 
                       check.names = FALSE, header = TRUE)

prophages <- metadata[metadata$vFAM == target_vfam, ]

host_info <- subset(prophages, !is.na(host_Family) & !is.na(host_Phylum),
                    select = c("host_Family", "host_Phylum"))

family_counts <- sort(table(host_info$host_Family), decreasing = TRUE)
top10_families <- names(family_counts)[1:min(10, length(family_counts))]

host_info$family <- host_info$host_Family
host_info$family[!host_info$family %in% top10_families] <- "other"
host_info$phylum  <- host_info$host_Phylum
host_info$phylum[host_info$family == "other"] <- "other"

library(dplyr)
final_df <- host_info %>%
  group_by(family = family, phylum = phylum) %>%
  summarise(count = n(), .groups = "drop") %>%
  arrange(desc(count))

if ("other" %in% final_df$family) {
  final_df <- final_df[order(final_df$family == "other"), ]
}

final_df$percentage <- round(final_df$count / sum(final_df$count) * 100, 1)

phylum_levels <- unique(final_df$phylum)
phylum_color <- sapply(phylum_levels, function(p) {
  if (p %in% names(PHYLUM_COLORS)) return(PHYLUM_COLORS[p])
  else if (p == "other") return("white")
  else return("grey50")
})
names(phylum_color) <- phylum_levels

library(ggplot2)

p <- ggplot(final_df, aes(x = "", y = count, fill = phylum)) +
  geom_bar(stat = "identity", width = 1, color = "black", linewidth = 0.3) +
  coord_polar(theta = "y", start = 0) +
  theme_void() +
  scale_fill_manual(values = phylum_color) +
  labs(title = paste("Host source of", target_vfam)) +
  geom_text(aes(label = paste0(family, " (", count, ")")),
            position = position_stack(vjust = 0.5),
            size = 4, color = "black") +
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 16, face = "bold"))

ggsave(output_image, plot = p, width = 8, height = 7)