#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
from Bio import SeqIO

DIR = Path(".")

FASTA_SOURCES = [
    (DIR / "Heliusvirales_1032_genomes.fna", "Heliusvirales"),
    (DIR / "VFC1.fasta", "VFC1"),
    (DIR / "vFAM_7_genomes.fasta", "vFAM_7"),
]

VC2_OVERVIEW = DIR / "2_vcontact2/vfam7_genome_by_genome_overview.csv"

ALLPP_META_TSV    = DIR / "../../../metadata/allpp_metadata.tsv"
BASELINE_STAT_TSV = DIR / "../../1_sataxon/stats_baseline_vOTU.tsv"

OUT_GENOME_ANNOT = DIR / "2_vcontact2/vfam7_genome_annotated.tsv"

def norm_id(s):
    if pd.isna(s):
        return ""
    return str(s).strip().replace("-", "_")

genome_source_map = {}

for fasta_file, label in FASTA_SOURCES:
    count = 0
    if fasta_file.exists():
        for record in SeqIO.parse(str(fasta_file), "fasta"):
            seq_id = record.id.strip()
            genome_source_map[seq_id] = label
            genome_source_map[norm_id(seq_id)] = label
            count += 1

if not genome_source_map:
    raise FileNotFoundError("No FASTA files loaded successfully!")

allpp = pd.read_csv(ALLPP_META_TSV, sep="\t", dtype=str)
allpp["Activity_Score"] = pd.to_numeric(allpp["Activity_Score"], errors="coerce").fillna(0.0)

allpp["norm_phage_id"] = allpp["phage_id"].apply(norm_id)

votu_max_act = allpp.groupby("vOTU")["Activity_Score"].max().to_dict()

phage2votu = {}
phage2vsubfam = {}
phage2vgenus = {}
phage2act_max = {}

for _, row in allpp.iterrows():
    nid = row["norm_phage_id"]
    votu = row["vOTU"]
    phage2votu[nid] = votu
    phage2vsubfam[nid] = row.get("vSUBFAM", "NA")
    phage2vgenus[nid] = row.get("vGENUS", "NA")
    phage2act_max[nid] = votu_max_act.get(votu, 0.0)

sig_active_votus = set()
if BASELINE_STAT_TSV.exists():
    base_stat = pd.read_csv(BASELINE_STAT_TSV, sep="\t", dtype=str)
    sig_df = base_stat[base_stat["Significance_Type"] == "Significant"]
    sig_active_votus = set(sig_df["vOTU"].dropna().unique())

vc2_df = pd.read_csv(VC2_OVERVIEW, dtype=str)

annot_rows = []

for _, row in vc2_df.iterrows():
    genome = row["Genome"].strip()
    norm_g = norm_id(genome)

    source_origin = genome_source_map.get(genome, genome_source_map.get(norm_g, "Unknown"))
    if source_origin == "vFAM_7":
        source_cat = "vFAM_7"
    elif source_origin in ("Heliusvirales", "VFC1"):
        source_cat = "Reference"
    else:
        source_cat = "Unknown"

    votu = phage2votu.get(norm_g, "NA")
    vsubfam = phage2vsubfam.get(norm_g, "NA")
    vgenus = phage2vgenus.get(norm_g, "NA")
    act_score = phage2act_max.get(norm_g, None)

    if votu != "NA" and act_score is not None:
        is_active = (act_score >= 0.8)
        is_sig_active = (votu in sig_active_votus)
    else:
        is_active = False
        is_sig_active = False
        act_score = "NA"

    row_dict = row.to_dict()
    row_dict.update({
        "Source_Origin": source_origin,
        "Source_Category": source_cat,
        "vOTU": votu,
        "vSUBFAM": vsubfam,
        "vGENUS": vgenus,
        "vOTU_Max_Activity_Score": act_score,
        "Is_Active": is_active,
        "Is_Significantly_Active": is_sig_active
    })
    annot_rows.append(row_dict)

annot_df = pd.DataFrame(annot_rows)

front_cols = [
    "Genome", "Source_Origin", "Source_Category",
    "vOTU", "vSUBFAM", "vGENUS",
    "vOTU_Max_Activity_Score", "Is_Active", "Is_Significantly_Active",
    "VC Status", "VC"
]
other_cols = [c for c in annot_df.columns if c not in front_cols]
annot_df = annot_df[front_cols + other_cols]

annot_df.to_csv(OUT_GENOME_ANNOT, sep="\t", index=False)