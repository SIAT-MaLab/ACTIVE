#!/usr/bin/env python3

import os
import re
import sys
import html
from pathlib import Path
from urllib.parse import unquote

import pandas as pd
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord


# ============================================================
# 输入文件
# ============================================================

META = Path(os.path.expanduser(
    "~/databaseHY/inphared_202504/26_JAN/"
    "7Apr2026_millardlab_website_table.txt"
))

FASTA = Path(os.path.expanduser(
    "~/databaseHY/inphared_202504/26_JAN/"
    "7Apr2026_genomes.fa"
))

# GTDB-Tk release 220 taxonomy
GTDB_TAX = Path(os.path.expanduser(
    "~/anaconda3/envs/binning/share/"
    "gtdbtk-2.4.0/db/release220/taxonomy/"
    "bac120_taxonomy_r220_reps.tsv"
))


# 最终仅生成这两个文件
OUT_FASTA = Path(
    "INPHARED_GTDBr220_Bacteroidales.fa"
)

OUT_TABLE = Path(
    "INPHARED_GTDBr220_Bacteroidales.tsv"
)


# ============================================================
# 基本函数
# ============================================================

def clean_accession(x):
    """
    从以下格式中提取 accession：

    <a href="https://www.ncbi.nlm.nih.gov/nuccore/OP172833">
    OP172833</a>
    """

    x = html.unescape(str(x)).strip()

    m = re.search(
        r"/nuccore/([^\"'<>/?#]+)",
        x,
        flags=re.IGNORECASE
    )

    if m:
        return unquote(m.group(1)).strip()

    x = re.sub(r"<[^>]+>", "", x).strip()

    if not x:
        return ""

    return x.split()[0]


def host_from_description(description):
    """
    从描述中提取宿主属。

    例如：

    Parabacteroides phage PM708P2
    -> Parabacteroides
    """

    description = html.unescape(str(description)).strip()

    m = re.match(
        r"^\s*([A-Za-z][A-Za-z0-9_.-]*)\s+phage\b",
        description,
        flags=re.IGNORECASE
    )

    if m:
        return m.group(1)

    return None


def clean_host_genus(host):
    """
    清理 INPHARED Host 字段。

    可以处理：

    Parabacteroides
    Bacteroides fragilis
    UnclassifiedParabacteroides
    Unclassified Parabacteroides
    """

    if host is None or pd.isna(host):
        return None

    host = html.unescape(str(host)).strip()

    # 修复常见拼接格式
    host = re.sub(
        r"^(unclassified|unknown)\s*",
        "",
        host,
        flags=re.IGNORECASE
    ).strip()

    if not host:
        return None

    invalid = {
        "unclassified",
        "unknown",
        "uncultured",
        "na",
        "n/a",
        "-"
    }

    if host.lower() in invalid:
        return None

    # 如果有多个宿主，取第一个
    host = re.split(r"[;,|/]", host)[0].strip()

    # 如果是种名，只取属名
    genus = host.split()[0]

    # 保留标准属名字符
    genus = re.sub(
        r"[^A-Za-z0-9_.-]",
        "",
        genus
    )

    return genus if genus else None


def genus_key(x):
    """
    用于大小写不敏感匹配宿主属。
    """

    if x is None or pd.isna(x):
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(x).strip()
    ).casefold()


def unique_join(values):
    """
    对同一属的多个 GTDB representative 分类结果进行合并。
    """

    values = [
        str(x).strip()
        for x in values
        if x is not None
        and not pd.isna(x)
        and str(x).strip()
    ]

    return "|".join(sorted(set(values)))


# ============================================================
# 读取 INPHARED metadata
# ============================================================

def read_inphared_metadata(path):
    """
    读取 INPHARED website table。

    正常格式为 8 列：

    Accession
    Description
    Genome Length (KB)
    molGC (%)
    Genus
    Sub-family
    Family
    Host

    对于部分异常行，例如：

    PeduoviridaeSalmonella
    UnclassifiedParabacteroides

    使用 Description 中的：

    Salmonella phage ...
    Parabacteroides phage ...

    修复 Family 和 Host。
    """

    records = []

    with open(path, encoding="utf-8-sig") as f:
        header = f.readline()

        if "\t" not in header:
            raise ValueError(
                "metadata 文件看起来不是制表符分隔文件，"
                "请使用 cat -vet 检查实际分隔符。"
            )

        for line_no, line in enumerate(f, start=2):

            if not line.strip():
                continue

            fields = line.rstrip("\r\n").split("\t")

            if len(fields) < 7:
                print(
                    f"Warning: line {line_no} has only "
                    f"{len(fields)} fields; skipped",
                    file=sys.stderr
                )
                continue

            accession = clean_accession(fields[0])
            description = fields[1].strip()

            if not accession:
                continue

            description_host = host_from_description(
                description
            )

            # 正常行：Host 是第 8 列
            if len(fields) >= 8:

                genome_length_kb = fields[2].strip()
                molGC_percent = fields[3].strip()
                inphared_genus = fields[4].strip()
                inphared_subfamily = fields[5].strip()
                inphared_family = fields[6].strip()
                inphared_host_raw = "\t".join(
                    fields[7:]
                ).strip()

            # 异常行：Family 和 Host 粘连在第 7 列
            else:

                genome_length_kb = fields[2].strip()
                molGC_percent = fields[3].strip()
                inphared_genus = fields[4].strip()
                inphared_subfamily = fields[5].strip()

                family_host_combined = fields[6].strip()

                inphared_family = family_host_combined
                inphared_host_raw = (
                    description_host or ""
                )

                # 例如：
                # PeduoviridaeSalmonella
                # -> Family = Peduoviridae
                # -> Host = Salmonella
                if (
                    description_host
                    and family_host_combined.casefold().endswith(
                        description_host.casefold()
                    )
                ):

                    inphared_family = family_host_combined[
                        :len(family_host_combined)
                        - len(description_host)
                    ].strip()

                    inphared_host_raw = description_host

            host_from_column = clean_host_genus(
                inphared_host_raw
            )

            # 优先使用 Host 字段；
            # 如果为 Unclassified，则使用 Description 提取宿主属
            host_genus = (
                host_from_column
                or description_host
            )

            records.append({
                "phage_id": accession,
                "description": description,
                "genome_length_kb": genome_length_kb,
                "molGC_percent": molGC_percent,
                "inphared_genus": inphared_genus,
                "inphared_subfamily": inphared_subfamily,
                "inphared_family": inphared_family,
                "inphared_host_raw": inphared_host_raw,
                "host_genus": host_genus,
                "host_key": genus_key(host_genus),
            })

    return pd.DataFrame(records)


metadata = read_inphared_metadata(META)

print(
    f"INPHARED metadata records: {len(metadata)}"
)

print(
    "Unique INPHARED accessions: "
    f"{metadata['phage_id'].nunique()}"
)

print(
    "Unique host genera: "
    f"{metadata['host_genus'].nunique(dropna=True)}"
)


# ============================================================
# 读取 GTDB-Tk r220 taxonomy
# ============================================================

if not GTDB_TAX.exists():
    raise FileNotFoundError(
        f"GTDB taxonomy file not found:\n{GTDB_TAX}"
    )


RANK_PREFIX = {
    "d": "domain",
    "p": "phylum",
    "c": "class",
    "o": "order",
    "f": "family",
    "g": "genus",
    "s": "species",
}


def parse_gtdb_taxonomy(taxonomy_string):
    """
    解析：

    d__Bacteria;p__Bacillota;c__Bacilli;
    o__Bacillales;f__Bacillaceae;
    g__Bacillus;s__Bacillus subtilis

    返回：

    domain
    phylum
    class
    order
    family
    genus
    species
    """

    result = {
        rank: None
        for rank in RANK_PREFIX.values()
    }

    for item in str(taxonomy_string).split(";"):

        if "__" not in item:
            continue

        prefix, value = item.split("__", 1)

        if prefix in RANK_PREFIX:

            rank = RANK_PREFIX[prefix]
            value = value.strip()

            if value:
                result[rank] = value

    return result


gtdb = pd.read_csv(
    GTDB_TAX,
    sep="\t",
    header=None,
    names=[
        "gtdb_reference",
        "taxonomy"
    ],
    dtype=str,
    keep_default_na=False
)


# ============================================================
# 按 GTDB genus 建立映射
# ============================================================

tax_by_genus = {}

for row in gtdb.itertuples(index=False):

    parsed = parse_gtdb_taxonomy(
        row.taxonomy
    )

    genus = parsed.get("genus")

    if not genus:
        continue

    key = genus_key(genus)

    parsed["gtdb_reference"] = (
        row.gtdb_reference
    )

    parsed["taxonomy"] = row.taxonomy

    tax_by_genus.setdefault(
        key,
        []
    ).append(parsed)


# ============================================================
# 汇总每个 GTDB genus 的完整分类信息
# 并筛选 Bacteroidales
# ============================================================

tax_rows = []

for host_key, entries in tax_by_genus.items():

    tax_row = {
        "host_key": host_key,
        "gtdb_reference_count": len(entries),
    }

    for rank in RANK_PREFIX.values():

        tax_row[
            f"gtdb_{rank}"
        ] = unique_join(
            [
                x.get(rank)
                for x in entries
            ]
        )

    tax_row["gtdb_taxonomy"] = " || ".join(
        sorted(
            set(
                x["taxonomy"]
                for x in entries
                if x.get("taxonomy")
            )
        )
    )

    # 用于严格筛选的 GTDB 分类集合
    phylum_values = [
        x.get("phylum")
        for x in entries
        if x.get("phylum")
    ]

    order_values = [
        x.get("order")
        for x in entries
        if x.get("order")
    ]

    target_groups = []

    # ========================================================
    # 仅保留拟杆菌目 Bacteroidales
    #
    # 严格要求：
    #   phylum = Bacteroidota
    #   order  = Bacteroidales
    #
    # 对同一宿主属的所有 GTDB representative，
    # 门和目必须全部一致。
    # ========================================================

    if (
        len(phylum_values) == len(entries)
        and len(order_values) == len(entries)
        and set(phylum_values) == {"Bacteroidota"}
        and set(order_values) == {"Bacteroidales"}
    ):

        target_groups.append(
            "Bacteroidota_Bacteroidales"
        )

    tax_row["target_group"] = ";".join(
        target_groups
    )

    tax_rows.append(tax_row)


gtdb_map = pd.DataFrame(tax_rows)


# ============================================================
# 合并 INPHARED 宿主与 GTDB r220 分类
# ============================================================

annotated = metadata.merge(
    gtdb_map,
    on="host_key",
    how="left"
)

annotated["target_group"] = annotated[
    "target_group"
].fillna("")


# 只保留 Bacteroidales 宿主分类
selected = annotated[
    annotated["target_group"] != ""
].copy()


# 每个 accession 只保留一行
selected = selected.drop_duplicates(
    subset=["phage_id"],
    keep="first"
).reset_index(drop=True)


print(
    "GTDB Bacteroidales metadata accessions: "
    f"{len(selected)}"
)

print(
    "GTDB Bacteroidales host genera: "
    f"{selected['host_genus'].nunique()}"
)


# ============================================================
# 打印 metadata 中的属水平计数
# 不生成额外的统计文件
# ============================================================

if len(selected) > 0:

    metadata_counts = (
        selected
        .groupby(
            [
                "target_group",
                "host_genus"
            ],
            as_index=False
        )["phage_id"]
        .nunique()
        .rename(
            columns={
                "phage_id": "n_metadata_phages"
            }
        )
        .sort_values(
            [
                "target_group",
                "n_metadata_phages"
            ],
            ascending=[
                True,
                False
            ]
        )
    )

    print(
        "\n===== Counts in selected "
        "INPHARED metadata ====="
    )

    print(
        metadata_counts.to_string(
            index=False
        )
    )


# ============================================================
# 读取 FASTA
# ============================================================

if not FASTA.exists():
    raise FileNotFoundError(
        f"FASTA file not found:\n{FASTA}"
    )


seq_by_id = {}
source_header_by_id = {}
duplicate_fasta_ids = set()

for record in SeqIO.parse(
    str(FASTA),
    "fasta"
):

    # Biopython 的 record.id 通常就是
    # > 后面的第一个字段
    fasta_id = record.id.strip()

    if fasta_id in seq_by_id:

        duplicate_fasta_ids.add(
            fasta_id
        )

        continue

    seq_by_id[fasta_id] = record.seq
    source_header_by_id[
        fasta_id
    ] = record.description


# ============================================================
# 匹配 metadata accession 与 FASTA ID
# ============================================================

missing_ids = sorted(
    set(selected["phage_id"])
    - set(seq_by_id)
)

if missing_ids:

    print(
        f"\nWARNING: {len(missing_ids)} selected "
        "accessions were not found in FASTA.",
        file=sys.stderr
    )

    print(
        "First missing IDs:",
        ", ".join(missing_ids[:20]),
        file=sys.stderr
    )


extracted = selected[
    selected["phage_id"].isin(seq_by_id)
].copy()

extracted = extracted.reset_index(
    drop=True
)


if len(extracted) == 0:

    raise RuntimeError(
        "没有任何 Bacteroidales accession "
        "在 FASTA 中匹配成功，"
        "因此没有生成输出文件。"
    )


# ============================================================
# 增加序列相关信息和提取后计数
# ============================================================

extracted[
    "sequence_length_bp"
] = extracted[
    "phage_id"
].map(
    lambda x: len(seq_by_id[x])
)

extracted[
    "source_fasta_header"
] = extracted[
    "phage_id"
].map(
    lambda x: source_header_by_id[x]
)


# 每个宿主属提取到的噬菌体数量
extracted[
    "n_extracted_phages_same_host_genus"
] = (
    extracted
    .groupby(
        "host_genus"
    )["phage_id"]
    .transform("nunique")
    .astype(int)
)


# Bacteroidales 分类组提取到的噬菌体数量
extracted[
    "n_extracted_phages_same_target_group"
] = (
    extracted
    .groupby(
        "target_group"
    )["phage_id"]
    .transform("nunique")
    .astype(int)
)


# ============================================================
# 输出 FASTA
# ============================================================

with open(
    OUT_FASTA,
    "w"
) as out_fasta:

    for row in extracted.itertuples(
        index=False
    ):

        phage_id = row.phage_id
        description = row.description

        output_record = SeqRecord(
            seq_by_id[phage_id],
            id=phage_id,
            description=description
        )

        SeqIO.write(
            output_record,
            out_fasta,
            "fasta"
        )


# ============================================================
# 输出最终宿主分类信息表
# ============================================================

# 将 GTDB 分类列改成更明确的宿主分类名称
rank_rename = {
    f"gtdb_{rank}": f"host_gtdb_{rank}"
    for rank in RANK_PREFIX.values()
}

rank_rename[
    "gtdb_taxonomy"
] = "host_gtdb_taxonomy"

rank_rename[
    "gtdb_reference_count"
] = "host_gtdb_reference_count"


output_table = extracted.rename(
    columns=rank_rename
)


table_columns = [

    # 噬菌体信息
    "phage_id",
    "description",
    "genome_length_kb",
    "molGC_percent",

    # INPHARED 原始信息
    "inphared_genus",
    "inphared_subfamily",
    "inphared_family",
    "inphared_host_raw",

    # INPHARED 解析出的宿主属
    "host_genus",

    # 目标分类组
    "target_group",

    # GTDB-Tk r220 宿主完整分类
    "host_gtdb_domain",
    "host_gtdb_phylum",
    "host_gtdb_class",
    "host_gtdb_order",
    "host_gtdb_family",
    "host_gtdb_genus",
    "host_gtdb_species",
    "host_gtdb_taxonomy",
    "host_gtdb_reference_count",

    # 序列信息
    "sequence_length_bp",
    "source_fasta_header",

    # 统计信息
    "n_extracted_phages_same_host_genus",
    "n_extracted_phages_same_target_group",
]


output_table[
    table_columns
].to_csv(
    OUT_TABLE,
    sep="\t",
    index=False
)


# ============================================================
# 终端统计
# ============================================================

print(
    "\n===== Final extracted sequence counts ====="
)

final_counts = (
    extracted
    .groupby(
        [
            "target_group",
            "host_genus"
        ],
        as_index=False
    )["phage_id"]
    .nunique()
    .rename(
        columns={
            "phage_id": "n_extracted_phages"
        }
    )
    .sort_values(
        [
            "target_group",
            "n_extracted_phages"
        ],
        ascending=[
            True,
            False
        ]
    )
)

print(
    final_counts.to_string(
        index=False
    )
)


print(
    "\n===== Output files ====="
)

print(
    OUT_FASTA.resolve()
)

print(
    OUT_TABLE.resolve()
)


print(
    "\n===== Summary ====="
)

print(
    f"FASTA records written: {len(extracted)}"
)

print(
    f"TSV records written: {len(extracted)}"
)

if duplicate_fasta_ids:

    print(
        "Duplicate FASTA IDs ignored: "
        f"{len(duplicate_fasta_ids)}",
        file=sys.stderr
    )
