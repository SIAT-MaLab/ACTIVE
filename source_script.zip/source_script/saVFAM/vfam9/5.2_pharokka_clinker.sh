mkdir -p 5_rep_vOTU/annot 5_rep_vOTU/clinker_output

#pharokka.py -i 5_rep_vOTU/vFAM9_selected_reps.fasta -o 5_rep_vOTU/annot -t 26 -f -m -s --meta_hmm --skip_mash -g prodigal-gv -d "/home/huangyan/databaseHY/pharokka_v1.8.0_databases/"

clinker 5_rep_vOTU/annot/single*gbk*/*.gbk -o 5_rep_vOTU/clinker_output/vFAM9.txt -dl "\t" -j 15 -p 5_rep_vOTU/clinker_output/vFAM9.html
