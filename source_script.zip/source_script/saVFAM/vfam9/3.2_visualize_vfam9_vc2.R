#!/usr/bin/env Rscript

# ============================================================
# Visualize vContact2 results:
# vFAM_9 genomes vs INPHARED Bacteroidales references
#
# Outputs:
#   vcontact2/vfam9_vc2_visualization/
#
# All input paths are configured below; no command-line arguments.
# ============================================================

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(ggplot2)
  library(forcats)
})

# ============================================================
# 1. Paths and global settings
# ============================================================

DIR <- "."

VFAM9_FASTA <- file.path(DIR, "vFAM_9_genomes.fasta")
REF_FASTA <- file.path(DIR, "INPHARED_GTDBr220_Bacteroidales.fa")

VC2_ANNOT_TSV <- file.path(
  DIR,
  "vcontact2/vfam9_genome_annotated.tsv"
)

ALLPP_META_TSV <- file.path(
  DIR,
  "../../../../metadata/allpp_metadata.tsv"
)

BASELINE_STAT_TSV <- file.path(
  DIR,
  "../../../1_sataxon/stats_baseline_vOTU.tsv"
)

OUT_DIR <- file.path(
  DIR,
  "vcontact2/vfam9_vc2_visualization"
)

ACTIVITY_CUTOFF <- 0.8
TOP_N_VCS_FOR_BAR <- 40
FIGURE_DPI <- 300

dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

# ============================================================
# 2. Colors
# ============================================================

FATE_LEVELS <- c(
  "VC with Bacteroidales reference",
  "VC without Bacteroidales reference",
  "Singleton VC",
  "Overlap (multi-VC assignment)",
  "Outlier (not assigned to VC)",
  "Not represented in VC2 overview",
  "Other / unresolved"
)

FATE_COLORS <- c(
  "VC with Bacteroidales reference" =
    "#E68F9F",
  "VC without Bacteroidales reference" =
    "#7ABBCE",
  "Singleton VC" =
    "#769499",
  "Overlap (multi-VC assignment)" =
    "#B7A3C9",
  "Outlier (not assigned to VC)" =
    "#F5CFA6",
  "Not represented in VC2 overview" =
    "#D5D5D6",
  "Other / unresolved" =
    "#414141"
)

ACTIVITY_LEVELS <- c(
  "Active & significant",
  "Active, not significant",
  "Significant, but score < 0.8",
  "Not active / not significant"
)

ACTIVITY_COLORS <- c(
  "Active & significant" =
    "#C83E4D",
  "Active, not significant" =
    "#E8A340",
  "Significant, but score < 0.8" =
    "#8064A2",
  "Not active / not significant" =
    "#D9D9D9"
)

VC_COMP_COLORS <- c(
  "vFAM9 + Bacteroidales reference" =
    "#E68F9F",
  "vFAM9 only" =
    "#7ABBCE",
  "Other source composition" =
    "#D5D5D6"
)

# ============================================================
# 3. Helper functions
# ============================================================

clean_chr <- function(x) {
  x <- trimws(as.character(x))
  x[
    is.na(x) |
      x %in% c("", "NA", "<NA>", "NaN", "N/A")
  ] <- NA_character_
  x
}

norm_id <- function(x) {
  x <- clean_chr(x)
  str_replace_all(x, "-", "_")
}

safe_max <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x)]

  if (length(x) == 0) {
    return(NA_real_)
  }

  max(x)
}

first_nonmissing_chr <- function(x) {
  x <- clean_chr(x)
  x <- x[!is.na(x)]

  if (length(x) == 0) {
    return(NA_character_)
  }

  x[[1]]
}

first_nonmissing_num <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x)]

  if (length(x) == 0) {
    return(NA_real_)
  }

  x[[1]]
}

collapse_unique <- function(x) {
  x <- clean_chr(x)
  x <- sort(unique(x[!is.na(x)]))

  if (length(x) == 0) {
    return(NA_character_)
  }

  paste(x, collapse = ";")
}

read_fasta_ids <- function(fasta_file) {
  if (!file.exists(fasta_file)) {
    stop("FASTA file not found: ", fasta_file)
  }

  lines <- readLines(fasta_file, warn = FALSE)
  headers <- lines[grepl("^>", lines)]

  ids <- sub(
    "^>([^[:space:]]+).*",
    "\\1",
    headers
  )

  ids <- clean_chr(ids)
  ids <- ids[!is.na(ids)]

  if (length(ids) != length(unique(ids))) {
    warning(
      "Duplicate FASTA IDs detected in: ",
      fasta_file
    )
  }

  unique(ids)
}

save_plot <- function(plot_object, file_prefix,
                      width = 9, height = 6) {

  ggsave(
    filename = file.path(
      OUT_DIR,
      paste0(file_prefix, ".pdf")
    ),
    plot = plot_object,
    width = width,
    height = height
  )

  ggsave(
    filename = file.path(
      OUT_DIR,
      paste0(file_prefix, ".png")
    ),
    plot = plot_object,
    width = width,
    height = height,
    dpi = FIGURE_DPI
  )
}

# ============================================================
# 4. Validate input files
# ============================================================

required_files <- c(
  VFAM9_FASTA,
  REF_FASTA,
  VC2_ANNOT_TSV,
  ALLPP_META_TSV,
  BASELINE_STAT_TSV
)

missing_files <- required_files[
  !file.exists(required_files)
]

if (length(missing_files) > 0) {
  stop(
    "Missing required input files:\n",
    paste(missing_files, collapse = "\n")
  )
}

# ============================================================
# 5. Read FASTA IDs and define sequence source
# ============================================================

message("[1/8] Reading vFAM9 and reference FASTA IDs...")

vfam9_ids <- read_fasta_ids(VFAM9_FASTA)
ref_ids <- read_fasta_ids(REF_FASTA)

vfam9_ids_norm <- norm_id(vfam9_ids)
ref_ids_norm <- norm_id(ref_ids)

shared_ids <- intersect(
  vfam9_ids_norm,
  ref_ids_norm
)

if (length(shared_ids) > 0) {
  stop(
    "Some genome IDs occur in both vFAM9 and reference FASTA:\n",
    paste(shared_ids[1:min(20, length(shared_ids))],
          collapse = ", ")
  )
}

message("  vFAM9 input genomes: ", length(vfam9_ids))
message("  Bacteroidales references: ", length(ref_ids))

# ============================================================
# 6. Read allpp metadata and calculate vOTU activity
# ============================================================

message("[2/8] Reading allpp metadata and calculating vOTU activity...")

allpp <- read_tsv(
  ALLPP_META_TSV,
  col_types = cols(.default = col_character()),
  show_col_types = FALSE,
  progress = FALSE
)

required_meta_cols <- c(
  "phage_id",
  "vOTU",
  "Activity_Score",
  "vSUBFAM",
  "vGENUS"
)

missing_meta_cols <- setdiff(
  required_meta_cols,
  colnames(allpp)
)

if (length(missing_meta_cols) > 0) {
  stop(
    "Missing columns in allpp_metadata.tsv:\n",
    paste(missing_meta_cols, collapse = ", ")
  )
}

allpp_clean <- allpp %>%
  transmute(
    norm_genome_id = norm_id(phage_id),
    metadata_vOTU = clean_chr(vOTU),
    metadata_vSUBFAM = clean_chr(vSUBFAM),
    metadata_vGENUS = clean_chr(vGENUS),
    activity_score = suppressWarnings(
      as.numeric(Activity_Score)
    )
  )

# phage ID -> taxonomy mapping
metadata_id_map <- allpp_clean %>%
  filter(!is.na(norm_genome_id)) %>%
  group_by(norm_genome_id) %>%
  summarise(
    metadata_vOTU =
      first_nonmissing_chr(metadata_vOTU),
    metadata_vSUBFAM =
      first_nonmissing_chr(metadata_vSUBFAM),
    metadata_vGENUS =
      first_nonmissing_chr(metadata_vGENUS),
    .groups = "drop"
  )

# vOTU-level maximum activity score
activity_by_votu <- allpp_clean %>%
  filter(!is.na(metadata_vOTU)) %>%
  group_by(metadata_vOTU) %>%
  summarise(
    vOTU_Max_Activity_Score_AllPP =
      safe_max(activity_score),
    .groups = "drop"
  ) %>%
  rename(vOTU = metadata_vOTU)

# ============================================================
# 7. Read baseline significance results
# ============================================================

message("[3/8] Reading baseline significance results...")

baseline <- read_tsv(
  BASELINE_STAT_TSV,
  col_types = cols(.default = col_character()),
  show_col_types = FALSE,
  progress = FALSE
)

required_base_cols <- c(
  "vOTU",
  "Significance_Type"
)

missing_base_cols <- setdiff(
  required_base_cols,
  colnames(baseline)
)

if (length(missing_base_cols) > 0) {
  stop(
    "Missing columns in stats_baseline_vOTU.tsv:\n",
    paste(missing_base_cols, collapse = ", ")
  )
}

significant_votus <- baseline %>%
  transmute(
    vOTU = clean_chr(vOTU),
    Significance_Type =
      clean_chr(Significance_Type)
  ) %>%
  filter(
    !is.na(vOTU),
    Significance_Type == "Significant"
  ) %>%
  pull(vOTU) %>%
  unique()

message(
  "  Significantly active vOTUs: ",
  length(significant_votus)
)

# ============================================================
# 8. Read annotated VC2 overview
# ============================================================

message("[4/8] Reading annotated vContact2 overview...")

annot <- read_tsv(
  VC2_ANNOT_TSV,
  col_types = cols(.default = col_character()),
  show_col_types = FALSE,
  progress = FALSE
)

required_annot_cols <- c(
  "Genome",
  "Source_Origin",
  "vOTU",
  "VC Status",
  "VC"
)

missing_annot_cols <- setdiff(
  required_annot_cols,
  colnames(annot)
)

if (length(missing_annot_cols) > 0) {
  stop(
    "Missing columns in vfam9_genome_annotated.tsv:\n",
    paste(missing_annot_cols, collapse = ", ")
  )
}

# If previous annotation script did not yet add vSUBFAM / vGENUS,
# fill them from allpp_metadata.tsv below.
if (!"vSUBFAM" %in% colnames(annot)) {
  annot$vSUBFAM <- NA_character_
}

if (!"vGENUS" %in% colnames(annot)) {
  annot$vGENUS <- NA_character_
}

if (!"VC Size" %in% colnames(annot)) {
  annot$`VC Size` <- NA_character_
}

annot2 <- annot %>%
  mutate(
    Genome = clean_chr(Genome),
    Source_Origin = clean_chr(Source_Origin),
    vOTU = clean_chr(vOTU),
    vSUBFAM = clean_chr(vSUBFAM),
    vGENUS = clean_chr(vGENUS),
    `VC Status` = clean_chr(`VC Status`),
    VC = clean_chr(VC),
    VC_Size_Reported = suppressWarnings(
      as.numeric(`VC Size`)
    ),
    norm_genome_id = norm_id(Genome)
  ) %>%
  left_join(
    metadata_id_map,
    by = "norm_genome_id"
  ) %>%
  mutate(
    # Use metadata fields if prior annotation lacks them
    vOTU = coalesce(
      vOTU,
      metadata_vOTU
    ),
    vSUBFAM = coalesce(
      vSUBFAM,
      metadata_vSUBFAM
    ),
    vGENUS = coalesce(
      vGENUS,
      metadata_vGENUS
    ),

    # Strict source reassignment based on current FASTA inputs
    Source_Origin = case_when(
      norm_genome_id %in% vfam9_ids_norm ~
        "vFAM_9",

      norm_genome_id %in% ref_ids_norm ~
        "Ref_Bacteroidales",

      is.na(Source_Origin) ~
        "Unknown",

      TRUE ~
        Source_Origin
    )
  ) %>%
  left_join(
    activity_by_votu,
    by = "vOTU"
  ) %>%
  mutate(
    Is_Active_080 =
      !is.na(vOTU_Max_Activity_Score_AllPP) &
      vOTU_Max_Activity_Score_AllPP >=
        ACTIVITY_CUTOFF,

    Is_Baseline_Significant =
      !is.na(vOTU) &
      vOTU %in% significant_votus
  )

# ============================================================
# 9. FASTA input accounting and QC
# ============================================================

message("[5/8] Checking FASTA input accounting...")

overview_ids_norm <- unique(
  annot2$norm_genome_id
)

vfam9_missing_in_overview <- setdiff(
  vfam9_ids_norm,
  overview_ids_norm
)

ref_missing_in_overview <- setdiff(
  ref_ids_norm,
  overview_ids_norm
)

vfam9_ids_lookup <- tibble(
  Genome = vfam9_ids,
  norm_genome_id = vfam9_ids_norm
)

missing_vfam9_input <- vfam9_ids_lookup %>%
  filter(
    norm_genome_id %in%
      vfam9_missing_in_overview
  ) %>%
  left_join(
    metadata_id_map,
    by = "norm_genome_id"
  ) %>%
  transmute(
    Genome,
    norm_genome_id,
    Source_Origin = "vFAM_9",
    vOTU = metadata_vOTU,
    vSUBFAM = metadata_vSUBFAM,
    vGENUS = metadata_vGENUS,
    `VC Status` =
      "Not represented in VC2 overview",
    VC = NA_character_,
    VC_Size_Reported = NA_real_
  ) %>%
  left_join(
    activity_by_votu,
    by = "vOTU"
  ) %>%
  mutate(
    Is_Active_080 =
      !is.na(vOTU_Max_Activity_Score_AllPP) &
      vOTU_Max_Activity_Score_AllPP >=
        ACTIVITY_CUTOFF,

    Is_Baseline_Significant =
      !is.na(vOTU) &
      vOTU %in% significant_votus
  )

input_accounting <- tibble(
  Dataset = c(
    "vFAM_9",
    "Ref_Bacteroidales"
  ),
  N_FASTA_Genomes = c(
    length(vfam9_ids_norm),
    length(ref_ids_norm)
  ),
  N_In_VC2_Overview = c(
    sum(vfam9_ids_norm %in% overview_ids_norm),
    sum(ref_ids_norm %in% overview_ids_norm)
  ),
  N_Not_In_VC2_Overview = c(
    length(vfam9_missing_in_overview),
    length(ref_missing_in_overview)
  )
)

write_tsv(
  input_accounting,
  file.path(
    OUT_DIR,
    "00_input_genome_accounting.tsv"
  )
)

# ============================================================
# 10. Build direct VC composition table
# ============================================================

message("[6/8] Building VC-level composition summary...")

clustered_all <- annot2 %>%
  filter(
    `VC Status` == "Clustered",
    !is.na(VC)
  )

vc_summary <- clustered_all %>%
  group_by(VC) %>%
  summarise(
    VC_Size_Input =
      n_distinct(Genome),

    VC_Size_Reported =
      first_nonmissing_num(
        VC_Size_Reported
      ),

    Num_vFAM9 =
      sum(
        Source_Origin == "vFAM_9"
      ),

    Num_Ref_Bacteroidales =
      sum(
        Source_Origin ==
          "Ref_Bacteroidales"
      ),

    Num_Other_Source =
      sum(
        !Source_Origin %in%
          c(
            "vFAM_9",
            "Ref_Bacteroidales"
          )
      ),

    Num_vOTUs =
      n_distinct(
        vOTU[
          Source_Origin == "vFAM_9"
        ],
        na.rm = TRUE
      ),

    Num_Active_vOTUs =
      n_distinct(
        vOTU[
          Source_Origin == "vFAM_9" &
            Is_Active_080
        ],
        na.rm = TRUE
      ),

    Num_Significant_vOTUs =
      n_distinct(
        vOTU[
          Source_Origin == "vFAM_9" &
            Is_Baseline_Significant
        ],
        na.rm = TRUE
      ),

    Num_Active_and_Significant_vOTUs =
      n_distinct(
        vOTU[
          Source_Origin == "vFAM_9" &
            Is_Active_080 &
            Is_Baseline_Significant
        ],
        na.rm = TRUE
      ),

    vSUBFAM_List =
      collapse_unique(
        vSUBFAM[
          Source_Origin == "vFAM_9"
        ]
      ),

    Num_vSUBFAM =
      n_distinct(
        vSUBFAM[
          Source_Origin == "vFAM_9"
        ],
        na.rm = TRUE
      ),

    vGENUS_List =
      collapse_unique(
        vGENUS[
          Source_Origin == "vFAM_9"
        ]
      ),

    Num_vGENUS =
      n_distinct(
        vGENUS[
          Source_Origin == "vFAM_9"
        ],
        na.rm = TRUE
      ),

    .groups = "drop"
  ) %>%
  mutate(
    VC_Composition = case_when(
      Num_vFAM9 > 0 &
        Num_Ref_Bacteroidales > 0 ~
        "vFAM9 + Bacteroidales reference",

      Num_vFAM9 > 0 &
        Num_Ref_Bacteroidales == 0 ~
        "vFAM9 only",

      TRUE ~
        "Other source composition"
    ),

    VC_Activity_Content = case_when(
      Num_Active_and_Significant_vOTUs > 0 ~
        "Contains active & significant vOTU",

      Num_Active_vOTUs > 0 ~
        "Contains active vOTU only",

      Num_Significant_vOTUs > 0 ~
        "Contains significant vOTU only",

      TRUE ~
        "No active/significant vOTU"
    )
  )

vc_with_vfam9 <- vc_summary %>%
  filter(Num_vFAM9 > 0) %>%
  mutate(
    VC_Cluster_Category = case_when(
      VC_Size_Input == 1 ~
        "Singleton VC",

      Num_Ref_Bacteroidales > 0 ~
        "VC with Bacteroidales reference",

      TRUE ~
        "VC without Bacteroidales reference"
    )
  ) %>%
  arrange(
    desc(VC_Size_Input),
    VC
  )

write_tsv(
  vc_with_vfam9,
  file.path(
    OUT_DIR,
    "01_vfam9_VC_cluster_summary.tsv"
  )
)

vc_category_summary <- vc_with_vfam9 %>%
  group_by(VC_Cluster_Category) %>%
  summarise(
    N_VCs = n(),
    N_vFAM9_Genomes =
      sum(Num_vFAM9),
    N_vOTUs =
      sum(Num_vOTUs),
    .groups = "drop"
  )

write_tsv(
  vc_category_summary,
  file.path(
    OUT_DIR,
    "02_vfam9_VC_category_summary.tsv"
  )
)

# ============================================================
# 11. Assign network fate to every vFAM9 genome
# ============================================================

message("[7/8] Assigning genome-level and vOTU-level network fates...")

vfam9_direct <- annot2 %>%
  filter(
    norm_genome_id %in%
      vfam9_ids_norm
  ) %>%
  left_join(
    vc_summary %>%
      select(
        VC,
        VC_Size_Input,
        Num_vFAM9,
        Num_Ref_Bacteroidales,
        Num_Other_Source,
        VC_Composition,
        VC_Activity_Content
      ),
    by = "VC"
  )

vfam9_all <- bind_rows(
  vfam9_direct,
  missing_vfam9_input
)

vfam9_genome_fate <- vfam9_all %>%
  mutate(
    Network_Fate = case_when(

      `VC Status` ==
        "Not represented in VC2 overview" ~
        "Not represented in VC2 overview",

      `VC Status` == "Clustered" &
        !is.na(VC) &
        VC_Size_Input == 1 ~
        "Singleton VC",

      `VC Status` == "Clustered" &
        !is.na(VC) &
        Num_Ref_Bacteroidales > 0 ~
        "VC with Bacteroidales reference",

      `VC Status` == "Clustered" &
        !is.na(VC) ~
        "VC without Bacteroidales reference",

      str_detect(
        coalesce(`VC Status`, ""),
        "^Overlap"
      ) ~
        "Overlap (multi-VC assignment)",

      str_detect(
        coalesce(`VC Status`, ""),
        "^Outlier"
      ) ~
        "Outlier (not assigned to VC)",

      TRUE ~
        "Other / unresolved"
    ),

    Activity_Class = case_when(
      Is_Active_080 &
        Is_Baseline_Significant ~
        "Active & significant",

      Is_Active_080 ~
        "Active, not significant",

      Is_Baseline_Significant ~
        "Significant, but score < 0.8",

      TRUE ~
        "Not active / not significant"
    ),

    Network_Fate = factor(
      Network_Fate,
      levels = FATE_LEVELS
    ),

    Activity_Class = factor(
      Activity_Class,
      levels = ACTIVITY_LEVELS
    )
  ) %>%
  arrange(
    Network_Fate,
    Genome
  )

write_tsv(
  vfam9_genome_fate,
  file.path(
    OUT_DIR,
    "03_vfam9_genome_network_fate.tsv"
  )
)

# Genome-level fate summary
genome_fate_counts <- vfam9_genome_fate %>%
  count(
    Network_Fate,
    name = "N_vFAM9_Genomes"
  )

genome_fate_summary <- tibble(
  Network_Fate = FATE_LEVELS
) %>%
  left_join(
    genome_fate_counts,
    by = "Network_Fate"
  ) %>%
  mutate(
    N_vFAM9_Genomes =
      replace_na(
        N_vFAM9_Genomes,
        0L
      ),

    Percent_vFAM9_Genomes =
      100 *
      N_vFAM9_Genomes /
      sum(N_vFAM9_Genomes)
  ) %>%
  left_join(
    vfam9_genome_fate %>%
      group_by(Network_Fate) %>%
      summarise(
        N_Active_Genomes =
          sum(Is_Active_080),

        N_Significant_Genomes =
          sum(Is_Baseline_Significant),

        N_Active_and_Significant_Genomes =
          sum(
            Is_Active_080 &
              Is_Baseline_Significant
          ),

        N_vOTUs =
          n_distinct(
            vOTU,
            na.rm = TRUE
          ),

        .groups = "drop"
      ),
    by = "Network_Fate"
  ) %>%
  mutate(
    across(
      starts_with("N_"),
      ~ replace_na(.x, 0L)
    )
  )

write_tsv(
  genome_fate_summary,
  file.path(
    OUT_DIR,
    "04_vfam9_genome_fate_summary.tsv"
  )
)

# ============================================================
# 12. vOTU-level network fate summary
# ============================================================

vfam9_votu_fate <- vfam9_genome_fate %>%
  filter(!is.na(vOTU)) %>%
  group_by(vOTU) %>%
  summarise(
    N_vFAM9_Genomes = n(),

    vOTU_Max_Activity_Score =
      safe_max(
        vOTU_Max_Activity_Score_AllPP
      ),

    Is_Active_080 =
      any(Is_Active_080),

    Is_Baseline_Significant =
      any(Is_Baseline_Significant),

    vSUBFAM_List =
      collapse_unique(vSUBFAM),

    vGENUS_List =
      collapse_unique(vGENUS),

    Genome_Network_Fates =
      collapse_unique(
        as.character(Network_Fate)
      ),

    N_Distinct_Genome_Fates =
      n_distinct(Network_Fate),

    Has_Reference_Associated_VC =
      any(
        Network_Fate ==
          "VC with Bacteroidales reference"
      ),

    Has_vFAM9_Only_VC =
      any(
        Network_Fate ==
          "VC without Bacteroidales reference"
      ),

    Has_Singleton_VC =
      any(
        Network_Fate ==
          "Singleton VC"
      ),

    Has_Overlap =
      any(
        Network_Fate ==
          "Overlap (multi-VC assignment)"
      ),

    Has_Outlier =
      any(
        Network_Fate ==
          "Outlier (not assigned to VC)"
      ),

    Has_Not_Represented =
      any(
        Network_Fate ==
          "Not represented in VC2 overview"
      ),

    .groups = "drop"
  ) %>%
  mutate(
    # Priority denotes the strongest direct VC evidence
    Primary_Network_Fate = case_when(
      Has_Reference_Associated_VC ~
        "VC with Bacteroidales reference",

      Has_vFAM9_Only_VC ~
        "VC without Bacteroidales reference",

      Has_Singleton_VC ~
        "Singleton VC",

      Has_Overlap ~
        "Overlap (multi-VC assignment)",

      Has_Outlier ~
        "Outlier (not assigned to VC)",

      Has_Not_Represented ~
        "Not represented in VC2 overview",

      TRUE ~
        "Other / unresolved"
    ),

    Activity_Class = case_when(
      Is_Active_080 &
        Is_Baseline_Significant ~
        "Active & significant",

      Is_Active_080 ~
        "Active, not significant",

      Is_Baseline_Significant ~
        "Significant, but score < 0.8",

      TRUE ~
        "Not active / not significant"
    ),

    Primary_Network_Fate = factor(
      Primary_Network_Fate,
      levels = FATE_LEVELS
    ),

    Activity_Class = factor(
      Activity_Class,
      levels = ACTIVITY_LEVELS
    )
  ) %>%
  arrange(
    Primary_Network_Fate,
    desc(vOTU_Max_Activity_Score),
    vOTU
  )

write_tsv(
  vfam9_votu_fate,
  file.path(
    OUT_DIR,
    "05_vfam9_vOTU_network_fate.tsv"
  )
)

votu_fate_counts <- vfam9_votu_fate %>%
  count(
    Primary_Network_Fate,
    name = "N_vOTUs"
  )

votu_fate_summary <- tibble(
  Primary_Network_Fate = FATE_LEVELS
) %>%
  left_join(
    votu_fate_counts,
    by = "Primary_Network_Fate"
  ) %>%
  mutate(
    N_vOTUs =
      replace_na(
        N_vOTUs,
        0L
      ),

    Percent_vOTUs =
      100 *
      N_vOTUs /
      sum(N_vOTUs)
  ) %>%
  left_join(
    vfam9_votu_fate %>%
      group_by(Primary_Network_Fate) %>%
      summarise(
        N_Active_vOTUs =
          sum(Is_Active_080),

        N_Significant_vOTUs =
          sum(Is_Baseline_Significant),

        N_Active_and_Significant_vOTUs =
          sum(
            Is_Active_080 &
              Is_Baseline_Significant
          ),

        .groups = "drop"
      ),
    by = "Primary_Network_Fate"
  ) %>%
  mutate(
    across(
      starts_with("N_"),
      ~ replace_na(.x, 0L)
    )
  )

write_tsv(
  votu_fate_summary,
  file.path(
    OUT_DIR,
    "06_vfam9_vOTU_fate_summary.tsv"
  )
)

# ============================================================
# 13. Create figures
# ============================================================

message("[8/8] Generating figures...")

theme_vc <- theme_classic(base_size = 12) +
  theme(
    axis.title.y = element_blank(),
    legend.title = element_text(face = "bold"),
    plot.title = element_text(face = "bold"),
    plot.subtitle = element_text(
      color = "#4D4D4D"
    )
  )

# ------------------------------------------------------------
# Figure 1A: Genome-level network fate
# ------------------------------------------------------------

p_genome_fate <- genome_fate_summary %>%
  mutate(
    Network_Fate = factor(
      Network_Fate,
      levels = rev(FATE_LEVELS)
    ),

    Label = sprintf(
      "%d (%.1f%%)",
      N_vFAM9_Genomes,
      Percent_vFAM9_Genomes
    )
  ) %>%
  ggplot(
    aes(
      x = N_vFAM9_Genomes,
      y = Network_Fate,
      fill = Network_Fate
    )
  ) +
  geom_col(
    width = 0.72,
    show.legend = FALSE
  ) +
  geom_text(
    aes(label = Label),
    hjust = -0.12,
    size = 3.6
  ) +
  scale_fill_manual(
    values = FATE_COLORS,
    drop = FALSE
  ) +
  scale_x_continuous(
    expand = expansion(
      mult = c(0, 0.20)
    )
  ) +
  labs(
    title =
      "Network fate of vFAM9 genomes",
    subtitle =
      "Classification is based on vContact2 VC status and direct VC composition",
    x =
      "Number of vFAM9 genomes"
  ) +
  theme_vc

save_plot(
  p_genome_fate,
  "Fig1A_vfam9_genome_network_fate",
  width = 10,
  height = 6
)

# ------------------------------------------------------------
# Figure 1B: vOTU-level primary network fate
# ------------------------------------------------------------

p_votu_fate <- votu_fate_summary %>%
  mutate(
    Primary_Network_Fate = factor(
      Primary_Network_Fate,
      levels = rev(FATE_LEVELS)
    ),

    Label = sprintf(
      "%d (%.1f%%)",
      N_vOTUs,
      Percent_vOTUs
    )
  ) %>%
  ggplot(
    aes(
      x = N_vOTUs,
      y = Primary_Network_Fate,
      fill = Primary_Network_Fate
    )
  ) +
  geom_col(
    width = 0.72,
    show.legend = FALSE
  ) +
  geom_text(
    aes(label = Label),
    hjust = -0.12,
    size = 3.6
  ) +
  scale_fill_manual(
    values = FATE_COLORS,
    drop = FALSE
  ) +
  scale_x_continuous(
    expand = expansion(
      mult = c(0, 0.20)
    )
  ) +
  labs(
    title =
      "Primary network fate of vFAM9 vOTUs",
    subtitle =
      "A vOTU is assigned according to its strongest observed VC evidence",
    x =
      "Number of vOTUs"
  ) +
  theme_vc

save_plot(
  p_votu_fate,
  "Fig1B_vfam9_vOTU_network_fate",
  width = 10,
  height = 6
)

# ------------------------------------------------------------
# Figure 2: Activity composition within network fate
# ------------------------------------------------------------

activity_plot_table <- expand_grid(
  Primary_Network_Fate = FATE_LEVELS,
  Activity_Class = ACTIVITY_LEVELS
) %>%
  left_join(
    vfam9_votu_fate %>%
      count(
        Primary_Network_Fate,
        Activity_Class,
        name = "N_vOTUs"
      ),
    by = c(
      "Primary_Network_Fate",
      "Activity_Class"
    )
  ) %>%
  mutate(
    N_vOTUs =
      replace_na(
        N_vOTUs,
        0L
      ),

    Primary_Network_Fate = factor(
      Primary_Network_Fate,
      levels = rev(FATE_LEVELS)
    ),

    Activity_Class = factor(
      Activity_Class,
      levels = ACTIVITY_LEVELS
    )
  )

p_activity <- ggplot(
  activity_plot_table,
  aes(
    x = N_vOTUs,
    y = Primary_Network_Fate,
    fill = Activity_Class
  )
) +
  geom_col(
    width = 0.72
  ) +
  scale_fill_manual(
    values = ACTIVITY_COLORS,
    drop = FALSE
  ) +
  scale_x_continuous(
    expand = expansion(
      mult = c(0, 0.15)
    )
  ) +
  labs(
    title =
      "Activity status of vFAM9 vOTUs across VC network fates",
    subtitle =
      paste0(
        "Active: maximum Activity_Score >= ",
        ACTIVITY_CUTOFF,
        "; significant: baseline vOTU test"
      ),
    x =
      "Number of vOTUs",
    y = NULL,
    fill =
      "Activity class"
  ) +
  theme_vc

save_plot(
  p_activity,
  "Fig2_vfam9_vOTU_activity_by_network_fate",
  width = 11,
  height = 6
)

# ------------------------------------------------------------
# Figure 3: VC composition scatter plot
# ------------------------------------------------------------

if (nrow(vc_with_vfam9) > 0) {

  p_vc_scatter <- ggplot(
    vc_with_vfam9,
    aes(
      x = Num_vFAM9,
      y = Num_Ref_Bacteroidales,
      size = VC_Size_Input,
      color = VC_Composition,
      shape = VC_Activity_Content
    )
  ) +
    geom_hline(
      yintercept = 0,
      color = "#BDBDBD",
      linewidth = 0.4
    ) +
    geom_point(
      alpha = 0.85,
      stroke = 0.8
    ) +
    scale_color_manual(
      values = VC_COMP_COLORS
    ) +
    scale_size_area(
      max_size = 13
    ) +
    labs(
      title =
        "Composition of VC clusters containing vFAM9 genomes",
      subtitle =
        "VCs on y = 0 contain no Bacteroidales reference genome",
      x =
        "Number of vFAM9 genomes in VC",
      y =
        "Number of Bacteroidales reference genomes in VC",
      color =
        "VC composition",
      size =
        "VC size",
      shape =
        "Activity content"
    ) +
    theme_classic(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold"),
      legend.title = element_text(face = "bold")
    )

  save_plot(
    p_vc_scatter,
    "Fig3_vfam9_VC_composition_scatter",
    width = 10,
    height = 7
  )
}

# ------------------------------------------------------------
# Figure 4: Top VC source compositions
# ------------------------------------------------------------

if (nrow(vc_with_vfam9) > 0) {

  n_show <- min(
    TOP_N_VCS_FOR_BAR,
    nrow(vc_with_vfam9)
  )

  top_vcs <- vc_with_vfam9 %>%
    slice_max(
      order_by = VC_Size_Input,
      n = n_show,
      with_ties = FALSE
    ) %>%
    mutate(
      VC = fct_reorder(
        VC,
        VC_Size_Input
      )
    )

  vc_bar_table <- top_vcs %>%
    select(
      VC,
      Num_vFAM9,
      Num_Ref_Bacteroidales
    ) %>%
    pivot_longer(
      cols = c(
        Num_vFAM9,
        Num_Ref_Bacteroidales
      ),
      names_to = "Source",
      values_to = "N_Genomes"
    ) %>%
    mutate(
      Source = recode(
        Source,
        Num_vFAM9 = "vFAM_9",
        Num_Ref_Bacteroidales =
          "Bacteroidales reference"
      )
    )

  p_vc_bar <- ggplot(
    vc_bar_table,
    aes(
      x = N_Genomes,
      y = VC,
      fill = Source
    )
  ) +
    geom_col(
      width = 0.72
    ) +
    scale_fill_manual(
      values = c(
        "vFAM_9" = "#7ABBCE",
        "Bacteroidales reference" =
          "#E68F9F"
      )
    ) +
    labs(
      title =
        paste0(
          "Top ",
          n_show,
          " largest VCs containing vFAM9 genomes"
        ),
      subtitle =
        "Stacked bars show vFAM9 and Bacteroidales-reference membership",
      x =
        "Number of genomes",
      y = NULL,
      fill =
        "Genome source"
    ) +
    theme_classic(base_size = 11) +
    theme(
      plot.title = element_text(face = "bold"),
      legend.title = element_text(face = "bold")
    )

  save_plot(
    p_vc_bar,
    "Fig4_top_vfam9_VC_source_composition",
    width = 10,
    height = max(6, n_show * 0.18 + 1.5)
  )
}

# ============================================================
# 14. Write analysis notes
# ============================================================

notes <- c(
  "vFAM9 vContact2 network analysis notes",
  "====================================",
  "",
  paste0(
    "Activity threshold: vOTU maximum Activity_Score >= ",
    ACTIVITY_CUTOFF
  ),
  "Significant vOTU: Significance_Type == Significant in stats_baseline_vOTU.tsv.",
  "",
  "Definitions:",
  "- Singleton VC: VC Status = Clustered and direct VC membership = 1 genome.",
  "- VC with Bacteroidales reference: Clustered VC containing >=1 vFAM9 genome and >=1 Bacteroidales reference genome.",
  "- VC without Bacteroidales reference: Clustered VC containing vFAM9 genome(s), but no Bacteroidales reference genome.",
  "- Overlap: vContact2 assigned the genome to multiple overlapping VC contexts; it is retained as a separate category.",
  "- Outlier: genome was not assigned to a final VC by vContact2.",
  "- Not represented: genome exists in vFAM_9_genomes.fasta but is absent from the VC2 overview file.",
  "",
  "Interpretation:",
  "- 'VC without Bacteroidales reference' means no connection to the current reference set under the current vContact2 settings.",
  "- It should not be interpreted as definitive evidence of a new viral family.",
  "- Outlier does not necessarily mean complete absence of protein-sharing edges; it means no final VC assignment.",
  "- vOTU-level primary fate prioritizes direct reference-associated VC evidence over vFAM9-only, singleton, overlap, and outlier evidence."
)

writeLines(
  notes,
  file.path(
    OUT_DIR,
    "README_network_fate_definitions.txt"
  )
)

# ============================================================
# 15. Console summary
# ============================================================

message("")
message("============================================================")
message("vFAM9 VC2 visualization completed")
message("============================================================")
message("Output directory: ", normalizePath(OUT_DIR))

message("")
message("Genome-level fate summary:")
print(
  genome_fate_summary %>%
    select(
      Network_Fate,
      N_vFAM9_Genomes,
      Percent_vFAM9_Genomes
    )
)

message("")
message("vOTU-level fate summary:")
print(
  votu_fate_summary %>%
    select(
      Primary_Network_Fate,
      N_vOTUs,
      Percent_vOTUs,
      N_Active_vOTUs,
      N_Significant_vOTUs
    )
)

message("")
message("Input accounting:")
print(input_accounting)

message("============================================================")
