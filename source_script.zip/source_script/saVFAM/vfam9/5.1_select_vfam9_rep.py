import os
import sys
import csv
import subprocess
from collections import Counter

BASE_DIR = "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/rep_sataxon/9_vfam"

STATS_FILE = "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/1_sataxon/stats_baseline_vOTU.tsv"
VOTU_MAP_FILE = "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/taxonomy/vOTU/genome_to_vOTU.tsv"
NEW_META_FILE = "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
FASTA_FILE = "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp.fasta"

OUT_DIR = os.path.join(BASE_DIR, "5_rep_vOTU")
OUT_TSV = os.path.join(OUT_DIR, "vFAM9_selected_reps_taxonomy.tsv")
OUT_FASTA = os.path.join(OUT_DIR, "vFAM9_selected_reps.fasta")
TEMP_ID_LIST = os.path.join(OUT_DIR, "temp_seqkit_ids.txt")

VFAM_TARGET = "vFAM_9"

def norm_id(raw_id):
    if not raw_id or raw_id == "NA": return "NA"
    return str(raw_id).replace('-', '_').strip()

def main():
    rep_dict = {}
    with open(VOTU_MAP_FILE, 'r', encoding='utf-8') as f:
        for row in csv.reader(f, delimiter='\t'):
            if len(row) >= 3:
                votu_norm = norm_id(row[1])
                rep_norm = norm_id(row[2])
                if votu_norm != "NA" and rep_norm != "NA":
                    rep_dict[votu_norm] = rep_norm

    active_vOTUs = set()
    with open(STATS_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter='\t')
        for row in reader:
            if row.get('Significance_Type', '') == 'Significant':
                votu_norm = norm_id(row.get('vOTU', ''))
                if votu_norm != "NA":
                    active_vOTUs.add(votu_norm)

    vfam9_data = []
    id_to_tax = {}
    
    with open(NEW_META_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if line.startswith('Folder'): continue
            parts = line.strip().split('\t')
            if len(parts) < 40: continue
            
            phage_id_norm = norm_id(parts[4])
            
            vfam_idx = -1
            for i in range(len(parts) - 1, -1, -1):
                p_norm = norm_id(parts[i])
                if p_norm.startswith('vFAM_') or p_norm.startswith('vFAM-'):
                    if i > 0 and (norm_id(parts[i-1]).startswith('vOTU_') or norm_id(parts[i-1]).startswith('vOTU-')):
                        vfam_idx = i
                        break
            
            if vfam_idx != -1:
                vOTU = norm_id(parts[vfam_idx - 1]).replace('vOTU-', 'vOTU_')
                vFAM = norm_id(parts[vfam_idx]).replace('vFAM-', 'vFAM_')
                vSUBFAM = norm_id(parts[vfam_idx + 1]).replace('vSUBFAM-', 'vSUBFAM_') if vfam_idx + 1 < len(parts) else "NA"
                vGENUS = norm_id(parts[vfam_idx + 2]).replace('vGENUS-', 'vGENUS_') if vfam_idx + 2 < len(parts) else "NA"
                vSUBGEN = norm_id(parts[vfam_idx + 3]).replace('vSUBGEN-', 'vSUBGEN_') if vfam_idx + 3 < len(parts) else "NA"
                
                tax_info = {
                    'phage_id': phage_id_norm, 
                    'vOTU': vOTU, 'vFAM': vFAM, 
                    'vSUBFAM': vSUBFAM, 'vGENUS': vGENUS, 'vSUBGEN': vSUBGEN
                }
                id_to_tax[phage_id_norm] = tax_info
                
                if vFAM == VFAM_TARGET:
                    vfam9_data.append(tax_info)

    selected_ids = set()
    
    vfam9_vOTUs = set(d['vOTU'] for d in vfam9_data)
    
    active_in_vfam9 = 0
    for votu in active_vOTUs:
        if votu in vfam9_vOTUs:
            if votu in rep_dict:
                rep_id = rep_dict[votu]
                selected_ids.add(rep_id)
                active_in_vfam9 += 1

    subfam_counts = Counter(d['vSUBFAM'] for d in vfam9_data if d['vSUBFAM'] != 'NA')
    top5_subfams = [item[0] for item in subfam_counts.most_common(5)]
    
    subfam_rep_count = 0
    for subfam in top5_subfams:
        subfam_data = [d for d in vfam9_data if d['vSUBFAM'] == subfam]
        votu_counts_in_subfam = Counter(d['vOTU'] for d in subfam_data if d['vOTU'] != 'NA')
        
        if not votu_counts_in_subfam: continue
        top1_votu_in_subfam = votu_counts_in_subfam.most_common(1)[0][0]
        
        if top1_votu_in_subfam in rep_dict:
            rep_id = rep_dict[top1_votu_in_subfam]
            selected_ids.add(rep_id)
            subfam_rep_count += 1

    os.makedirs(OUT_DIR, exist_ok=True)
    
    out_rows = []
    for sel_id in sorted(list(selected_ids)):
        tax_info = id_to_tax.get(sel_id, {})
        out_rows.append({
            'Rep_Genome_ID': sel_id,
            'vOTU': tax_info.get('vOTU', 'NA'),
            'vFAM': tax_info.get('vFAM', 'NA'),
            'vSUBFAM': tax_info.get('vSUBFAM', 'NA'),
            'vGENUS': tax_info.get('vGENUS', 'NA'),
            'vSUBGEN': tax_info.get('vSUBGEN', 'NA')
        })
        
    with open(OUT_TSV, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['Rep_Genome_ID', 'vOTU', 'vFAM', 'vSUBFAM', 'vGENUS', 'vSUBGEN'], delimiter='\t')
        writer.writeheader()
        writer.writerows(out_rows)

    with open(TEMP_ID_LIST, 'w', encoding='utf-8') as f:
        for sel_id in selected_ids:
            f.write(sel_id + '\n')
            
    try:
        cmd = ['seqkit', 'grep', '-i', '-f', TEMP_ID_LIST, FASTA_FILE, '-o', OUT_FASTA]
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError:
        pass
    except FileNotFoundError:
        pass
        
    if os.path.exists(TEMP_ID_LIST):
        os.remove(TEMP_ID_LIST)

if __name__ == "__main__":
    main()