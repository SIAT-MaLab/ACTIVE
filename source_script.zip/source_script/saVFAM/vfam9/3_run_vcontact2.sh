mkdir -p vcontact2

vcontact2_gene2genome --proteins genomad_annot/allvirus_annotate/allvirus_proteins.faa --output vcontact2/allout_map.csv --source-type Prodigal-FAA

vcontact2 -r genomad_annot/allvirus_annotate/allvirus_proteins.faa -p vcontact2/allout_map.csv --output-dir vcontact2 -t 22 --db None

