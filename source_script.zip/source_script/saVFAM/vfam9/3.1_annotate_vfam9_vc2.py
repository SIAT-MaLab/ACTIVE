from pathlib import Path
import pandas as pd
from Bio import SeqIO

DIR = Path(".")

VFAM9_FASTA = DIR / "vFAM_9_genomes.fasta"
REF_FASTA   = DIR / "INPHARED_GTDBr220_Bacteroidales.fa"

VC2_OVERVIEW = DIR / "vcontact2/genome_by_genome_overview.csv"

ALLPP_META_TSV    = DIR / "../../../../metadata/allpp_metadata.tsv"
BASELINE_STAT_TSV = DIR / "../../../1_sataxon/stats_baseline_vOTU.tsv"

OUT_GENOME_ANNOT = DIR / "vcontact2/vfam9_genome_annotated.tsv"
OUT_VC_SUMMARY   = DIR / "vcontact2/vfam9_cluster_summary.tsv"


def norm_id(s):
    if pd.isna(s):
        return ""
    return str(s).strip().replace("-", "_")


genome_source_map = {}

vfam9_count = 0
if VFAM9_FASTA.exists():
    for record in SeqIO.parse(str(VFAM9_FASTA), "fasta"):
        seq_id = record.id.strip()
        genome_source_map[seq_id] = "vFAM_9"
        genome_source_map[norm_id(seq_id)] = "vFAM_9"
        vfam9_count += 1
else:
    raise FileNotFoundError(VFAM9_FASTA)

ref_count = 0
if REF_FASTA.exists():
    for record in SeqIO.parse(str(REF_FASTA), "fasta"):
        seq_id = record.id.strip()
        genome_source_map[seq_id] = "Ref_Bacteroidales"
        genome_source_map[norm_id(seq_id)] = "Ref_Bacteroidales"
        ref_count += 1
else:
    raise FileNotFoundError(REF_FASTA)


allpp = pd.read_csv(ALLPP_META_TSV, sep="\t", dtype=str)
allpp["Activity_Score"] = pd.to_numeric(allpp["Activity_Score"], errors="coerce").fillna(0.0)

allpp["norm_phage_id"] = allpp["phage_id"].apply(norm_id)

votu_max_act = allpp.groupby("vOTU")["Activity_Score"].max().to_dict()

phage2votu = {}
phage2vsubfam = {}
phage2vgenus = {}
phage2act_max = {}

for _, row in allpp.iterrows():
    nid = row["norm_phage_id"]
    votu = row["vOTU"]
    
    phage2votu[nid] = votu
    phage2vsubfam[nid] = row.get("vSUBFAM", "NA")
    phage2vgenus[nid] = row.get("vGENUS", "NA")
    phage2act_max[nid] = votu_max_act.get(votu, 0.0)

sig_active_votus = set()
if BASELINE_STAT_TSV.exists():
    base_stat = pd.read_csv(BASELINE_STAT_TSV, sep="\t", dtype=str)
    sig_df = base_stat[base_stat["Significance_Type"] == "Significant"]
    sig_active_votus = set(sig_df["vOTU"].dropna().unique())


vc2_df = pd.read_csv(VC2_OVERVIEW, dtype=str)

annot_rows = []

for _, row in vc2_df.iterrows():
    genome = row["Genome"].strip()
    norm_g = norm_id(genome)

    source_origin = genome_source_map.get(genome, genome_source_map.get(norm_g, "Unknown"))
    if source_origin == "vFAM_9":
        source_cat = "vFAM_9"
    elif source_origin == "Ref_Bacteroidales":
        source_cat = "Reference"
    else:
        source_cat = "Unknown"

    votu = phage2votu.get(norm_g, "NA")
    vsubfam = phage2vsubfam.get(norm_g, "NA")
    vgenus = phage2vgenus.get(norm_g, "NA")
    act_score = phage2act_max.get(norm_g, None)

    if votu != "NA" and act_score is not None:
        is_active = (act_score >= 0.8)
        is_sig_active = (votu in sig_active_votus)
    else:
        is_active = False
        is_sig_active = False
        act_score = "NA"

    row_dict = row.to_dict()
    row_dict.update({
        "Source_Origin": source_origin,
        "Source_Category": source_cat,
        "vOTU": votu,
        "vSUBFAM": vsubfam,
        "vGENUS": vgenus,
        "vOTU_Max_Activity_Score": act_score,
        "Is_Active": is_active,
        "Is_Significantly_Active": is_sig_active
    })
    annot_rows.append(row_dict)

annot_df = pd.DataFrame(annot_rows)

front_cols = [
    "Genome", "Source_Origin", "Source_Category", 
    "vOTU", "vSUBFAM", "vGENUS", 
    "vOTU_Max_Activity_Score", "Is_Active", "Is_Significantly_Active",
    "VC Status", "VC"
]
other_cols = [c for c in annot_df.columns if c not in front_cols]
annot_df = annot_df[front_cols + other_cols]

annot_df.to_csv(OUT_GENOME_ANNOT, sep="\t", index=False)


clustered_df = annot_df[
    (annot_df["VC"].notna()) & 
    (annot_df["VC"] != "") & 
    (annot_df["VC Status"] == "Clustered")
].copy()

vc_summaries = []

for vc_id, group in clustered_df.groupby("VC"):
    total_genomes = len(group)
    
    n_vfam9 = (group["Source_Origin"] == "vFAM_9").sum()
    n_ref   = (group["Source_Origin"] == "Ref_Bacteroidales").sum()

    if n_vfam9 > 0 and n_ref == 0:
        comp_type = "Novel_vFAM9_Only"
    elif n_vfam9 == 0 and n_ref > 0:
        comp_type = "Reference_Only"
    elif n_vfam9 > 0 and n_ref > 0:
        comp_type = "Hybrid (vFAM9 + Ref_Bacteroidales)"
    else:
        comp_type = "Other"

    vfam9_sub = group[group["Source_Origin"] == "vFAM_9"]
    
    active_votus = vfam9_sub[vfam9_sub["Is_Active"] == True]["vOTU"].nunique()
    sig_active_votus_cnt = vfam9_sub[vfam9_sub["Is_Significantly_Active"] == True]["vOTU"].nunique()
    
    subfams = sorted(list(set(vfam9_sub["vSUBFAM"].dropna()) - {"NA", ""}))
    genera = sorted(list(set(vfam9_sub["vGENUS"].dropna()) - {"NA", ""}))
    
    subfams_str = ";".join(subfams) if subfams else "NA"
    genera_str = ";".join(genera) if genera else "NA"

    vc_summaries.append({
        "VC": vc_id,
        "VC_Size": total_genomes,
        "Composition_Type": comp_type,
        "Num_vFAM_9": n_vfam9,
        "Num_Ref_Bacteroidales": n_ref,
        "Num_Active_vOTUs": active_votus,
        "Num_Sig_Active_vOTUs": sig_active_votus_cnt,
        "vSUBFAM_List": subfams_str,
        "Num_vSUBFAMs": len(subfams),
        "vGENUS_List": genera_str,
        "Num_vGENUSs": len(genera)
    })

vc_sum_df = pd.DataFrame(vc_summaries)
vc_sum_df = vc_sum_df.sort_values("VC_Size", ascending=False)
vc_sum_df.to_csv(OUT_VC_SUMMARY, sep="\t", index=False)