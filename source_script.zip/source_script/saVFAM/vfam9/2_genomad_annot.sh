 cat vFAM_9_genomes.fasta INPHARED_GTDBr220_Bacteroidales.fa > allvirus.fna
genomad annotate --threads 28 --use-minimal-db allvirus.fna genomad_annot "/home/malab/databases_of_malab/genomad_db/genomad_db/"
