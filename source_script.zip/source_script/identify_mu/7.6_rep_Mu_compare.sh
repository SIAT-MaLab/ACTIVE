mkdir -p  7_mulikephage/compare/clinker_output
cp "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/7_mulikephage/compare/mu_annot/pharokka.gbk" "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/7_mulikephage/compare/annot/single_gbks/"
clinker 7_mulikephage/compare/annot/single_gbks/*gbk -o 7_mulikephage/compare/clinker_output/mu-like.txt -dl "\t" -j 15 -p 7_mulikephage/compare/clinker_output/mu.html
