#!/usr/bin/env Rscript
library(tidyverse)
library(patchwork)
library(scales)

OUT_DIR <- "7_mulikephage"
META_FILE <- file.path("..", "metadata", "allpp_metadata.tsv")

if (!dir.exists(OUT_DIR)) dir.create(OUT_DIR, recursive = TRUE)
if (!file.exists(META_FILE)) {
  stop("Cannot find metadata: ", normalizePath(META_FILE, mustWork = FALSE))
}

format_pval <- function(p) {
  if (is.na(p)) "P = NA" else if (p < 0.001) "P < 0.001" else paste0("P = ", signif(p, 3))
}


cat("Loading lifestyle mapping data from", OUT_DIR, "...\n")
input_file <- file.path(OUT_DIR, "Phage_Lifestyle.tsv")
df <- read_tsv(input_file, show_col_types = FALSE) %>%
  mutate(
    is_active = !is.na(Activity_Score) & Activity_Score >= 0.8,
    Group_Tnp = factor(
      ifelse(Encodes_Transposase == "Yes", "Transposase (+)", "Transposase (-)"),
      levels = c("Transposase (+)", "Transposase (-)")
    ),
    Group_Mu = factor(
      ifelse(Analyzed_Mu_Lifestyle == "Mu-like Lifestyle", "Mu-like", "Other"),
      levels = c("Mu-like", "Other")
    )
  )

write_tsv(df, file.path(OUT_DIR, "clean_df_output.tsv"))
cat("Analysis table exported to clean_df_output.tsv\n")

t2_table <- table(df$Group_Tnp, df$is_active)
f_test_t2 <- fisher.test(t2_table)

t3_table <- table(df$Group_Mu, df$is_active)
f_test_t3 <- fisher.test(t3_table)

stats_t2 <- df %>%
  group_by(Group_Tnp) %>%
  summarise(Total = n(), Active = sum(is_active), Rate = Active / Total, .groups = "drop") %>%
  filter(!is.na(Group_Tnp))

p_t2 <- ggplot(stats_t2, aes(x = Group_Tnp, y = Rate, fill = Group_Tnp)) +
  geom_col(width = 0.5, color = "black", size = 0.3) +
  geom_text(aes(label = paste0(round(Rate * 100, 1), "%\n(n=", Total, ")")), vjust = -0.3, size = 3.5) +
  scale_y_continuous(labels = percent, limits = c(0, max(stats_t2$Rate) * 1.3)) +
  scale_fill_manual(values = c("Transposase (+)" = "#E74C3C", "Transposase (-)" = "#95A5A6")) +
  labs(title = "Transposase Activity", subtitle = format_pval(f_test_t2$p.value), x = "", y = "Active Rate") +
  theme_classic() +
  theme(legend.position = "none", plot.title = element_text(face = "bold"))

stats_t3 <- df %>%
  group_by(Group_Mu) %>%
  summarise(Total = n(), Active = sum(is_active), Rate = Active / Total, .groups = "drop") %>%
  filter(!is.na(Group_Mu))

p_t3 <- ggplot(stats_t3, aes(x = Group_Mu, y = Rate, fill = Group_Mu)) +
  geom_col(width = 0.5, color = "black", size = 0.3) +
  geom_text(aes(label = paste0(round(Rate * 100, 1), "%\n(n=", Total, ")")), vjust = -0.3, size = 3.5) +
  scale_y_continuous(labels = percent, limits = c(0, max(stats_t3$Rate) * 1.3)) +
  scale_fill_manual(values = c("Mu-like" = "#9B59B6", "Other" = "#95A5A6")) +
  labs(title = "Mu-like Lifestyle Activity", subtitle = format_pval(f_test_t3$p.value), x = "", y = "Active Rate") +
  theme_classic() +
  theme(legend.position = "none", plot.title = element_text(face = "bold"))


vfam_counts <- df %>%
  filter(!is.na(vFAM)) %>%
  count(vFAM, name = "Global_Total")

mu_phages <- df %>% filter(Group_Mu == "Mu-like")

vfam_summary_raw <- mu_phages %>%
  filter(!is.na(vFAM)) %>%
  group_by(vFAM) %>%
  summarise(
    Total_Members = n(),
    Active_Count  = sum(is_active),
    Active_Rate   = Active_Count / n(),
    .groups = "drop"
  ) %>%
  left_join(vfam_counts, by = "vFAM") %>%
  mutate(Mu_Proportion = Total_Members / Global_Total) %>%
  arrange(desc(Total_Members)) %>%
  filter(Total_Members > 4)

write_tsv(vfam_summary_raw, file.path(OUT_DIR, "Task3_Mu_like_vFAM_Candidates.tsv"))
cat("Candidate vFAMs (Mu-like n > 4):", nrow(vfam_summary_raw), "\n")

meta <- read_tsv(
  META_FILE,
  show_col_types = FALSE,
  col_select = any_of(c("vFAM", "ictv_Class", "host_Phylum"))
)

vfam_qc <- meta %>%
  filter(vFAM %in% vfam_summary_raw$vFAM) %>%
  mutate(
    ictv_Class = na_if(str_squish(as.character(ictv_Class)), ""),
    is_caudo = if_else(
      is.na(ictv_Class),
      NA,
      str_detect(ictv_Class, regex("Caudoviricetes", ignore_case = TRUE))
    )
  ) %>%
  group_by(vFAM) %>%
  summarise(
    n_meta = n(),
    n_caudo = sum(is_caudo %in% TRUE),
    n_non_caudo = sum(is_caudo %in% FALSE),
    n_class_na = sum(is.na(is_caudo)),
    ictv_classes = paste(sort(unique(na.omit(ictv_Class))), collapse = "; "),
    non_caudo_classes = paste(sort(unique(ictv_Class[is_caudo %in% FALSE])), collapse = "; "),
    n_host_phyla = n_distinct(host_Phylum[!is.na(host_Phylum) & host_Phylum != "Unknown"]),
    host_phyla = paste(
      sort(unique(na.omit(host_Phylum[host_Phylum != "Unknown"]))),
      collapse = "; "
    ),
    .groups = "drop"
  ) %>%
  mutate(is_pure_caudo = n_non_caudo == 0)

vfam_qc_full <- vfam_summary_raw %>%
  left_join(vfam_qc, by = "vFAM") %>%
  mutate(
    n_meta = replace_na(n_meta, 0L),
    n_caudo = replace_na(n_caudo, 0L),
    n_non_caudo = replace_na(n_non_caudo, 0L),
    n_class_na = replace_na(n_class_na, 0L),
    is_pure_caudo = replace_na(is_pure_caudo, TRUE),
    missing_in_metadata = n_meta == 0
  )

write_tsv(vfam_qc_full, file.path(OUT_DIR, "Task3_candidate_vFAM_QC.tsv"))

dropped_vfams <- vfam_qc_full %>%
  filter(!is_pure_caudo) %>%
  arrange(desc(n_non_caudo), desc(Total_Members))

write_tsv(dropped_vfams, file.path(OUT_DIR, "Task3_dropped_vFAM.tsv"))

if (any(vfam_qc_full$missing_in_metadata)) {
  cat(
    "Warning: candidate vFAM not found in metadata and kept by default:",
    paste(vfam_qc_full$vFAM[vfam_qc_full$missing_in_metadata], collapse = ", "),
    "\n"
  )
}

if (nrow(dropped_vfams) > 0) {
  cat("Dropped contaminated vFAMs:\n")
  cat(
    paste0(
      "  ", dropped_vfams$vFAM,
      " | non-Caudo n=", dropped_vfams$n_non_caudo,
      " | classes: ", dropped_vfams$non_caudo_classes
    ),
    sep = "\n"
  )
  cat("\n")
} else {
  cat("All candidate vFAMs are pure Caudoviricetes in metadata.\n")
}

vfam_summary <- vfam_qc_full %>%
  filter(is_pure_caudo) %>%
  arrange(desc(Total_Members)) %>%
  mutate(vFAM = factor(vFAM, levels = rev(vFAM))) %>%
  select(vFAM, Total_Members, Active_Count, Active_Rate, Global_Total, Mu_Proportion)

write_tsv(vfam_summary, file.path(OUT_DIR, "Task3_Mu_like_vFAM_Summary.tsv"))
cat("Pure candidate vFAMs retained for Figure B:", nrow(vfam_summary), "\n")


if (nrow(vfam_summary) > 0) {
  p_b1 <- ggplot(vfam_summary, aes(x = vFAM, y = Total_Members)) +
    geom_col(fill = "#3498DB", width = 0.6) +
    geom_text(aes(label = Total_Members), hjust = -0.2, size = 3) +
    scale_y_log10(expand = expansion(mult = c(0, 0.6))) +
    coord_flip() +
    labs(title = "Mu-like Counts", x = "vFAM", y = "Count (log10)") +
    theme_bw()

  p_b2 <- ggplot(vfam_summary, aes(x = vFAM, y = Active_Rate)) +
    geom_col(fill = "#5DADE2", color = "black", width = 0.6) +
    geom_text(aes(label = paste0(round(Active_Rate * 100, 0), "%")), hjust = -0.2, size = 3) +
    scale_y_continuous(labels = percent, expand = expansion(mult = c(0, 0.3))) +
    coord_flip() +
    labs(title = "Active Rate", x = "", y = "Rate") +
    theme_bw() +
    theme(axis.text.y = element_blank(), axis.ticks.y = element_blank())

  p_b3 <- ggplot(vfam_summary, aes(x = vFAM, y = Mu_Proportion)) +
    geom_col(fill = "#8E44AD", alpha = 0.7, width = 0.6) +
    geom_text(aes(label = paste0(round(Mu_Proportion * 100, 0), "%")), hjust = -0.2, size = 3) +
    scale_y_continuous(labels = percent, limits = c(0, 1.2), expand = expansion(mult = c(0, 0))) +
    coord_flip() +
    labs(title = "Prop. of Mu-like in vFAM", x = "", y = "Proportion") +
    theme_bw() +
    theme(axis.text.y = element_blank(), axis.ticks.y = element_blank())

  layout_b <- p_b1 + p_b2 + p_b3 + plot_layout(widths = c(1.2, 1, 1))
} else {
  layout_b <- ggplot() +
    theme_void() +
    labs(title = "No pure candidate vFAM remaining")
}


mu_phages_host <- df %>%
  filter(Analyzed_Mu_Lifestyle == "Mu-like Lifestyle")

host_initial_summary <- mu_phages_host %>%
  filter(!is.na(host_Family) & host_Family != "Unknown") %>%
  group_by(host_Family) %>%
  summarise(
    Total_Members = n(),
    Active_Count  = sum(is_active),
    .groups = "drop"
  )

host_plot_df <- host_initial_summary %>%
  mutate(host_Family_Group = if_else(Total_Members >= 4, host_Family, "Other")) %>%
  group_by(host_Family_Group) %>%
  summarise(
    Total_Members = sum(Total_Members),
    Active_Count  = sum(Active_Count),
    .groups = "drop"
  ) %>%
  mutate(Active_Rate = Active_Count / Total_Members) %>%
  mutate(is_other = host_Family_Group == "Other") %>%
  arrange(is_other, desc(Total_Members))

host_levels <- host_plot_df$host_Family_Group
host_plot_df <- host_plot_df %>%
  mutate(host_Family = factor(host_Family_Group, levels = rev(host_levels)))

write_tsv(host_plot_df, file.path(OUT_DIR, "Task3_Mu_like_Host_Summary.tsv"))

if (nrow(host_plot_df) > 0) {
  p_c1 <- ggplot(host_plot_df, aes(x = host_Family, y = Total_Members)) +
    geom_col(fill = "#2ECC71", width = 0.6) +
    geom_text(aes(label = Total_Members), hjust = -0.2, size = 3) +
    scale_y_log10(expand = expansion(mult = c(0, 0.6))) +
    coord_flip() +
    labs(title = "Host Family Counts (MuAB+)", x = "Host Family", y = "Count (log10)") +
    theme_bw()

  p_c2 <- ggplot(host_plot_df, aes(x = host_Family, y = Active_Rate)) +
    geom_col(fill = "#58D68D", color = "black", width = 0.6) +
    geom_text(aes(label = paste0(round(Active_Rate * 100, 0), "%")), hjust = -0.2, size = 3) +
    scale_y_continuous(labels = percent, expand = expansion(mult = c(0, 0.3))) +
    coord_flip() +
    labs(title = "Active Rate", x = "", y = "Rate") +
    theme_bw() +
    theme(axis.text.y = element_blank(), axis.ticks.y = element_blank())

  layout_c <- p_c1 + p_c2 + plot_layout(widths = c(1.2, 1))
} else {
  layout_c <- ggplot() + theme_void() + labs(title = "No host data available")
}


cat("Saving final figure panel to", OUT_DIR, "...\n")
panel_left <- p_t2 / p_t3
final_layout <- (panel_left | layout_b | layout_c) +
  plot_layout(widths = c(1, 3, 2)) +
  plot_annotation(
    title = "Activity & Genomic Insights of Transposable and Mu-like Gut Prophages",
    subtitle = "Analysis on High-Quality Caudoviricetes Prophages",
    theme = theme(plot.title = element_text(size = 16, face = "bold"))
  )

output_pdf_path <- file.path(OUT_DIR, "Integrated_Prophage_Lifestyle_Analysis.pdf")
ggsave(output_pdf_path, final_layout, width = 18, height = 7, dpi = 300)
cat("Workflow completed! Plot saved to:", output_pdf_path, "\n")
