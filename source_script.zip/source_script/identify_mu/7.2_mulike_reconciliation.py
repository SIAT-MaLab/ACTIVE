#!/usr/bin/env python3
import pandas as pd
import numpy as np
import os

# ==============================================================================
# 文件路径定义（全部使用 7_mulikephage）
# ==============================================================================
METADATA_FILE = "../metadata/hqphage_metadata.tsv"
PHAROKKA_FILE = "../metadata/allpharokka_annot.tsv"
PC_MAP_FILE   = "allpp_PC_map.tsv"

TARGET_DIR    = "7_mulikephage"
PFAM_FILE     = os.path.join(TARGET_DIR, "pfam_merged_best_hits.tsv")
ISE_FILE      = os.path.join(TARGET_DIR, "isescan_best_hits_cleaned.tsv")
COG_FILE      = os.path.join(TARGET_DIR, "COG2842_result.final.tsv")
OUTPUT_FILE   = os.path.join(TARGET_DIR, "Phage_Lifestyle.tsv")

print(f"Loading datasets, outputs will go to {TARGET_DIR}...")

# 载入高质量元数据并转换 ID（把 - 换成 _）
df_meta = pd.read_csv(METADATA_FILE, sep='\t', low_memory=False)
df_meta['Merge_Key'] = df_meta['phage_id'].astype(str).str.replace('-', '_', regex=False)

# 读取 Pharokka 注释并根据高质量 Contig 快速过滤 (减小内存开销)
df_cds = pd.read_csv(PHAROKKA_FILE, sep='\t', low_memory=False)
hq_contigs = set(df_meta['Merge_Key'].unique())
df_cds = df_cds[df_cds['contig'].isin(hq_contigs)].copy()

# ==============================================================================
# 提取整合酶与转座酶结构域 (Pfam)
# ==============================================================================
integrase_pfams = {'PF07508', 'PF00239', 'PF00589'}
transposase_pfams = {'PF00665', 'PF13333', 'PF13683'}

pfam_gene_annot = {}
if os.path.exists(PFAM_FILE):
    with open(PFAM_FILE, 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) > 5:
                gene_id = parts[0]
                pfam_id = parts[4].split('.')[0]
                if pfam_id in integrase_pfams:
                    pfam_gene_annot[gene_id] = 'integrase'
                elif pfam_id in transposase_pfams:
                    pfam_gene_annot[gene_id] = 'transposase'

# ==============================================================================
# 提取 ISEScan 转座酶特征
# ==============================================================================
isescan_valid_hits = set()
if os.path.exists(ISE_FILE):
    df_ise = pd.read_csv(ISE_FILE, sep='\t', header=None, comment='#', usecols=range(10))
    subset_ise = df_ise[(df_ise[6] <= 1e-9) & (df_ise[7] >= 60)]
    isescan_valid_hits = set(subset_ise[0].values)

# ==============================================================================
# 整合 Pharokka 软件注释与结构域，解决冲突
# ==============================================================================
df_cds['annot_lower'] = df_cds['annot'].fillna('').astype(str).str.lower()
df_cds['phys_start'] = df_cds[['start', 'stop']].min(axis=1)
df_cds = df_cds.sort_values(by=['contig', 'phys_start']).reset_index(drop=True)

def map_roles(row):
    gene = row['gene']
    annot = row['annot_lower']
    p_annot = pfam_gene_annot.get(gene, 'None')
    
    is_int_ph = 'integrase' in annot
    is_trans_ph = 'transposase' in annot or 'transposon' in annot
    
    if p_annot == 'integrase':
        return 'integrase', 'Pfam'
    elif p_annot == 'transposase':
        return 'transposase', 'Pfam'
    elif is_int_ph and not is_trans_ph:
        return 'integrase', 'Pharokka'
    elif is_trans_ph and not is_int_ph:
        return 'transposase', 'Pharokka'
    elif 'hypothetical' in annot and gene in isescan_valid_hits:
        return 'transposase', 'ISEScan'
    else:
        return 'None', 'None'

df_cds[['Final_Role', 'Source']] = df_cds.apply(map_roles, axis=1, result_type='expand')
df_cds['Is_Transposase'] = df_cds['Final_Role'] == 'transposase'
df_cds['Is_Integrase'] = df_cds['Final_Role'] == 'integrase'

# ==============================================================================
# 映射 COG2842 (Mu_TnpB) 标志基因
# ==============================================================================
cog_reps = set()
if os.path.exists(COG_FILE):
    with open(COG_FILE, 'r') as f:
        for line in f:
            parts = line.strip().split('\t')
            if parts:
                cog_reps.add(parts[0])

mu_tnpb_genes = set()
if os.path.exists(PC_MAP_FILE) and cog_reps:
    df_map = pd.read_csv(PC_MAP_FILE, sep='\t', low_memory=False)
    matched = df_map[df_map['rep_seq_id'].isin(cog_reps)]
    mu_tnpb_genes = set(matched['protein_id'].values)

df_cds['Is_Mu_TnpB'] = df_cds['gene'].isin(mu_tnpb_genes)

# ==============================================================================
# 邻近共线性分析
# ==============================================================================
genome_results = {}
for contig, group in df_cds.groupby('contig'):
    group = group.sort_values('phys_start').reset_index(drop=True)
    n_genes = len(group)
    
    has_tnp = group['Is_Transposase'].any()
    has_int = group['Is_Integrase'].any()
    
    if has_int and not has_tnp:
        basic_lifestyle = 'Integrase_lifestyle'
    elif has_tnp and not has_int:
        basic_lifestyle = 'Transposase_lifestyle'
    elif has_int and has_tnp:
        basic_lifestyle = 'Mixed_lifestyle'
    else:
        basic_lifestyle = 'Unannotated'
        
    tnp_indices = group.index[group['Is_Transposase']].tolist()
    mu_indices = group.index[group['Is_Mu_TnpB']].tolist()
    
    mu_lifestyle = "Other"
    tnp_gene, tnp_source, mu_gene = "NA", "NA", "NA"
    found_pair = False
    
    for idx in tnp_indices:
        strand = group.loc[idx, 'frame']
        if idx > 0 and group.loc[idx - 1, 'Is_Mu_TnpB']:
            if group.loc[idx - 1, 'frame'] == strand:
                found_pair, tnp_gene, mu_gene = True, group.loc[idx, 'gene'], group.loc[idx - 1, 'gene']
                tnp_source = group.loc[idx, 'Source']
                break
        if idx < n_genes - 1 and group.loc[idx + 1, 'Is_Mu_TnpB']:
            if group.loc[idx + 1, 'frame'] == strand:
                found_pair, tnp_gene, mu_gene = True, group.loc[idx, 'gene'], group.loc[idx + 1, 'gene']
                tnp_source = group.loc[idx, 'Source']
                break

    if found_pair:
        mu_lifestyle = "Mu-like Lifestyle"
    elif len(tnp_indices) > 0 and len(mu_indices) == 0:
        mu_lifestyle = "Transposon Insertion / Other Tnp"
        tnp_gene, tnp_source = group.loc[tnp_indices[0], 'gene'], group.loc[tnp_indices[0], 'Source']
    elif len(tnp_indices) == 0 and len(mu_indices) > 0:
        mu_lifestyle = "Orphan Mu_TnpB"
        mu_gene = group.loc[mu_indices[0], 'gene']
    elif len(tnp_indices) > 0 and len(mu_indices) > 0:
        mu_lifestyle = "Transposase + Mu_TnpB (Separated)"
        tnp_gene, mu_gene = group.loc[tnp_indices[0], 'gene'], group.loc[mu_indices[0], 'gene']

    genome_results[contig] = {
        'Contig': contig,
        'Basic_Lifestyle': basic_lifestyle,
        'Encodes_Transposase': 'Yes' if has_tnp else 'No',
        'Analyzed_Mu_Lifestyle': mu_lifestyle,
        'Tnp_Gene': tnp_gene,
        'Tnp_Source': tnp_source,
        'Mu_TnpB_Gene': mu_gene
    }

df_res = pd.DataFrame.from_dict(genome_results, orient='index')

# ==============================================================================
# 最终合并高质量元数据并输出
# ==============================================================================
df_final = df_res.merge(df_meta, left_on='Contig', right_on='Merge_Key', how='right')

cols_to_export = [
    'phage_id', 'Basic_Lifestyle', 'Encodes_Transposase', 'Analyzed_Mu_Lifestyle',
    'Tnp_Gene', 'Tnp_Source', 'Mu_TnpB_Gene',
    'v_Family', 'ictv_Class', 'vOTU', 'vFAM', 'vSUBFAM', 'vGENUS', 
    'Activity_Score', 'host_Family', 'host_Genus', 'host_Species'
]
cols_final = [c for c in cols_to_export if c in df_final.columns]

df_final[cols_final].to_csv(OUTPUT_FILE, sep='\t', index=False)
print(f"Success! Lifestyle decisions written to {OUTPUT_FILE}")
