#!/bin/bash
#SBATCH --jobs=24
#set -e

THREADS=26
PROT_FILE="6_genetic_factor/hqpp_proteins.faa"
PFAM_DIR="/home/huangyan/experiment/SPA/3/gut_isolate/prophage/analysis/3_prophage_stats/allpp_annot/pfamscan"
ISESCAN_HMM="/home/huangyan/experiment/SPA/3/gut_isolate/prophage/analysis/3_prophage_stats/allpp_annot/isescan_results/clusters.faa.hmm"
COG_DB="/home/huangyan/databaseHY/CDD/raw/COG2842_db"

OUT_DIR="7_mulikephage"
mkdir -p "$OUT_DIR"

echo "[$(date)] Starting Phage Annotation Pipeline..."
echo "All outputs will be saved to: $OUT_DIR"

echo "[$(date)] Checking Pfam HMMER checkpoints..."
PFAM_IDS=("PF00239" "PF00589" "PF00665" "PF07508" "PF13333" "PF13683")

bg_jobs=0
for pfam in "${PFAM_IDS[@]}"; do
    hmm_path="${PFAM_DIR}/${pfam}.hmm"
    out_domtblout="${OUT_DIR}/${pfam}.domtblout"
    
    if [ -f "$out_domtblout" ] && [ -s "$out_domtblout" ]; then
        echo "  [SKIP] Pfam $pfam already processed ($out_domtblout exists)."
    else
        if [ -f "$hmm_path" ]; then
            echo "  [RUN] Running hmmsearch for $pfam..."
            hmmsearch --cpu 4 --noali -E 1e-5 --domtblout "$out_domtblout" "$hmm_path" "$PROT_FILE" > /dev/null &
            bg_jobs=$((bg_jobs + 1))
        else
            echo "  [ERROR] $hmm_path not found!"
        fi
    fi
done

if [ "$bg_jobs" -gt 0 ]; then
    echo "Waiting for active Pfam hmmsearch jobs to finish..."
    wait
else
    echo "All Pfam HMM search checkpoints PASSED."
fi

echo "[$(date)] Checking ISEScan HMMER checkpoint..."
ISE_DOMTBLOUT="${OUT_DIR}/isescan.domtblout"

if [ -f "$ISE_DOMTBLOUT" ] && [ -s "$ISE_DOMTBLOUT" ]; then
    echo "  [SKIP] ISEScan already processed ($ISE_DOMTBLOUT exists)."
else
    echo "  [RUN] Running hmmsearch for ISEScan..."
    hmmsearch --cpu $THREADS --noali -E 1e-5 --domtblout "$ISE_DOMTBLOUT" "$ISESCAN_HMM" "$PROT_FILE" > /dev/null
fi

echo "[$(date)] Checking RPS-BLAST checkpoint..."
COG_RAW_OUT="${OUT_DIR}/COG2842_result.tsv"

if [ -f "$COG_RAW_OUT" ] && [ -s "$COG_RAW_OUT" ]; then
    echo "  [SKIP] RPS-BLAST already processed ($COG_RAW_OUT exists)."
else
    echo "  [RUN] Running RPS-BLAST for COG2842..."
    rpsblast -query $PROT_FILE -db "$COG_DB" -evalue 1e-5 -outfmt "6 qseqid sseqid pident length qstart qend sstart send evalue bitscore" -out "$COG_RAW_OUT" -num_threads $THREADS
fi


echo "[$(date)] Filtering best hits..."

awk '{
    if ($0 == "" || /^==>/ || /^#/) next; 
    query = $1; evalue = $7 + 0; 
    if (!(query in min_e) || evalue < min_e[query]) {
        min_e[query] = evalue;
        best_line[query] = $0;
    }
} 
END {
    for (q in best_line) print best_line[q];
}' ${OUT_DIR}/PF*.domtblout > ${OUT_DIR}/pfam_merged_best_hits.tsv

awk '{
    if ($0 == "" || /^==>/ || /^#/) next; 
    query = $1; evalue = $7 + 0; 
    if (!(query in min_e) || evalue < min_e[query]) {
        min_e[query] = evalue;
        best_line[query] = $0;
    }
} 
END {
    for (q in best_line) {
        gsub(/[[:space:]]+/, "\t", best_line[q]);
        print best_line[q];
    }
}' "$ISE_DOMTBLOUT" > ${OUT_DIR}/isescan_best_hits_cleaned.tsv

if [ -f "$COG_RAW_OUT" ]; then
    awk '$9 <= 1e-9 && $10 > 50' "$COG_RAW_OUT" > ${OUT_DIR}/COG2842_result.final.tsv
fi

echo "[$(date)] Annotation phase completed successfully!"
