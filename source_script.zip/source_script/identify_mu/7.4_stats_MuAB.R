#!/usr/bin/env Rscript

library(dplyr)
library(readr)
library(stringr)
library(ggplot2)
library(patchwork)

META_FILE      <- "../metadata/hqphage_metadata.tsv"
ANNOT_FILE     <- "../metadata/allpharokka_annot.tsv"
LIFESTYLE_FILE <- "7_mulikephage/Phage_Lifestyle.tsv"

DIR_OUT        <- "7_mulikephage/MuAB_analysis_results"
if(!dir.exists(DIR_OUT)) dir.create(DIR_OUT)

OUT_TSV_ADJ    <- file.path(DIR_OUT, "Caudo_Transposase_Adjacent_Genes_Stats.tsv")
OUT_TSV_LIFE   <- file.path(DIR_OUT, "Caudo_Mu_Lifestyle_Stats.tsv")
OUT_PLOT_COMB  <- file.path(DIR_OUT, "Caudo_Phage_Combined_Analysis.pdf")

df_meta  <- read_tsv(META_FILE, show_col_types = FALSE)
df_cds   <- read_tsv(ANNOT_FILE, show_col_types = FALSE)
df_life  <- read_tsv(LIFESTYLE_FILE, show_col_types = FALSE)

df_meta  <- df_meta  %>% mutate(phage_id_clean = str_replace_all(phage_id, "-", "_"))
df_cds   <- df_cds   %>% mutate(contig_clean   = str_replace_all(contig, "-", "_"))
df_life  <- df_life  %>% mutate(phage_id_clean = str_replace_all(phage_id, "-", "_"))

caudo_phages_clean <- df_meta %>%
  filter(str_detect(ictv_Class, "(?i)Caudo")) %>%
  pull(phage_id_clean) %>%
  unique()

total_caudo_count <- length(caudo_phages_clean)

df_cds_caudo <- df_cds %>%
  filter(contig_clean %in% caudo_phages_clean)

df_processed <- df_cds_caudo %>%
  mutate(
    phys_start = pmin(start, stop),
    annot_lower = tolower(annot),
    is_transposase = str_detect(annot_lower, "transposase|transposon")
  ) %>%
  arrange(contig, phys_start)

df_adj <- df_processed %>%
  group_by(contig) %>%
  mutate(
    prev_is_tnp = lag(is_transposase, default = FALSE),
    prev_frame  = lag(frame, default = "NA"),
    next_is_tnp = lead(is_transposase, default = FALSE),
    next_frame  = lead(frame, default = "NA")
  ) %>%
  filter(
    is_transposase == FALSE & (
      (prev_is_tnp == TRUE & prev_frame == frame) |
      (next_is_tnp == TRUE & next_frame == frame)
    )
  ) %>%
  ungroup() %>%
  distinct(gene, .keep_all = TRUE)

total_valid_adj_contigs <- n_distinct(df_adj$contig)

df_adj_stats <- df_adj %>%
  distinct(contig, phrog, category, annot) %>%
  group_by(phrog, category, annot) %>%
  summarise(Contig_Count = n(), .groups = "drop") %>%
  mutate(Genome_Frequency_Pct = (Contig_Count / total_valid_adj_contigs) * 100) %>%
  arrange(desc(Contig_Count))

write_tsv(df_adj_stats, OUT_TSV_ADJ)

top10_adj <- df_adj_stats %>%
  head(10) %>%
  mutate(
    short_annot = str_trunc(annot, 35, "right"),
    plot_label = sprintf("%s\n(%s)", phrog, short_annot)
  )

p1 <- ggplot(top10_adj, aes(x = reorder(plot_label, Genome_Frequency_Pct), y = Genome_Frequency_Pct, fill = category)) +
  geom_bar(stat = "identity", color = "black", alpha = 0.8) +
  coord_flip() +
  scale_y_continuous(expand = expansion(mult = c(0, 0.1))) +
  theme_bw(base_size = 11) +
  theme(
    axis.text.y = element_text(size = 9, face = "bold"),
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5),
    legend.position = "bottom",
    legend.title = element_text(size = 9),
    legend.text = element_text(size = 8)
  ) +
  labs(
    title = "Top 10 Co-directional Genes Adjacent to Transposase",
    x = "PHROG & Annotation",
    y = "Genome Presence Frequency (%)",
    fill = "Phrog Category"
  )

df_life_caudo <- df_life %>%
  filter(phage_id_clean %in% caudo_phages_clean)

df_mu_stats <- df_life_caudo %>%
  filter(
    !is.na(Analyzed_Mu_Lifestyle),
    !str_detect(Analyzed_Mu_Lifestyle, "(?i)^(unknown|other)$")
  ) %>%
  group_by(Analyzed_Mu_Lifestyle) %>%
  summarise(Count = n(), .groups = "drop") %>%
  mutate(Percentage = (Count / sum(Count)) * 100) %>%
  arrange(desc(Count))

write_tsv(df_mu_stats, OUT_TSV_LIFE)
total_analyzed_mu <- sum(df_mu_stats$Count)

p2 <- ggplot(df_mu_stats, aes(x = reorder(Analyzed_Mu_Lifestyle, Percentage),
                              y = Percentage, fill = Analyzed_Mu_Lifestyle)) +
  geom_col(color = "black", alpha = 0.8, show.legend = FALSE) +
  geom_text(aes(label = sprintf("%.1f%% (%d)", Percentage, Count)),
            hjust = -0.1, size = 3.5, fontface = "bold") +
  coord_flip() +
  scale_y_continuous(expand = expansion(mult = c(0, 0.2))) +
  scale_fill_brewer(palette = "Set2") +
  theme_bw(base_size = 11) +
  theme(
    axis.text.y = element_text(size = 10, face = "bold"),
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5)
  ) +
  labs(
    title = "Mu-like Lifestyle among MuA/MuB-encoding Phages",
    subtitle = sprintf("MuA/MuB-encoding genomes: %d", total_analyzed_mu),
    x = "Mu-like Lifestyle Category",
    y = "Percentage (%)"
  )

combined_plot <- (p1 / p2) +
  plot_annotation(
    title = "Genomic Features and Lifestyle Landscape of Caudoviricetes Prophages",
    theme = theme(plot.title = element_text(size = 14, face = "bold", hjust = 0.5))
  )

ggsave(OUT_PLOT_COMB, plot = combined_plot, width = 11, height = 10, dpi = 300)

message(OUT_TSV_ADJ)
message(OUT_TSV_LIFE)
message(OUT_PLOT_COMB)