#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
From 7.3 QC'd vFAM summary, keep strict Mu-like families, pick the largest
vOTU representative from HQ metadata, extract FASTA, run Pharokka.
"""

import os
import sys
import subprocess
import pandas as pd

OUT_DIR = "7_mulikephage"
COMPARE_DIR = os.path.join(OUT_DIR, "compare")
ANNOT_DIR = os.path.join(COMPARE_DIR, "annot")

SUMMARY_FILE = os.path.join(OUT_DIR, "Task3_Mu_like_vFAM_Summary.tsv")
METADATA_FILE = os.path.join("..", "metadata", "allpp_metadata.tsv")
VOTU_MAP_FILE = os.path.join("..", "taxonomy", "vOTU", "genome_to_vOTU.tsv")
FASTA_FILE = os.path.join("..", "metadata", "allpp.fasta")

MU_PROPORTION_CUTOFF = 0.5
MIN_MU_MEMBERS = 5
PHAROKKA_DB = "/home/huangyan/databaseHY/pharokka_v1.8.0_databases/"

os.makedirs(COMPARE_DIR, exist_ok=True)
os.makedirs(ANNOT_DIR, exist_ok=True)


def normalize_id(seq_id):
    return str(seq_id).replace("-", "_").replace(".", "_")


def is_caudo(x):
    if pd.isna(x):
        return False
    s = str(x).strip()
    return s != "" and "caudoviricetes" in s.lower()


print("=====[ Phase 1: Strict Mu-like vFAMs from 7.3 summary ]=====")

for path in (SUMMARY_FILE, METADATA_FILE, VOTU_MAP_FILE, FASTA_FILE):
    if not os.path.exists(path):
        sys.exit(f"Error: {path} not found.")

summary = pd.read_csv(SUMMARY_FILE, sep="\t")
need = {"vFAM", "Total_Members", "Global_Total", "Mu_Proportion"}
missing = need - set(summary.columns)
if missing:
    sys.exit(f"Error: {SUMMARY_FILE} missing columns: {sorted(missing)}")

strict_vfams_df = (
    summary.loc[
        (summary["Total_Members"] >= MIN_MU_MEMBERS)
        & (summary["Mu_Proportion"] >= MU_PROPORTION_CUTOFF)
    ]
    .sort_values(["Total_Members", "vFAM"], ascending=[False, True])
    .copy()
)
strict_vfams_df["vFAM"] = strict_vfams_df["vFAM"].astype(str)

if strict_vfams_df.empty:
    sys.exit(
        f"Error: no vFAM passed Mu-like n >= {MIN_MU_MEMBERS} "
        f"and Mu_Proportion >= {MU_PROPORTION_CUTOFF}."
    )

strict_vfams = strict_vfams_df["vFAM"].tolist()
print(
    f"Kept {len(strict_vfams)} vFAMs "
    f"(Mu-like n >= {MIN_MU_MEMBERS}, Mu-like % >= {MU_PROPORTION_CUTOFF:.0%}):"
)
print(strict_vfams_df.to_string(index=False))
strict_vfams_df.to_csv(
    os.path.join(COMPARE_DIR, "strict_Mu_like_vFAMs.tsv"),
    sep="\t",
    index=False,
)


print("\n=====[ Phase 2: Largest vOTU per vFAM from HQ metadata ]=====")

meta = pd.read_csv(METADATA_FILE, sep="\t", low_memory=False)
for col in ("vFAM", "vOTU"):
    if col not in meta.columns:
        sys.exit(f"Error: {METADATA_FILE} missing column {col}")

meta["vFAM"] = meta["vFAM"].astype(str)
meta = meta.loc[
    meta["vFAM"].isin(strict_vfams)
    & meta["vOTU"].notna()
    & (meta["vOTU"].astype(str).str.strip() != "")
].copy()
meta["vOTU"] = meta["vOTU"].astype(str)


if "ictv_Class" in meta.columns:
    n_before = len(meta)
    meta = meta.loc[meta["ictv_Class"].map(is_caudo)].copy()
    n_drop = n_before - len(meta)
    if n_drop:
        print(f"Dropped {n_drop} non-Caudoviricetes rows from HQ metadata.")

votu_in_vfam = (
    meta.groupby(["vFAM", "vOTU"], as_index=False)
    .size()
    .rename(columns={"size": "n_in_vfam_hq"})
)

largest = (
    votu_in_vfam.sort_values(
        ["vFAM", "n_in_vfam_hq", "vOTU"],
        ascending=[True, False, True],
    )
    .groupby("vFAM", as_index=False)
    .head(1)
)

votu_map = pd.read_csv(VOTU_MAP_FILE, sep="\t", names=["Genome", "vOTU", "Rep"])
votu_map["vOTU"] = votu_map["vOTU"].astype(str)
votu_global_n = votu_map.groupby("vOTU").size().to_dict()
votu_to_rep = (
    votu_map.dropna(subset=["vOTU", "Rep"])
    .drop_duplicates(subset=["vOTU"], keep="first")
    .set_index("vOTU")["Rep"]
    .to_dict()
)

selected_rows = []
for vfam in strict_vfams:
    hit = largest.loc[largest["vFAM"] == vfam]
    if hit.empty:
        print(f"Warning: {vfam} has no vOTU in HQ metadata, skipped.")
        continue
    votu = hit["vOTU"].iloc[0]
    n_hq = int(hit["n_in_vfam_hq"].iloc[0])
    rep = votu_to_rep.get(votu)
    if not rep:
        print(f"Warning: {vfam} / {votu} has no Rep in genome_to_vOTU, skipped.")
        continue
    selected_rows.append(
        {
            "vFAM": vfam,
            "vOTU": votu,
            "n_in_vfam_hq": n_hq,
            "votu_global_size": int(votu_global_n.get(votu, 0)),
            "rep_genome": rep,
        }
    )

if not selected_rows:
    sys.exit("Error: no representative genomes mapped.")

print(f"{'vFAM':<12} {'vOTU':<15} {'n_HQ':<8} {'global':<8} {'Rep'}")
for row in selected_rows:
    print(
        f"{row['vFAM']:<12} {row['vOTU']:<15} {row['n_in_vfam_hq']:<8} "
        f"{row['votu_global_size']:<8} {row['rep_genome']}"
    )


print("\n=====[ Phase 3: Extract representative FASTA ]=====")

fasta_headers = []
with open(FASTA_FILE) as f:
    for line in f:
        if line.startswith(">"):
            fasta_headers.append(line.strip().split()[0][1:])
fasta_lookup = {normalize_id(h): h for h in fasta_headers}

exact_headers = []
mapping_rows = []
for row in selected_rows:
    meta_id = row["rep_genome"]
    exact = fasta_lookup.get(normalize_id(meta_id))
    if exact is None:
        hits = [h for h in fasta_headers if normalize_id(meta_id) in normalize_id(h)]
        exact = hits[0] if hits else None
    if exact is None:
        print(f"Warning: no FASTA hit for {meta_id}")
        continue
    exact_headers.append(exact)
    mapping_rows.append(
        {
            "vFAM": row["vFAM"],
            "vOTU": row["vOTU"],
            "n_in_vfam_hq": row["n_in_vfam_hq"],
            "votu_global_size": row["votu_global_size"],
            "Rep_Genome_Metadata": meta_id,
            "Exact_FASTA_Header": exact,
        }
    )

if not exact_headers:
    sys.exit("Error: no FASTA headers matched.")

pd.DataFrame(mapping_rows).to_csv(
    os.path.join(COMPARE_DIR, "vFAM_reps_mapping.tsv"),
    sep="\t",
    index=False,
)

id_list_file = os.path.join(COMPARE_DIR, "headers_to_extract.txt")
with open(id_list_file, "w") as f:
    f.write("\n".join(exact_headers) + "\n")

output_fasta = os.path.join(COMPARE_DIR, "Mu_like_vFAM_reps.fasta")
print(f"Extracting {len(exact_headers)} sequences with seqkit...")
try:
    subprocess.run(
        ["seqkit", "grep", "-f", id_list_file, FASTA_FILE, "-o", output_fasta],
        check=True,
    )
except subprocess.CalledProcessError as e:
    sys.exit(f"Error executing seqkit: {e}")
print(f"FASTA written: {output_fasta}")

# ==============================================================================
# 5. Pharokka
# ==============================================================================
print("\n=====[ Phase 4: Pharokka ]=====")
pharokka_cmd = [
    "pharokka.py",
    "-i", output_fasta,
    "-o", ANNOT_DIR,
    "-t", "26",
    "-f", "-m", "-s",
    "--meta_hmm",
    "--skip_mash",
    "-g", "prodigal-gv",
    "-d", PHAROKKA_DB,
]
print("Executing:", " ".join(pharokka_cmd))
try:
    subprocess.run(pharokka_cmd, check=True)
except subprocess.CalledProcessError as e:
    sys.exit(f"Error executing Pharokka: {e}")

print("\n=======================================================")
print("Done.")
print(f"Mapping: {os.path.join(COMPARE_DIR, 'vFAM_reps_mapping.tsv')}")
print(f"FASTA:   {output_fasta}")
print(f"Annot:   {ANNOT_DIR}")
print("=======================================================")
