import os
import csv
from Bio import SeqIO
from concurrent.futures import ProcessPoolExecutor
import time

input_tsv = "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allphage_activity.tsv"
genome_dir = "/home/huangyan/experiment/SPA/3/gut_isolate/allgenome"
output_file = "phage_terminal_status_output.tsv"
min_length = 100
num_workers = 20
def parse_phage_filename(filename):
    """
    解析文件名以获取 Contig ID, Start, Stop
    格式示例: phage_depth_SRR28697128_1_746574_784991.txt
    """
    base = filename.strip()
    if base.endswith('.txt'):
        base = base[:-4]

    parts = base.split('_')

    if len(parts) < 5:
        return None, None, None

    try:
        stop = int(parts[-1])
        start = int(parts[-2])
    except ValueError:
        return None, None, None

      contig_id = "_".join(parts[2:-2])

    return contig_id, start, stop


def process_single_genome(args):

    genome_name, phages, genome_dir_path, min_len = args
    
    fasta_path = os.path.join(genome_dir_path, f"{genome_name}.fasta")
    results = []
    if not os.path.exists(fasta_path):
        for p in phages:
            results.append(f"{p['phage_name']}\tError_GenomeNotFound\t{p['contig']}\tNA\t{p['start']}\t{p['stop']}\tNA\n")
        return results
    contig_lengths = {}
    try:
        for record in SeqIO.parse(fasta_path, "fasta"):
            contig_lengths[record.id] = len(record.seq)
    except Exception as e:
           for p in phages:
            results.append(f"{p['phage_name']}\tError_FastaRead\t{p['contig']}\tNA\t{p['start']}\t{p['stop']}\tNA\n")
        return results

    for p in phages:
        c_id = p['contig']
        start = p['start']
        stop = p['stop']

        if c_id in contig_lengths:
            c_len = contig_lengths[c_id]
            is_terminal = False
            dist_info = []

            if start < min_len:
                is_terminal = True
                dist_info.append(f"Left:{start}")

            dist_to_right = c_len - stop
            if dist_to_right < min_len:
                is_terminal = True
                dist_info.append(f"Right:{dist_to_right}")

            status = "Yes" if is_terminal else "No"
            dist_str = ";".join(dist_info) if dist_info else "Internal"

            results.append(f"{p['phage_name']}\t{status}\t{c_id}\t{c_len}\t{start}\t{stop}\t{dist_str}\n")
        else:
            results.append(f"{p['phage_name']}\tError_ContigNotFound\t{c_id}\tNA\t{p['start']}\t{p['stop']}\tNA\n")

    return results


def main():
    start_time = time.time()
    print("Step 1: Reading TSV and grouping phages by Genome...")

    genome_tasks = {}

    with open(input_tsv, 'r') as f:
        reader = csv.DictReader(f, delimiter='\t')
        
        for row in reader:
 
            genome_name = row['Genome']
            phage_file = row['File']

            contig_id, start, stop = parse_phage_filename(phage_file)

            if contig_id is None:

                continue

            if genome_name not in genome_tasks:
                genome_tasks[genome_name] = []

            genome_tasks[genome_name].append({
                'phage_name': phage_file,
                'contig': contig_id,
                'start': start,
                'stop': stop
            })

    total_genomes = len(genome_tasks)
    print(f"Found {total_genomes} unique genomes to process.")

    print(f"Step 2: Processing genomes using {num_workers} parallel workers...")
    
    tasks_args = [(g_name, phages, genome_dir, min_length) for g_name, phages in genome_tasks.items()]

    all_results = []
    
    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        for idx, result_list in enumerate(executor.map(process_single_genome, tasks_args)):
            if (idx + 1) % 100 == 0 or (idx + 1) == total_genomes:
                print(f"  -> Processed {idx + 1}/{total_genomes} genomes...")

            all_results.extend(result_list)

    print("Step 3: Writing results to output file...")
    with open(output_file, 'w') as out_f:
        header = ["Phage_Name", "Is_Terminal", "Contig_ID", "Contig_Length", "Start", "Stop", "Distance_to_End"]
        out_f.write("\t".join(header) + "\n")
        
        out_f.writelines(all_results)

    end_time = time.time()
    print(f"Done! Results saved to {output_file}")
    print(f"Total time elapsed: {end_time - start_time:.2f} seconds.")

if __name__ == "__main__":
    main()
