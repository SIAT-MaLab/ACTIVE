#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(ggdist)
  library(ggpubr)
  library(patchwork)
  library(scales)
  library(ggExtra)
})

input_file <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
base_out_dir <- "."
dir_active   <- file.path(base_out_dir, "activepp")
dir_all      <- file.path(base_out_dir, "allpp")

for (d in c(base_out_dir, dir_active, dir_all)) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE)
}

threshold_activity <- 0.8


raw_df <- read_tsv(input_file, show_col_types = FALSE)

df <- raw_df %>%
  mutate(across(where(is.character), ~ str_remove_all(., "\r"))) %>%
  mutate(
    Activity_Score = as.numeric(Activity_Score),
    Log2_Ratio = as.numeric(Log2_Ratio),
    completeness = as.numeric(completeness),
    Activity_Score = ifelse(is.na(Activity_Score), 0, Activity_Score),
    is_active = ifelse(Activity_Score >= threshold_activity, 1, 0),
    is_active_char = ifelse(Activity_Score >= threshold_activity, "Active", "Inactive")
  )
if (!"contig_length" %in% colnames(df)) {
  message("[WARN] no contig_length in metadata。")
  df <- df %>%
    mutate(
      coords = str_match(File, "_([0-9]+)_([0-9]+)\\.[a-zA-Z0-9]+$"),
      start_coord = as.numeric(coords[, 2]),
      stop_coord = as.numeric(coords[, 3]),
      contig_length = abs(stop_coord - start_coord) 
    ) %>%
    select(-coords, -start_coord, -stop_coord)
} else {
  df$contig_length <- as.numeric(df$contig_length)
}

clean_df <- df %>% filter(!is.na(Log2_Ratio) & is.finite(Log2_Ratio))


draw_raincloud_horizontal <- function(df_plot, title_text) {
  stats <- quantile(df_plot$Log2_Ratio, probs = c(0.25, 0.5, 0.75), na.rm = TRUE)
  q1 <- stats[1]; median_val <- stats[2]; q3 <- stats[3]

  cat(sprintf("   - 子集 [%s]: 数量=%d, Median=%.4f, Q1=%.4f, Q3=%.4f\n",
              title_text, nrow(df_plot), median_val, q1, q3))

  df_plot <- df_plot %>% arrange(factor(is_active_char, levels = c("Inactive", "Active")))

  p <- ggplot(df_plot, aes(x = Log2_Ratio, y = 1)) +
    stat_halfeye(
      adjust = 0.6, justification = -0.2, .width = 0, point_colour = NA,
      fill = "#E0E0E0", slab_color = "black", slab_linewidth = 0.5, alpha = 1.0
    ) +
    geom_jitter(
      aes(y = 1, color = is_active_char),
      height = 0.08, size = 1.2, alpha = 0.6, show.legend = FALSE
    ) +
    scale_color_manual(values = c("Active" = "#6790B7", "Inactive" = "#4D4D4D")) +
    geom_vline(xintercept = median_val, color = "#d95f02", linewidth = 1, linetype = "solid") +
    geom_vline(xintercept = c(q1, q3), color = "#333333", linewidth = 0.6, linetype = "dashed") +
    labs(x = "Log2 Ratio (Phage/Host)", y = "", title = title_text) +
    theme_classic() +
    theme(
      panel.grid = element_blank(),
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 1),
      axis.text.y = element_blank(),
      axis.ticks.y = element_blank(),
      axis.line.y = element_blank(),
      plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
      axis.title.x = element_text(size = 12),
      axis.text.x  = element_text(size = 11)
    ) +
    scale_x_continuous(n.breaks = 8)

  return(p)
}

df_high <- clean_df %>% filter(Activity_Score >= threshold_activity)
p_high  <- draw_raincloud_horizontal(df_high, "Active Prophage")
p_all   <- draw_raincloud_horizontal(clean_df, "All Data (Full Set)")

final_raincloud <- ggarrange(p_high, p_all, ncol = 1, nrow = 2, heights = c(1, 1))
raincloud_out <- file.path(base_out_dir, "01_raincloud_horizontal_comparison.pdf")
ggsave(raincloud_out, final_raincloud, width = 8, height = 5.5, device = "pdf")


df_class <- df %>%
  mutate(
    ictv_Class = str_remove(ictv_Class, " \\(.*\\)$"),
    ictv_Class = str_remove(ictv_Class, "^[a-z]__"),
    ictv_Class = ifelse(is.na(ictv_Class) | ictv_Class == "" | ictv_Class == "None", "Other", ictv_Class)
  )

summary_grouped <- df_class %>%
  group_by(ictv_Class) %>%
  summarise(
    Counts = n(),
    Active_Count = sum(is_active, na.rm = TRUE),
    Active_Rate = Active_Count / Counts,
    .groups = "drop"
  )

summary_total <- df_class %>%
  summarise(
    ictv_Class = "Total",
    Counts = n(),
    Active_Count = sum(is_active, na.rm = TRUE),
    Active_Rate = Active_Count / Counts
  )

summary_df <- bind_rows(summary_grouped, summary_total) %>%
  mutate(
    Type = case_when(
      ictv_Class == "Total" ~ "Total",
      ictv_Class == "Caudoviricetes" ~ "Target",
      ictv_Class == "Other" ~ "Other",
      TRUE ~ "Normal"
    )
  ) %>%
  arrange(Active_Rate) %>%
  mutate(ictv_Class = factor(ictv_Class, levels = c(setdiff(ictv_Class, "Total"), "Total")))

write_tsv(summary_df, file.path(base_out_dir, "02_class_activity_stats.tsv"))

y_axis_levels <- levels(summary_df$ictv_Class)
color_mapping <- c("Target" = "#A41A00", "Normal" = "#AEAFB0", "Other" = "#F2F3F4", "Total" = "#3b262b")

pA <- ggplot(summary_df, aes(x = Active_Rate, y = ictv_Class, fill = Type)) +
  geom_col(width = 0.7, show.legend = FALSE, color = "black", linewidth = 0.3) +
  geom_text(aes(label = percent(Active_Rate, accuracy = 0.1)), hjust = -0.1, size = 3.5, color = "black") +
  scale_fill_manual(values = color_mapping) +
  scale_x_continuous(labels = percent, expand = expansion(mult = c(0, 0.2))) +
  labs(title = "A. Class Active Rate", x = "Active Rate", y = NULL) +
  theme_minimal() +
  theme(
    panel.grid = element_blank(),
    plot.title   = element_text(hjust = 0, size = 12, face = "bold"),
    axis.title.x = element_text(size = 12, color = "black"),
    axis.text.x  = element_text(size = 10, color = "grey40"),
    axis.text.y  = element_text(
      size = 11,
      face = ifelse(y_axis_levels %in% c("Total", "Caudoviricetes"), "bold", "plain"),
      color = ifelse(y_axis_levels %in% c("Total", "Caudoviricetes"), "black", "grey40")
    ),
    axis.ticks   = element_blank()
  )

pB <- ggplot(summary_df, aes(x = Counts, y = ictv_Class, fill = Type)) +
  geom_col(width = 0.7, show.legend = FALSE, color = "black", linewidth = 0.3) +
  geom_text(aes(label = comma(Counts)), hjust = -0.1, size = 3.5, color = "black") +
  scale_fill_manual(values = color_mapping) +
  scale_x_log10(labels = comma, expand = expansion(mult = c(0, 0.2))) +
  labs(title = "B. Genome Counts (Log Scale)", x = "Counts (Log10)", y = NULL) +
  theme_minimal() +
  theme(
    panel.grid = element_blank(),
    plot.title   = element_text(hjust = 0, size = 12, face = "bold"),
    axis.title.x = element_text(size = 12, color = "black"),
    axis.text.x  = element_text(size = 10, color = "grey40"),
    axis.text.y  = element_blank(),
    axis.ticks   = element_blank()
  )

class_plot <- pA + pB + plot_layout(widths = c(1, 1))
class_plot_out <- file.path(base_out_dir, "02_class_activity.pdf")
ggsave(class_plot_out, plot = class_plot, width = 11, height = 5.5, device = "pdf")
message(sprintf("[SUCCESS] ICTV 纲活性图已保存至: %s", class_plot_out))

uhgv_cols_low_to_high <- c("v_MemberID", "v_SubGenus", "v_Genus", "v_Subfamily", "v_Family")
ictv_cols_low_to_high <- c("ictv_Genus", "ictv_Subfamily", "ictv_Family", "ictv_Order", "ictv_Class", "ictv_Phylum", "ictv_Kingdom", "ictv_Realm")
get_lowest_rank_low_to_high <- function(data, cols, prefix_to_remove) {
  res <- rep("Unclassified", nrow(data))
  
  for (i in 1:nrow(data)) {
    for (col in cols) {
      if (col %in% names(data)) {
        val <- data[[col]][i]
        if (!is.na(val) && trimws(val) != "") {
          val_clean <- gsub("^[a-zA-Z0-9_]+__", "", val)
          val_clean <- gsub("^[a-zA-Z0-9_]+-", "", val_clean)
          val_clean <- trimws(val_clean)
          if (!tolower(val_clean) %in% c("unclassified", "none", "na", "")) {
            clean_rank_name <- gsub(prefix_to_remove, "", col)
            if (tolower(clean_rank_name) == "subfamily") {
              clean_rank_name <- "Subfamily"
            }
            res[i] <- clean_rank_name
            break 
          }
        }
      }
    }
  }
  return(res)
}

plot_single_database_depth <- function(data, col_name, output_path, title_text, rank_levels) {
  
  summary_df <- data %>%
    count(!!sym(col_name)) %>%
    mutate(prop = n / sum(n)) %>%
    rename(Rank = !!sym(col_name))

  summary_df$Rank <- factor(summary_df$Rank, levels = intersect(rank_levels, unique(summary_df$Rank)))
  unique_ranks <- levels(summary_df$Rank)
  my_colors <- scales::hue_pal()(length(unique_ranks))
  names(my_colors) <- unique_ranks
  if ("Unclassified" %in% names(my_colors)) {
    my_colors["Unclassified"] <- "#E0E0E0"
  }
  
  p <- ggplot(summary_df, aes(x = "", y = prop, fill = Rank)) +
    geom_bar(stat = "identity", width = 1, color = "white", linewidth = 0.5) +
    coord_polar("y", start = 0) +
    geom_text(aes(label = ifelse(prop > 0.02, scales::percent(prop, accuracy = 0.1), "")),
              position = position_stack(vjust = 0.5), size = 3.5) +
    scale_fill_manual(values = my_colors) +
    labs(title = title_text) +
    theme_void() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 12, face = "bold", margin = margin(b = 10)),
      legend.title = element_text(size = 11, face = "bold"),
      legend.text = element_text(size = 10),
      legend.position = "right"
    )
  
  ggsave(output_path, p, width = 6, height = 4.5, device = "pdf")
}

uhgv_levels <- c("Family", "SubFamily", "Genus", "SubGenus", "MemberID", "Unclassified")
ictv_levels <- c("Realm", "Kingdom", "Phylum", "Class", "Order", "Family", "Subfamily", "Genus", "Unclassified")

df$UHGV_Depth <- get_lowest_rank_low_to_high(df, uhgv_cols_low_to_high, "v_")
df$ICTV_Depth <- get_lowest_rank_low_to_high(df, ictv_cols_low_to_high, "ictv_")

plot_single_database_depth(
  df, "UHGV_Depth", 
  file.path(dir_all, "03_all_UHGV_taxonomy_annotation_depth.pdf"), 
  "UHGV Taxonomic Resolution Depth (All Prophages)", 
  uhgv_levels
)

plot_single_database_depth(
  df, "ICTV_Depth", 
  file.path(dir_all, "03_all_ICTV_taxonomy_annotation_depth.pdf"), 
  "ICTV Taxonomic Resolution Depth (All Prophages)", 
  ictv_levels
)

df_active_only <- df %>% filter(is_active == 1)

plot_single_database_depth(
  df_active_only, "UHGV_Depth", 
  file.path(dir_active, "03_active_UHGV_taxonomy_annotation_depth.pdf"), 
  "UHGV Taxonomic Resolution Depth (Active Prophages)", 
  uhgv_levels
)

plot_single_database_depth(
  df_active_only, "ICTV_Depth", 
  file.path(dir_active, "03_active_ICTV_taxonomy_annotation_depth.pdf"), 
  "ICTV Taxonomic Resolution Depth (Active Prophages)", 
  ictv_levels
)

df_checkv_plot <- df %>%
  filter(!is.na(completeness) & !is.na(contig_length)) %>%
  mutate(
    Length_Kb = contig_length / 1000,
    Status = ifelse(is_active == 1, "Active", "Inactive")
  ) %>%
  arrange(factor(Status, levels = c("Inactive", "Active")))

if (nrow(df_checkv_plot) == 0) {
  message("[WARN] in completeness and contig_length")
} else {
  p_main <- ggplot(df_checkv_plot, aes(x = completeness, y = Length_Kb, color = Status)) +
    geom_point(alpha = 0.6, size = 1.5) +
    scale_color_manual(values = c("Active" = "#4A728C", "Inactive" = "#4D4D4D")) +
    scale_y_log10(
      breaks = c(1, 2, 5, 10, 20, 50, 100, 200, 500, 1000),
      labels = scales::comma
    ) +
    labs(
      x = "CheckV Completeness (%)",
      y = "Length (Kb, Log10 Scale)",
      color = "Prophage Status"
    ) +
    theme_classic() +
    theme(
      axis.title = element_text(size = 12, face = "bold"),
      axis.text = element_text(size = 10),
      legend.title = element_text(size = 11, face = "bold"),
      legend.text = element_text(size = 10),
      legend.position = "right",
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 1)
    )

  p_final <- ggMarginal(
    p_main, type = "histogram", margins = "both", size = 5,
    fill = "#B0B0B0", color = "black", bins = 40
  )

  checkv_out_file <- file.path(dir_all, "04_allpp_completeness_vs_length.pdf")
  ggsave(checkv_out_file, p_final, width = 8, height = 7, device = "pdf")
  }
