
library(tidyverse)

file_path <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/terminal_pp/phage_terminal_status_output.tsv"
df <- read_tsv(file_path, show_col_types = FALSE)

df <- df %>%
  mutate(
    Contig_Length = as.numeric(Contig_Length),
    Start = as.numeric(Start),
    Stop = as.numeric(Stop)
  )

df <- df %>%
  mutate(
    Category = if_else(
      Start == 1 & Stop == Contig_Length,
      "Inaccessible terminal prophage",
      "Other prophage"
    )
  )

total_count <- nrow(df)

pie_data <- df %>%
  count(Category) %>%
  mutate(
    Percentage = n / total_count * 100,
    Label = sprintf("%.1f%%\n(n=%d)", Percentage, n)
  )


print(pie_data)
cat("Total count:", total_count, "\n\n")

custom_colors <- c(
  "Inaccessible terminal prophage" = "#E64B35",
  "Other prophage"                = "#4DBBD5"
)

p <- ggplot(pie_data, aes(x = 2, y = n, fill = Category)) +
  geom_col(color = "white", linewidth = 1.2, width = 1) +
  coord_polar(theta = "y", start = 0) +
  xlim(0.5, 2.5) +  
  geom_text(
    aes(label = Label),
    position = position_stack(vjust = 0.5),
    size = 4.2, 
    fontface = "bold", 
    color = "black"
  ) +

  annotate(
    "text", x = 0.5, y = 0, 
    label = paste0("Total\n", total_count),
    size = 4.8, 
    fontface = "bold", 
    color = "#2B2B2B"
  ) +
  scale_fill_manual(values = custom_colors) +
  theme_void() +
  theme(
    legend.position = "right",
    legend.title = element_blank(),
    legend.text = element_text(size = 11),
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14, margin = margin(b = 15))
  ) +
  labs(title = "Proportion of Inaccessible Terminal Prophages")

output_dir <- dirname(file_path)

ggsave(file.path(output_dir, "prophage_accessibility_pie.pdf"), plot = p, width = 6.5, height = 5)
ggsave(file.path(output_dir, "prophage_accessibility_pie.png"), plot = p, width = 6.5, height = 5, dpi = 300)

