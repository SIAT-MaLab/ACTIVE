#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(stringr)
  library(scales)
})


options(stringsAsFactors = FALSE)
options(scipen = 999)

input_dir <- "/home/huangyan/experiment/SPA/2-2/used_results"

propagate_file <- file.path(
  input_dir,
  "M_AB_propagate.tsv"
)

spa_file <- file.path(
  input_dir,
  "M_AB_spa_precise.csv"
)

output_dir <- file.path(
  input_dir,
  "M_AB_statistics_plots"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

if (!file.exists(propagate_file)) {
  stop(
    "Propagate file not found:\n",
    propagate_file
  )
}

if (!file.exists(spa_file)) {
  stop(
    "SPA precise file not found:\n",
    spa_file
  )
}

propagate_dt <- fread(
  file = propagate_file,
  sep = "\t",
  header = TRUE,
  fill = TRUE,
  check.names = FALSE,
  data.table = TRUE
)

if ("prophage-host_ratio" %in% names(propagate_dt)) {

  setnames(
    propagate_dt,
    old = "prophage-host_ratio",
    new = "PtoH_Ratio"
  )

} else if ("prophage.host_ratio" %in% names(propagate_dt)) {

  setnames(
    propagate_dt,
    old = "prophage.host_ratio",
    new = "PtoH_Ratio"
  )
}


required_propagate_cols <- c(
  "prophage",
  "host",
  "active",
  "CohenD",
  "PtoH_Ratio",
  "prophage_len"
)

missing_propagate_cols <- setdiff(
  required_propagate_cols,
  names(propagate_dt)
)

if (length(missing_propagate_cols) > 0) {
  stop(
    "M_AB_propagate.tsv is missing the following columns:\n",
    paste(missing_propagate_cols, collapse = ", ")
  )
}

propagate_dt[, prophage := as.character(prophage)]
propagate_dt[, host := as.character(host)]
propagate_dt[, active := as.character(active)]

propagate_dt[, CohenD := suppressWarnings(
  as.numeric(CohenD)
)]

propagate_dt[, PtoH_Ratio := suppressWarnings(
  as.numeric(PtoH_Ratio)
)]

propagate_dt[, prophage_len := suppressWarnings(
  as.numeric(prophage_len)
)]

propagate_dt <- propagate_dt[
  !is.na(prophage) &
    prophage != ""
]

duplicate_prophage <- propagate_dt[
  duplicated(prophage) |
    duplicated(prophage, fromLast = TRUE)
]

if (nrow(duplicate_prophage) > 0) {
  warning(
    "Duplicate prophage entries in propagate file:\n",
    paste(unique(duplicate_prophage$prophage), collapse = "\n")
  )
}

propagate_dt <- propagate_dt[, .(
  prophage,
  host,
  active,
  CohenD,
  PtoH_Ratio,
  prophage_len
)]

spa_dt <- fread(
  file = spa_file,
  header = TRUE,
  fill = TRUE,
  check.names = FALSE,
  data.table = TRUE
)

required_spa_cols <- c(
  "Folder",
  "Genome",
  "Phage_File",
  "Phage_Sites",
  "Delta_Mean"
)

missing_spa_cols <- setdiff(
  required_spa_cols,
  names(spa_dt)
)

if (length(missing_spa_cols) > 0) {
  stop(
    "M_AB_spa_precise.csv is missing the following columns:\n",
    paste(missing_spa_cols, collapse = ", ")
  )
}

if (!"Significant" %in% names(spa_dt)) {
  spa_dt[, Significant := NA_character_]
}

if (!"p_value" %in% names(spa_dt)) {
  spa_dt[, p_value := NA_real_]
}

spa_dt[, Folder := as.character(Folder)]
spa_dt[, Genome := as.character(Genome)]
spa_dt[, Phage_File := as.character(Phage_File)]
spa_dt[, Significant := as.character(Significant)]

spa_dt[, Phage_Sites := suppressWarnings(
  as.numeric(Phage_Sites)
)]

spa_dt[, Delta_Mean := suppressWarnings(
  as.numeric(Delta_Mean)
)]

spa_dt[, p_value := suppressWarnings(
  as.numeric(p_value)
)]

spa_dt[, prophage := Phage_File]

spa_dt[, prophage := sub(
  "^phage_depth_",
  "",
  prophage
)]

spa_dt[, prophage := sub(
  "\\.txt$",
  "",
  prophage
)]

spa_dt[, prophage := trimws(prophage)]

print(
  spa_dt[
    grepl("SAB43B_9_34982_70852", prophage),
    .(
      Folder,
      Genome,
      Phage_File,
      prophage,
      Phage_Sites,
      Delta_Mean,
      Significant
    )
  ]
)

stats_dt <- merge(
  spa_dt,
  propagate_dt,
  by = "prophage",
  all = FALSE,
  allow.cartesian = FALSE
)

stats_dt <- unique(
  stats_dt,
  by = "prophage"
)

if (nrow(stats_dt) == 0) {
  stop(
    "M_AB_spa_precise.csv and M_AB_propagate.tsv did not match any prophage.\n",
    "Please check that Phage_File and prophage are named consistently."
  )
}

print(
  stats_dt[
    grepl("SAB43B_9_34982_70852", prophage),
    .(
      prophage,
      Folder,
      Genome,
      Phage_File,
      Delta_Mean,
      PtoH_Ratio,
      CohenD,
      active,
      Phage_Sites,
      prophage_len
    )
  ]
)

sab43b_check <- stats_dt[
  prophage == "SAB43B_9_34982_70852"
]

if (nrow(sab43b_check) > 0) {

  message(
    "SAB43B_9_34982_70852: CohenD = ",
    sprintf("%.15f", sab43b_check$CohenD[1]),
    ", PtoH_Ratio = ",
    sprintf("%.15f", sab43b_check$PtoH_Ratio[1]),
    ", Delta_Mean = ",
    sprintf("%.15f", sab43b_check$Delta_Mean[1])
  )
}

merged_file <- file.path(
  output_dir,
  "M_AB_statistics_merged.csv"
)

fwrite(
  stats_dt,
  file = merged_file
)

stat_colors <- c(
  "Cliff's delta" = "#9E9E9E",
  "PtoH Ratio"    = "#80B1D3",
  "Cohen's D"     = "#984EA3"
)

base_theme <- theme_classic(
  base_family = "Arial"
) +
  theme(
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      size = 15
    ),

    plot.subtitle = element_text(
      hjust = 0.5,
      size = 10
    ),

    axis.title.x = element_text(
      size = 14,
      face = "bold"
    ),

    axis.title.y = element_text(
      size = 14,
      face = "bold"
    ),

    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 12
    ),

    axis.text.y = element_text(
      size = 12
    ),

    axis.line = element_line(
      color = "black",
      linewidth = 0.8
    ),

    axis.ticks = element_line(
      color = "black",
      linewidth = 0.8
    ),

    legend.position = "none"
  )

plot_one_phage <- function(i) {

  row <- stats_dt[i]

  phage_id <- row$prophage[1]
  folder <- row$Folder[1]
  genome <- row$Genome[1]
  active <- row$active[1]
  significant <- row$Significant[1]

  plot_dt <- data.frame(
    Statistic = c(
      "Cliff's delta",
      "PtoH Ratio",
      "Cohen's D"
    ),

    Value = c(
      row$Delta_Mean[1],
      row$PtoH_Ratio[1],
      row$CohenD[1]
    )
  )

  plot_dt$Statistic <- factor(
    plot_dt$Statistic,
    levels = c(
      "Cliff's delta",
      "PtoH Ratio",
      "Cohen's D"
    )
  )

  plot_dt <- plot_dt[
    !is.na(plot_dt$Value),
    ,
    drop = FALSE
  ]

  if (nrow(plot_dt) == 0) {
    warning(
      "No available statistics for phage: ",
      phage_id
    )
    return(NA_character_)
  }

  safe_folder <- gsub(
    "[^A-Za-z0-9_.-]",
    "_",
    folder
  )

  safe_phage_id <- gsub(
    "[^A-Za-z0-9_.-]",
    "_",
    phage_id
  )

  output_file <- file.path(
    output_dir,
    paste0(
      safe_folder,
      "_",
      safe_phage_id,
      "_statistics.pdf"
    )
  )

  plot_dt$label_vjust <- ifelse(
    plot_dt$Value >= 0,
    -0.35,
    1.2
  )

  p <- ggplot(
    plot_dt,
    aes(
      x = Statistic,
      y = Value,
      fill = Statistic
    )
  ) +

    geom_hline(
      yintercept = 0,
      color = "black",
      linewidth = 0.5
    ) +

    geom_hline(
      yintercept = c(
        0.8,
        1,
        2
      ),
      linetype = "dashed",
      color = "black",
      linewidth = 0.45
    ) +

    geom_col(
      width = 0.62,
      color = "black",
      linewidth = 0.35
    ) +

    geom_text(
      aes(
        label = sprintf(
          "%.3f",
          Value
        ),
        vjust = label_vjust
      ),
      size = 4.0,
      family = "Arial"
    ) +

    scale_fill_manual(
      values = stat_colors
    ) +

    scale_y_continuous(
      labels = scales::label_number(
        accuracy = 0.01,
        notation = "plain"
      ),
      expand = expansion(
        mult = c(
          0.05,
          0.18
        )
      )
    ) +

    labs(
      title = paste0(
        "Statistical Parameters\n",
        folder,
        " | ",
        phage_id
      ),

      subtitle = paste0(
        "Genome: ",
        genome,
        " | active: ",
        active,
        " | Significant: ",
        significant
      ),

      x = NULL,
      y = "Value"
    ) +

    base_theme

  ggsave(
    filename = output_file,
    plot = p,
    width = 5.5,
    height = 5.5,
    units = "in",
    dpi = 300,
    device = cairo_pdf
  )

  return(output_file)
}

plot_files <- vapply(
  seq_len(nrow(stats_dt)),
  plot_one_phage,
  FUN.VALUE = character(1)
)

plot_files <- plot_files[
  !is.na(plot_files)
]

summary_dt <- stats_dt[
  ,
  .(
    Folder,
    Genome,
    prophage,
    Delta_Mean,
    PtoH_Ratio,
    CohenD
  )
]

summary_long <- melt(
  summary_dt,
  id.vars = c(
    "Folder",
    "Genome",
    "prophage"
  ),
  measure.vars = c(
    "Delta_Mean",
    "PtoH_Ratio",
    "CohenD"
  ),
  variable.name = "Statistic",
  value.name = "Value"
)

summary_long[, Statistic := fcase(
  Statistic == "Delta_Mean",
  "Cliff's delta",

  Statistic == "PtoH_Ratio",
  "PtoH Ratio",

  Statistic == "CohenD",
  "Cohen's D",

  default = Statistic
)]

summary_long[, Statistic := factor(
  Statistic,
  levels = c(
    "Cliff's delta",
    "PtoH Ratio",
    "Cohen's D"
  )
)]

summary_long <- summary_long[
  !is.na(Value)
]

p_summary <- ggplot(
  summary_long,
  aes(
    x = Statistic,
    y = Value,
    fill = Statistic
  )
) +

  geom_hline(
    yintercept = 0,
    color = "black",
    linewidth = 0.4
  ) +

  geom_hline(
    yintercept = c(
      0.8,
      1,
      2
    ),
    linetype = "dashed",
    color = "black",
    linewidth = 0.35
  ) +

  geom_col(
    width = 0.62,
    color = "black",
    linewidth = 0.25
  ) +

  facet_wrap(
    ~ prophage,
    scales = "free_y",
    ncol = 3
  ) +

  scale_fill_manual(
    values = stat_colors
  ) +

  scale_y_continuous(
    labels = scales::label_number(
      accuracy = 0.01,
      notation = "plain"
    ),
    expand = expansion(
      mult = c(
        0.05,
        0.15
      )
    )
  ) +

  labs(
    title = "M_AB Statistical Parameters",
    x = NULL,
    y = "Value"
  ) +

  base_theme +

  theme(
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 9
    ),

    strip.text = element_text(
      size = 9,
      face = "bold"
    )
  )

summary_file <- file.path(
  output_dir,
  "M_AB_all_phages_statistics.pdf"
)

ggsave(
  filename = summary_file,
  plot = p_summary,
  width = 14,
  height = 10,
  units = "in",
  dpi = 300,
  device = cairo_pdf
)