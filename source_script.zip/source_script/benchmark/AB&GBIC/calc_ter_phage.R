suppressPackageStartupMessages({
  library(tidyverse)
  library(data.table)
  library(patchwork)
})

# ==============================================================================
#                         Global Configuration
# ==============================================================================

# ------------------------------------------------------------------------------
# 1. Input files
# ------------------------------------------------------------------------------
gbic_fasta <- "/home/huangyan/experiment/SPA/2-2/GBIC/ref/gbic.fasta"
gbic_coord <- "/home/huangyan/experiment/SPA/2-2/GBIC/gbic_coordinate.tsv"

ab_fasta <- "/home/huangyan/experiment/SPA/2-2/AB/CM_results/genome/CM_AB.fasta"
ab_coord <- "/home/huangyan/experiment/SPA/2-2/AB/CM_results/CM_coordinate.tsv"

assembly_fasta <- "/home/huangyan/experiment/SPA/2-1_benchmark/benchmark/assembly_benchmark/assembly_ref/renamed_by_host/all_assembly_genome.fna"
assembly_coord <- "/home/huangyan/experiment/SPA/2-1_benchmark/benchmark/assembly_benchmark/phage_coordinate/coordinate_active.tsv"

# Output files
out_plot        <- "./plot_output/Terminal_Phage_PieChart.pdf"
out_source_long <- "./plot_output/Terminal_Phage_PieChart_SourceData_long.tsv"
out_source_wide <- "./plot_output/Terminal_Phage_PieChart_SourceData_wide.tsv"

# ------------------------------------------------------------------------------
# 2. Thresholds
# ------------------------------------------------------------------------------
min_length <- 100

# ------------------------------------------------------------------------------
# 3. Counting unit
# ------------------------------------------------------------------------------
count_unit <- "coordinate"

# ------------------------------------------------------------------------------
# 4. Pie chart colors and labels
# ------------------------------------------------------------------------------
label_internal    <- "Internal Phage"
label_term_comp   <- "Computable Terminal Phage"
label_term_incomp <- "Incomputable Terminal Phage"

type_levels <- c(label_internal, label_term_comp, label_term_incomp)

color_internal    <- "grey60"
color_term_comp   <- "#BF352A"
color_term_incomp <- "#F6A834"

pie_border_color <- "black"
pie_border_size  <- 0.7

# ------------------------------------------------------------------------------
# 5. Plot layout
# ------------------------------------------------------------------------------
plot_width  <- 14
plot_height <- 7

legend_position  <- "bottom"
legend_text_size <- 12
title_size <- 16
title_face <- "bold"


# ==============================================================================
#                         File check
# ==============================================================================
check_file <- function(file_path) {
  if (!file.exists(file_path)) stop("File not found: ", file_path)
}


# ==============================================================================
#                        FASTA length parser
# ==============================================================================
get_fasta_lengths <- function(fasta_file) {

  check_file(fasta_file)
  message("  -> Parsing FASTA: ", basename(fasta_file))

  awk_program <- paste0(
    "/^>/{",
    "if (id != \"\") print id \"\\t\" L; ",
    "id=substr($1,2); ",
    "L=0; ",
    "next",
    "} ",
    "{",
    "gsub(/[[:space:]]/, \"\", $0); ",
    "L += length($0)",
    "} ",
    "END{",
    "if (id != \"\") print id \"\\t\" L",
    "}"
  )

  awk_cmd <- paste("awk", shQuote(awk_program), shQuote(fasta_file))

  dt_lengths <- fread(
    cmd = awk_cmd, header = FALSE,
    col.names = c("contig", "contig_length")
  )

  if (nrow(dt_lengths) == 0) stop("No sequences parsed from FASTA: ", fasta_file)

  dt_lengths[, contig := as.character(contig)]
  dt_lengths[, contig_length := as.numeric(contig_length)]

  if (anyNA(dt_lengths$contig_length)) stop("FASTA length parsing failed: ", fasta_file)
  if (anyDuplicated(dt_lengths$contig))  stop("Duplicate contig names in FASTA: ", fasta_file)

  dt_lengths
}


# ==============================================================================
#                         Coordinate file reader
# ==============================================================================
read_coordinate_file <- function(coord_file) {

  check_file(coord_file)
  message("  -> Reading coordinate file: ", basename(coord_file))

  first_line <- readLines(coord_file, n = 1, warn = FALSE)
  if (length(first_line) == 0 || !nzchar(trimws(first_line))) {
    stop("Coordinate file is empty: ", coord_file)
  }

  first_line <- sub("^\ufeff", "", first_line)
  first_tokens <- tolower(trimws(strsplit(trimws(first_line), "\\s+")[[1]]))

  has_header <- (
    "contig" %in% first_tokens &&
      "start" %in% first_tokens &&
      any(c("end", "stop") %in% first_tokens)
  )

  if (has_header) {

    dt <- fread(coord_file, header = TRUE, check.names = FALSE, strip.white = TRUE)

    old_names <- names(dt)
    new_names <- tolower(trimws(old_names))
    new_names <- sub("^\ufeff", "", new_names)
    setnames(dt, old_names, new_names)

    if ("end" %in% names(dt) && "stop" %in% names(dt))
      stop("Coordinate file contains both 'end' and 'stop' columns: ", coord_file)
    if ("end" %in% names(dt)) setnames(dt, "end", "stop")

    if (!all(c("contig", "start", "stop") %in% names(dt)))
      stop("Coordinate file is missing required columns. Need: contig, start, end or stop; file: ", coord_file)

    if (!"phage_id" %in% names(dt))
      dt[, phage_id := paste(contig, start, stop, sep = "_")]

    dt <- dt[, .(
      phage_id = as.character(phage_id),
      contig   = as.character(contig),
      start    = suppressWarnings(as.numeric(start)),
      stop     = suppressWarnings(as.numeric(stop))
    )]

  } else {

    dt <- fread(coord_file, header = FALSE, strip.white = TRUE)
    n_col <- ncol(dt)

    if (n_col == 3) {
      setnames(dt, names(dt), c("contig", "start", "stop"))
      dt[, phage_id := paste(contig, start, stop, sep = "_")]
      dt <- dt[, .(
        phage_id = as.character(phage_id),
        contig   = as.character(contig),
        start    = suppressWarnings(as.numeric(start)),
        stop     = suppressWarnings(as.numeric(stop))
      )]
    } else if (n_col >= 4) {
      setnames(dt, names(dt)[1:4], c("phage_id", "contig", "start", "stop"))
      dt <- dt[, .(
        phage_id = as.character(phage_id),
        contig   = as.character(contig),
        start    = suppressWarnings(as.numeric(start)),
        stop     = suppressWarnings(as.numeric(stop))
      )]
    } else {
      stop("Unrecognized coordinate file format: ", coord_file, "\nNumber of columns: ", n_col)
    }
  }

  dt[is.na(phage_id) | phage_id == "",
     phage_id := paste(contig, start, stop, sep = "_")]

  dt
}


# ==============================================================================
#                         Core computation (compute only, no plotting)
# ==============================================================================
compute_summary <- function(coord_file, fasta_file, source_name,
                            count_unit = "coordinate") {

  message("\n>>> Processing source: ", source_name)

  if (!count_unit %in% c("coordinate", "phage_id"))
    stop("count_unit must be 'coordinate' or 'phage_id'")

  dt_coord <- read_coordinate_file(coord_file)
  if (nrow(dt_coord) == 0) stop("Coordinate file has no valid records: ", coord_file)

  dt_lens <- get_fasta_lengths(fasta_file)

  dt_merged <- merge(dt_coord, dt_lens, by = "contig",
                     all.x = TRUE, sort = FALSE)

  missing_contig <- is.na(dt_merged$contig_length)
  if (any(missing_contig)) {
    warning("Found ", sum(missing_contig),
            " coordinates whose contig is missing from FASTA; will be ignored.")
    dt_merged <- dt_merged[!missing_contig]
  }
  if (nrow(dt_merged) == 0) stop("No valid coordinates left after merging FASTA lengths: ", source_name)

  bad_coord <- (
    is.na(dt_merged$start) | is.na(dt_merged$stop) |
      dt_merged$start < 1 |
      dt_merged$stop < dt_merged$start |
      dt_merged$stop > dt_merged$contig_length
  )
  if (any(bad_coord)) {
    warning("Found ", sum(bad_coord), " invalid coordinates; will be ignored: ", source_name)
    dt_merged <- dt_merged[!bad_coord]
  }
  if (nrow(dt_merged) == 0) stop("No records left after removing invalid coordinates: ", source_name)

  dt_merged[, phage_len   := stop - start + 1]
  dt_merged[, host_len    := contig_length - phage_len]
  dt_merged[, left_flank  := start - 1]
  dt_merged[, right_flank := contig_length - stop]

  if (any(dt_merged$host_len < 0, na.rm = TRUE))
    stop("Phage region length exceeds contig length; check coordinate format: ", source_name)

  dt_merged[, Type := label_internal]
  is_terminal <- (dt_merged$left_flank < min_length |
                    dt_merged$right_flank < min_length)
  dt_merged[is_terminal,
            Type := ifelse(host_len == 0, label_term_incomp, label_term_comp)]

  if (count_unit == "coordinate") {
    dt_summary <- dt_merged[, .N, by = Type]
    count_description <- "coordinate records"
  } else {
    dt_by_phage <- dt_merged[, .(
      Type = if (any(Type == label_term_incomp)) label_term_incomp
             else if (any(Type == label_term_comp)) label_term_comp
             else label_internal
    ), by = phage_id]
    dt_summary <- dt_by_phage[, .N, by = Type]
    count_description <- "unique phage_id"
  }

  all_types <- data.table(Type = type_levels)
  dt_summary <- merge(all_types, dt_summary, by = "Type",
                      all.x = TRUE, sort = FALSE)
  dt_summary[is.na(N), N := 0L]

  total_n <- sum(dt_summary$N)
  if (total_n == 0) stop("Total count is 0: ", source_name)

  dt_summary[, fraction := N / total_n]
  dt_summary[, label := sprintf("%s\n(n=%d, %.1f%%)",
                                Type, as.integer(N), fraction * 100)]
  dt_summary[, Type := factor(Type, levels = type_levels)]

  get_count <- function(type_name) {
    idx <- which(as.character(dt_summary$Type) == type_name)
    if (length(idx) == 0) return(0L)
    as.integer(dt_summary$N[idx[1]])
  }

  message(sprintf(
    "  -> Done: total %d | Internal %d | Computable Terminal %d | Incomputable Terminal %d",
    total_n, get_count(label_internal),
    get_count(label_term_comp), get_count(label_term_incomp)
  ))
  message("  -> Counting unit: ", count_description)

  dt_summary
}


# ==============================================================================
#                         Combine multiple sources (sum by type, recompute fractions)
# ==============================================================================
combine_two_sources <- function(dt1, dt2) {
  dt_a <- data.table(Type = as.character(dt1$Type), N = as.integer(dt1$N))
  dt_b <- data.table(Type = as.character(dt2$Type), N = as.integer(dt2$N))

  merged <- rbindlist(list(dt_a, dt_b))[, .(N = sum(N)), by = Type]

  all_types <- data.table(Type = type_levels)
  merged <- merge(all_types, merged, by = "Type", all.x = TRUE, sort = FALSE)
  merged[is.na(N), N := 0L]

  total_n <- sum(merged$N)
  if (total_n == 0) stop("Combined total is 0; cannot plot")

  merged[, fraction := N / total_n]
  merged[, label := sprintf("%s\n(n=%d, %.1f%%)",
                            Type, as.integer(N), fraction * 100)]
  merged[, Type := factor(Type, levels = type_levels)]
  merged
}


# ==============================================================================
#                         Pie chart rendering
# ==============================================================================
make_pie <- function(dt_summary, title) {

  fill_values <- c(
    "Internal Phage"             = color_internal,
    "Computable Terminal Phage"  = color_term_comp,
    "Incomputable Terminal Phage"= color_term_incomp
  )
  label_values <- setNames(
    as.character(dt_summary$label),
    as.character(dt_summary$Type)
  )

  ggplot(dt_summary[N > 0], aes(x = "", y = fraction, fill = Type)) +
    geom_bar(stat = "identity", width = 1,
             color = pie_border_color, linewidth = pie_border_size) +
    coord_polar("y", start = 0) +
    scale_fill_manual(
      values = fill_values,
      breaks = type_levels,
      labels = label_values[type_levels],
      drop = FALSE
    ) +
    labs(title = title) +
    theme_void() +
    theme(
      plot.title = element_text(hjust = 0.5, face = title_face,
                                size = title_size, margin = margin(b = 20)),
      legend.position  = legend_position,
      legend.title     = element_blank(),
      legend.text      = element_text(size = legend_text_size),
      legend.key.size  = unit(1.5, "lines")
    )
}


# ==============================================================================
#                         Build source data
# ==============================================================================
build_source_data_long <- function(dt_gbic, dt_ab, dt_assembly, dt_combo) {

  rows <- list()

  # ---- Combined pie (GBIC + AB) details ----
  rows[[length(rows) + 1]] <- data.table(
    Figure = "Combined_GBIC_AB", Source = "GBIC",
    Type = as.character(dt_gbic$Type), Count = as.integer(dt_gbic$N)
  )
  rows[[length(rows) + 1]] <- data.table(
    Figure = "Combined_GBIC_AB", Source = "AB",
    Type = as.character(dt_ab$Type), Count = as.integer(dt_ab$N)
  )
  rows[[length(rows) + 1]] <- data.table(
    Figure = "Combined_GBIC_AB", Source = "GBIC+AB (Combined)",
    Type = as.character(dt_combo$Type), Count = as.integer(dt_combo$N)
  )

  # ---- Assembly benchmark pie details ----
  rows[[length(rows) + 1]] <- data.table(
    Figure = "Assembly_benchmark", Source = "Assembly benchmark",
    Type = as.character(dt_assembly$Type), Count = as.integer(dt_assembly$N)
  )

  dt_long <- rbindlist(rows)

  # Total / Fraction / Percent within each Figure x Source
  dt_long[, Total    := sum(Count), by = .(Figure, Source)]
  dt_long[, Fraction := Count / Total]
  dt_long[, Percent  := round(Fraction * 100, 4)]

  setcolorder(dt_long, c("Figure", "Source", "Type",
                         "Count", "Total", "Fraction", "Percent"))
  dt_long[]
}

build_source_data_wide <- function(dt_long) {
  wide <- dcast(dt_long, Figure + Source + Total ~ Type,
                value.var = "Count", fill = 0)

  # Fill missing type columns with 0 and fix column order
  for (col in type_levels) if (!col %in% names(wide)) wide[[col]] <- 0L
  setcolorder(wide, c("Figure", "Source", "Total", type_levels))

  # Append percentage columns (one per type)
  for (col in type_levels) {
    pct_col <- paste0(col, " (%)")
    wide[[pct_col]] <- round(wide[[col]] / wide$Total * 100, 4)
  }

  wide[]
}


dir.create(dirname(out_plot), recursive = TRUE, showWarnings = FALSE)

# One-time input check (verify all files exist before running)
for (f in c(gbic_fasta, gbic_coord,
            ab_fasta, ab_coord,
            assembly_fasta, assembly_coord)) check_file(f)

sum_gbic <- compute_summary(gbic_coord, gbic_fasta, "GBIC", count_unit)
sum_ab   <- compute_summary(ab_coord,   ab_fasta,   "AB",   count_unit)
sum_asm  <- compute_summary(assembly_coord, assembly_fasta,
                            "Assembly benchmark", count_unit)

sum_combo <- combine_two_sources(sum_gbic, sum_ab)

message("\n>>> Rendering two pie charts...")
p_combo <- make_pie(sum_combo, "Phage Location Profile: GBIC + AB")
p_asm   <- make_pie(sum_asm,   "Phage Location Profile: Assembly benchmark")

combined_plot <- p_combo | p_asm

ggsave(
  filename = out_plot,
  plot     = combined_plot,
  width    = plot_width,
  height   = plot_height,
  units    = "in",
  bg       = "white"
)

source_long <- build_source_data_long(sum_gbic, sum_ab, sum_asm, sum_combo)
source_wide <- build_source_data_wide(source_long)

fwrite(source_long, out_source_long, sep = "\t")
fwrite(source_wide, out_source_wide, sep = "\t")
