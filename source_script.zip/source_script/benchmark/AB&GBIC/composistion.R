suppressPackageStartupMessages({
  library(tidyverse)
  library(data.table)
  library(scales) 
})

data_dir <- "/home/huangyan/experiment/SPA/2-2/used_results"
out_dir  <- "./plot_output/activity_composition"
out_name <- "Combined_Prophage_Activity_Proportion.pdf"

sample_order <- c("Con_AB", "M_AB", "GBIC")

name_propagate <- "PropagAtE"
name_precise   <- "ACTIVE Precise"  
name_fast      <- "ACTIVE Fast"  
method_order <- c(name_propagate, name_precise, name_fast)

spa_threshold_active <- 0.8

drop_unassessable <- FALSE

label_active   <- "Active"
label_dormant  <- "Dormant"
label_unassess <- "Unassessable"

status_colors <- c(
  "Active"       = "#E41A1C",  
  "Dormant"      = "#377EB8",
  "Unassessable" = "#B0B0B0" 
)


plot_w     <- 9.0
plot_h     <- 5.2
global_dpi <- 300

bar_border_col <- "black"
bar_border_w   <- 0.35
bar_alpha      <- 0.9
bar_width      <- 0.65

strip_text_size <- 12
strip_text_face <- "bold"
strip_bg_col    <- "#EFEFEF"   

axis_title_size   <- 13
axis_title_face   <- "bold"
axis_text_size    <- 11
axis_text_face    <- "bold"
axis_text_x_angle <- 0         

legend_pos       <- "right"
legend_text_size <- 11


if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)


combined_data_list <- list()

for (sample in sample_order) {
  
  prop_file  <- file.path(data_dir, paste0(sample, "_propagate.tsv"))
  spa_p_file <- file.path(data_dir, paste0(sample, "_spa_precise.csv"))
  spa_s_file <- file.path(data_dir, paste0(sample, "_spa_sensitive.csv"))
  

  df_prop <- suppressWarnings(fread(prop_file)) %>%
    filter(rowSums(is.na(select(., -prophage))) < (ncol(.) - 1)) %>%
    mutate(
      Status = case_when(
        host_len == 0       ~ label_unassess,
        active == "active"  ~ label_active,
        active == "dormant" ~ label_dormant,
        TRUE                ~ label_unassess
      ),
      Method = name_propagate,
      Sample = sample
    ) %>% select(prophage, Sample, Method, Status)

  df_spa_p <- suppressWarnings(fread(spa_p_file)) %>%
    mutate(
      prophage = gsub("phage_depth_|\\.txt", "", Phage_File),
      Value    = as.numeric(Delta_Mean),
      Status   = case_when(
        is.na(Value)                  ~ label_dormant,
        Value >= spa_threshold_active ~ label_active,
        TRUE                          ~ label_dormant
      ),
      Method = name_precise,
      Sample = sample
    ) %>% select(prophage, Sample, Method, Status)

  df_spa_s <- suppressWarnings(fread(spa_s_file)) %>%
    mutate(
      prophage = gsub("phage_depth_|\\.txt", "", Phage_File),
      Value    = as.numeric(Effect_Size_Value),
      Status   = case_when(
        is.na(Value)                  ~ label_dormant,
        Value >= spa_threshold_active ~ label_active,
        TRUE                          ~ label_dormant
      ),
      Method = name_fast,
      Sample = sample
    ) %>% select(prophage, Sample, Method, Status)
  
  combined_data_list[[sample]] <- bind_rows(df_prop, df_spa_p, df_spa_s)
}

df_all_samples <- bind_rows(combined_data_list)

if (drop_unassessable) {
  df_all_samples <- df_all_samples %>% filter(Status != label_unassess)
}

status_levels <- if (drop_unassessable) c(label_active, label_dormant) else c(label_active, label_dormant, label_unassess)

df_summary <- df_all_samples %>%
  group_by(Method, Sample, Status) %>%
  summarise(Count = n(), .groups = "drop_last") %>%
  mutate(
    Proportion = Count / sum(Count) 
  ) %>%
  ungroup() %>%
  mutate(
    Sample = factor(Sample, levels = sample_order),
    Method = factor(Method, levels = method_order),
    Status = factor(Status, levels = status_levels)
  )

p <- ggplot(df_summary, aes(x = Sample, y = Proportion, fill = Status)) +
  geom_col(
    color     = bar_border_col, 
    linewidth = bar_border_w, 
    alpha     = bar_alpha, 
    width     = bar_width
  ) +
  facet_grid(. ~ Method) +
  scale_fill_manual(values = status_colors) +
  theme_classic(base_family = "Arial") +
  theme(
    strip.background = element_rect(fill = strip_bg_col, color = "black", linewidth = 0.6),
    strip.text       = element_text(size = strip_text_size, face = strip_text_face, color = "black"),
    axis.title.x     = element_blank(),
    axis.title.y     = element_text(size = axis_title_size, face = axis_title_face, color = "black"),
    axis.text.x      = element_text(size = axis_text_size, face = axis_text_face, color = "black",
                                    angle = axis_text_x_angle, hjust = if(axis_text_x_angle == 0) 0.5 else 1),
    axis.text.y      = element_text(size = axis_text_size, face = axis_text_face, color = "black"),
    axis.line        = element_line(color = "black", linewidth = 0.7),
    axis.ticks       = element_line(color = "black", linewidth = 0.7),
    legend.position  = legend_pos,
    legend.title     = element_blank(),
    legend.text      = element_text(size = legend_text_size, face = "bold", color = "black"),
    panel.spacing    = unit(1.2, "lines")
  ) +
 
  scale_y_continuous(
    labels = scales::percent_format(accuracy = 1),
    limits = c(0, 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    y = "Proportion of Prophages (%)"
  )

out_path <- file.path(out_dir, out_name)
ggsave(out_path, p, width = plot_w, height = plot_h, dpi = global_dpi, device = cairo_pdf)


