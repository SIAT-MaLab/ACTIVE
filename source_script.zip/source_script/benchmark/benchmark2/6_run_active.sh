
bash active_multi.sh \
  -g assembly_ref/renamed_by_host \
  -s ../cleanseq \
  -p phage_coordinate/coordinate_active.tsv \
  -o active_out_precise \
  -i filtered.index.tsv \
  -t 20 -r 20 \
  -c

bash active_multi.sh \
  -g assembly_ref/renamed_by_host \
  -s ../cleanseq \
  -p phage_coordinate/coordinate_active.tsv \
  -o active_out_sensitive \
  -i filtered.index.tsv \
  -t 20 -r 20
