#!/usr/bin/env bash
set -euo pipefail

show_help() {
cat <<'EOF'
Usage:
  bash run_propagate_from_spa.sh -s <SPA_OUT> -r <REF_DIR> -v <COORD_TSV>
             [-o <OUT_DIR>] [-m <MAPPED_BAM_DIR>] [-t THREADS] [-p IDENTITY]
             [--min MIN] [--breadth B] [--effect E] [--ratio C] [--skip-existing]

Required:
  -s    SPA output directory containing mapping_results/
  -r    Reference FASTA directory
  -v    Coordinate TSV with header: scaffold fragment start stop

Optional:
  -o    Propagate output parent [default: propagate_from_spa]
  -m    Filtered BAM directory [default: mapped_bam_from_spa]
  -t    Threads [default: 20]
  -p    Propagate -p [default: 0.97]
  --min / --breadth / --effect / --ratio
        Pass to Propagate --min / --breadth / -e / -c
  --skip-existing  Skip if *prophage_activity* exists
  -h               Help
EOF
}

SPA_OUT=""
REF_DIR=""
COORD_FILE=""
OUT_DIR="propagate_from_spa"
MAPPED_BAM_DIR="mapped_bam_from_spa"
THREADS=20
MIN_IDENT="0.97"
PROP_MIN=""
PROP_BREADTH=""
PROP_EFFECT=""
PROP_RATIO=""
SKIP_EXISTING=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        -s) SPA_OUT="$2"; shift 2 ;;
        -r) REF_DIR="$2"; shift 2 ;;
        -v) COORD_FILE="$2"; shift 2 ;;
        -o) OUT_DIR="$2"; shift 2 ;;
        -m) MAPPED_BAM_DIR="$2"; shift 2 ;;
        -t) THREADS="$2"; shift 2 ;;
        -p) MIN_IDENT="$2"; shift 2 ;;
        --min) PROP_MIN="$2"; shift 2 ;;
        --breadth) PROP_BREADTH="$2"; shift 2 ;;
        --effect) PROP_EFFECT="$2"; shift 2 ;;
        --ratio) PROP_RATIO="$2"; shift 2 ;;
        --skip-existing) SKIP_EXISTING=true; shift ;;
        -h|--help) show_help; exit 0 ;;
        *) echo "Unknown argument: $1"; show_help; exit 1 ;;
    esac
done

if [[ -z "$SPA_OUT" || -z "$REF_DIR" || -z "$COORD_FILE" ]]; then
    echo "Error: -s / -r / -v are required"
    show_help
    exit 1
fi

MAP_DIR="${SPA_OUT}/mapping_results"
if [[ ! -d "$MAP_DIR" ]]; then
    echo "Error: missing SPA mapping directory: $MAP_DIR"
    exit 1
fi
if [[ ! -d "$REF_DIR" ]]; then
    echo "Error: missing reference directory: $REF_DIR"
    exit 1
fi
if [[ ! -f "$COORD_FILE" ]]; then
    echo "Error: missing coordinate file: $COORD_FILE"
    exit 1
fi
if ! command -v Propagate >/dev/null 2>&1; then
    echo "Error: Propagate not found"
    exit 1
fi
if ! command -v samtools >/dev/null 2>&1; then
    echo "Error: samtools not found"
    exit 1
fi

TMP_DIR="${OUT_DIR}/_tmp_coords"
LOG_FILE="${OUT_DIR}/run_propagate.log"
SUMMARY="${OUT_DIR}/run_summary.tsv"

mkdir -p "$MAPPED_BAM_DIR" "$OUT_DIR" "$TMP_DIR"

{
    echo -e "sample\tref\tspa_bam\tmapped_bam\tn_coord\tmapped_reads\tstatus\tout_folder"
} > "$SUMMARY"

echo ">>> SPA mapping : $MAP_DIR"
echo ">>> reference   : $REF_DIR"
echo ">>> coordinates : $COORD_FILE"
echo ">>> output      : $OUT_DIR"
echo ">>> mapped BAM  : $MAPPED_BAM_DIR"
echo ">>> threads=$THREADS identity=-p $MIN_IDENT"
echo ">>> log         : $LOG_FILE"

n_ok=0
n_skip=0
n_fail=0

shopt -s nullglob
spa_bams=()
for bam in "$MAP_DIR"/*/*.bam; do
    base=$(basename "$bam")
    case "$base" in
        *.bai) continue ;;
        temp_sr_*|temp_lr_*) continue ;;
        *.mapped.sorted.bam) continue ;;
        *_*.bam) spa_bams+=("$bam") ;;
    esac
done
shopt -u nullglob

if [[ ${#spa_bams[@]} -eq 0 ]]; then
    echo "Error: no SPA BAM found under $MAP_DIR"
    exit 1
fi

echo ">>> found ${#spa_bams[@]} SPA BAMs"
echo

log() { echo "$*" | tee -a "$LOG_FILE"; }

filter_coords_by_fai() {
    local fai="$1"
    local coord="$2"
    local out="$3"
    awk 'NR==FNR { c[$1]=1; next }
         FNR==1 { print; next }
         NF>=4 && ($1 in c)' "$fai" "$coord" > "$out"
}

for bam in "${spa_bams[@]}"; do
    sample=$(basename "$(dirname "$bam")")
    bam_base=$(basename "$bam" .bam)

    prefix="${sample}_"
    if [[ "$bam_base" != "${prefix}"* ]]; then
        log "[SKIP] BAM name does not match sample directory: $bam"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\tNA\t${bam}\tNA\t0\t0\tNAME_MISMATCH\t" >> "$SUMMARY"
        continue
    fi
    ref_name="${bam_base#"$prefix"}"

    ref_fasta="${REF_DIR}/${ref_name}.fasta"
    mapped_bam="${MAPPED_BAM_DIR}/${sample}_${ref_name}.mapped.sorted.bam"
    temp_coord="${TMP_DIR}/${sample}_${ref_name}.tsv"
    out_folder="${OUT_DIR}/propagate_results_${sample}_${ref_name}"

    log "=================================================="
    log "sample: ${sample}"
    log "ref: ${ref_name}"
    log "SPA BAM: ${bam}"
    log "FASTA: ${ref_fasta}"

    if [[ ! -f "$ref_fasta" ]]; then
        log "[SKIP] missing FASTA: $ref_fasta"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\tNA\t0\t0\tMISSING_FASTA\t" >> "$SUMMARY"
        continue
    fi

    if [[ ! -f "${ref_fasta}.fai" ]]; then
        samtools faidx "$ref_fasta"
    fi

    filter_coords_by_fai "${ref_fasta}.fai" "$COORD_FILE" "$temp_coord"
    n_coord=$(awk 'NR>1 && NF>=4 {n++} END{print n+0}' "$temp_coord")
    if [[ "$n_coord" -eq 0 ]]; then
        log "[SKIP] no fai contig match for ${ref_name}"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\tNA\t0\t0\tNO_COORD\t" >> "$SUMMARY"
        rm -f "$temp_coord"
        continue
    fi
    log "[INFO] matched coordinates: ${n_coord}"

    if [[ "$SKIP_EXISTING" == true ]] && compgen -G "${out_folder}/*prophage_activity*" > /dev/null; then
        log "[SKIP] existing result: $out_folder"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\t${mapped_bam}\t${n_coord}\tNA\tSKIP_EXISTING\t${out_folder}" >> "$SUMMARY"
        continue
    fi

    if [[ ! -s "$mapped_bam" ]]; then
        log "[INFO] filtering unmapped reads (-F 4) and sorting/indexing..."
        samtools view -@ "$THREADS" -h -b -F 4 "$bam" \
            | samtools sort -@ "$THREADS" -o "$mapped_bam" -
        samtools index -@ "$THREADS" "$mapped_bam"
    else
        log "[INFO] reusing mapped BAM: $mapped_bam"
        [[ -f "${mapped_bam}.bai" ]] || samtools index -@ "$THREADS" "$mapped_bam"
    fi

    mapped_reads=$(samtools view -c -F 4 "$mapped_bam")
    if [[ "$mapped_reads" -eq 0 ]]; then
        log "[SKIP] no mapped reads"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\t${mapped_bam}\t${n_coord}\t0\tNO_MAPPED_READS\t" >> "$SUMMARY"
        continue
    fi
    log "[INFO] mapped reads: ${mapped_reads}"

    if [[ -e "$out_folder" ]]; then
        log "[INFO] removing existing output: $out_folder"
        rm -rf "$out_folder"
    fi

    cmd=(Propagate
        -f "$ref_fasta"
        -b "$mapped_bam"
        -v "$temp_coord"
        -o "$out_folder"
        -t "$THREADS"
        -p "$MIN_IDENT"
    )
    [[ -n "$PROP_MIN" ]] && cmd+=(--min "$PROP_MIN")
    [[ -n "$PROP_BREADTH" ]] && cmd+=(--breadth "$PROP_BREADTH")
    [[ -n "$PROP_EFFECT" ]] && cmd+=(-e "$PROP_EFFECT")
    [[ -n "$PROP_RATIO" ]] && cmd+=(-c "$PROP_RATIO")

    log "[INFO] ${cmd[*]}"
    if "${cmd[@]}" >> "$LOG_FILE" 2>&1; then
        log "[DONE] $sample / $ref_name"
        n_ok=$((n_ok + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\t${mapped_bam}\t${n_coord}\t${mapped_reads}\tOK\t${out_folder}" >> "$SUMMARY"
    else
        log "[FAIL] $sample / $ref_name (see $LOG_FILE)"
        n_fail=$((n_fail + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\t${mapped_bam}\t${n_coord}\t${mapped_reads}\tFAIL\t${out_folder}" >> "$SUMMARY"
    fi
    echo
done

echo "========== done =========="
echo "ok $n_ok  skip $n_skip  fail $n_fail"
echo "summary: $SUMMARY"
echo "log    : $LOG_FILE"