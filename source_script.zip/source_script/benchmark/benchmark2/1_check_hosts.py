#!/usr/bin/env python3
"""Check hosts in ref_assebly_source_seqdata.tsv against the two metadata tables."""

from __future__ import annotations

import csv
import re
import sys
from pathlib import Path

WORK_DIR = Path.cwd().resolve()
BENCHMARK_DIR = WORK_DIR.parent

REF_PATH = WORK_DIR / "ref_assebly_source_seqdata.tsv"
SEQTODL_PATH = WORK_DIR / "seqtodl.list"
META_PATH = BENCHMARK_DIR / "source_metadata_toactive_illumina.tsv"
DIAG_PATH = BENCHMARK_DIR / "all_samples_diagnostic_wide.tsv"

REPORT_OUT = WORK_DIR / "host_check_report.tsv"
KEPT_SRA_OUT = WORK_DIR / "kept_sras.txt"
MISSING_OUT = WORK_DIR / "hosts_not_in_both.tsv"
FILTERED_URLS_OUT = WORK_DIR / "seqtodl.filtered.list"
FILTERED_META_OUT = WORK_DIR / "source_metadata.tsv"

# True: host/SRA must be found in BOTH tables
REQUIRE_BOTH = True

ACC_RE = re.compile(r"^([A-Z]{1,2}_?\d+\.\d+)")
SRA_RE = re.compile(r"\b(?:SRR|ERR|DRR)\d+\b", re.IGNORECASE)


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def unique_fieldnames(fields):
    seen = {}
    out = []
    for f in fields:
        f = f.replace("\ufeff", "")
        if f not in seen:
            seen[f] = 0
            out.append(f)
        else:
            seen[f] += 1
            out.append(f"{f}__{seen[f]}")
    return out


def read_tsv(path: Path):
    if not path.is_file():
        die(f"file not found: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        header = handle.readline()
        if not header:
            return [], []
        raw_fields = header.rstrip("\n").split("\t")
        fields = unique_fieldnames(raw_fields)
        reader = csv.DictReader(handle, fieldnames=fields, delimiter="\t")
        rows = []
        for row in reader:
            if not any(str(v or "").strip() for v in row.values()):
                continue
            rows.append(row)
    return fields, rows


def host_keys(name: str):
    name = str(name or "").strip()
    if not name:
        return set()
    keys = {name}
    m = ACC_RE.match(name)
    if m:
        keys.add(m.group(1))
    token = name.split("_", 1)[0]
    if token:
        keys.add(token)
    return keys


def extract_sras(value: str):
    found = []
    for acc in SRA_RE.findall(str(value or "")):
        acc = acc.upper()
        if acc not in found:
            found.append(acc)
    return found


def collect_from_table(rows, host_cols, sra_cols):
    host_index = {}
    sra_index = {}
    for i, row in enumerate(rows):
        for col in host_cols:
            if col not in row:
                continue
            for key in host_keys(row.get(col, "")):
                host_index.setdefault(key, set()).add(i)
        for col in sra_cols:
            if col not in row:
                continue
            for acc in extract_sras(row.get(col, "")):
                sra_index.setdefault(acc, set()).add(i)
    return host_index, sra_index


def load_url_map(path: Path):
    mapping = {}
    if not path.is_file():
        return mapping
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        acc = Path(line.rstrip("/")).name.upper()
        mapping[acc] = line
    return mapping


def main():
    ref_fields, ref_rows = read_tsv(REF_PATH)
    meta_fields, meta_rows = read_tsv(META_PATH)
    diag_fields, diag_rows = read_tsv(DIAG_PATH)
    url_map = load_url_map(SEQTODL_PATH)

    ref_host_col = next((c for c in ref_fields if c.lower() == "host"), None)
    ref_sra_col = next((c for c in ref_fields if c.lower() == "sra"), None)
    if ref_host_col is None or ref_sra_col is None:
        die(f"ref file must have host and SRA columns: {ref_fields}")

    meta_host_cols = [
        c for c in meta_fields
        if "prophage_host" in c.lower() or c.lower() in {"host", "host_species"}
    ]
    meta_sra_cols = [
        c for c in meta_fields
        if "accession" in c.lower() or c.lower() in {"sra", "sample_key"}
    ]
    diag_host_cols = [
        c for c in diag_fields
        if c.lower() in {"host_species", "host", "prophage_host"}
        or "host" in c.lower()
    ]
    diag_sra_cols = [
        c for c in diag_fields
        if c.lower() in {"sample_key", "uid", "reads_accession", "sra"}
    ]

    meta_host_index, meta_sra_index = collect_from_table(
        meta_rows, meta_host_cols, meta_sra_cols
    )
    diag_host_index, diag_sra_index = collect_from_table(
        diag_rows, diag_host_cols, diag_sra_cols
    )

    report_fields = [
        "host",
        "sra",
        "type",
        "in_illumina_metadata_by_host",
        "in_illumina_metadata_by_sra",
        "in_diagnostic_by_host",
        "in_diagnostic_by_sra",
        "n_meta_rows",
        "n_diag_rows",
        "example_sample_id",
        "download_url",
        "keep",
        "reason",
    ]
    report_rows = []
    kept_sras = []
    kept_meta_idx = set()
    missing_rows = []

    for ref in ref_rows:
        host = str(ref.get(ref_host_col, "")).strip()
        sra = str(ref.get(ref_sra_col, "")).strip().upper()
        seqtype = str(ref.get("type", "")).strip()

        host_hit_meta = set()
        for key in host_keys(host):
            host_hit_meta |= meta_host_index.get(key, set())
        sra_hit_meta = set(meta_sra_index.get(sra, set()))
        meta_hits = host_hit_meta | sra_hit_meta

        host_hit_diag = set()
        for key in host_keys(host):
            host_hit_diag |= diag_host_index.get(key, set())
        sra_hit_diag = set(diag_sra_index.get(sra, set()))
        diag_hits = host_hit_diag | sra_hit_diag

        in_meta_host = bool(host_hit_meta)
        in_meta_sra = bool(sra_hit_meta)
        in_diag_host = bool(host_hit_diag)
        in_diag_sra = bool(sra_hit_diag)
        in_meta = bool(meta_hits)
        in_diag = bool(diag_hits)

        if REQUIRE_BOTH:
            keep = in_meta and in_diag
        else:
            keep = in_meta or in_diag

        if keep:
            reason = "present_in_both" if (in_meta and in_diag) else "present_in_one"
        else:
            if not in_meta and not in_diag:
                reason = "missing_in_both"
            elif not in_meta:
                reason = "missing_in_illumina_metadata"
            else:
                reason = "missing_in_diagnostic"

        example_sid = ""
        if meta_hits:
            row0 = meta_rows[sorted(meta_hits)[0]]
            example_sid = row0.get("sample_id", "")

        rec = {
            "host": host,
            "sra": sra,
            "type": seqtype,
            "in_illumina_metadata_by_host": str(in_meta_host),
            "in_illumina_metadata_by_sra": str(in_meta_sra),
            "in_diagnostic_by_host": str(in_diag_host),
            "in_diagnostic_by_sra": str(in_diag_sra),
            "n_meta_rows": str(len(meta_hits)),
            "n_diag_rows": str(len(diag_hits)),
            "example_sample_id": example_sid,
            "download_url": url_map.get(sra, ""),
            "keep": "TRUE" if keep else "FALSE",
            "reason": reason,
        }
        report_rows.append(rec)

        if keep:
            if sra and sra not in kept_sras:
                kept_sras.append(sra)
            kept_meta_idx |= meta_hits
        else:
            missing_rows.append(rec)

    with REPORT_OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=report_fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(report_rows)

    with MISSING_OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=report_fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(missing_rows)

    KEPT_SRA_OUT.write_text("".join(x + "\n" for x in kept_sras), encoding="utf-8")

    with FILTERED_URLS_OUT.open("w", encoding="utf-8") as handle:
        n_url = 0
        for sra in kept_sras:
            url = url_map.get(sra)
            if url:
                handle.write(url + "\n")
                n_url += 1

    # Write filtered metadata for grabseqs.py; keep original sample_id.
    # Use uniquified headers so duplicate prophage_host is preserved.
    with FILTERED_META_OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=meta_fields,
            delimiter="\t",
            lineterminator="\n",
            extrasaction="ignore",
        )
        writer.writeheader()
        kept_meta_rows = [meta_rows[i] for i in sorted(kept_meta_idx)]
        # Also keep metadata rows whose reads_accession is in kept_sras
        # even if host-key matching missed them.
        extra = []
        for row in meta_rows:
            accs = []
            for col in meta_sra_cols:
                accs.extend(extract_sras(row.get(col, "")))
            if any(acc in set(kept_sras) for acc in accs):
                extra.append(row)
        seen = set()
        out_rows = []
        for row in kept_meta_rows + extra:
            key = tuple(row.get(f, "") for f in meta_fields)
            if key in seen:
                continue
            seen.add(key)
            out_rows.append(row)
        writer.writerows(out_rows)

    n_ref = len(ref_rows)
    n_keep = sum(1 for r in report_rows if r["keep"] == "TRUE")
    n_miss = n_ref - n_keep

    print("=" * 72)
    print("Host check summary")
    print(f"  ref hosts/rows     : {n_ref}")
    print(f"  KEEP (in both)     : {n_keep}")
    print(f"  NOT in both        : {n_miss}")
    print(f"  unique kept SRAs   : {len(kept_sras)}")
    print(f"  URLs to download   : {n_url}")
    print(f"  filtered metadata  : {len(out_rows)} rows -> {FILTERED_META_OUT.name}")
    print()
    print(f"  report             : {REPORT_OUT}")
    print(f"  missing            : {MISSING_OUT}")
    print(f"  kept SRAs          : {KEPT_SRA_OUT}")
    print(f"  filtered URL list  : {FILTERED_URLS_OUT}")
    print("=" * 72)

    if n_miss:
        print("\nHosts / SRAs NOT kept:")
        for r in missing_rows:
            print(f"  {r['sra']:<12} {r['host']:<50} {r['reason']}")

    if n_keep == 0:
        die("no host/SRA present in both tables; stop before download")


if __name__ == "__main__":
    main()
