#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(stringr)
  library(ggplot2)
  library(scales)
  library(tibble)
})

HEATMAP_LOW  <- "#3c729f"
HEATMAP_MID  <- "#ffffff"
HEATMAP_HIGH <- "#d48895"

cat(">>> [1/4] loading host whitelist and ground truth...\n")
host_dir <- "assembly_ref/renamed_by_host"
if (!dir.exists(host_dir)) {
  stop(sprintf("Error: host directory not found: %s", host_dir))
}
valid_hosts <- unique(sub("\\.(fasta|fa)$", "", list.files(host_dir, pattern = "\\.(fasta|fa)$")))

meta_path <- if (file.exists("source_metadata_toactive_illumina.tsv")) {
  "source_metadata_toactive_illumina.tsv"
} else if (file.exists("../source_metadata_toactive_illumina.tsv")) {
  "../source_metadata_toactive_illumina.tsv"
} else {
  stop("Error: source_metadata_toactive_illumina.tsv not found")
}

meta_df <- read_tsv(meta_path, col_types = cols(.default = "c"), show_col_types = FALSE) %>%
  rename_with(~ "host_species", matches("^prophage_host\\.\\.\\.12$|^prophage_host$")) %>%
  rename_with(~ "genome_accession", matches("^prophage_host\\.\\.\\.14$|^prophage_host_acc$")) %>%
  mutate(
    start_clean = as.numeric(gsub(",", "", `prophage start`)),
    stop_clean  = as.numeric(gsub(",", "", `prophage stop`)),
    p_start     = pmin(start_clean, stop_clean),
    p_stop      = pmax(start_clean, stop_clean),
    sample_key  = ifelse(!is.na(reads_accession) & reads_accession != "" & reads_accession != "-", reads_accession, sample_id),
    truth       = tolower(str_trim(expected)),
    host_clean  = ifelse(!is.na(genome_accession), genome_accession, str_replace(contig_1, "_.*", "")),
    uid         = paste(sample_key, contig_1, p_start, p_stop, sep = "__")
  ) %>%
  filter(truth %in% c("active", "dormant")) %>%
  filter(host_clean %in% valid_hosts) %>%
  select(uid, sample_key, contig_1, p_start, p_stop, host_clean, prophage_name, truth) %>%
  distinct(uid, .keep_all = TRUE)

cat(sprintf(">>> valid ground truth entries: %d\n", nrow(meta_df)))

cat(">>> [2/4] parsing SPA predictions...\n")

precise_file <- list.files(c("active_out_precise", "spa_out_shared"), 
                           pattern = "(active_precise|all_active_precise_results).*\\.csv$", 
                           recursive = TRUE, full.names = TRUE)[1]
if (is.na(precise_file) || !file.exists(precise_file)) {
  stop("Error: active_precise result not found")
}
spa_precise_raw <- read_csv(precise_file, col_types = cols(.default = "c"), show_col_types = FALSE)

spa_precise_df <- spa_precise_raw %>%
  mutate(
    coords = str_extract(Phage_File, "(?<=phage_depth_).*(?=\\.txt)"),
    start  = as.numeric(str_extract(coords, "(?<=_)\\d+(?=_\\d+$)")),
    stop   = as.numeric(str_extract(coords, "\\d+$")),
    contig = str_remove(coords, "_\\d+_\\d+$"),
    p_start = pmin(start, stop),
    p_stop  = pmax(start, stop),
    uid     = paste(Folder, contig, p_start, p_stop, sep = "__"),
    Delta_Mean_num = suppressWarnings(as.numeric(Delta_Mean)),
    spa_precise_qc = ifelse(Significant == "Coverage failed" | is.na(Significant), "FAIL", "PASS"),
    spa_precise_sig = !is.na(Significant) & Significant == "Yes",
    spa_precise_pred = case_when(
      spa_precise_qc == "FAIL" ~ "uncal",
      spa_precise_sig & !is.na(Delta_Mean_num) & Delta_Mean_num >= 0.8 ~ "active",
      TRUE ~ "dormant"
    )
  ) %>%
  select(uid, spa_precise_qc, spa_precise_sig, Delta_Mean = Delta_Mean_num, spa_precise_pred) %>%
  distinct(uid, .keep_all = TRUE)

sensitive_file <- list.files(c("active_out_sensitive", "spa_out_shared"), 
                             pattern = "(active_sensitive|all_active_sensitive_results).*\\.csv$", 
                             recursive = TRUE, full.names = TRUE)[1]
if (is.na(sensitive_file) || !file.exists(sensitive_file)) {
  stop("Error: active_sensitive result not found")
}
spa_sensitive_raw <- read_csv(sensitive_file, col_types = cols(.default = "c"), show_col_types = FALSE)

spa_sensitive_df <- spa_sensitive_raw %>%
  mutate(
    coords = str_extract(Phage_File, "(?<=phage_depth_).*(?=\\.txt)"),
    start  = as.numeric(str_extract(coords, "(?<=_)\\d+(?=_\\d+$)")),
    stop   = as.numeric(str_extract(coords, "\\d+$")),
    contig = str_remove(coords, "_\\d+_\\d+$"),
    p_start = pmin(start, stop),
    p_stop  = pmax(start, stop),
    uid     = paste(Folder, contig, p_start, p_stop, sep = "__"),
    Effect_Size_num = suppressWarnings(as.numeric(Effect_Size_Value)),
    spa_sensitive_qc = ifelse(Significant == "Coverage failed" | is.na(Significant), "FAIL", "PASS"),
    spa_sensitive_sig = !is.na(Significant) & Significant == "Yes",
    spa_sensitive_pred = case_when(
      spa_sensitive_qc == "FAIL" ~ "uncal",
      spa_sensitive_sig & !is.na(Effect_Size_num) & Effect_Size_num >= 0.8 ~ "active",
      TRUE ~ "dormant"
    )
  ) %>%
  select(uid, spa_sensitive_qc, spa_sensitive_sig, Effect_Size = Effect_Size_num, spa_sensitive_pred) %>%
  distinct(uid, .keep_all = TRUE)

cat(">>> [3/4] calculating metrics...\n")
master_df <- meta_df %>%
  left_join(spa_precise_df,   by = "uid") %>%
  left_join(spa_sensitive_df, by = "uid")

assign_status <- function(truth, pred, qc) {
  case_when(
    qc == "FAIL" | is.na(qc) | pred == "uncal" | is.na(pred) ~ "QC_FAIL",
    truth == "active"  & pred == "active"  ~ "TP",
    truth == "dormant" & pred == "active"  ~ "FP",
    truth == "dormant" & pred == "dormant" ~ "TN",
    truth == "active"  & pred == "dormant" ~ "FN",
    TRUE ~ "QC_FAIL"
  )
}

diag_df <- master_df %>%
  mutate(
    SPA_Precise_status   = assign_status(truth, spa_precise_pred, spa_precise_qc),
    SPA_Sensitive_status = assign_status(truth, spa_sensitive_pred, spa_sensitive_qc)
  )

calc_spa_metrics <- function(df, status_col, method_name) {
  tp <- sum(df[[status_col]] == "TP", na.rm = TRUE)
  fp <- sum(df[[status_col]] == "FP", na.rm = TRUE)
  tn <- sum(df[[status_col]] == "TN", na.rm = TRUE)
  fn <- sum(df[[status_col]] == "FN", na.rm = TRUE)
  called_n <- tp + fp + tn + fn

  sen <- ifelse((tp + fn) > 0, tp / (tp + fn), NA_real_)
  spe <- ifelse((tn + fp) > 0, tn / (tn + fp), NA_real_)
  ppv <- ifelse((tp + fp) > 0, tp / (tp + fp), NA_real_)
  npv <- ifelse((tn + fn) > 0, tn / (tn + fn), NA_real_)
  acc <- ifelse(called_n > 0, (tp + tn) / called_n, NA_real_)
  f1  <- ifelse(!is.na(ppv) & !is.na(sen) & (ppv + sen) > 0, 2 * ppv * sen / (ppv + sen), NA_real_)
  
  mcc_den <- sqrt(as.numeric(tp + fp) * as.numeric(tp + fn) * as.numeric(tn + fp) * as.numeric(tn + fn))
  mcc <- ifelse(!is.na(mcc_den) & mcc_den > 0, ((tp * tn) - (fp * fn)) / mcc_den, NA_real_)

  tibble(
    Method = method_name,
    Sensitivity = sen, Specificity = spe, Precision = ppv,
    NPV = npv, Accuracy = acc, F1_Score = f1, MCC = mcc
  )
}

spa_metrics_df <- bind_rows(
  calc_spa_metrics(diag_df, "SPA_Precise_status",   "SPA (Precise)"),
  calc_spa_metrics(diag_df, "SPA_Sensitive_status", "SPA (Sensitive)")
)

heatmap_data <- spa_metrics_df %>%
  pivot_longer(cols = -Method, names_to = "Metric", values_to = "Value") %>%
  mutate(
    Metric = factor(Metric, levels = c("Sensitivity", "Specificity", "Precision", "NPV", "Accuracy", "F1_Score", "MCC")),
    Method = factor(Method, levels = c("SPA (Sensitive)", "SPA (Precise)"))
  )

cat(">>> [4/4] plotting and saving...\n")

theme_pub <- theme_classic(base_size = 11) +
  theme(
    axis.text        = element_text(color = "black", size = 10),
    axis.title       = element_text(face = "bold", size = 11),
    legend.title     = element_text(face = "bold", size = 9),
    legend.text      = element_text(size = 8.5),
    plot.title       = element_text(face = "bold", size = 12, hjust = 0.5)
  )

p_heatmap <- ggplot(heatmap_data, aes(x = Metric, y = Method, fill = Value)) +
  geom_tile(color = "black", linewidth = 0.5) +
  geom_text(aes(label = sprintf("%.2f", Value)), size = 4.2, fontface = "bold", color = "black") +
  scale_fill_gradient2(
    low = HEATMAP_LOW, mid = HEATMAP_MID, high = HEATMAP_HIGH, 
    midpoint = 0.85, limits = c(0.75, 1.0), oob = squish,
    name = "Score"
  ) +
  labs(title = "SPA Performance (Cliff's \u03b4 \u2265 0.8)", x = NULL, y = NULL) +
  theme_pub +
  theme(
    axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1, face = "bold"),
    axis.text.y = element_text(face = "bold"),
    legend.position = "right"
  )

out_png <- "SPA_performance_heatmap.png"
out_pdf <- "SPA_performance_heatmap.pdf"

ggsave(out_png, p_heatmap, width = 7.8, height = 3.6, dpi = 300)
ggsave(out_pdf, p_heatmap, width = 7.8, height = 3.6)

cat(sprintf(">>> [DONE] heatmap saved: %s / %s\n", out_png, out_pdf))