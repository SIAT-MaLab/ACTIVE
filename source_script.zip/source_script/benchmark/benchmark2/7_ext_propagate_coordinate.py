import pandas as pd

summary = pd.read_csv("phage_coordinate/summary.tsv", sep="\t", dtype=str, keep_default_na=False)

coords = pd.read_csv(
    "phage_coordinate/coordinate_active.tsv", sep="\t", dtype=str,
    keep_default_na=False,
).rename(columns={"phage_id": "fragment", "contig": "scaffold", "end": "stop"})

intact_ids = set(summary.loc[summary["class"].str.strip() == "intact", "phage_id"])
real = coords[coords["fragment"].isin(intact_ids)].copy()

for col in ["start", "stop"]:
    real[col] = pd.to_numeric(real[col].str.replace(",", "", regex=False).str.strip(),
                              errors="raise").astype(int)

if (real["start"] < 1).any() or (real["stop"] < real["start"]).any():
    raise ValueError("存在非法坐标")

missing = intact_ids - set(real["fragment"])
if missing:
    print(f"[提示] {len(missing)} 个 intact phage 在 coordinate_active.tsv 中无记录，跳过：{sorted(missing)}")

n = real.groupby("fragment").size()
multi = n[n > 1]
if len(multi):
    print(f"[警告] {len(multi)} 个 intact phage 有多条记录（多点匹配），已剔除：")
    for pid, cnt in multi.items():
        hits = real.loc[real["fragment"] == pid, "scaffold"].tolist()
        print(f"  {pid}  ({cnt} 行 → {', '.join(hits)})")
    real = real[real["fragment"].isin(set(n[n == 1].index))]

real = real[["scaffold", "fragment", "start", "stop"]].drop_duplicates().reset_index(drop=True)

extracted = real["scaffold"].str.extract(r"^(.*)_(\d+)$")
if extracted.isna().any().any():
    bad = real.loc[extracted.isna().any(axis=1), "scaffold"].unique()
    raise ValueError("scaffold 无法解析为 prefix_contigNumber:\n" + "\n".join(bad))

real["_prefix"] = extracted[0]
real["_ctg"] = extracted[1].astype(int)

host_map = summary.drop_duplicates("phage_id").set_index("phage_id")["host"]
real["_genome"] = real["fragment"].map(host_map).fillna(real["_prefix"])

genome_info = real.groupby("_genome").agg(prefix=("_prefix", "first"),
                                          max_ctg=("_ctg", "max"))
fake = pd.DataFrame({
    "scaffold": genome_info["prefix"] + "_" + (genome_info["max_ctg"] + 1).astype(str),
    "fragment": genome_info.index + "_fakepp",
    "start": 3000,
    "stop": 5000,
}).reset_index(drop=True)

result = pd.concat([real[["scaffold", "fragment", "start", "stop"]], fake], ignore_index=True)


result.to_csv("propagate_coordinates.tsv", sep="\t", index=False)

