
dir=$(basename "$PWD")
out=clinker_output
mkdir -p $out
clinker annot/single_gbks/*.gbk -o $out/${dir}.txt -dl "\t" -j 15 -p $out/${dir}.html
#done
