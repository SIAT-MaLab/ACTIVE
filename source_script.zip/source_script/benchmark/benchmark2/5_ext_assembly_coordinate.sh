#!/usr/bin/env bash
set -euo pipefail

THREADS=20
WORKDIR="/home/huangyan/experiment/SPA/2-1_benchmark/benchmark/assembly_benchmark"
OUT="${WORKDIR}/phage_coordinate"
META="${WORKDIR}/../source_metadata_toactive_illumina.tsv"
ASM_DIR="${WORKDIR}/assembly_ref/renamed_by_host"
REF_DIR="${WORKDIR}/../references"

for d in "${REF_DIR}" "${ASM_DIR}"; do
    [[ -d "${d}" ]] || { echo "[Error] missing directory: ${d}" >&2; exit 1; }
done
[[ -f "${META}" ]] || { echo "[Error] missing metadata: ${META}" >&2; exit 1; }
for c in python3 blastn; do
    command -v "${c}" >/dev/null 2>&1 || { echo "[Error] missing command: ${c}" >&2; exit 1; }
done

mkdir -p "${OUT}/.tmp/q_by_host"
export THREADS OUT META ASM_DIR REF_DIR

python3 - <<'PY'
import csv
import os
import re
import shutil
import subprocess
from collections import Counter, defaultdict

THREADS = int(os.environ["THREADS"])
OUT     = os.environ["OUT"]
META    = os.environ["META"]
ASM_DIR = os.environ["ASM_DIR"]
REF_DIR = os.environ["REF_DIR"]
TMP     = os.path.join(OUT, ".tmp")

MIN_LEN       = 200
MIN_PIDENT    = 95.0
PIDENT_STRICT = 99.0
MERGE_GAP     = 1000
INTACT_QCOV   = 0.90
ACTIVE_QCOV   = 0.80

print(f"[0] params: MIN_LEN={MIN_LEN} p95={MIN_PIDENT} p99={PIDENT_STRICT} "
      f"MERGE_GAP={MERGE_GAP} INTACT_QCOV={INTACT_QCOV} ACTIVE_QCOV={ACTIVE_QCOV}")

def find_fasta(folder, host):
    for ext in (".fasta", ".fa", ".fna"):
        p = os.path.join(folder, host + ext)
        if os.path.isfile(p):
            return p
    return None

def host_of_contig(contig):
    m = re.match(r"^(.*)_\d+$", contig)
    return m.group(1) if m else contig

def to_int(v):
    return int(v.replace(",", "").replace('"', "").strip())

def read_fasta(path):
    recs, name, buf = {}, None, []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith(">"):
                if name is not None:
                    recs[name] = "".join(buf)
                name, buf = line[1:].split()[0], []
            else:
                buf.append(line.strip())
        if name is not None:
            recs[name] = "".join(buf)
    return recs

def write_fasta(path, records):
    with open(path, "w") as f:
        for sid, seq in records:
            f.write(f">{sid}\n")
            for i in range(0, len(seq), 80):
                f.write(seq[i:i + 80] + "\n")

def merge_iv(ivs, gap):
    if not ivs:
        return []
    ivs = sorted(ivs)
    out = [[ivs[0][0], ivs[0][1]]]
    for a, b in ivs[1:]:
        if a <= out[-1][1] + gap + 1:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out

def union_len(ivs):
    return sum(b - a + 1 for a, b in merge_iv(ivs, 0))

def classify(s99, s95):
    if s99["n_ctg"] == 0:
        return "p95_only" if s95["n_ctg"] > 0 else "low_quality"
    if s99["n_ctg"] >= 2:
        return "split"
    if s99["n_iv"] > 1:
        return "gapped"
    return "intact" if s99["qcov"] >= INTACT_QCOV else "partial"

uniq, n_meta = {}, 0
with open(META, "r", encoding="utf-8", errors="ignore") as f:
    header = f.readline().rstrip("\n").lstrip("\ufeff").split("\t")
    col = {n.strip(): i for i, n in enumerate(header)}
    for need in ("contig_1", "prophage start", "prophage stop"):
        if need not in col:
            raise SystemExit(f"[Error] metadata missing columns: {need}\ncolumns: {header}")
    i_c, i_s, i_e = col["contig_1"], col["prophage start"], col["prophage stop"]
    for line in f:
        if not line.strip():
            continue
        p = line.rstrip("\n").split("\t")
        if max(i_c, i_s, i_e) >= len(p):
            continue
        n_meta += 1
        contig = p[i_c].strip()
        smin = min(to_int(p[i_s]), to_int(p[i_e]))
        smax = max(to_int(p[i_s]), to_int(p[i_e]))
        uniq[(contig, smin, smax)] = None

dropped_rows, kept = [], []
for contig, smin, smax in sorted(uniq):
    pid  = f"{contig}_{smin}_{smax}"
    host = host_of_contig(contig)
    asm  = find_fasta(ASM_DIR, host)
    ref  = find_fasta(REF_DIR, host)
    if asm is None:
        dropped_rows.append((pid, host, contig, smin, smax, "no_assembly_fasta"))
    elif ref is None:
        dropped_rows.append((pid, host, contig, smin, smax, "no_complete_fasta"))
    else:
        kept.append((pid, host, contig, smin, smax, asm, ref))

print(f"[1] metadata rows={n_meta} unique={len(uniq)} ready={len(kept)} dropped={len(dropped_rows)}")

by_ref = defaultdict(list)
for rec in kept:
    by_ref[rec[6]].append(rec)

query_all, query_map, host_queries = [], {}, defaultdict(list)
for ref_fa, recs in by_ref.items():
    fa = read_fasta(ref_fa)
    for pid, host, contig, smin, smax, asm, ref in recs:
        if contig not in fa:
            dropped_rows.append((pid, host, contig, smin, smax, "contig_not_in_complete"))
            continue
        seq = fa[contig]
        if smin < 1 or smax > len(seq) or smin > smax:
            dropped_rows.append((pid, host, contig, smin, smax, "coords_out_of_range"))
            continue
        sub = seq[smin - 1:smax].upper()
        if len(sub) < MIN_LEN:
            dropped_rows.append((pid, host, contig, smin, smax, "seq_shorter_than_200"))
            continue
        query_all.append((pid, sub))
        query_map[pid] = dict(pid=pid, host=host, contig=contig,
                              start=smin, end=smax, qlen=len(sub))
        host_queries[host].append((pid, sub))

with open(os.path.join(OUT, "query.fasta"), "w") as _:
    pass
write_fasta(os.path.join(OUT, "query.fasta"), query_all)
with open(os.path.join(OUT, "dropped.tsv"), "w", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(["phage_id", "host", "contig", "start", "end", "reason"])
    w.writerows(dropped_rows)

print(f"[2] queries={len(query_map)} dropped=dropped.tsv")
if not query_map:
    raise SystemExit("[Error] no extractable prophage sequences")

raw_path = os.path.join(TMP, "blast_raw.tsv")
if os.path.exists(raw_path):
    os.remove(raw_path)

n_host = 0
for host, recs in sorted(host_queries.items()):
    qpath = os.path.join(TMP, "q_by_host", f"{host}.fasta")
    write_fasta(qpath, recs)
    cmd = [
        "blastn", "-task", "megablast",
        "-query", qpath,
        "-subject", find_fasta(ASM_DIR, host),
        "-num_threads", str(THREADS),
        "-evalue", "1e-10",
        "-perc_identity", str(MIN_PIDENT),
        "-max_target_seqs", "10000",
        "-outfmt", "6 qseqid sseqid pident length mismatch gapopen "
                   "qstart qend sstart send evalue bitscore qlen slen",
    ]
    try:
        r = subprocess.run(cmd, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        raise SystemExit(f"[Error] blastn failed (host={host}):\n{e.stderr}")
    with open(raw_path, "a") as out_f:
        out_f.write(r.stdout)
    n_host += 1

print(f"[3] BLAST done hosts={n_host}")

hq_rows = []
host_mismatch = 0
if os.path.exists(raw_path) and os.path.getsize(raw_path) > 0:
    with open(raw_path, "r") as f:
        for line in f:
            if not line.strip():
                continue
            a = line.rstrip("\n").split("\t")
            if len(a) < 14:
                continue
            qseqid, sseqid = a[0], a[1].split()[0]
            pident, length = float(a[2]), int(a[3])
            if length < MIN_LEN or pident < MIN_PIDENT:
                continue
            if qseqid not in query_map:
                continue
            qhost = query_map[qseqid]["host"]
            shost = host_of_contig(sseqid)
            if qhost != shost:
                host_mismatch += 1
                continue
            sstart, send = int(a[8]), int(a[9])
            smin, smax = (sstart, send) if sstart <= send else (send, sstart)
            hq_rows.append(dict(
                qseqid=qseqid, sseqid=sseqid, pident=pident, length=length,
                mismatch=int(a[4]), gapopen=int(a[5]),
                qstart=int(a[6]), qend=int(a[7]),
                sstart=sstart, send=send, smin=smin, smax=smax,
                evalue=a[10], bitscore=a[11],
                qlen=query_map[qseqid]["qlen"], slen=int(a[13]),
            ))
if host_mismatch:
    print(f"[!] WARNING: {host_mismatch} HSPs with host mismatch removed")

hq_rows.sort(key=lambda x: (x["qseqid"], -x["pident"], -x["length"],
                            x["sseqid"], x["smin"]))
rows99 = [r for r in hq_rows if r["pident"] >= PIDENT_STRICT]

HQ_FIELDS = ["qseqid", "sseqid", "pident", "length", "mismatch", "gapopen",
             "qstart", "qend", "sstart", "send", "smin", "smax",
             "evalue", "bitscore", "qlen", "slen"]

def write_hits(path, rows):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=HQ_FIELDS, delimiter="\t", lineterminator="\n")
        w.writeheader()
        for row in rows:
            out = dict(row)
            out["pident"] = f"{row['pident']:.3f}"
            w.writerow(out)

write_hits(os.path.join(OUT, "blast_hq.tsv"), hq_rows)
write_hits(os.path.join(OUT, "hits_p99.tsv"), rows99)
print(f"[4] p95 HSP={len(hq_rows)} p99 HSP={len(rows99)}")

def build_coords(rows, gap):
    groups  = defaultdict(list)
    qspans  = defaultdict(list)
    hsp_n   = defaultdict(int)
    for r in rows:
        groups[(r["qseqid"], r["sseqid"])].append((r["smin"], r["smax"]))
        qspans[r["qseqid"]].append((min(r["qstart"], r["qend"]),
                                    max(r["qstart"], r["qend"])))
        hsp_n[r["qseqid"]] += 1
    coords = []
    for (pid, ctg), ivs in groups.items():
        for a, b in merge_iv(ivs, gap):
            coords.append((pid, ctg, a, b))
    coords.sort()
    ctg_set, iv_cnt = defaultdict(set), defaultdict(int)
    for pid, ctg, a, b in coords:
        ctg_set[pid].add(ctg)
        iv_cnt[pid] += 1
    stats = {}
    for pid, spans in qspans.items():
        qlen = query_map[pid]["qlen"]
        stats[pid] = dict(
            n_hsp=hsp_n[pid],
            n_ctg=len(ctg_set.get(pid, ())),
            n_iv=iv_cnt.get(pid, 0),
            qcov=union_len(spans) / qlen if qlen else 0.0,
            hits=";".join(f"{ctg}:{a}-{b}" for p, ctg, a, b in coords if p == pid),
        )
    return coords, stats

coords95, st95 = build_coords(hq_rows, MERGE_GAP)
coords99, st99 = build_coords(rows99,  MERGE_GAP)

def write_coords(path, coords):
    with open(path, "w") as f:
        for pid, ctg, a, b in coords:
            f.write(f"{pid}\t{ctg}\t{a}\t{b}\n")

write_coords(os.path.join(OUT, "coords_p95.tsv"), coords95)
write_coords(os.path.join(OUT, "coords_p99.tsv"), coords99)

active_pids = {pid for pid, s in st99.items() if s["qcov"] >= ACTIVE_QCOV}
with open(os.path.join(OUT, "coordinate_active.tsv"), "w") as f:
    f.write("phage_id\tcontig\tstart\tend\n")
    for pid, ctg, a, b in coords99:
        if pid in active_pids:
            f.write(f"{pid}\t{ctg}\t{a}\t{b}\n")

sum_path = os.path.join(OUT, "summary.tsv")
empty = dict(n_hsp=0, n_ctg=0, n_iv=0, qcov=0.0, hits="")
class_n = Counter()
with open(sum_path, "w", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(["phage_id", "host", "orig_contig", "orig_start", "orig_end", "qlen",
                "n_hsp_p95", "n_ctg_p95", "n_iv_p95", "qcov_p95", "hits_p95",
                "n_hsp_p99", "n_ctg_p99", "n_iv_p99", "qcov_p99", "hits_p99",
                "class"])
    for pid in sorted(query_map):
        m   = query_map[pid]
        s95 = st95.get(pid, empty)
        s99 = st99.get(pid, empty)
        cls = classify(s99, s95)
        class_n[cls] += 1
        w.writerow([
            pid, m["host"], m["contig"], m["start"], m["end"], m["qlen"],
            s95["n_hsp"], s95["n_ctg"], s95["n_iv"], f"{s95['qcov']:.4f}", s95["hits"],
            s99["n_hsp"], s99["n_ctg"], s99["n_iv"], f"{s99['qcov']:.4f}", s99["hits"],
            cls,
        ])

shutil.rmtree(TMP, ignore_errors=True)

print("[5] done")
print(f"    dropped.tsv            {len(dropped_rows)} rows")
print(f"    blast_hq.tsv           {len(hq_rows)} HSP")
print(f"    hits_p99.tsv           {len(rows99)} HSP")
print(f"    coords_p95.tsv         {len(coords95)} intervals")
print(f"    coords_p99.tsv         {len(coords99)} intervals")
print(f"    coordinate_active.tsv  {len(active_pids)} phages")
print(f"    summary.tsv            {len(query_map)} phages")
print("    class: " + "  ".join(f"{k}={class_n.get(k, 0)}" for k in
      ("intact", "split", "gapped", "partial", "p95_only", "low_quality")))
PY