#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

DEFAULT_REPORT = Path("host_check_report.tsv")
DEFAULT_SEQTODL = Path("seqtodl.filtered.list")
DEFAULT_SEQTODL_FALLBACK = Path("seqtodl.list")
DEFAULT_SRC_CLEANSEQ = Path("../cleanseq")
DEFAULT_OUT_CLEANSEQ = Path("cleanseq")
DEFAULT_RAWSEQ = Path("rawseq_data")
DEFAULT_TMP = Path("sra_tmp")
DEFAULT_OUT_REPORT = Path("prepare_reads_report.tsv")

SRA_URL_TMPL = "https://sra-pub-run-odp.s3.amazonaws.com/sra/{acc}/{acc}"
MIN_SRA_BYTES = 1 * 1024 * 1024
MIN_FASTQ_BYTES = 1 * 1024 * 1024

TRUE_SET = {"1", "true", "t", "yes", "y"}

R1_PATTERNS = (
    "{acc}_1_clean.fastq.gz",
    "{acc}_R1_clean.fastq.gz",
    "{acc}_1.fastq.gz",
    "{acc}_R1.fastq.gz",
)
R2_PATTERNS = (
    "{acc}_2_clean.fastq.gz",
    "{acc}_R2_clean.fastq.gz",
    "{acc}_2.fastq.gz",
    "{acc}_R2.fastq.gz",
)

LOG = logging.getLogger("prepare_reads")


def is_true(v: object) -> bool:
    return str(v or "").strip().lower() in TRUE_SET


def read_tsv(path: Path) -> List[Dict[str, str]]:
    if not path.is_file():
        raise FileNotFoundError(f"File not found: {path}")
    with path.open(encoding="utf-8-sig", newline="") as h:
        return list(csv.DictReader(h, delimiter="\t"))


def load_url_map(*lists: Path) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for p in lists:
        if not p.is_file():
            continue
        for line in p.read_text(encoding="utf-8").splitlines():
            url = line.strip()
            if not url or url.startswith("#"):
                continue
            acc = url.rstrip("/").split("/")[-1].split("?")[0]
            if acc:
                out[acc.upper()] = url
    return out


def find_pe(acc: str, folder: Path) -> Tuple[Optional[Path], Optional[Path]]:
    r1 = next((folder / pat.format(acc=acc) for pat in R1_PATTERNS
               if (folder / pat.format(acc=acc)).is_file()), None)
    r2 = next((folder / pat.format(acc=acc) for pat in R2_PATTERNS
               if (folder / pat.format(acc=acc)).is_file()), None)
    return r1, r2


def ensure_symlink(src: Path, dest: Path, dry: bool) -> str:
    src = src.resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_symlink() or dest.exists():
        try:
            if dest.resolve() == src:
                return "exists"
        except FileNotFoundError:
            pass
        if dest.is_symlink():
            if dry:
                return "would_replace"
            dest.unlink()
        else:
            raise FileExistsError(f"Refusing to overwrite regular file: {dest}")
    if dry:
        return "would_create"
    dest.symlink_to(src)
    return "created"


def looks_like_sra(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size < MIN_SRA_BYTES:
        return False
    with path.open("rb") as h:
        head = h.read(64)
    if not head or head[:1] in (b"<", b"{", b"["):
        return False
    if head.lstrip().lower().startswith((b"<!doctype", b"<html", b"<?xml")):
        return False
    return True


def which_or_die(name: str) -> str:
    p = shutil.which(name)
    if not p:
        raise RuntimeError(f"Not found in PATH: {name}")
    return p


def run_cmd(cmd: List[str], dry: bool, cwd: Optional[Path] = None) -> int:
    LOG.info("$ %s", " ".join(cmd))
    if dry:
        return 0
    proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None)
    return proc.returncode


def collect_jobs(
    report_path: Path,
    url_map: Dict[str, str],
    src_clean: Path,
) -> List[dict]:
    rows = read_tsv(report_path)
    if not rows:
        raise RuntimeError(f"Empty report: {report_path}")

    jobs: Dict[str, dict] = {}
    for r in rows:
        acc = (r.get("sra") or "").strip()
        if not acc:
            continue
        key = acc.upper()
        url = (r.get("download_url") or "").strip() or url_map.get(key) or SRA_URL_TMPL.format(acc=acc)
        r1, r2 = find_pe(acc, src_clean)
        job = {
            "host": (r.get("host") or "").strip(),
            "sra": acc,
            "type": (r.get("type") or "").strip(),
            "keep": is_true(r.get("keep")),
            "by_sra_meta": is_true(r.get("in_illumina_metadata_by_sra")),
            "by_sra_diag": is_true(r.get("in_diagnostic_by_sra")),
            "url": url,
            "src_r1": r1,
            "src_r2": r2,
        }
        if key in jobs:
            old = jobs[key]["host"]
            if job["host"] and job["host"] not in old.split(";"):
                jobs[key]["host"] = f"{old};{job['host']}"
            continue
        jobs[key] = job
    return list(jobs.values())


def link_existing(job: dict, out_clean: Path, dry: bool) -> dict:
    acc = job["sra"]
    r1, r2 = job["src_r1"], job["src_r2"]
    rec = {
        **{k: job[k] for k in ("host", "sra", "type", "by_sra_meta", "by_sra_diag", "url")},
        "action": "link",
        "status": "",
        "dest_r1": "",
        "dest_r2": "",
        "message": "",
    }
    try:
        d1 = out_clean / r1.name
        d2 = out_clean / r2.name
        s1 = ensure_symlink(r1, d1, dry)
        s2 = ensure_symlink(r2, d2, dry)
        rec["dest_r1"] = str(d1)
        rec["dest_r2"] = str(d2)
        rec["status"] = "ok"
        rec["message"] = f"R1={s1};R2={s2}"
        LOG.info("[link] %s -> %s (%s, %s)", acc, out_clean, s1, s2)
    except Exception as e:
        rec["status"] = "fail"
        rec["message"] = str(e)
        LOG.error("[link] %s %s", acc, e)
    return rec


def wget_sra(url: str, dest: Path, wget: str, dry: bool) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".partial")
    if dest.is_file() and looks_like_sra(dest):
        LOG.info("[wget] %s exists, skip", dest.name)
        return
    if dest.is_file() and not looks_like_sra(dest):
        LOG.warning("[wget] %s invalid, removing", dest)
        if not dry:
            dest.unlink()
    cmd = [
        wget, "-c",
        "-O", str(tmp),
        url,
    ]
    rc = run_cmd(cmd, dry)
    if dry:
        return
    if rc != 0:
        raise RuntimeError(f"wget exit {rc}: {url}")
    if not looks_like_sra(tmp):
        head = tmp.read_bytes()[:80] if tmp.is_file() else b""
        raise RuntimeError(
            f"Downloaded file is not SRA: {tmp} size={tmp.stat().st_size if tmp.is_file() else 0} head={head!r}"
        )
    tmp.replace(dest)


def convert_sra(
    sra_path: Path,
    rawseq: Path,
    tmp_root: Path,
    acc: str,
    threads: int,
    fasterq: str,
    pigz: Optional[str],
    dry: bool,
) -> Tuple[Path, Path]:
    out1 = rawseq / f"{acc}_1.fastq.gz"
    out2 = rawseq / f"{acc}_2.fastq.gz"
    if (
        out1.is_file() and out2.is_file()
        and out1.stat().st_size >= MIN_FASTQ_BYTES
        and out2.stat().st_size >= MIN_FASTQ_BYTES
    ):
        LOG.info("[dump] %s FASTQ exists, skip", acc)
        return out1, out2

    tmpdir = tmp_root / acc
    if not dry:
        tmpdir.mkdir(parents=True, exist_ok=True)
        for leftover in rawseq.glob(f"{acc}_*.fastq"):
            leftover.unlink()

    cmd = [
        fasterq,
        "--split-files",
        "-e", str(threads),
        "--temp", str(tmpdir),
        "--outdir", str(rawseq),
        str(sra_path),
    ]
    rc = run_cmd(cmd, dry)
    if rc != 0:
        raise RuntimeError(f"fasterq-dump exit {rc}: {sra_path}")
    if dry:
        return out1, out2

    raw1 = rawseq / f"{acc}_1.fastq"
    raw2 = rawseq / f"{acc}_2.fastq"
    if not raw1.is_file() or not raw2.is_file():
        found = sorted(p.name for p in rawseq.glob(f"{acc}*"))
        raise RuntimeError(f"fasterq-dump produced no paired FASTQ: {found}")

    compressor = [pigz, "-p", str(threads), "-f"] if pigz else ["gzip", "-f"]
    rc = run_cmd(compressor + [str(raw1), str(raw2)], dry=False)
    if rc != 0:
        raise RuntimeError(f"Compression failed: {rc}")
    if not out1.is_file() or not out2.is_file():
        raise RuntimeError(f"Missing compressed FASTQ: {out1.name} / {out2.name}")
    shutil.rmtree(tmpdir, ignore_errors=True)
    return out1, out2


def download_and_convert(
    job: dict,
    rawseq: Path,
    tmp_root: Path,
    threads: int,
    tools: dict,
    dry: bool,
) -> dict:
    acc = job["sra"]
    rec = {
        **{k: job[k] for k in ("host", "sra", "type", "by_sra_meta", "by_sra_diag", "url")},
        "action": "download+convert",
        "status": "",
        "dest_r1": "",
        "dest_r2": "",
        "message": "",
    }
    sra_path = rawseq / f"{acc}.sra"
    try:
        wget_sra(job["url"], sra_path, tools["wget"], dry)
        r1, r2 = convert_sra(
            sra_path, rawseq, tmp_root, acc, threads,
            tools["fasterq-dump"], tools.get("pigz"), dry,
        )
        rec["dest_r1"] = str(r1)
        rec["dest_r2"] = str(r2)
        rec["status"] = "ok" if not dry else "dry-run"
        rec["message"] = f"sra={sra_path}"
        LOG.info("[done] %s %s %s", acc, r1.name, r2.name)
    except Exception as e:
        rec["status"] = "fail"
        rec["message"] = str(e)
        LOG.error("[fail] %s %s", acc, e)
    return rec


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Link existing clean reads or download and convert missing SRA.")
    p.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    p.add_argument("--seqtodl", type=Path, default=DEFAULT_SEQTODL)
    p.add_argument("--src-cleanseq", type=Path, default=DEFAULT_SRC_CLEANSEQ,
                   help="Existing clean paired-read directory")
    p.add_argument("--out-cleanseq", type=Path, default=DEFAULT_OUT_CLEANSEQ,
                   help="Symlink output directory")
    p.add_argument("--rawseq-data", type=Path, default=DEFAULT_RAWSEQ,
                   help="Download and conversion directory")
    p.add_argument("--tmp", type=Path, default=DEFAULT_TMP)
    p.add_argument("--out-report", type=Path, default=DEFAULT_OUT_REPORT)
    p.add_argument("--threads", type=int, default=18)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--only-link", action="store_true", help="Only create symlinks")
    p.add_argument("--only-download", action="store_true", help="Only download and convert")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s  %(message)s",
        datefmt="%H:%M:%S",
    )

    src_clean = args.src_cleanseq.resolve()
    out_clean = args.out_cleanseq
    rawseq = args.rawseq_data
    tmp_root = args.tmp

    LOG.info("report       = %s", args.report)
    LOG.info("src_cleanseq = %s", src_clean)
    LOG.info("out_cleanseq = %s", out_clean.resolve())
    LOG.info("rawseq_data  = %s", rawseq.resolve())
    LOG.info("dry_run      = %s", args.dry_run)

    url_map = load_url_map(args.seqtodl, DEFAULT_SEQTODL_FALLBACK)
    jobs = collect_jobs(args.report, url_map, src_clean)
    if not jobs:
        LOG.error("No valid SRA in report")
        return 2

    link_jobs = [j for j in jobs if j["src_r1"] and j["src_r2"]]
    dl_jobs = [j for j in jobs if not (j["src_r1"] and j["src_r2"])]

    LOG.info("grouping by %s", src_clean)
    LOG.info("link %d: %s", len(link_jobs), [j["sra"] for j in link_jobs])
    LOG.info("download %d: %s", len(dl_jobs), [j["sra"] for j in dl_jobs])
    for j in dl_jobs:
        missing = []
        if not j["src_r1"]:
            missing.append("R1")
        if not j["src_r2"]:
            missing.append("R2")
        LOG.info("  %s %s missing %s url=%s", j["sra"], j["host"], "+".join(missing), j["url"])

    tools = {}
    if dl_jobs and not args.only_link:
        tools["wget"] = which_or_die("wget")
        tools["fasterq-dump"] = which_or_die("fasterq-dump")
        tools["pigz"] = shutil.which("pigz")
        if not tools["pigz"]:
            which_or_die("gzip")
            LOG.warning("pigz not found; using gzip")

    if not args.dry_run:
        out_clean.mkdir(parents=True, exist_ok=True)
        rawseq.mkdir(parents=True, exist_ok=True)
        tmp_root.mkdir(parents=True, exist_ok=True)

    records: List[dict] = []

    if not args.only_download:
        for j in link_jobs:
            records.append(link_existing(j, out_clean, args.dry_run))

    if not args.only_link:
        for j in dl_jobs:
            records.append(download_and_convert(
                j, rawseq, tmp_root, args.threads, tools, args.dry_run,
            ))

    fields = [
        "host", "sra", "type", "by_sra_meta", "by_sra_diag",
        "action", "status", "dest_r1", "dest_r2", "url", "message",
    ]
    if not args.dry_run:
        with args.out_report.open("w", encoding="utf-8", newline="") as h:
            w = csv.DictWriter(h, fieldnames=fields, delimiter="\t", extrasaction="ignore")
            w.writeheader()
            w.writerows(records)
        LOG.info("report -> %s", args.out_report.resolve())

    n_ok = sum(1 for r in records if r["status"] in {"ok", "dry-run"})
    n_fail = sum(1 for r in records if r["status"] == "fail")
    LOG.info("done ok=%d fail=%d total=%d", n_ok, n_fail, len(records))
    for r in records:
        LOG.info("  %-18s %-16s %-6s %s", r["sra"], r["action"], r["status"], r["message"])
    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(main())