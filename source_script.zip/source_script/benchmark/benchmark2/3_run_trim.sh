in=$1
mkdir -p trim_log  
for data in $in/*_1.fastq; do
    samplename=$(basename "$data" _1.fastq)
    name1="$in/${samplename}_1.fastq"      
    name2="$in/${samplename}_2.fastq"      

    out_1_paired="${samplename}_1_clean.fastq.gz"
    out_1_unpaired="${samplename}_1_unpaired.fastq.gz"
    out_2_paired="${samplename}_2_clean.fastq.gz"
    out_2_unpaired="${samplename}_2_unpaired.fastq.gz"
    out_merged_unpaired="${samplename}_unpaired_clean.fastq.gz"    
    echo "Processing: $samplename"
    echo "Input files: $name1, $name2"   
    # trim
    trimmomatic PE -threads 24 -phred33 -summary trim_log/"${samplename}_summary" \
        "$name1" "$name2" \
        "$out_1_paired" "$out_1_unpaired" \
        "$out_2_paired" "$out_2_unpaired" \
        SLIDINGWINDOW:4:25 MINLEN:100
done
