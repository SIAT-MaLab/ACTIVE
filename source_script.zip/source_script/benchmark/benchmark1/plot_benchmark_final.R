suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(stringr)
  library(ggplot2)
  library(patchwork)
  library(scales)
  library(purrr)
  library(pROC)
  library(PRROC)
  library(tibble)
})

META_FILE          <- "source_metadata_toactive_illumina.tsv"
SPA_PRECISE_CSV    <- "spa_out_shared/activity_results/all_active_precise_results_illumina.csv"
SPA_SENSITIVE_CSV  <- "spa_out_shared/activity_results/all_active_sensitive_results_illumina.csv"
PROP_DIR           <- "propagate_from_spa"
PROP_FALLBACK_TSV  <- "propagate_from_spa/all_propagate_illumina.tsv"

PT_FULL_TSV        <- "prophage_tracer/prophage_tracer_coordinates_full.tsv"
PT_STRICT_TSV      <- "prophage_tracer/prophage_tracer_coordinates_strict.tsv"
MVIRS_TSV          <- "mvirs/prophage_coordinates.tsv"

OVERLAP_CUTOFF     <- 0.5
SPA_EFFECT_THR     <- 0.8

OUT_CALLABLE_META  <- "callable_source_metadata.tsv"
OUT_DIAG_WIDE      <- "all_samples_diagnostic_wide.tsv"
OUT_METRICS        <- "comprehensive_benchmark_metrics.tsv"
OUT_PDF            <- "benchmark_evaluation_results.pdf"
OUT_PNG            <- "benchmark_evaluation_results.png"
OUT_PDF_SPA        <- "benchmark_evaluation_spa_only_ROC_PR.pdf"
OUT_PNG_SPA        <- "benchmark_evaluation_spa_only_ROC_PR.png"

METHOD_COLORS <- c(
  "SPA (Precise)"              = "#34666b",
  "SPA (Sensitive)"            = "#7abbce",
  "PropagAtE (Conservative)"   = "#e68f9f",
  "ProphageTracer (Full)"      = "#5b8c5a",
  "ProphageTracer (Strict)"    = "#8fbc8f",
  "mVIRs"                      = "#c4a35a"
)

# ==============================================================================
# 1. Ground Truth
# ==============================================================================
cat(">>> [1] Ground Truth metadata\n")
meta_raw <- read_tsv(META_FILE, col_types = cols(.default = "c"), name_repair = "unique")

meta_df <- meta_raw %>%
  rename_with(~ "host_species", matches("^prophage_host\\.\\.\\.12$|^prophage_host$")) %>%
  rename_with(~ "genome_accession", matches("^prophage_host\\.\\.\\.14$")) %>%
  mutate(
    start_clean = as.numeric(gsub(",", "", `prophage start`)),
    stop_clean  = as.numeric(gsub(",", "", `prophage stop`)),
    p_start     = pmin(start_clean, stop_clean),
    p_stop      = pmax(start_clean, stop_clean),
    sample_key  = ifelse(
      !is.na(reads_accession) & reads_accession != "" & reads_accession != "-",
      reads_accession, sample_id
    ),
    truth       = tolower(str_trim(expected)),
    uid         = paste(sample_key, contig_1, p_start, p_stop, sep = "__")
  ) %>%
  filter(truth %in% c("active", "dormant")) %>%
  select(
    uid, sample_key, contig_1, p_start, p_stop, prophage_name,
    host_species, truth, paper_source,
    sample_id, reads_accession
  ) %>%
  distinct(uid, .keep_all = TRUE)

cat(sprintf(">>> GT rows: %d\n", nrow(meta_df)))

# ==============================================================================
# 2. SPA
# ==============================================================================
cat(">>> [2] SPA Precise / Sensitive\n")
spa_precise_raw <- read_csv(SPA_PRECISE_CSV, col_types = cols(.default = "c"), show_col_types = FALSE)
spa_precise_df <- spa_precise_raw %>%
  mutate(
    coords = str_extract(Phage_File, "(?<=phage_depth_).*(?=\\.txt)"),
    start  = as.numeric(str_extract(coords, "(?<=_)\\d+(?=\\_\\d+$)")),
    stop   = as.numeric(str_extract(coords, "\\d+$")),
    contig = str_remove(coords, "_\\d+_\\d+$"),
    p_start = pmin(start, stop),
    p_stop  = pmax(start, stop),
    uid     = paste(Folder, contig, p_start, p_stop, sep = "__"),
    Delta_Mean_num = suppressWarnings(as.numeric(Delta_Mean)),
    spa_precise_qc = ifelse(Significant == "Coverage failed" | is.na(Significant), "FAIL", "PASS"),
    spa_precise_sig = !is.na(Significant) & Significant == "Yes",
    spa_precise_pred = case_when(
      spa_precise_qc == "FAIL" ~ "uncal",
      spa_precise_sig & !is.na(Delta_Mean_num) & Delta_Mean_num >= SPA_EFFECT_THR ~ "active",
      TRUE ~ "dormant"
    )
  ) %>%
  select(uid, spa_precise_qc, spa_precise_sig, Delta_Mean = Delta_Mean_num, spa_precise_pred) %>%
  distinct(uid, .keep_all = TRUE)

spa_sensitive_raw <- read_csv(SPA_SENSITIVE_CSV, col_types = cols(.default = "c"), show_col_types = FALSE)
spa_sensitive_df <- spa_sensitive_raw %>%
  mutate(
    coords = str_extract(Phage_File, "(?<=phage_depth_).*(?=\\.txt)"),
    start  = as.numeric(str_extract(coords, "(?<=_)\\d+(?=\\_\\d+$)")),
    stop   = as.numeric(str_extract(coords, "\\d+$")),
    contig = str_remove(coords, "_\\d+_\\d+$"),
    p_start = pmin(start, stop),
    p_stop  = pmax(start, stop),
    uid     = paste(Folder, contig, p_start, p_stop, sep = "__"),
    Effect_Size_num = suppressWarnings(as.numeric(Effect_Size_Value)),
    spa_sensitive_qc = ifelse(Significant == "Coverage failed" | is.na(Significant), "FAIL", "PASS"),
    spa_sensitive_sig = !is.na(Significant) & Significant == "Yes",
    spa_sensitive_pred = case_when(
      spa_sensitive_qc == "FAIL" ~ "uncal",
      spa_sensitive_sig & !is.na(Effect_Size_num) & Effect_Size_num >= SPA_EFFECT_THR ~ "active",
      TRUE ~ "dormant"
    )
  ) %>%
  select(uid, spa_sensitive_qc, spa_sensitive_sig, Effect_Size = Effect_Size_num, spa_sensitive_pred) %>%
  distinct(uid, .keep_all = TRUE)

# ==============================================================================
# 3. PropagAtE
# ==============================================================================
cat(">>> [3] PropagAtE\n")
prop_files <- list.files(PROP_DIR, pattern = "^propagate_results_.*\\.tsv$",
                         recursive = TRUE, full.names = TRUE)
prop_files <- prop_files[!grepl("all_propagate_results\\.tsv", prop_files)]
if (length(prop_files) > 0) {
  propagate_raw <- map_dfr(prop_files, function(f) {
    s_key <- str_extract(basename(f), "(?<=propagate_results_)[^._]+")
    read_tsv(f, col_types = cols(.default = "c"), show_col_types = FALSE) %>%
      mutate(sample_key = s_key)
  })
} else {
  propagate_raw <- read_tsv(PROP_FALLBACK_TSV, col_types = cols(.default = "c"), show_col_types = FALSE)
}

propagate_df <- propagate_raw %>%
  filter(!grepl("fakepp", prophage)) %>%
  inner_join(
    meta_df %>% select(uid, sample_key, prophage_name),
    by = c("sample_key" = "sample_key", "prophage" = "prophage_name")
  ) %>%
  mutate(
    host_len_num    = suppressWarnings(as.numeric(host_len)),
    CohenD_num      = suppressWarnings(as.numeric(CohenD)),
    ratio_num       = suppressWarnings(as.numeric(`prophage-host_ratio`)),
    cov_breadth_num = suppressWarnings(as.numeric(prophage_cov_breadth)),
    propagate_qc = ifelse(
      is.na(host_len_num) | host_len_num == 0 |
        is.na(cov_breadth_num) | cov_breadth_num < 0.75, "FAIL", "PASS"
    ),
    propagate_pred = case_when(
      propagate_qc == "FAIL" ~ "uncal",
      tolower(active) == "active" ~ "active",
      TRUE ~ "dormant"
    ),
    propagate_cons_pred = case_when(
      propagate_qc == "FAIL" ~ "uncal",
      !is.na(CohenD_num) & !is.na(ratio_num) & CohenD_num >= 0.7 & ratio_num >= 2 ~ "active",
      TRUE ~ "dormant"
    )
  ) %>%
  select(
    uid, host_len = host_len_num, CohenD = CohenD_num, propagate_ratio = ratio_num,
    prophage_cov_breadth = cov_breadth_num, propagate_qc,
    propagate_pred, propagate_cons_pred
  ) %>%
  distinct(uid, .keep_all = TRUE)

# ==============================================================================
# 4. Overlap-based callers: PT full / PT strict / mVIRs
# ==============================================================================
cat(">>> [4] ProphageTracer / mVIRs (overlap >= ", OVERLAP_CUTOFF, ")\n", sep = "")

clean_coord_num <- function(x) {
  suppressWarnings(as.numeric(gsub(",", "", str_trim(as.character(x)))))
}

read_pred_coords <- function(path) {
  if (!file.exists(path)) {
    warning("Missing prediction file: ", path)
    return(tibble(sample = character(), contig = character(),
                  start = numeric(), end = numeric()))
  }
  df <- read_tsv(path, col_types = cols(.default = "c"), show_col_types = FALSE)
  nm <- names(df)
  if (!"sample" %in% nm && "reads_accession" %in% nm) df <- rename(df, sample = reads_accession)
  if (!"end" %in% nm && "stop" %in% nm) df <- rename(df, end = stop)
  df %>%
    mutate(
      sample = str_trim(as.character(sample)),
      contig = str_trim(as.character(contig)),
      start  = clean_coord_num(start),
      end    = clean_coord_num(end),
      p_start = pmin(start, end),
      p_stop  = pmax(start, end)
    ) %>%
    filter(!is.na(sample), !is.na(contig), !is.na(p_start), !is.na(p_stop)) %>%
    select(sample, contig, p_start, p_stop)
}

overlap_predict <- function(meta_sub, pred_df, cutoff = OVERLAP_CUTOFF) {
  if (nrow(meta_sub) == 0) {
    return(tibble(uid = character(), pred = character(), detected = logical()))
  }
  pred_df <- pred_df %>%
    mutate(sample = str_trim(as.character(sample)), contig = str_trim(as.character(contig)))

  meta_sub %>%
    mutate(
      sample_key = str_trim(as.character(sample_key)),
      contig_1   = str_trim(as.character(contig_1)),
      m_len      = p_stop - p_start + 1
    ) %>%
    rowwise() %>%
    mutate(
      detected = {
        hits <- pred_df %>%
          filter(sample == sample_key, contig == contig_1)
        if (nrow(hits) == 0 || is.na(m_len) || m_len <= 0) {
          FALSE
        } else {
          ov <- pmax(0, pmin(p_stop, hits$p_stop) - pmax(p_start, hits$p_start) + 1)
          any((ov / m_len) >= cutoff, na.rm = TRUE)
        }
      },
      pred = ifelse(detected, "active", "dormant")
    ) %>%
    ungroup() %>%
    select(uid, pred, detected)
}

pt_full_pred   <- read_pred_coords(PT_FULL_TSV)
pt_strict_pred <- read_pred_coords(PT_STRICT_TSV)
mvirs_pred     <- read_pred_coords(MVIRS_TSV)

pt_full_all   <- overlap_predict(meta_df, pt_full_pred)   %>%
  rename(pt_full_pred = pred, pt_full_detected = detected)
pt_strict_all <- overlap_predict(meta_df, pt_strict_pred) %>%
  rename(pt_strict_pred = pred, pt_strict_detected = detected)
mvirs_all     <- overlap_predict(meta_df, mvirs_pred)     %>%
  rename(mvirs_pred = pred, mvirs_detected = detected)

# ==============================================================================
# 5. Master + callable + export callable meta
# ==============================================================================
cat(">>> [5] Master table / callable / metrics\n")
assign_status <- function(truth, pred, qc = "PASS") {
  case_when(
    !is.na(qc) & qc == "FAIL" ~ "QC_FAIL",
    is.na(pred) | pred == "uncal" ~ "QC_FAIL",
    truth == "active"  & pred == "active"  ~ "TP",
    truth == "dormant" & pred == "active"  ~ "FP",
    truth == "dormant" & pred == "dormant" ~ "TN",
    truth == "active"  & pred == "dormant" ~ "FN",
    TRUE ~ "QC_FAIL"
  )
}

master_df <- meta_df %>%
  left_join(spa_precise_df, by = "uid") %>%
  left_join(spa_sensitive_df, by = "uid") %>%
  left_join(propagate_df, by = "uid") %>%
  left_join(pt_full_all, by = "uid") %>%
  left_join(pt_strict_all, by = "uid") %>%
  left_join(mvirs_all, by = "uid") %>%
  mutate(
    pt_full_pred   = ifelse(is.na(pt_full_pred),   "dormant", pt_full_pred),
    pt_strict_pred = ifelse(is.na(pt_strict_pred), "dormant", pt_strict_pred),
    mvirs_pred     = ifelse(is.na(mvirs_pred),     "dormant", mvirs_pred),
    .record_id = row_number()
  )

all_samples_diagnostic_wide <- master_df %>%
  mutate(
    is_callable_intersection = (
      spa_precise_qc == "PASS" & spa_sensitive_qc == "PASS" & propagate_qc == "PASS"
    ),
    SPA_Precise_status    = assign_status(truth, spa_precise_pred, spa_precise_qc),
    SPA_Sensitive_status  = assign_status(truth, spa_sensitive_pred, spa_sensitive_qc),
    PropagAtE_status      = assign_status(truth, propagate_pred, propagate_qc),
    PropagAtE_Cons_status = assign_status(truth, propagate_cons_pred, propagate_qc),
    PT_Full_status        = assign_status(truth, pt_full_pred, "PASS"),
    PT_Strict_status      = assign_status(truth, pt_strict_pred, "PASS"),
    mVIRs_status          = assign_status(truth, mvirs_pred, "PASS")
  )

write_tsv(all_samples_diagnostic_wide, OUT_DIAG_WIDE, na = "NA")
cat(">>> Wrote ", OUT_DIAG_WIDE, " n=", nrow(all_samples_diagnostic_wide), "\n", sep = "")

callable_df <- all_samples_diagnostic_wide %>%
  filter(is_callable_intersection == TRUE)

callable_meta_out <- callable_df %>%
  transmute(
    uid,
    sample          = sample_key,
    sample_id,
    reads_accession,
    contig          = contig_1,
    `prophage start` = p_start,
    `prophage stop`  = p_stop,
    prophage_name,
    expected        = truth,
    host_species,
    paper_source
  )
write_tsv(callable_meta_out, OUT_CALLABLE_META, na = "NA")
cat(">>> Wrote ", OUT_CALLABLE_META, " n=", nrow(callable_meta_out), "\n", sep = "")

calc_metrics_from_status <- function(df, status_col, method_name, scope_name,
                                     qc_col = NULL) {
  total_n <- nrow(df)
  if (!is.null(qc_col) && qc_col %in% names(df)) {
    qc_pass_n <- sum(df[[qc_col]] == "PASS", na.rm = TRUE)
  } else {
    qc_pass_n <- total_n
  }
  qc_fail_n <- total_n - qc_pass_n

  tp <- sum(df[[status_col]] == "TP", na.rm = TRUE)
  fp <- sum(df[[status_col]] == "FP", na.rm = TRUE)
  tn <- sum(df[[status_col]] == "TN", na.rm = TRUE)
  fn <- sum(df[[status_col]] == "FN", na.rm = TRUE)
  called_n <- tp + fp + tn + fn

  sen <- ifelse((tp + fn) > 0, tp / (tp + fn), NA_real_)
  spe <- ifelse((tn + fp) > 0, tn / (tn + fp), NA_real_)
  ppv <- ifelse((tp + fp) > 0, tp / (tp + fp), NA_real_)
  npv <- ifelse((tn + fn) > 0, tn / (tn + fn), NA_real_)
  acc <- ifelse(called_n > 0, (tp + tn) / called_n, NA_real_)
  f1  <- ifelse(!is.na(ppv) & !is.na(sen) & (ppv + sen) > 0, 2 * ppv * sen / (ppv + sen), NA_real_)
  mcc_den <- sqrt(as.numeric(tp + fp) * as.numeric(tp + fn) * as.numeric(tn + fp) * as.numeric(tn + fn))
  mcc <- ifelse(!is.na(mcc_den) & mcc_den > 0, ((tp * tn) - (fp * fn)) / mcc_den, NA_real_)

  tibble(
    Dataset = scope_name, Method = method_name,
    Total_Samples = total_n, QC_PASS_Count = qc_pass_n, QC_FAIL_Count = qc_fail_n,
    Coverage_Rate = ifelse(total_n > 0, qc_pass_n / total_n, NA_real_),
    Sensitivity = sen, Specificity = spe, Precision = ppv, NPV = npv,
    Accuracy = acc, F1_Score = f1, MCC = mcc,
    TP = tp, FP = fp, TN = tn, FN = fn
  )
}

comprehensive_metrics <- bind_rows(
  calc_metrics_from_status(callable_df, "SPA_Precise_status",    "SPA (Precise)",            "Callable Intersection", "spa_precise_qc"),
  calc_metrics_from_status(callable_df, "SPA_Sensitive_status",  "SPA (Sensitive)",          "Callable Intersection", "spa_sensitive_qc"),
  calc_metrics_from_status(callable_df, "PropagAtE_Cons_status", "PropagAtE (Conservative)", "Callable Intersection", "propagate_qc"),
  calc_metrics_from_status(callable_df, "PT_Full_status",        "ProphageTracer (Full)",    "Callable Intersection", NULL),
  calc_metrics_from_status(callable_df, "PT_Strict_status",      "ProphageTracer (Strict)",  "Callable Intersection", NULL),
  calc_metrics_from_status(callable_df, "mVIRs_status",          "mVIRs",                    "Callable Intersection", NULL),
  calc_metrics_from_status(all_samples_diagnostic_wide, "SPA_Precise_status",    "SPA (Precise)",            "All Samples", "spa_precise_qc"),
  calc_metrics_from_status(all_samples_diagnostic_wide, "SPA_Sensitive_status",  "SPA (Sensitive)",          "All Samples", "spa_sensitive_qc"),
  calc_metrics_from_status(all_samples_diagnostic_wide, "PropagAtE_Cons_status", "PropagAtE (Conservative)", "All Samples", "propagate_qc"),
  calc_metrics_from_status(all_samples_diagnostic_wide, "PT_Full_status",        "ProphageTracer (Full)",    "All Samples", NULL),
  calc_metrics_from_status(all_samples_diagnostic_wide, "PT_Strict_status",      "ProphageTracer (Strict)",  "All Samples", NULL),
  calc_metrics_from_status(all_samples_diagnostic_wide, "mVIRs_status",          "mVIRs",                    "All Samples", NULL)
)

metrics_callable_print <- comprehensive_metrics %>%
  filter(Dataset == "Callable Intersection") %>%
  select(-Coverage_Rate) %>%
  mutate(across(where(is.double), ~ round(.x, 4)))

write_tsv(
  comprehensive_metrics %>% mutate(across(where(is.double), ~ round(.x, 4))),
  OUT_METRICS, na = "NA"
)
cat("\n===== Callable Intersection metrics (no Coverage) =====\n")
print(as.data.frame(metrics_callable_print), digits = 4)

# ==============================================================================
# 6. A2-A7 threshold scan + A8 extended bar chart
# ==============================================================================
cat(">>> [6] Curves / bars / ROC-PR\n")
theme_pub <- theme_classic(base_size = 11) +
  theme(
    axis.text = element_text(color = "black", size = 10),
    axis.title = element_text(face = "bold", size = 11),
    legend.title = element_text(face = "bold", size = 9),
    legend.text = element_text(size = 8),
    plot.title = element_text(face = "bold", size = 12, hjust = 0),
    plot.tag = element_text(face = "bold", size = 14)
  )

thresholds <- seq(0, 1, by = 0.001)

compute_metric_curve <- function(score, sig, truth) {
  score <- as.numeric(score)
  map_dfr(thresholds, function(t) {
    pred <- ifelse(sig & !is.na(score) & score >= t, "active", "dormant")
    tp <- sum(truth == "active"  & pred == "active",  na.rm = TRUE)
    fp <- sum(truth == "dormant" & pred == "active",  na.rm = TRUE)
    tn <- sum(truth == "dormant" & pred == "dormant", na.rm = TRUE)
    fn <- sum(truth == "active"  & pred == "dormant", na.rm = TRUE)
    sen <- if ((tp + fn) > 0) tp / (tp + fn) else NA_real_
    spe <- if ((tn + fp) > 0) tn / (tn + fp) else NA_real_
    ppv <- if ((tp + fp) > 0) tp / (tp + fp) else NA_real_
    acc <- if ((tp + fp + tn + fn) > 0) (tp + tn) / (tp + fp + tn + fn) else NA_real_
    f1  <- if (!is.na(ppv) & !is.na(sen) & (ppv + sen) > 0) 2 * ppv * sen / (ppv + sen) else NA_real_
    den <- sqrt(as.numeric(tp + fp) * as.numeric(tp + fn) * as.numeric(tn + fp) * as.numeric(tn + fn))
    mcc <- if (!is.na(den) & den > 0) ((tp * tn) - (fp * fn)) / den else NA_real_
    tibble(Threshold = t, Sensitivity = sen, Specificity = spe,
           Precision = ppv, Accuracy = acc, F1_Score = f1, MCC = mcc)
  })
}

curve_precise   <- compute_metric_curve(callable_df$Delta_Mean,  callable_df$spa_precise_sig,   callable_df$truth) %>%
  mutate(Method = "SPA (Precise)")
curve_sensitive <- compute_metric_curve(callable_df$Effect_Size, callable_df$spa_sensitive_sig, callable_df$truth) %>%
  mutate(Method = "SPA (Sensitive)")

spa_curves_long <- bind_rows(curve_precise, curve_sensitive) %>%
  pivot_longer(cols = -c(Threshold, Method), names_to = "Metric", values_to = "Value")

prop_ref_lines <- comprehensive_metrics %>%
  filter(Dataset == "Callable Intersection", grepl("PropagAtE", Method)) %>%
  select(Mode = Method, Sensitivity, Specificity, Precision, Accuracy, F1_Score, MCC) %>%
  pivot_longer(cols = -Mode, names_to = "Metric", values_to = "Value") %>%
  filter(!is.na(Value))

make_metric_panel <- function(metric_name, tag_label,
                              y_lim = c(0, 1.05), y_breaks = seq(0, 1, 0.25)) {
  cdat    <- spa_curves_long %>% filter(Metric == metric_name)
  ref_dat <- prop_ref_lines  %>% filter(Metric == metric_name)
  pretty  <- switch(metric_name, "F1_Score" = "F1 Score", metric_name)

  ggplot(cdat, aes(x = Threshold, y = Value)) +
    geom_line(aes(color = Method), linewidth = 0.7, na.rm = TRUE) +
    geom_hline(data = ref_dat, aes(yintercept = Value, color = Mode, linetype = Mode),
               linewidth = 0.6, na.rm = TRUE) +
    geom_vline(xintercept = 0.47, linetype = "longdash", color = "gray30", linewidth = 0.4) +
    geom_vline(xintercept = 0.80, linetype = "dashed",  color = "gray30", linewidth = 0.4) +
    annotate("text", x = 0.47, y = max(y_lim) - 0.03, label = "0.47", size = 2.3, color = "gray25") +
    annotate("text", x = 0.80, y = max(y_lim) - 0.03, label = "0.80", size = 2.3, color = "gray25") +
    scale_color_manual(
      values = METHOD_COLORS, name = "Method",
      breaks = c("SPA (Precise)", "SPA (Sensitive)", "PropagAtE (Conservative)")
    ) +
    scale_linetype_manual(
      values = c("PropagAtE (Conservative)" = "solid"),
      name = "PropagAtE\ncall rule"
    ) +
    scale_x_continuous(breaks = seq(0, 1, 0.25)) +
    scale_y_continuous(breaks = y_breaks) +
    coord_cartesian(xlim = c(0, 1), ylim = y_lim) +
    labs(tag = tag_label, title = pretty, x = "Delta / Effect size threshold", y = pretty) +
    theme_pub +
    theme(plot.title = element_text(size = 10.5))
}

p_sen <- make_metric_panel("Sensitivity", "A2")
p_spe <- make_metric_panel("Specificity", "A3")
p_ppv <- make_metric_panel("Precision",   "A4")
p_f1  <- make_metric_panel("F1_Score",    "A5")
p_mcc <- make_metric_panel("MCC", "A6", y_lim = c(-0.25, 1.05), y_breaks = seq(-0.25, 1, 0.25))
p_acc <- make_metric_panel("Accuracy", "A7")

bar08_methods <- c(
  "SPA (Precise)", "SPA (Sensitive)",
  "PropagAtE (Conservative)",
  "ProphageTracer (Full)", "ProphageTracer (Strict)", "mVIRs"
)

bar08_data <- comprehensive_metrics %>%
  filter(Dataset == "Callable Intersection", Method %in% bar08_methods) %>%
  select(Method, Sensitivity, Specificity, Precision, Accuracy, F1_Score, MCC) %>%
  pivot_longer(cols = -Method, names_to = "Metric", values_to = "Value") %>%
  filter(!is.na(Value)) %>%
  mutate(
    Metric = factor(
      Metric,
      levels = c("Sensitivity", "Specificity", "Precision", "Accuracy", "F1_Score", "MCC"),
      labels = c("Sensitivity", "Specificity", "Precision", "Accuracy", "F1 Score", "MCC")
    ),
    Method = factor(Method, levels = bar08_methods)
  )

y_min_bar  <- min(0, bar08_data$Value, na.rm = TRUE)
y_breaks_b <- if (y_min_bar < 0) c(y_min_bar, seq(0, 1, 0.25)) else seq(0, 1, 0.25)

p_bar08 <- ggplot(bar08_data, aes(x = Metric, y = Value, fill = Method)) +
  geom_bar(stat = "identity", position = position_dodge(0.82), width = 0.75,
           color = "black", linewidth = 0.25) +
  geom_text(aes(label = sprintf("%.2f", Value)),
            position = position_dodge(0.82), vjust = -0.35, size = 1.9) +
  scale_fill_manual(values = METHOD_COLORS, name = "Method", breaks = bar08_methods) +
  scale_y_continuous(limits = c(y_min_bar, 1.18), breaks = y_breaks_b) +
  labs(
    tag = "A8",
    title = "Metrics @ SPA thr=0.8 + fixed callers (Callable Set)",
    x = NULL, y = "Metric Value"
  ) +
  theme_pub +
  theme(plot.title = element_text(size = 11), legend.key.size = unit(0.35, "cm"))

# ==============================================================================
# 7. ROC / PR for SPA-only figure
# ==============================================================================
truth_binary_num <- ifelse(callable_df$truth == "active", 1, 0)

score_precise   <- ifelse(is.na(callable_df$Delta_Mean),  0, callable_df$Delta_Mean)
score_sensitive <- ifelse(is.na(callable_df$Effect_Size), 0, callable_df$Effect_Size)

roc_pr_one <- function(score, label_tool) {
  r <- roc(truth_binary_num, score, quiet = TRUE)
  p <- pr.curve(
    scores.class0 = score[truth_binary_num == 1],
    scores.class1 = score[truth_binary_num == 0],
    curve = TRUE
  )
  list(
    roc_df = tibble(
      FPR = 1 - r$specificities, TPR = r$sensitivities,
      Method = sprintf("%s (AUC = %.3f)", label_tool, as.numeric(auc(r))),
      Tool = label_tool
    ),
    pr_df = tibble(
      Recall = p$curve[, 1], Precision = p$curve[, 2],
      Method = sprintf("%s (AUC-PR = %.3f)", label_tool, p$auc.integral),
      Tool = label_tool
    )
  )
}

rp_prec <- roc_pr_one(score_precise,   "SPA (Precise)")
rp_sens <- roc_pr_one(score_sensitive, "SPA (Sensitive)")

df_roc_spa <- bind_rows(rp_prec$roc_df, rp_sens$roc_df)
df_pr_spa  <- bind_rows(rp_prec$pr_df,  rp_sens$pr_df)

make_roc <- function(df, tag, title) {
  ggplot(df, aes(x = FPR, y = TPR