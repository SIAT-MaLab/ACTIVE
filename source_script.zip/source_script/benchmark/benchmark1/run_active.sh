bash active_20260815.sh \
  -g references -s cleanseq -p GCA_019904235.1_coordinate.tsv \
  -o spa_GCA_019904235.1 -i tmp.log \
  -t 20 -r 20 -c

bash active_20260815.sh \
  -g references -s cleanseq -p GCA_019904235.1_coordinate.tsv \
  -o spa_GCA_019904235.1 -i tmp.log \
  -t 20 -r 20
echo "active-s-done"
