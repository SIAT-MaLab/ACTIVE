import pandas as pd

input_file = "source_metadata_toactive.tsv"
output_file = "propagate_coordinates.tsv"

columns = [
    "sample_id",
    "run_count",
    "sequencing_type",
    "expected",
    "reads_accession",
    "treatment",
    "start",
    "stop",
    "scaffold",
    "contig_2",
    "fragment",
    "prophage_host",
    "paper_source",
    "genome_id"
]

df = pd.read_csv(
    input_file,
    sep="\t",
    header=None,
    names=columns,
    dtype=str,
    keep_default_na=False
)

if len(df) > 0 and df.iloc[0]["sample_id"] == "sample_id":
    df = df.iloc[1:].copy()

df = df[df["sample_id"].str.strip() != ""].copy()

for col in ["start", "stop"]:
    df[col] = df[col].astype(str).str.replace(",", "", regex=False).str.strip()

try:
    df["start"] = pd.to_numeric(df["start"], errors="raise").astype(int)
    df["stop"] = pd.to_numeric(df["stop"], errors="raise").astype(int)
except ValueError as e:
    for col in ["start", "stop"]:
        bad = df[pd.to_numeric(df[col], errors="coerce").isna() & (df[col] != "")]
        if not bad.empty:
            print(f"Unparseable coordinates in column {col}, e.g.:")
            print(bad[["sample_id", col]].head(10).to_string(index=False))
    raise e

if (df["start"] < 1).any():
    raise ValueError("Found start coordinate < 1; please check the input file.")

if (df["stop"] < df["start"]).any():
    raise ValueError("Found stop < start; please check the input file.")

extracted = df["scaffold"].str.extract(r"^(.*)_(\d+)$")

if extracted.isna().any().any():
    bad_scaffolds = df.loc[
        extracted.isna().any(axis=1), "scaffold"
    ].unique()
    raise ValueError(
        "The following scaffolds cannot be parsed as genome_contigNumber:\n"
        + "\n".join(bad_scaffolds)
    )

df["_genome_prefix"] = extracted[0]
df["_contig_number"] = extracted[1].astype(int)

df["genome_id"] = df["genome_id"].str.strip()
df.loc[df["genome_id"] == "", "genome_id"] = pd.NA
df["genome_id"] = df["genome_id"].fillna(df["_genome_prefix"])

prefix_count = df.groupby("genome_id")["_genome_prefix"].nunique()
if (prefix_count > 1).any():
    bad_genomes = prefix_count[prefix_count > 1].index.tolist()
    raise ValueError(
        "The following genomes map to multiple scaffold prefixes; please check naming:\n"
        + "\n".join(bad_genomes)
    )

real_coordinates = df[
    ["scaffold", "fragment", "start", "stop"]
].drop_duplicates().copy()

genome_info = (
    df.groupby("genome_id", sort=False)
      .agg(
          genome_prefix=("_genome_prefix", "first"),
          max_contig=("_contig_number", "max")
      )
      .reset_index()
)

fake_coordinates = []

for _, row in genome_info.iterrows():
    genome_id = row["genome_id"]
    genome_prefix = row["genome_prefix"]
    max_contig = int(row["max_contig"])
    fake_coordinates.append({
        "scaffold": f"{genome_prefix}_{max_contig + 1}",
        "fragment": f"{genome_id}_fakepp",
        "start": 3000,
        "stop": 5000
    })

fake_coordinates = pd.DataFrame(
    fake_coordinates,
    columns=["scaffold", "fragment", "start", "stop"]
)

result = pd.concat([real_coordinates, fake_coordinates], ignore_index=True)

result.to_csv(output_file, sep="\t", index=False)

print(f"Generated: {output_file}")
print(f"Real prophage coordinates: {len(real_coordinates)}")
print(f"Pseudo coordinates: {len(fake_coordinates)}")
print(f"Total coordinates: {len(result)}")