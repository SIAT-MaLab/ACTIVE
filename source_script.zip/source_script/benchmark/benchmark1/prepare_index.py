from __future__ import annotations

import argparse
import csv
import re
import sys
from collections import OrderedDict
from pathlib import Path

DEFAULT_METADATA = Path("source_metadata_toactive.tsv")
DEFAULT_CLEANSEQ = Path("cleanseq")
DEFAULT_REFERENCES = Path("references")
DEFAULT_INDEX = Path("sample_ref_index.tsv")
DEFAULT_REPORT = Path("prepare_spa_inputs.report.tsv")
DEFAULT_MAPPING = Path("pacbio_merged_runs_mapping.tsv")

HAS_HEADER = True

SAMPLE_ID_COL = 0
PLATFORM_COL = 2
RUNS_COL = 4
REF_COL = -1

OLD_PACBIO_MARKERS = (
    "_clean_pacbio.fastq.gz",
    "_clean_pacbio.fq.gz",
    "_clean_pacbio.fastq",
    "_clean_pacbio.fq",
)

NEW_EXT_FROM_OLD = {
    "_clean_pacbio.fastq.gz": ".fastq.gz",
    "_clean_pacbio.fq.gz": ".fq.gz",
    "_clean_pacbio.fastq": ".fastq",
    "_clean_pacbio.fq": ".fq",
}

ILLUMINA_R1_SUFFIXES = (
    "_1_clean.fastq.gz",
    "_1_clean.fastq",
    "_1_clean.fq.gz",
    "_1_clean.fq",
)

ILLUMINA_R2_FROM_R1 = {
    "_1_clean.fastq.gz": "_2_clean.fastq.gz",
    "_1_clean.fastq": "_2_clean.fastq",
    "_1_clean.fq.gz": "_2_clean.fq.gz",
    "_1_clean.fq": "_2_clean.fq",
}

LR_TYPE_TO_SUFFIX = {
    "pbhifi": "pbhifi",
    "pacbio": "pacbio",
    "ont": "ont",
}


def die(msg: str, code: int = 1) -> None:
    print(f"Error: {msg}", file=sys.stderr)
    raise SystemExit(code)


def split_runs(run_field: str) -> list[str]:
    value = (run_field or "").strip()
    if value == "" or value.lower() in {"na", "nan", "none", "-"}:
        return []
    parts = [x.strip() for x in re.split(r"[\s,;|]+", value) if x.strip()]
    return list(dict.fromkeys(parts))


def detect_platform(raw: str) -> str:
    s = (raw or "").strip().casefold()
    if any(k in s for k in ("pbhifi", "hifi", "ccs")):
        return "pbhifi"
    if "pacbio" in s or s in {"pb", "clr"}:
        return "pacbio"
    if any(k in s for k in ("ont", "nanopore", "promethion", "minion", "gridion")):
        return "ont"
    if "illumina" in s:
        return "illumina"
    return "unknown"


def strip_known_lr_stem(name: str) -> str | None:
    stem = Path(name).name
    for old in OLD_PACBIO_MARKERS:
        if stem.endswith(old):
            return stem[: -len(old)]
    for lr in ("pbhifi", "pacbio", "ont"):
        for ext in (".fastq.gz", ".fq.gz", ".fastq", ".fq"):
            suf = f"_{lr}{ext}"
            if stem.endswith(suf):
                return stem[: -len(suf)]
    return None


def find_illumina_pair(cleanseq: Path, run_id: str):
    for r1_suf in ILLUMINA_R1_SUFFIXES:
        r1 = cleanseq / f"{run_id}{r1_suf}"
        if r1.is_file():
            r2 = cleanseq / f"{run_id}{ILLUMINA_R2_FROM_R1[r1_suf]}"
            return r1, r2
    return None, None


def find_existing_longread(cleanseq: Path, stem: str):
    for old in OLD_PACBIO_MARKERS:
        path = cleanseq / f"{stem}{old}"
        if path.is_file():
            return path, "old_pacbio"
    for kind in ("pbhifi", "pacbio", "ont"):
        for ext in (".fastq.gz", ".fq.gz", ".fastq", ".fq"):
            path = cleanseq / f"{stem}_{kind}{ext}"
            if path.is_file():
                return path, kind
    return None, None


def target_from_old(old_path: Path, lr_type: str) -> Path:
    name = old_path.name
    for old, ext in NEW_EXT_FROM_OLD.items():
        if name.endswith(old):
            stem = name[: -len(old)]
            return old_path.with_name(f"{stem}_{lr_type}{ext}")
    raise ValueError(f"Cannot derive new name from old name: {old_path}")


def fasta_exists(ref_dir: Path, ref: str) -> bool:
    return (ref_dir / f"{ref}.fasta").is_file() or (ref_dir / f"{ref}.fa").is_file()


def load_metadata(path: Path):
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.reader(handle, delimiter="\t"))
    if not rows:
        die(f"metadata is empty: {path}")
    if HAS_HEADER:
        return rows[0], rows[1:]
    return None, rows


def cell(row: list[str], idx: int) -> str:
    if idx < 0:
        idx = len(row) + idx
    if idx < 0 or idx >= len(row):
        return ""
    return row[idx].strip()


def collect_rename_jobs(cleanseq: Path, lr_type: str):
    jobs = []
    seen_src = set()
    for old in OLD_PACBIO_MARKERS:
        for src in sorted(cleanseq.glob(f"*{old}")):
            if not src.is_file():
                continue
            key = str(src.resolve())
            if key in seen_src:
                continue
            seen_src.add(key)
            dst = target_from_old(src, lr_type)
            jobs.append((src, dst))
    return jobs


def spa_key_for_row(row: list[str], platform: str, cleanseq: Path) -> tuple[str, str]:
    sample_id = cell(row, SAMPLE_ID_COL)
    runs = split_runs(cell(row, RUNS_COL))

    if platform == "illumina":
        if not runs:
            return "", "EMPTY_RUNS"
        return runs[0], "illumina_run"

    for token in runs:
        stem = strip_known_lr_stem(token)
        if stem:
            return stem, "runs_filename"

    if sample_id:
        path, kind = find_existing_longread(cleanseq, sample_id)
        if path is not None:
            return sample_id, f"sample_id_file:{kind}"

    for token in runs:
        path, kind = find_existing_longread(cleanseq, token)
        if path is not None:
            return token, f"run_file:{kind}"

    if sample_id:
        return sample_id, "sample_id_fallback"
    if runs:
        return runs[0], "run_fallback"
    return "", "NO_SAMPLE_KEY"


def parse_args():
    p = argparse.ArgumentParser(
        description="Build the SPA index and rename old PacBio files to _pbhifi / _pacbio"
    )
    p.add_argument("--metadata", type=Path, default=DEFAULT_METADATA)
    p.add_argument("--cleanseq", type=Path, default=DEFAULT_CLEANSEQ)
    p.add_argument("--references", type=Path, default=DEFAULT_REFERENCES)
    p.add_argument("--index-out", type=Path, default=DEFAULT_INDEX)
    p.add_argument("--report-out", type=Path, default=DEFAULT_REPORT)
    p.add_argument(
        "--mapping",
        type=Path,
        default=DEFAULT_MAPPING,
        help="Optional; only used to check that merged PacBio files exist",
    )
    p.add_argument(
        "--lr-type",
        required=True,
        choices=("pbhifi", "pacbio"),
        help="SPA suffix for old *_clean_pacbio.* files. Use pbhifi for HiFi, pacbio for CLR",
    )
    p.add_argument("--dry-run", action="store_true", help="Print only; no rename, no file writes")
    p.add_argument("--skip-rename", action="store_true", help="Only build the index, no rename")
    p.add_argument("--skip-index", action="store_true", help="Only rename, no index")
    return p.parse_args()


def main():
    args = parse_args()

    if not args.metadata.is_file():
        die(f"metadata not found: {args.metadata}")
    if not args.cleanseq.is_dir():
        die(f"cleanseq not found: {args.cleanseq}")
    if not args.skip_index and not args.references.is_dir():
        die(f"references not found: {args.references}")

    header, data_rows = load_metadata(args.metadata)
    print(f">>> metadata: {args.metadata}  ({len(data_rows)} rows)")
    if header:
        print(f"    header columns: {len(header)}")

    rename_jobs = collect_rename_jobs(args.cleanseq, args.lr_type)
    rename_ok = 0
    rename_skip = 0
    rename_conflict = 0

    print(f"\n>>> Rename scan: found {len(rename_jobs)} *_clean_pacbio.*")
    if args.skip_rename:
        print("    --skip-rename: skipping renames")
    else:
        if not rename_jobs:
            print("    No old PacBio files to rename (already renamed?)")

        for src, dst in rename_jobs:
            if dst.exists():
                print(f"    [CONFLICT] Target exists, not overwriting: {src.name}  ->  {dst.name}")
                rename_conflict += 1
                continue
            if args.dry_run:
                print(f"    [DRY] {src.name}  ->  {dst.name}")
                rename_ok += 1
                continue
            src.rename(dst)
            print(f"    [RENAMED] {src.name}  ->  {dst.name}")
            rename_ok += 1

    index_pairs = OrderedDict()
    report_rows = [[
        "metadata_sample_id",
        "platform_raw",
        "platform",
        "spa_sample",
        "ref",
        "key_reason",
        "seq_status",
        "ref_status",
        "index_kept",
    ]]

    kept = 0
    dropped = 0

    if not args.skip_index:
        print("\n>>> Building index")
        for row in data_rows:
            if not row or all(x.strip() == "" for x in row):
                continue

            meta_sid = cell(row, SAMPLE_ID_COL)
            platform_raw = cell(row, PLATFORM_COL)
            platform = detect_platform(platform_raw)
            ref = cell(row, REF_COL)
            spa_sample, key_reason = spa_key_for_row(row, platform, args.cleanseq)

            seq_status = "NA"
            ref_status = "NA"
            keep = False

            if not spa_sample:
                seq_status = "NO_SPA_SAMPLE"
            elif not ref:
                seq_status = "NO_REF"
            else:
                if platform == "illumina" or (
                    platform == "unknown"
                    and find_illumina_pair(args.cleanseq, spa_sample)[0] is not None
                ):
                    r1, r2 = find_illumina_pair(args.cleanseq, spa_sample)
                    if r1 is None:
                        seq_status = "MISSING_ILLUMINA_R1"
                    elif r2 is None or not r2.is_file():
                        seq_status = f"MISSING_ILLUMINA_R2:{r1.name}"
                    else:
                        seq_status = f"OK_ILLUMINA:{r1.name}"
                        keep = True
                else:
                    path, kind = find_existing_longread(args.cleanseq, spa_sample)
                    if path is None:
                        seq_status = "MISSING_LONGREAD"
                    elif kind == "old_pacbio":
                        seq_status = f"STILL_OLD_NAME:{path.name}"
                        if not args.skip_rename and rename_conflict == 0:
                            keep = True
                            seq_status += ":WILL_RENAME"
                        else:
                            keep = False
                    else:
                        expected = args.lr_type if platform in {"pacbio", "pbhifi", "unknown"} else kind
                        if platform in {"pacbio", "pbhifi"} and kind != args.lr_type and kind != "ont":
                            seq_status = f"LR_TYPE_MISMATCH:file={kind},want={args.lr_type}:{path.name}"
                            keep = True
                        else:
                            seq_status = f"OK_LONGREAD:{kind}:{path.name}"
                            keep = True

                if fasta_exists(args.references, ref):
                    ref_status = "OK_FASTA"
                else:
                    ref_status = f"MISSING_FASTA:{ref}.fasta"
                    keep = False

            if keep:
                pair = (spa_sample, ref)
                if pair not in index_pairs:
                    index_pairs[pair] = {
                        "platform": platform,
                        "examples": [meta_sid],
                    }
                    kept += 1
                else:
                    index_pairs[pair]["examples"].append(meta_sid)
            else:
                dropped += 1

            report_rows.append([
                meta_sid,
                platform_raw,
                platform,
                spa_sample,
                ref,
                key_reason,
                seq_status,
                ref_status,
                "YES" if keep else "NO",
            ])

        index_rows = [["sample", "ref"]]
        for sample, ref in index_pairs:
            index_rows.append([sample, ref])

        print(f"    Unique sample-ref pairs: {len(index_pairs)}")
        print(f"    metadata rows kept/dropped: {kept} / {dropped}")
        print(f"    Index rows written (excluding header): {len(index_pairs)}")

        missing_seq = [r for r in report_rows[1:] if r[-1] == "NO" and r[6].startswith("MISSING")]
        missing_fa = [r for r in report_rows[1:] if r[-1] == "NO" and r[7].startswith("MISSING")]
        still_old = [r for r in report_rows[1:] if "STILL_OLD_NAME" in r[6]]

        if missing_seq:
            print(f"    metadata rows with missing sequencing files: {len(missing_seq)}")
        if missing_fa:
            print(f"    metadata rows with missing reference fasta: {len(missing_fa)}")
        if still_old:
            print(f"    rows still using old PacBio names: {len(still_old)}")

        if args.dry_run:
            print(f"    [DRY] Will write {args.index_out}")
            print(f"    [DRY] Will write {args.report_out}")
            print("\n    index preview (up to 15 rows):")
            for row in index_rows[:16]:
                print("      " + "\t".join(row))
        else:
            with args.index_out.open("w", encoding="utf-8", newline="") as handle:
                csv.writer(handle, delimiter="\t", lineterminator="\n").writerows(index_rows)
            with args.report_out.open("w", encoding="utf-8", newline="") as handle:
                csv.writer(handle, delimiter="\t", lineterminator="\n").writerows(report_rows)
            print(f"    Wrote index : {args.index_out}")
            print(f"    Wrote report: {args.report_out}")

    if args.mapping.is_file():
        print(f"\n>>> Checking {args.mapping}")
        with args.mapping.open("r", encoding="utf-8", newline="") as handle:
            maps = list(csv.reader(handle, delimiter="\t"))
        body = maps[1:] if maps and maps[0] and maps[0][0] == "sample_id" else maps
        miss = 0
        for row in body:
            if len(row) < 3:
                continue
            sid = row[0].strip()
            old_name = Path(row[2].strip()).name
            stem = strip_known_lr_stem(old_name) or sid
            path, kind = find_existing_longread(args.cleanseq, stem)
            if path is None:
                print(f"    [MISSING] merged sample {sid} ({stem}): no long-read file found")
                miss += 1
            else:
                print(f"    [OK] {sid} -> {path.name} ({kind})")
        if miss == 0:
            print("    All merged samples in the mapping have files")

    print("\n========== Done ==========")
    print(f"Rename: processed {rename_ok}, conflicts {rename_conflict}, scanned {len(rename_jobs)}")
    if args.dry_run:
        print("This was a dry-run; nothing on disk was modified. Remove --dry-run when ready.")
    print("\nSPA example:")
    print("  bash spa_20260126.sh \\")
    print("    -g references -s cleanseq -p active_coordinate.tsv \\")
    print(f"    -o spa_out_precise -i {args.index_out} -t 20 -r 20 -c")


if __name__ == "__main__":
    main()