#!/bin/bash
set -uo pipefail

CLEAN_DIR="/home/huangyan/experiment/SPA/2-1_benchmark/benchmark/cleanseq/"
REF_DIR="/home/huangyan/experiment/SPA/2-1_benchmark/benchmark/references/"
OUT_DIR=results
INDEX_TSV=filtered.index.tsv
THREADS=24
LOG_DIR=logs
mkdir -p "$OUT_DIR" "$LOG_DIR"

resolve_fastq() {
  local s="$1" m="$2"
  local f1="${CLEAN_DIR}/${s}_${m}_clean.fastq"
  local f2="${f1}.gz"
  if [[ -f "$f1" ]]; then echo "$f1"
  elif [[ -f "$f2" ]]; then echo "$f2"
  else return 1
  fi
}

ensure_bwa_index() {
  local ref="$1"
  if [[ ! -e "${ref}.bwt" && ! -e "${ref}.0123" ]]; then
    echo "[INFO] Building BWA index: ${ref}"
    bwa index "$ref"
  fi
}

fail_list="${LOG_DIR}/failed.samples.txt"
: > "$fail_list"

while IFS=$'\t' read -r sample ref_base || [[ -n "${sample:-}" ]]; do
  [[ -z "${sample:-}" || "$sample" == "sample" ]] && continue

  bam="${OUT_DIR}/${sample}/${sample}.rmdup.bam"
  if [[ -s "$bam" ]]; then
    echo "[SKIP] ${sample} already has $(du -h "$bam" | cut -f1) rmdup.bam"
    continue
  fi

  log="${LOG_DIR}/${sample}.log"
  echo "=== Start ${sample} ===" | tee -a "$log"

  ref="${REF_DIR}/${ref_base}.fasta"
  if [[ ! -f "$ref" ]]; then
    echo "[FAIL] Missing reference ${ref}" | tee -a "$log"
    echo -e "${sample}\tno_ref" >> "$fail_list"
    continue
  fi
  if ! fq1="$(resolve_fastq "$sample" 1)"; then
    echo "[FAIL] Missing R1" | tee -a "$log"
    echo -e "${sample}\tno_fq1" >> "$fail_list"
    continue
  fi
  if ! fq2="$(resolve_fastq "$sample" 2)"; then
    echo "[FAIL] Missing R2" | tee -a "$log"
    echo -e "${sample}\tno_fq2" >> "$fail_list"
    continue
  fi

  sample_dir="${OUT_DIR}/${sample}"
  mkdir -p "$sample_dir"
  ensure_bwa_index "$ref" || { echo -e "${sample}\tbwa_index" >> "$fail_list"; continue; }

  if ! bwa mem -t "$THREADS" "$ref" "$fq1" "$fq2" \
      | samtools view -@ "$THREADS" -bS - \
      | samtools sort -@ "$THREADS" -o "${sample_dir}/${sample}.sorted.bam" -
  then
    echo -e "${sample}\tbwa" >> "$fail_list"
    rm -f "${sample_dir}/${sample}.sorted.bam"
    continue
  fi

  if ! sambamba markdup -t "$THREADS" -r \
      "${sample_dir}/${sample}.sorted.bam" \
      "${sample_dir}/${sample}.rmdup.bam"
  then
    echo -e "${sample}\tmarkdup" >> "$fail_list"
    continue
  fi
  rm -f "${sample_dir}/${sample}.sorted.bam"

  samtools view -@ "$THREADS" "${sample_dir}/${sample}.rmdup.bam" \
    -o "${sample_dir}/${sample}.rmdup.sam"

  if ! bash prophage_tracer.sh \
        -m "${sample_dir}/${sample}.rmdup.sam" \
        -r "$ref" -p "$sample" -t "$THREADS"
  then
    if [[ ! -s "${sample}.prophage.out" ]]; then
      echo -e "${sample}\ttracer" >> "$fail_list"
      rm -f "${sample_dir}/${sample}.rmdup.sam"
      continue
    fi
    echo "[INFO] tracer exited non-zero, but ${sample}.prophage.out exists, continuing"
  fi

  rm -f "${sample_dir}/${sample}.rmdup.sam"
  echo "=== ${sample} done ==="
done < "$INDEX_TSV"

echo "==== Finished ===="
echo "Failure list: ${fail_list}"
[[ -s "$fail_list" ]] && cat "$fail_list" || echo "(none)"