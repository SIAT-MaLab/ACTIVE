#!/usr/bin/env bash
set -eo pipefail

METADATA=""
REF_DIR=""
OUT_DIR=""
CHECKV_DB="/home/huangyan/databaseHY/checkv-db-v1.5/"
THREADS=8

usage() {
    echo "Usage: $0 -m <metadata.tsv> -r <references_dir> -o <output_dir> [-d <checkv_db>] [-t <threads>]"
    echo "  -m : Path to source_metadata_toactive.tsv"
    echo "  -r : Directory containing reference FASTA files"
    echo "  -o : Output directory"
    echo "  -d : Path to CheckV database (Default: /home/huangyan/databaseHY/checkv-db-v1.5/)"
    echo "  -t : Number of threads (Default: 8)"
    exit 1
}

while getopts "m:r:o:d:t:h" opt; do
    case $opt in
        m) METADATA="$OPTARG" ;;
        r) REF_DIR="$OPTARG" ;;
        o) OUT_DIR="$OPTARG" ;;
        d) CHECKV_DB="$OPTARG" ;;
        t) THREADS="$OPTARG" ;;
        h|*) usage ;;
    esac
done

if [[ -z "$METADATA" || -z "$REF_DIR" || -z "$OUT_DIR" ]]; then
    echo "[Error] Missing required arguments!"
    usage
fi

mkdir -p "${OUT_DIR}"
LOG="${OUT_DIR}/pipeline.log"
exec > >(tee -a "${LOG}") 2>&1

echo "========================================================"
echo "      Prophage Extraction & Validation Pipeline         "
echo "========================================================"
echo "Start Time   : $(date)"
echo "Metadata     : ${METADATA}"
echo "References   : ${REF_DIR}"
echo "Output Dir   : ${OUT_DIR}"
echo "CheckV DB    : ${CHECKV_DB}"
echo "Threads      : ${THREADS}"
echo "--------------------------------------------------------"

echo "[Step 1] Parsing all contig IDs from reference genomes..."
TMP_FASTA_IDS="${OUT_DIR}/all_ref_contig_ids.txt"
MERGED_REF="${OUT_DIR}/merged_references.fasta"

> "${MERGED_REF}"
find "${REF_DIR}" -maxdepth 1 -type f \( -name "*.fasta" -o -name "*.fa" -o -name "*.fna" \) -exec cat {} + >> "${MERGED_REF}"

grep '^>' "${MERGED_REF}" | awk '{print $1}' | tr -d '>' | sort -u > "${TMP_FASTA_IDS}"
TOTAL_REF_CONTIGS=$(wc -l < "${TMP_FASTA_IDS}")
echo "  -> Found ${TOTAL_REF_CONTIGS} unique contigs in reference genomes."

echo -e "\n[Step 2] Validating metadata and computing statistics..."

python3 - <<EOF
import os
import glob

metadata_file = "${METADATA}"
ref_dir = "${REF_DIR}"
ref_ids_file = "${TMP_FASTA_IDS}"

with open(ref_ids_file, 'r', encoding='utf-8', errors='ignore') as f:
    ref_contigs = set(line.strip() for line in f if line.strip())

fasta_contig_count = {}
contig_to_file = {}

fasta_files = []
for ext in ("*.fasta", "*.fa", "*.fna"):
    fasta_files.extend(glob.glob(os.path.join(ref_dir, ext)))

for fasta in fasta_files:
    if not os.path.isfile(fasta):
        continue
    fname = os.path.basename(fasta)
    c_count = 0
    with open(fasta, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if line.startswith('>'):
                c_count += 1
                cid = line[1:].strip().split()[0]
                contig_to_file[cid] = fname
    fasta_contig_count[fname] = c_count

missing_contigs = set()
contig_match_stats = []
total_records = 0

with open(metadata_file, 'r', encoding='utf-8', errors='ignore') as f:
    header = f.readline().strip().split('\t')
    col_map = {name: idx for idx, name in enumerate(header)}
    c1_idx = col_map['contig_1']
    c2_idx = col_map['contig_2']

    for line in f:
        if not line.strip():
            continue
        total_records += 1
        cols = line.strip().split('\t')
        c1 = cols[c1_idx]
        c2 = cols[c2_idx]

        if c1 not in ref_contigs:
            missing_contigs.add(c1)

        if c1 == c2:
            fname = contig_to_file.get(c1, "Unknown")
            c_num = fasta_contig_count.get(fname, -1)
            contig_match_stats.append((c1, fname, c_num))

print("\n--- [QC Check Results] ---")
if missing_contigs:
    print(f"WARNING: {len(missing_contigs)} contig_1 entries not found in reference genomes!")
    print("   Missing examples:", list(missing_contigs)[:10])
else:
    print("PASS: all contig_1 entries in the table exist in the reference genomes.")

matched_unique_fastas = {item[1]: item[2] for item in contig_match_stats if item[1] != "Unknown"}
single_contig_fastas = [k for k, v in matched_unique_fastas.items() if v == 1]
multi_contig_fastas = [k for k, v in matched_unique_fastas.items() if v > 1]

print(f"\n--- [Genome completeness for contig_1 == contig_2] ---")
print(f"Total {len(contig_match_stats)} records with contig_1 == contig_2 (across {len(matched_unique_fastas)} unique FASTA files)")
print(f"  -> Single-contig (1 contig / complete genome): {len(single_contig_fastas)} files")
print(f"  -> Multi-contig (>1 contig / draft genome): {len(multi_contig_fastas)} files")
if multi_contig_fastas:
    print(f"  -> Multi-contig examples (file, contig count): {[(k, matched_unique_fastas[k]) for k in multi_contig_fastas[:5]]}")
EOF

echo -e "\n[Step 3] Generating deduplicated coordinate files active_coordinate.tsv and active_coordinate.bed..."

COORD_TSV="${OUT_DIR}/active_coordinate.tsv"
COORD_BED="${OUT_DIR}/active_coordinate.bed"

python3 - "${METADATA}" "${COORD_TSV}" "${COORD_BED}" <<'PYEOF'
import sys

metadata_file = sys.argv[1]
coord_tsv = sys.argv[2]
coord_bed = sys.argv[3]

def to_int(value):
    cleaned = value.replace(',', '').replace('"', '').strip()
    return int(cleaned)

unique_coords = set()

with open(metadata_file, 'r', encoding='utf-8', errors='ignore') as f:
    header = f.readline().strip().split('\t')
    col_map = {name: idx for idx, name in enumerate(header)}
    c1_idx = col_map['contig_1']
    start_idx = col_map['prophage start']
    stop_idx = col_map['prophage stop']
    name_idx = col_map['prophage_name']

    with open(coord_tsv, 'w', encoding='utf-8') as f_tsv, open(coord_bed, 'w', encoding='utf-8') as f_bed:
        for line in f:
            if not line.strip():
                continue
            cols = line.strip().split('\t')
            contig = cols[c1_idx]
            start = to_int(cols[start_idx])
            stop = to_int(cols[stop_idx])
            name = cols[name_idx]

            s_min = min(start, stop)
            s_max = max(start, stop)

            coord_key = (contig, s_min, s_max)
            if coord_key not in unique_coords:
                unique_coords.add(coord_key)
                f_tsv.write(f"{contig}\t{s_min}\t{s_max}\n")
                f_bed.write(f"{contig}\t{s_min - 1}\t{s_max}\t{name}\n")

print(f"  -> Coordinate deduplication done; exported {len(unique_coords)} unique prophage regions.")
PYEOF

echo -e "\n[Step 4] Extracting sequences with bedtools..."
PP_EXT_FASTA="${OUT_DIR}/pp_ext.fasta"

bedtools getfasta -fi "${MERGED_REF}" -bed "${COORD_BED}" -name -fo "${PP_EXT_FASTA}"
echo "  -> Sequence extraction done: ${PP_EXT_FASTA}"
echo "  -> Extracted prophage sequences: $(grep -c '^>' "${PP_EXT_FASTA}")"

echo -e "\n[Step 5] Running CheckV end_to_end..."
CHECKV_OUT="${OUT_DIR}/checkv_out"

if [ ! -d "${CHECKV_DB}" ]; then
    echo "ERROR: CheckV database not found at: ${CHECKV_DB}"
    exit 1
fi

checkv end_to_end "${PP_EXT_FASTA}" "${CHECKV_OUT}" -d "${CHECKV_DB}" -t "${THREADS}"

rm  pp_ext.fasta merged_references.fasta.fai merged_references.fasta all_ref_contig_ids.txt pipeline.log

echo "--------------------------------------------------------"
echo "Pipeline finished!"
echo "CheckV output dir: ${CHECKV_OUT}"
echo "End Time: $(date)"
echo "========================================================"


