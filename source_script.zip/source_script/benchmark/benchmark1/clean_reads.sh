#!/usr/bin/env bash

set -uo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

META="${BASE_DIR}/source_metadata.cleaned.with_sample_id.tsv"
RAW_DIR="${BASE_DIR}/raw_seqdata"
OUT_DIR="${BASE_DIR}/cleanseq"

THREADS="${THREADS:-16}"

TRIMMOMATIC_BIN="$(command -v trimmomatic || true)"
FASTPLONG_BIN="$(command -v fastplong || true)"

mkdir -p "$OUT_DIR"

LOG_FILE="${OUT_DIR}/clean_reads.log"
STATUS_FILE="${OUT_DIR}/clean_reads.status.tsv"
MISSING_FILE="${OUT_DIR}/clean_reads.missing.tsv"

exec > >(tee -a "$LOG_FILE") 2>&1

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

record_status() {
    local sample_id="$1"
    local data_type="$2"
    local accession="$3"
    local status="$4"
    local message="$5"

    printf "%s\t%s\t%s\t%s\t%s\n" \
        "$sample_id" "$data_type" "$accession" "$status" "$message" \
        >> "$STATUS_FILE"

    if [[ "$status" == "MISSING_RAW" ||
          "$status" == "INCOMPLETE_CLEAN" ||
          "$status" == "FAILED" ]]; then
        printf "%s\t%s\t%s\t%s\t%s\n" \
            "$sample_id" "$data_type" "$accession" "$status" "$message" \
            >> "$MISSING_FILE"
    fi
}

if [[ ! -f "$META" ]]; then
    log "[ERROR] metadata file not found: $META"
    exit 1
fi

if [[ ! -d "$RAW_DIR" ]]; then
    log "[ERROR] raw data dir not found: $RAW_DIR"
    exit 1
fi

if [[ -z "$TRIMMOMATIC_BIN" ]]; then
    log "[ERROR] trimmomatic not found"
    exit 1
fi

if [[ -z "$FASTPLONG_BIN" ]]; then
    log "[ERROR] fastplong not found"
    exit 1
fi

command -v gzip >/dev/null 2>&1 || {
    log "[ERROR] gzip not found"
    exit 1
}

printf "sample_id\tdata_type\taccession\tstatus\tmessage\n" > "$STATUS_FILE"
printf "sample_id\tdata_type\taccession\tstatus\tmessage\n" > "$MISSING_FILE"

TMP_DIR="$(mktemp -d "${OUT_DIR}/.clean_tmp.XXXXXX")"

cleanup() {
    rm -rf "$TMP_DIR" 2>/dev/null || true
}

trap cleanup EXIT

log "Starting read cleaning"
log "Metadata: $META"
log "Raw data dir: $RAW_DIR"
log "Output dir: $OUT_DIR"
log "Threads: $THREADS"
log "Trimmomatic: $TRIMMOMATIC_BIN"
log "Fastplong: $FASTPLONG_BIN"

###############################################################################
# Locate raw FASTQ files
###############################################################################

find_input_file() {
    local accession="$1"
    local mate="${2:-}"
    local pattern
    local file

    if [[ -n "$mate" ]]; then
        for pattern in \
            "${accession}_${mate}.fastq.gz" \
            "${accession}_${mate}.fq.gz" \
            "${accession}_${mate}.fastq" \
            "${accession}_${mate}.fq" \
            "${accession}.${mate}.fastq.gz" \
            "${accession}.${mate}.fq.gz" \
            "${accession}.${mate}.fastq" \
            "${accession}.${mate}.fq"
        do
            file="$(find "$RAW_DIR" -type f -name "$pattern" -print -quit 2>/dev/null)"
            if [[ -n "$file" ]]; then
                printf "%s\n" "$file"
                return 0
            fi
        done
    else
        for pattern in \
            "${accession}.fastq.gz" \
            "${accession}.fq.gz" \
            "${accession}.fastq" \
            "${accession}.fq" \
            "${accession}.subreads.fastq.gz" \
            "${accession}.subreads.fq.gz" \
            "${accession}.subreads.fastq" \
            "${accession}.subreads.fq" \
            "${accession}_1.fastq.gz" \
            "${accession}_1.fq.gz" \
            "${accession}_1.fastq" \
            "${accession}_1.fq"
        do
            file="$(find "$RAW_DIR" -type f -name "$pattern" -print -quit 2>/dev/null)"
            if [[ -n "$file" ]]; then
                printf "%s\n" "$file"
                return 0
            fi
        done
    fi

    return 1
}

###############################################################################
# Validate clean file
###############################################################################

valid_clean_file() {
    local file="$1"

    [[ -s "$file" ]] || return 1
    gzip -t "$file" >/dev/null 2>&1
}

###############################################################################
# Ensure gzip compression
###############################################################################

ensure_gzip() {
    local file="$1"
    local plain_file

    [[ -s "$file" ]] || return 1

    if gzip -t "$file" >/dev/null 2>&1; then
        return 0
    fi

    plain_file="${file%.gz}"

    mv -f "$file" "$plain_file" || return 1
    gzip -f "$plain_file" || return 1

    valid_clean_file "$file"
}

###############################################################################
# Illumina PE
###############################################################################

process_pe() {
    local sample_id="$1"
    local accession="$2"

    local output_r1="${OUT_DIR}/${accession}_1_clean.fastq.gz"
    local output_r2="${OUT_DIR}/${accession}_2_clean.fastq.gz"

    local input_r1=""
    local input_r2=""

    local temp_r1="${TMP_DIR}/${accession}_1_clean.fastq.gz"
    local temp_r2="${TMP_DIR}/${accession}_2_clean.fastq.gz"
    local unpaired_r1="${TMP_DIR}/${accession}_1_unpaired.fastq.gz"
    local unpaired_r2="${TMP_DIR}/${accession}_2_unpaired.fastq.gz"

    if valid_clean_file "$output_r1" && valid_clean_file "$output_r2"; then
        log "[SKIP] PE clean already exists: $accession"
        record_status "$sample_id" "Illumina_PE" "$accession" \
            "SKIP_EXISTING" "${output_r1};${output_r2}"
        return 0
    fi

    input_r1="$(find_input_file "$accession" 1 2>/dev/null || true)"
    input_r2="$(find_input_file "$accession" 2 2>/dev/null || true)"

    if [[ -z "$input_r1" || -z "$input_r2" ]]; then
        local message="R1=${input_r1:-NOT_FOUND};R2=${input_r2:-NOT_FOUND}"

        if [[ -e "$output_r1" || -e "$output_r2" ]]; then
            log "[INCOMPLETE_CLEAN] $accession: $message"
            record_status "$sample_id" "Illumina_PE" "$accession" \
                "INCOMPLETE_CLEAN" "$message"
        else
            log "[MISSING_RAW] PE $accession: $message"
            record_status "$sample_id" "Illumina_PE" "$accession" \
                "MISSING_RAW" "$message"
        fi

        return 0
    fi

    log "[RUN] Illumina_PE: $accession"
    log "      R1: $input_r1"
    log "      R2: $input_r2"

    rm -f "$temp_r1" "$temp_r2" "$unpaired_r1" "$unpaired_r2"

    if ! "$TRIMMOMATIC_BIN" PE \
        -threads "$THREADS" \
        -phred33 \
        "$input_r1" \
        "$input_r2" \
        "$temp_r1" \
        "$unpaired_r1" \
        "$temp_r2" \
        "$unpaired_r2" \
        SLIDINGWINDOW:4:25 \
        MINLEN:100
    then
        log "[FAILED] Trimmomatic PE: $accession"
        record_status "$sample_id" "Illumina_PE" "$accession" \
            "FAILED" "trimmomatic_PE_failed"
        rm -f "$temp_r1" "$temp_r2" "$unpaired_r1" "$unpaired_r2"
        return 0
    fi

    rm -f "$unpaired_r1" "$unpaired_r2"

    if ! ensure_gzip "$temp_r1" || ! ensure_gzip "$temp_r2"; then
        log "[FAILED] PE output file abnormal: $accession"
        record_status "$sample_id" "Illumina_PE" "$accession" \
            "FAILED" "invalid_clean_output"
        rm -f "$temp_r1" "$temp_r2"
        return 0
    fi

    mv -f "$temp_r1" "$output_r1"
    mv -f "$temp_r2" "$output_r2"

    log "[DONE] $output_r1"
    log "[DONE] $output_r2"

    record_status "$sample_id" "Illumina_PE" "$accession" \
        "DONE" "${output_r1};${output_r2}"
}

###############################################################################
# Illumina SE
###############################################################################

process_se() {
    local sample_id="$1"
    local accession="$2"

    local output="${OUT_DIR}/${accession}_clean.fastq.gz"
    local input_file=""
    local temp_file="${TMP_DIR}/${accession}_clean.fastq.gz"

    if valid_clean_file "$output"; then
        log "[SKIP] SE clean already exists: $accession"
        record_status "$sample_id" "Illumina_SE" "$accession" \
            "SKIP_EXISTING" "$output"
        return 0
    fi

    input_file="$(find_input_file "$accession" 2>/dev/null || true)"

    if [[ -z "$input_file" ]]; then
        if [[ -e "$output" ]]; then
            log "[INCOMPLETE_CLEAN] SE $accession: clean exists but invalid, and raw file not found"
            record_status "$sample_id" "Illumina_SE" "$accession" \
                "INCOMPLETE_CLEAN" "invalid_clean_and_raw_not_found"
        else
            log "[MISSING_RAW] SE $accession"
            record_status "$sample_id" "Illumina_SE" "$accession" \
                "MISSING_RAW" "raw_file_not_found"
        fi

        return 0
    fi

    log "[RUN] Illumina_SE: $accession"
    log "      Input: $input_file"

    rm -f "$temp_file"

    if ! "$TRIMMOMATIC_BIN" SE \
        -threads "$THREADS" \
        -phred33 \
        "$input_file" \
        "$temp_file" \
        SLIDINGWINDOW:4:25 \
        MINLEN:100
    then
        log "[FAILED] Trimmomatic SE: $accession"
        record_status "$sample_id" "Illumina_SE" "$accession" \
            "FAILED" "trimmomatic_SE_failed"
        rm -f "$temp_file"
        return 0
    fi

    if ! ensure_gzip "$temp_file"; then
        log "[FAILED] SE output file abnormal: $accession"
        record_status "$sample_id" "Illumina_SE" "$accession" \
            "FAILED" "invalid_clean_output"
        rm -f "$temp_file"
        return 0
    fi

    mv -f "$temp_file" "$output"

    log "[DONE] $output"

    record_status "$sample_id" "Illumina_SE" "$accession" \
        "DONE" "$output"
}

###############################################################################
# PacBio
###############################################################################

process_pacbio() {
    local sample_id="$1"
    local accession="$2"

    local output="${OUT_DIR}/${accession}_clean_pacbio.fastq.gz"
    local input_file=""
    local temp_file="${TMP_DIR}/${accession}_clean_pacbio.fastq.gz"

    if valid_clean_file "$output"; then
        log "[SKIP] PacBio clean already exists: $accession"
        record_status "$sample_id" "PacBio" "$accession" \
            "SKIP_EXISTING" "$output"
        return 0
    fi

    input_file="$(find_input_file "$accession" 2>/dev/null || true)"

    if [[ -z "$input_file" ]]; then
        if [[ -e "$output" ]]; then
            log "[INCOMPLETE_CLEAN] PacBio $accession: clean exists but invalid, and raw file not found"
            record_status "$sample_id" "PacBio" "$accession" \
                "INCOMPLETE_CLEAN" "invalid_clean_and_raw_not_found"
        else
            log "[MISSING_RAW] PacBio $accession"
            record_status "$sample_id" "PacBio" "$accession" \
                "MISSING_RAW" "raw_file_not_found"
        fi

        return 0
    fi

    log "[RUN] PacBio: $accession"
    log "      Input: $input_file"

    rm -f "$temp_file"

    if ! "$FASTPLONG_BIN" \
        -i "$input_file" \
        -o "$temp_file" \
        -q 7 \
        -l 50
    then
        log "[FAILED] fastplong: $accession"
        record_status "$sample_id" "PacBio" "$accession" \
            "FAILED" "fastplong_failed"
        rm -f "$temp_file"
        return 0
    fi

    if ! ensure_gzip "$temp_file"; then
        log "[FAILED] PacBio output file abnormal: $accession"
        record_status "$sample_id" "PacBio" "$accession" \
            "FAILED" "invalid_clean_output"
        rm -f "$temp_file"
        return 0
    fi

    mv -f "$temp_file" "$output"

    log "[DONE] $output"

    record_status "$sample_id" "PacBio" "$accession" \
        "DONE" "$output"
}

###############################################################################
# Parse metadata
#
# col 1: sample_id
# col 2: accession count
# col 3: Illumina_PE / Illumina_SE / PacBio
# col 5+: accessions
#
# Uses awk default whitespace splitting, so metadata can be space- or tab-delimited.
###############################################################################

PARSED_META="${TMP_DIR}/parsed_metadata.tsv"

awk '
BEGIN {
    OFS="\t"
}

$1 ~ /^#/ || $1 == "sample_id" {
    next
}

NF >= 5 &&
($3 == "Illumina_PE" || $3 == "Illumina_SE" || $3 == "PacBio") {

    n = int($2 + 0)

    if (n < 1) {
        next
    }

    for (i = 0; i < n; i++) {
        acc = $(5 + i)

        if (acc != "") {
            print $1, $3, acc
        }
    }
}
' "$META" > "$PARSED_META"

if [[ ! -s "$PARSED_META" ]]; then
    log "[ERROR] no processable entries in metadata"
    exit 1
fi

###############################################################################
# Process each accession
###############################################################################

declare -A SEEN

n_total=0
n_done=0
n_skip=0
n_missing=0
n_failed=0

while IFS=$'\t' read -r sample_id data_type accession; do

    [[ -n "$sample_id" ]] || continue
    [[ -n "$data_type" ]] || continue
    [[ -n "$accession" ]] || continue

    n_total=$((n_total + 1))

    key="${data_type}|${accession}"

    if [[ -n "${SEEN[$key]+yes}" ]]; then
        log "[SKIP] duplicate accession: $sample_id $data_type $accession"
        record_status "$sample_id" "$data_type" "$accession" \
            "SKIP_DUPLICATE" "already_processed_in_this_run"
        continue
    fi

    SEEN["$key"]=1

    case "$data_type" in
        Illumina_PE)
            process_pe "$sample_id" "$accession"
            ;;

        Illumina_SE)
            process_se "$sample_id" "$accession"
            ;;

        PacBio)
            process_pacbio "$sample_id" "$accession"
            ;;
    esac

done < "$PARSED_META"

###############################################################################
# Summary
###############################################################################

log ""
log "Read cleaning pipeline finished"
log "Accessions to process from metadata: $n_total"
log "Status file: $STATUS_FILE"
log "Missing/abnormal files: $MISSING_FILE"
log "Log file: $LOG_FILE"

log ""
log "FASTQ files currently in cleanseq:"
find "$OUT_DIR" -maxdepth 1 -type f -name "*.fastq.gz" \
    -printf "%f\n" | sort

exit 0