set -uo pipefail
THREADS=16
INDEX_TSV="filtered.index.tsv"
REF_DIR="../references"
READ_DIR="../cleanseq"
OUT_DIR="results"
LOG_DIR="logs"
mkdir -p "$OUT_DIR" "$LOG_DIR"
declare -A INDEXED_REFS
tail -n +2 "$INDEX_TSV" |
awk 'NF >= 2 && $1 !~ /^#/ {print $1 "\t" $2}' |
while IFS=$'\t' read -r SAMPLE REF_ID; do
    SAMPLE="${SAMPLE//$'\r'/}"
    REF_ID="${REF_ID//$'\r'/}"
    REF="${REF_DIR}/${REF_ID}.fasta"
    R1="${READ_DIR}/${SAMPLE}_1_clean.fastq.gz"
    R2="${READ_DIR}/${SAMPLE}_2_clean.fastq.gz"
    PREFIX="${OUT_DIR}/${SAMPLE}__${REF_ID}"
    LOG="${LOG_DIR}/${SAMPLE}__${REF_ID}.log"
    echo "============================================================"
    echo "[INFO] Sample: $SAMPLE"
    echo "[INFO] Reference: $REF_ID"
    if [[ ! -s "$REF" ]]; then
        echo "[ERROR] Missing reference: $REF" | tee -a "$LOG"
        continue
    fi
    if [[ ! -s "$R1" ]]; then
        echo "[ERROR] Missing R1: $R1" | tee -a "$LOG"
        continue
    fi
    if [[ ! -s "$R2" ]]; then
        echo "[ERROR] Missing R2: $R2" | tee -a "$LOG"
        continue
    fi
    if [[ -z "${INDEXED_REFS[$REF]+x}" ]]; then
        if [[ ! -s "${REF}.bwt" ||
              ! -s "${REF}.ann" ||
              ! -s "${REF}.pac" ]]; then
            echo "[INFO] Building BWA index: $REF" | tee -a "$LOG"
            if ! mvirs index -f "$REF" >> "$LOG" 2>&1; then
                echo "[ERROR] Failed to build BWA index: $REF" | tee -a "$LOG"
                continue
            fi
        else
            echo "[INFO] BWA index already exists: $REF" | tee -a "$LOG"
        fi
        INDEXED_REFS["$REF"]=1
    fi
    if [[ -s "${PREFIX}.fasta" &&
          -s "${PREFIX}.oprs" &&
          -s "${PREFIX}.clipped" ]]; then
        echo "[INFO] Output exists, skip: $PREFIX" | tee -a "$LOG"
        continue
    fi
    echo "[INFO] Running mVIRs..." | tee -a "$LOG"
    mvirs oprs \
        -f "$R1" \
        -r "$R2" \
        -db "$REF" \
        -o "$PREFIX" \
        -t "$THREADS" \
        >> "$LOG" 2>&1
    STATUS=$?
    if [[ "$STATUS" -eq 0 ]]; then
        echo "[INFO] Finished successfully: $PREFIX" | tee -a "$LOG"
    else
        echo "[ERROR] mVIRs failed, exit code: $STATUS" | tee -a "$LOG"
    fi
done
#!/bin/bash
out="prophage_coordinates.tsv"
echo -e "sample\tref\tcontig\tstart\tend" > "$out"

for f in results/*.fasta; do
    base=$(basename "$f" .fasta)   
    sample="${base%%__*}"
    ref="${base#*__}"
    awk -v s="$sample" -v r="$ref" '
        /^>/ {
            header = substr($1, 2)  
            split(header, a, ":")    # a[1]=contig, a[2]=start-end
            split(a[2], b, "-")
            print s"\t"r"\t"a[1]"\t"b[1]"\t"b[2]
        }' "$f"
done >> "$out"
