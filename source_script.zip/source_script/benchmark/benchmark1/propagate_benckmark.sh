#!/usr/bin/env bash
set -euo pipefail

show_help() {
cat <<'EOF'
Usage:
  bash run_propagate_from_spa.sh -s <spa_out_dir> -r <ref_fasta_dir> -v <propagate_coords.tsv>
             [-o <propagate_out>] [-m <mapped_bam_dir>] [-t threads] [-p identity]
             [--min MIN] [--breadth B] [--effect E] [--ratio C] [--skip-existing]

Required:
  -s   SPA output dir (must contain mapping_results/)
  -r   Reference genome dir (same as SPA -g, *.fasta)
  -v   Propagate coordinate file (header: scaffold  fragment  start  stop)

Optional:
  -o   Propagate output parent dir  [default: propagate_from_spa]
  -m   Dir for unmapped-filtered BAMs [default: mapped_bam_from_spa]
  -t   Threads                      [default: 20]
  -p   Propagate -p (min identity)  [default: 0.97]
  --min / --breadth / --effect / --ratio
        Passed through to Propagate --min / --breadth / -e / -c
  --skip-existing   Skip if *prophage_activity* already in the output dir
  -h                Help

Notes:
  - sample / ref are parsed from the SPA directory structure, not from the BAM name after the last underscore.
  - Coordinates are filtered exactly against the current reference .fai contigs.
  - Input BAMs are first samtools view -F 4 then sorted/indexed, to avoid a PropagAtE v1.1.0 issue with unmapped reads.
  - The per sample×ref -o dir is created by Propagate itself; this script only rm -rf before re-running.
EOF
}

SPA_OUT=""
REF_DIR=""
COORD_FILE=""
OUT_DIR="propagate_from_spa"
MAPPED_BAM_DIR="mapped_bam_from_spa"
THREADS=20
MIN_IDENT="0.97"
PROP_MIN=""
PROP_BREADTH=""
PROP_EFFECT=""
PROP_RATIO=""
SKIP_EXISTING=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        -s) SPA_OUT="$2"; shift 2 ;;
        -r) REF_DIR="$2"; shift 2 ;;
        -v) COORD_FILE="$2"; shift 2 ;;
        -o) OUT_DIR="$2"; shift 2 ;;
        -m) MAPPED_BAM_DIR="$2"; shift 2 ;;
        -t) THREADS="$2"; shift 2 ;;
        -p) MIN_IDENT="$2"; shift 2 ;;
        --min) PROP_MIN="$2"; shift 2 ;;
        --breadth) PROP_BREADTH="$2"; shift 2 ;;
        --effect) PROP_EFFECT="$2"; shift 2 ;;
        --ratio) PROP_RATIO="$2"; shift 2 ;;
        --skip-existing) SKIP_EXISTING=true; shift ;;
        -h|--help) show_help; exit 0 ;;
        *) echo "Unknown argument: $1"; show_help; exit 1 ;;
    esac
done

if [[ -z "$SPA_OUT" || -z "$REF_DIR" || -z "$COORD_FILE" ]]; then
    echo "Error: -s / -r / -v are required"
    show_help
    exit 1
fi

MAP_DIR="${SPA_OUT}/mapping_results"
if [[ ! -d "$MAP_DIR" ]]; then
    echo "Error: SPA mapping dir not found: $MAP_DIR"
    exit 1
fi
if [[ ! -d "$REF_DIR" ]]; then
    echo "Error: reference dir not found: $REF_DIR"
    exit 1
fi
if [[ ! -f "$COORD_FILE" ]]; then
    echo "Error: coordinate file not found: $COORD_FILE"
    exit 1
fi
if ! command -v Propagate >/dev/null 2>&1; then
    echo "Error: Propagate not found in PATH; run conda activate propagate first"
    exit 1
fi
if ! command -v samtools >/dev/null 2>&1; then
    echo "Error: samtools not found in PATH"
    exit 1
fi

TMP_DIR="${OUT_DIR}/_tmp_coords"
LOG_FILE="${OUT_DIR}/run_propagate.log"
SUMMARY="${OUT_DIR}/run_summary.tsv"

mkdir -p "$MAPPED_BAM_DIR" "$OUT_DIR" "$TMP_DIR"

{
    echo -e "sample\tref\tspa_bam\tmapped_bam\tn_coord\tmapped_reads\tstatus\tout_folder"
} > "$SUMMARY"

echo ">>> SPA mapping : $MAP_DIR"
echo ">>> References  : $REF_DIR"
echo ">>> Coordinates : $COORD_FILE"
echo ">>> Output root : $OUT_DIR"
echo ">>> mapped BAMs : $MAPPED_BAM_DIR"
echo ">>> Threads=$THREADS  identity=-p $MIN_IDENT"
echo ">>> Log         : $LOG_FILE"

n_ok=0
n_skip=0
n_fail=0

shopt -s nullglob
spa_bams=()
for bam in "$MAP_DIR"/*/*.bam; do
    base=$(basename "$bam")
    case "$base" in
        *.bai) continue ;;
        temp_sr_*|temp_lr_*) continue ;;
        *.mapped.sorted.bam) continue ;;
        *_*.bam) spa_bams+=("$bam") ;;
    esac
done
shopt -u nullglob

if [[ ${#spa_bams[@]} -eq 0 ]]; then
    echo "Error: no usable SPA BAMs under $MAP_DIR"
    exit 1
fi

echo ">>> Found ${#spa_bams[@]} SPA BAMs"
echo

log() { echo "$*" | tee -a "$LOG_FILE"; }

filter_coords_by_fai() {
    local fai="$1"
    local coord="$2"
    local out="$3"
    awk 'NR==FNR { c[$1]=1; next }
         FNR==1 { print; next }
         NF>=4 && ($1 in c)' "$fai" "$coord" > "$out"
}

for bam in "${spa_bams[@]}"; do
    sample=$(basename "$(dirname "$bam")")
    bam_base=$(basename "$bam" .bam)

    prefix="${sample}_"
    if [[ "$bam_base" != "${prefix}"* ]]; then
        log "[SKIP] BAM name does not match directory sample: $bam"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\tNA\t${bam}\tNA\t0\t0\tNAME_MISMATCH\t" >> "$SUMMARY"
        continue
    fi
    ref_name="${bam_base#"$prefix"}"

    ref_fasta="${REF_DIR}/${ref_name}.fasta"
    mapped_bam="${MAPPED_BAM_DIR}/${sample}_${ref_name}.mapped.sorted.bam"
    temp_coord="${TMP_DIR}/${sample}_${ref_name}.tsv"
    out_folder="${OUT_DIR}/propagate_results_${sample}_${ref_name}"

    log "=================================================="
    log "Sample : ${sample}"
    log "Ref    : ${ref_name}"
    log "SPA BAM: ${bam}"
    log "FASTA  : ${ref_fasta}"

    if [[ ! -f "$ref_fasta" ]]; then
        log "[SKIP] Reference not found: $ref_fasta"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\tNA\t0\t0\tMISSING_FASTA\t" >> "$SUMMARY"
        continue
    fi

    if [[ ! -f "${ref_fasta}.fai" ]]; then
        samtools faidx "$ref_fasta"
    fi

    filter_coords_by_fai "${ref_fasta}.fai" "$COORD_FILE" "$temp_coord"
    n_coord=$(awk 'NR>1 && NF>=4 {n++} END{print n+0}' "$temp_coord")
    if [[ "$n_coord" -eq 0 ]]; then
        log "[SKIP] No coordinates match the fai contigs of ${ref_name} (check header vs scaffold column)"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\tNA\t0\t0\tNO_COORD\t" >> "$SUMMARY"
        rm -f "$temp_coord"
        continue
    fi
    log "[INFO] Matched ${n_coord} prophage coordinates"

    if [[ "$SKIP_EXISTING" == true ]] && compgen -G "${out_folder}/*prophage_activity*" > /dev/null; then
        log "[SKIP] Propagate results already exist: $out_folder"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\t${mapped_bam}\t${n_coord}\tNA\tSKIP_EXISTING\t${out_folder}" >> "$SUMMARY"
        continue
    fi

    if [[ ! -s "$mapped_bam" ]]; then
        log "[INFO] Filtering unmapped reads (-F 4) and sort/index..."
        samtools view -@ "$THREADS" -h -b -F 4 "$bam" \
            | samtools sort -@ "$THREADS" -o "$mapped_bam" -
        samtools index -@ "$THREADS" "$mapped_bam"
    else
        log "[INFO] Reusing existing mapped BAM: $mapped_bam"
        [[ -f "${mapped_bam}.bai" ]] || samtools index -@ "$THREADS" "$mapped_bam"
    fi

    mapped_reads=$(samtools view -c -F 4 "$mapped_bam")
    if [[ "$mapped_reads" -eq 0 ]]; then
        log "[SKIP] No mapped reads after filtering"
        n_skip=$((n_skip + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\t${mapped_bam}\t${n_coord}\t0\tNO_MAPPED_READS\t" >> "$SUMMARY"
        continue
    fi
    log "[INFO] mapped reads: ${mapped_reads}"

    if [[ -e "$out_folder" ]]; then
        log "[INFO] Removing existing output dir: $out_folder"
        rm -rf "$out_folder"
    fi

    cmd=(Propagate
        -f "$ref_fasta"
        -b "$mapped_bam"
        -v "$temp_coord"
        -o "$out_folder"
        -t "$THREADS"
        -p "$MIN_IDENT"
    )
    [[ -n "$PROP_MIN" ]] && cmd+=(--min "$PROP_MIN")
    [[ -n "$PROP_BREADTH" ]] && cmd+=(--breadth "$PROP_BREADTH")
    [[ -n "$PROP_EFFECT" ]] && cmd+=(-e "$PROP_EFFECT")
    [[ -n "$PROP_RATIO" ]] && cmd+=(-c "$PROP_RATIO")

    log "[INFO] ${cmd[*]}"
    if "${cmd[@]}" >> "$LOG_FILE" 2>&1; then
        log "[DONE] $sample / $ref_name"
        n_ok=$((n_ok + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\t${mapped_bam}\t${n_coord}\t${mapped_reads}\tOK\t${out_folder}" >> "$SUMMARY"
    else
        log "[FAIL] $sample / $ref_name  (see $LOG_FILE)"
        n_fail=$((n_fail + 1))
        echo -e "${sample}\t${ref_name}\t${bam}\t${mapped_bam}\t${n_coord}\t${mapped_reads}\tFAIL\t${out_folder}" >> "$SUMMARY"
    fi
    echo
done

echo "========== Done =========="
echo "OK $n_ok  SKIP $n_skip  FAIL $n_fail"
echo "Summary: $SUMMARY"
echo "Log    : $LOG_FILE"