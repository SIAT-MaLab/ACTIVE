suppressPackageStartupMessages({
  library(tidyverse)
  library(ggrepel)
  library(patchwork)
  library(ggsci)
  library(scales)
})

file_path <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/host/metadata/prophage_stats_final.tsv"
out_dir   <- "./1_acitivity_stats_results"
global_dpi <- 600
global_base_family <- "Arial"

if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

raw_data <- read_tsv(file_path, show_col_types = FALSE)

df_task1 <- raw_data %>%
  mutate(
    Prophage_Count = replace_na(as.numeric(Prophage_Count), 0),
    Active_Prophage_Count = replace_na(as.numeric(Active_Prophage_Count), 0)
  )

id_col_name <- colnames(raw_data)[1]
df_task2 <- raw_data %>%
  mutate(Real_Genome_ID = str_remove(.data[[id_col_name]], "_[0-9]+$")) %>%
  group_by(Real_Genome_ID, Domain, Phylum, Class, Order, Family, Genus, Species, source) %>%
  summarise(
    Prophage_Count = sum(Prophage_Count, na.rm = TRUE),
    Active_Prophage_Count = sum(Active_Prophage_Count, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(Lysogeny_Status = case_when(
    Prophage_Count == 0 ~ "Non-lysogen",
    Prophage_Count == 1 ~ "Single-lysogen",
    Prophage_Count > 1  ~ "Poly-lysogen"
  ))


t1_plot_6panel_w <- 14
t1_plot_6panel_h <- 15
t1_plot_method_w <- 12
t1_plot_method_h <- 7

t1_legend_position <- "top"
t1_legend_text_size <- 14
t1_legend_text_color <- "black"
t1_title_size <- 12
t1_title_face <- "bold"
t1_color_axis_title <- "black"
t1_size_axis_title <- 18
t1_face_axis_title <- "bold"
t1_color_axis_text <- "black"
t1_size_axis_text <- 16
t1_face_axis_text <- "plain"
t1_axis_text_angle_x <- 45
t1_panel_border_color <- "black"
t1_panel_border_width <- 1

t1_color_lysogeny <- "#374E55FF"
t1_color_induction <- "#DF8F44FF"
t1_color_poly <- "#00A1D5FF"
t1_metric_colors <- setNames(c(t1_color_lysogeny, t1_color_induction, t1_color_poly),
                              c("Lysogeny_Rate", "Induction_Rate", "Poly_Lysogeny_Rate"))
t1_bar_width <- 0.7
t1_bar_border_color <- "black"
t1_bar_border_width <- 0.5
t1_bar_label_size <- 4
t1_bar_label_face <- "bold"

metric_levels <- c("Lysogeny_Rate", "Induction_Rate", "Poly_Lysogeny_Rate")

t1_shared_theme <- theme_bw(base_size = 12, base_family = global_base_family) +
  theme(
    plot.title = element_text(hjust = 0, face = t1_title_face, size = t1_title_size, color = "black"),
    axis.title.x = element_text(size = t1_size_axis_title, color = t1_color_axis_title, face = t1_face_axis_title),
    axis.title.y = element_text(size = t1_size_axis_title, color = t1_color_axis_title, face = t1_face_axis_title),
    axis.text.x = element_text(size = t1_size_axis_text, color = t1_color_axis_text, face = t1_face_axis_text, angle = t1_axis_text_angle_x, hjust = ifelse(t1_axis_text_angle_x > 0, 1, 0.5)),
    axis.text.y = element_text(size = t1_size_axis_text, color = t1_color_axis_text, face = t1_face_axis_text),
    panel.grid = element_blank(),
    panel.border = element_rect(colour = t1_panel_border_color, fill = NA, linewidth = t1_panel_border_width),
    legend.position = t1_legend_position,
    legend.title = element_blank(),
    legend.text = element_text(size = t1_legend_text_size, color = t1_legend_text_color),
    legend.background = element_blank()
  )

calculate_stats <- function(data, tax_rank = NULL, group_col = "source") {
  if (is.null(tax_rank) || tax_rank == "Unweighted") {
    stats <- data %>%
      group_by(.data[[group_col]]) %>%
      summarise(
        Lysogeny_Rate = mean(Prophage_Count > 0),
        n_lysogens = sum(Prophage_Count > 0),
        n_active = sum(Active_Prophage_Count > 0),
        n_poly_events = sum(Prophage_Count >= 2),
        Induction_Rate = if_else(n_lysogens > 0, n_active / n_lysogens, 0),
        Poly_Lysogeny_Rate = if_else(n_lysogens > 0, n_poly_events / n_lysogens, 0),
        .groups = "drop"
      )
  } else {
    taxa_stats <- data %>%
      group_by(.data[[group_col]], .data[[tax_rank]]) %>%
      summarise(
        t_lysogeny = mean(Prophage_Count > 0),
        t_n_lysogens = sum(Prophage_Count > 0),
        t_n_active = sum(Active_Prophage_Count > 0),
        t_n_poly = sum(Prophage_Count >= 2),
        t_induction = if_else(t_n_lysogens > 0, t_n_active / t_n_lysogens, NA_real_),
        t_poly = if_else(t_n_lysogens > 0, t_n_poly / t_n_lysogens, NA_real_),
        .groups = "drop"
      )
    stats <- taxa_stats %>%
      group_by(.data[[group_col]]) %>%
      summarise(
        Lysogeny_Rate = mean(t_lysogeny, na.rm = TRUE),
        Induction_Rate = mean(t_induction, na.rm = TRUE),
        Poly_Lysogeny_Rate = mean(t_poly, na.rm = TRUE),
        .groups = "drop"
      )
  }
  return(stats)
}

plot_source_comparison <- function(data, tax_rank, title_suffix) {
  stats_df <- calculate_stats(data, tax_rank = tax_rank, group_col = "source")
  plot_data <- stats_df %>%
    pivot_longer(cols = ends_with("_Rate"), names_to = "Metric", values_to = "Rate") %>%
    mutate(Metric = factor(Metric, levels = metric_levels))
  p <- ggplot(plot_data, aes(x = source, y = Rate, fill = Metric)) +
    geom_col(position = position_dodge(width = 0.8), width = t1_bar_width,
             color = t1_bar_border_color, linewidth = t1_bar_border_width) +
    geom_text(aes(label = sprintf("%.2f", Rate)),
              position = position_dodge(width = 0.8), vjust = -0.5,
              size = t1_bar_label_size, fontface = t1_bar_label_face) +
    scale_fill_manual(values = t1_metric_colors) +
    scale_y_continuous(expand = expansion(mult = c(0, 0.05)), limits = c(0, 1)) +
    labs(title = paste(title_suffix), y = "Rate", x = NULL) +
    t1_shared_theme
  return(p)
}


rank_levels <- c("Unweighted", "Species")
list_results <- list()
for (r in rank_levels) {
  temp_df <- df_task1 %>%
    mutate(dummy_group = "All_Data")
  if (r != "Unweighted") {
    temp_df <- temp_df %>%
      filter(!is.na(.data[[r]]) & .data[[r]] != "")
  }
  res <- calculate_stats(
    temp_df,
    tax_rank = if (r == "Unweighted") NULL else r,
    group_col = "dummy_group"
  )
  res$Method <- r
  list_results[[r]] <- res
}
df_methods <- bind_rows(list_results) %>%
  select(-dummy_group) %>%
  pivot_longer(
    cols = ends_with("_Rate"),
    names_to = "Metric",
    values_to = "Rate"
  ) %>%
  mutate(
    Metric = factor(Metric, levels = metric_levels),
    Method = factor(
      Method,
      levels = c("Unweighted", "Species"),
      labels = c("per isolates", "per species")
    )
  )
p_method <- ggplot(
  df_methods,
  aes(x = Method, y = Rate, fill = Metric)
) +
  geom_col(
    position = position_dodge(width = 0.8),
    width = t1_bar_width,
    color = t1_bar_border_color,
    linewidth = t1_bar_border_width
  ) +
  geom_text(
    aes(label = sprintf("%.2f", Rate)),
    position = position_dodge(width = 0.8),
    vjust = -0.5,
    size = t1_bar_label_size + 0.5,
    fontface = t1_bar_label_face
  ) +
  scale_fill_manual(values = t1_metric_colors) +
  scale_y_continuous(
    expand = expansion(mult = c(0, 0.08)),
    limits = c(0, 1)
  ) +
  labs(
    title = "Prophage Rates Calculated per Isolate and per Species",
    subtitle = "Definition: Induction Rate = Active Lysogens / All Lysogens",
    x = "Calculation unit",
    y = "Calculated rate"
  ) +
  t1_shared_theme +
  theme(
    axis.text.x = element_text(
      angle = 0,
      hjust = 0.5,
      size = t1_size_axis_text,
      color = t1_color_axis_text,
      face = t1_face_axis_text
    )
  )
out_file_2 <- file.path(out_dir, "Host_activity_summary.pdf")
ggsave(
  out_file_2,
  p_method,
  width = t1_plot_method_w,
  height = t1_plot_method_h,
  dpi = global_dpi,
  device = cairo_pdf
)


t2_min_host_count <- 5
t2_threshold_count <- 100
t2_threshold_active <- 0.20

t2_custom_phylum_colors <- c(
  "Bacillota_A" = "#dce8ef", "Bacillota_C" = "#add2e5", "Bacillota_I" = "#34666b", "Bacillota" = "#7abbce",
  "Bacillota_B" = "#769499", "Actinomycetota" = "#f5cfa6", "Bacteroidota" = "#efe3ef", "Verrucomicrobiota" = "#d4d68a",
  "Pseudomonadota" = "#e68f9f", "Desulfobacterota" = "#d5d5d6", "Fusobacteriota" = "#b7a3c9", "Synergistota" = "#414141"
)

t2_phylum_point_alpha <- 0.85
t2_cols_bar <- c("Non" = "grey60", "Single" = "#E41A1C", "Poly" = "#74004A")
t2_global_base_size <- 20

t2_plot_phylum_w <- 12
t2_plot_phylum_h_min <- 10
t2_plot_widths_ratio <- c(1.5, 1, 0.4) 
target_levels <- c("Phylum")

for (plot_level in target_levels) {

  df_subset <- df_task2 %>% drop_na(all_of(plot_level))
  parent_col <- switch(plot_level, "Phylum" = "Domain", "Species" = "Genus")

  stats_df <- df_subset %>%
    group_by(Taxon = .data[[plot_level]], Parent = .data[[parent_col]], Phylum) %>%
    summarise(
      Total_Strains = n(),
      Count_Non = sum(Lysogeny_Status == "Non-lysogen"),
      Count_Single = sum(Lysogeny_Status == "Single-lysogen"),
      Count_Poly = sum(Lysogeny_Status == "Poly-lysogen"),
      Count_Lysogens = sum(Prophage_Count > 0),
      Count_Active_Hosts = sum(Active_Prophage_Count > 0),
      .groups = "drop"
    ) %>%
    filter(Total_Strains >= t2_min_host_count) %>%
    mutate(
      Rate_Lysogeny_X = Count_Lysogens / Total_Strains,
      Rate_Active_Host_Y = ifelse(Count_Lysogens > 0, Count_Active_Hosts / Count_Lysogens, 0),
      Ratio_Non = Count_Non / Total_Strains,
      Ratio_Single = Count_Single / Total_Strains,
      Ratio_Poly = Count_Poly / Total_Strains
    )

  if (nrow(stats_df) == 0) next

  global_mean_lysogeny <- sum(stats_df$Count_Lysogens) / sum(stats_df$Total_Strains)
  total_lysogens_pop <- sum(stats_df$Count_Lysogens)
  global_mean_active <- if(total_lysogens_pop > 0) sum(stats_df$Count_Active_Hosts) / total_lysogens_pop else 0

  stats_df <- stats_df %>%
    mutate(is_highlight = Total_Strains >= t2_threshold_count | Rate_Active_Host_Y >= t2_threshold_active) %>%
    filter(is_highlight) %>%
    mutate(Color_Group = Taxon)

  if (nrow(stats_df) == 0) next

  legend_title_text <- "Phylum"

  sorted_groups <- sort(unique(stats_df$Color_Group))
  stats_df$Color_Group <- factor(stats_df$Color_Group, levels = sorted_groups)
  stats_df <- stats_df %>% arrange(Color_Group)

  my_palette <- c()
  predefined <- sorted_groups[sorted_groups %in% names(t2_custom_phylum_colors)]
  missing <- sorted_groups[!sorted_groups %in% names(t2_custom_phylum_colors)]
  for (p in predefined) my_palette[p] <- t2_custom_phylum_colors[p]
  if (length(missing) > 0) {
    base_cols <- pal_npg("nrc")(min(length(missing), 10))
    final_cols <- if(length(missing) > length(base_cols)) colorRampPalette(base_cols)(length(missing)) else base_cols[1:length(missing)]
    for (i in seq_along(missing)) my_palette[missing[i]] <- final_cols[i]
  }

  export_df <- stats_df %>%
    mutate(
      Global_Mean_X = global_mean_lysogeny,
      Global_Mean_Y = global_mean_active,
      Quadrant = case_when(
        Rate_Lysogeny_X >= global_mean_lysogeny & Rate_Active_Host_Y >= global_mean_active ~ "Q1",
        Rate_Lysogeny_X <  global_mean_lysogeny & Rate_Active_Host_Y >= global_mean_active ~ "Q2",
        Rate_Lysogeny_X <  global_mean_lysogeny & Rate_Active_Host_Y <  global_mean_active ~ "Q3",
        Rate_Lysogeny_X >= global_mean_lysogeny & Rate_Active_Host_Y <  global_mean_active ~ "Q4"
      )
    )
  csv_out <- file.path(out_dir, paste0("Statistics_", plot_level, ".csv"))
  write_csv(export_df, csv_out)

  stats_df <- stats_df %>% mutate(Label_Text = Taxon) 
  
  p1 <- ggplot(stats_df, aes(x = Rate_Lysogeny_X, y = Rate_Active_Host_Y)) +
    geom_vline(xintercept = global_mean_lysogeny, linetype = "dashed", color = "black", alpha=0.6) +
    geom_hline(yintercept = global_mean_active, linetype = "dashed", color = "black", alpha=0.6) +
    geom_point(aes(size = Total_Strains, fill = Color_Group),
               shape = 21, color = "black", stroke = 0.3, alpha = t2_phylum_point_alpha) +
    geom_text_repel(aes(label = Label_Text, color = Color_Group),
                    size = 5, fontface = "bold", bg.color = "white", bg.r = 0.15,
                    box.padding = 0.6, max.overlaps = Inf, show.legend = FALSE) +
    scale_fill_manual(values = my_palette, name = legend_title_text) +
    scale_color_manual(values = my_palette, guide = "none") +
    scale_size_continuous(trans = "log10", range = c(3, 12), breaks = c(10, 100, 1000, 10000),
                          labels = c("10", "100", "1k", "10k"), name = "Genome Count") +
    scale_y_continuous(expand = expansion(mult = c(0.02, 0.15)), limits = c(0, max(stats_df$Rate_Active_Host_Y) * 1.05)) +
    scale_x_continuous(limits = c(0, 1.05), expand = expansion(mult = c(0.01, 0.05))) +
    labs(title = paste0("A. Overview (", plot_level, ")"),
         subtitle = "Quadrants defined by population weighted means",
         x = "Lysogen Rate", y = "Active Rate") +
    theme_bw(base_size = t2_global_base_size, base_family = global_base_family) +
    theme(
      legend.position = "bottom",
      legend.box = "vertical",
      plot.title = element_text(face = "bold", size = 16),
      legend.title = element_text(hjust = 0.5)
    ) +
    guides(fill = guide_legend(title.position = "top", title.hjust = 0.5, order = 1),
           size = guide_legend(title.position = "top", title.hjust = 0.5, order = 2))

  df_hi <- stats_df   
  levs <- df_hi %>% filter(Taxon!="Other") %>% arrange(Ratio_Non) %>% pull(Taxon)
  df_hi$Taxon <- factor(df_hi$Taxon, levels = levs)

  bar_long <- df_hi %>% select(Taxon, Ratio_Non, Ratio_Single, Ratio_Poly) %>%
    pivot_longer(-Taxon, names_to="Type", values_to="Val") %>%
    mutate(Type = factor(str_remove(Type,"Ratio_"), levels=c("Non","Single","Poly")))

  p2 <- ggplot(bar_long, aes(Taxon, Val, fill=Type)) +
    geom_col(color="black", width=0.8, linewidth=0.2) + coord_flip() +
    scale_fill_manual(values=t2_cols_bar) +
    scale_y_continuous(labels = scales::percent, expand = c(0,0)) +
    theme_bw(base_size=t2_global_base_size, base_family = global_base_family) +
    labs(title="B. Lysogeny Patterns", x=NULL, y="Proportion") +
    theme(legend.position="bottom", axis.text.y = element_text(face="italic"), legend.title = element_text(hjust = 0.5)) +
    guides(fill = guide_legend(title.position = "top", title.hjust = 0.5))

  p3 <- ggplot(df_hi, aes(Taxon, Total_Strains)) +
    geom_col(fill="grey80", color="black", width=0.8, linewidth=0.2) +
    geom_text(aes(label=Total_Strains), hjust=-0.1, size=4.5) + coord_flip() +
    scale_y_continuous(expand = expansion(mult = c(0, 0.3))) +
    theme_bw(base_size=t2_global_base_size, base_family = global_base_family) +
    labs(title="C. Count", x=NULL, y="Genomes") +
    theme(axis.text.y=element_blank(), axis.ticks.y=element_blank(), panel.grid=element_blank())

 
  combined_plot <- p1 + p2 + p3 + plot_layout(widths = t2_plot_widths_ratio)
  plot_h <- max(t2_plot_phylum_h_min, 0.4 * nrow(df_hi) + 4)

  pdf_out <- file.path(out_dir, paste0("Merged_Analysis_Quadrants_", plot_level, ".pdf"))
  ggsave(pdf_out, combined_plot, width = t2_plot_phylum_w, height = plot_h, dpi = global_dpi, limitsize = FALSE, device = cairo_pdf)

}
