#!/usr/bin/env Rscript

# Two-trait lysogeny–activity divergence.
# Traits are species-level prevalences, not isolate-level binary variables:
#   lysogeny prevalence = lysogens / isolates
#   active prophage carriage prevalence = active lysogens / lysogens
# Phenotypic distance is Euclidean distance in this unscaled 0–1 space.
# PCA is intentionally omitted because two traits already define the full space.

suppressPackageStartupMessages({
  library(tidyverse)
  library(data.table)
  library(patchwork)
  library(ggsci)
})

setDTthreads(parallel::detectCores(logical = FALSE))
set.seed(20260529)

INPUT_PROPHAGE_STATS <- "../metadata/prophage_stats_final.tsv"
INPUT_SKANI_DIST     <- "3_close_species/species_skani_distances.tsv"

DIR_OUT_TBL <- "3_close_species/two_trait_tables"
DIR_OUT_FIG <- "3_close_species/two_trait_plots"
dir.create(DIR_OUT_TBL, recursive = TRUE, showWarnings = FALSE)
dir.create(DIR_OUT_FIG, recursive = TRUE, showWarnings = FALSE)

MIN_ISOLATES <- 5L
MIN_LYSOGENS <- 3L
N_PERM       <- 1000L

TARGET_PHYLA <- c(
  "Actinomycetota", "Pseudomonadota", "Bacteroidota",
  "Bacillota", "Bacillota_A", "Bacillota_B", "Bacillota_C",
  "Verrucomicrobiota"
)

CUSTOM_PHYLUM_COLORS <- c(
  "Bacillota_A"       = "#dce8ef",
  "Bacillota_C"       = "#add2e5",
  "Bacillota_I"       = "#34666b",
  "Bacillota"         = "#7abbce",
  "Bacillota_B"       = "#769499",
  "Actinomycetota"    = "#f5cfa6",
  "Bacteroidota"      = "#efe3ef",
  "Verrucomicrobiota" = "#d4d68a",
  "Pseudomonadota"    = "#e68f9f",
  "Desulfobacterota"  = "#d5d5d6",
  "Fusobacteriota"    = "#231815",
  "Synergistota"      = "#414141"
)

CUSTOM_SHAPES <- c(21, 22, 23, 24, 25)
SHAPE_LEVELS  <- c(
  "Actinomycetota", "Bacillota*", "Bacteroidota",
  "Pseudomonadota", "Others"
)

stopifnot(file.exists(INPUT_PROPHAGE_STATS), file.exists(INPUT_SKANI_DIST))

format_p <- function(p) {
  ifelse(is.na(p), "NA", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}

majority_label <- function(x) {
  x <- as.character(x)
  x <- x[!is.na(x) & x != ""]
  if (!length(x)) return(NA_character_)
  names(sort(table(x), decreasing = TRUE))[1]
}

message("[1/4] Calculating species-level prevalences...")

raw_df <- read_tsv(INPUT_PROPHAGE_STATS, show_col_types = FALSE)

required_cols <- c(
  "Genome_ID", "Prophage_Count", "Active_Prophage_Count",
  "Phylum", "Family", "Genus", "Species"
)
missing_cols <- setdiff(required_cols, colnames(raw_df))
if (length(missing_cols)) {
  stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
}

df <- raw_df %>%
  mutate(
    across(c(Genome_ID, Phylum, Family, Genus, Species), ~str_trim(as.character(.x))),
    Prophage_Count = as.numeric(Prophage_Count),
    Active_Prophage_Count = as.numeric(Active_Prophage_Count)
  ) %>%
  filter(!is.na(Species), Species != "", Species != "s__", Species != "NA")

if (anyDuplicated(df$Genome_ID)) {
  stop(
    "Duplicate Genome_ID values found. This script does not strip ID suffixes ",
    "or sum counts; please resolve duplicate isolates first."
  )
}

n_missing_counts <- sum(is.na(df$Prophage_Count) | is.na(df$Active_Prophage_Count))
if (n_missing_counts) {
  warning(n_missing_counts, " rows have missing counts; missing values are treated as zero.")
}

df <- df %>%
  replace_na(list(Prophage_Count = 0, Active_Prophage_Count = 0))

species_all <- df %>%
  group_by(Species) %>%
  summarise(
    Phylum = majority_label(Phylum),
    Family = majority_label(Family),
    Genus  = majority_label(Genus),
    n_isolates = n(),
    n_lysogens = sum(Prophage_Count > 0),
    n_active_lysogens = sum(Prophage_Count > 0 & Active_Prophage_Count > 0),
    .groups = "drop"
  ) %>%
  mutate(
    lysogeny_prevalence = n_lysogens / n_isolates,
    active_carriage_prevalence = if_else(
      n_lysogens > 0,
      n_active_lysogens / n_lysogens,
      NA_real_
    ),
    exclude_reason = case_when(
      n_isolates < MIN_ISOLATES ~ sprintf("<%d isolates", MIN_ISOLATES),
      n_lysogens < MIN_LYSOGENS ~ sprintf("<%d lysogens", MIN_LYSOGENS),
      TRUE ~ NA_character_
    )
  )

traits <- species_all %>%
  filter(is.na(exclude_reason)) %>%
  mutate(
    Shape_Group = case_when(
      Phylum == "Actinomycetota" ~ "Actinomycetota",
      str_detect(Phylum, "^Bacillota") ~ "Bacillota*",
      Phylum == "Bacteroidota" ~ "Bacteroidota",
      Phylum == "Pseudomonadota" ~ "Pseudomonadota",
      TRUE ~ "Others"
    ),
    Shape_Group = factor(Shape_Group, levels = SHAPE_LEVELS)
  ) %>%
  arrange(Phylum, Genus, Species)

trait_cor <- cor.test(
  traits$lysogeny_prevalence,
  traits$active_carriage_prevalence,
  method = "spearman",
  exact = FALSE
)

message(
  "    Species retained: ", nrow(traits),
  " / ", nrow(species_all),
  sprintf(
    "; Spearman rho between traits = %.3f (asymptotic P = %s)",
    unname(trait_cor$estimate), format_p(trait_cor$p.value)
  )
)

write_tsv(species_all, file.path(DIR_OUT_TBL, "species_traits_all.tsv"))
write_tsv(traits, file.path(DIR_OUT_TBL, "species_traits_analyzed.tsv"))

message("[2/4] Aggregating intra-genus skani distances...")

dt_skani <- fread(INPUT_SKANI_DIST)
required_skani <- c("Genus", "Species_A", "Species_B", "Genomic_Dist", "ANI")
missing_skani <- setdiff(required_skani, names(dt_skani))
if (length(missing_skani)) {
  stop("Missing skani columns: ", paste(missing_skani, collapse = ", "))
}

dt_skani[, `:=`(
  Genus = str_trim(as.character(Genus)),
  Species_A = str_trim(as.character(Species_A)),
  Species_B = str_trim(as.character(Species_B)),
  Genomic_Dist = as.numeric(Genomic_Dist),
  ANI = as.numeric(ANI)
)]

dt_skani <- dt_skani[!is.na(Genomic_Dist) & Species_A != Species_B]
dt_skani[, `:=`(
  S1 = pmin(Species_A, Species_B),
  S2 = pmax(Species_A, Species_B)
)]

pair_agg <- dt_skani[, .(
  Genomic_Dist_Mean = mean(Genomic_Dist),
  ANI_Mean = mean(ANI),
  N_Genome_Pairs = .N
), by = .(Genus, Species_A = S1, Species_B = S2)]

ta <- traits %>%
  transmute(
    Genus, Species_A = Species, Phylum_A = Phylum,
    lys_a = lysogeny_prevalence, act_a = active_carriage_prevalence,
    n_iso_a = n_isolates, n_lys_a = n_lysogens
  )
tb <- traits %>%
  transmute(
    Genus, Species_B = Species, Phylum_B = Phylum,
    lys_b = lysogeny_prevalence, act_b = active_carriage_prevalence,
    n_iso_b = n_isolates, n_lys_b = n_lysogens
  )

pairs <- as_tibble(pair_agg) %>%
  inner_join(ta, by = c("Genus", "Species_A")) %>%
  inner_join(tb, by = c("Genus", "Species_B")) %>%
  filter(Phylum_A == Phylum_B) %>%
  mutate(
    Phylum = Phylum_A,
    d_lysogeny = lys_a - lys_b,
    d_active = act_a - act_b,
    phenotypic_distance = sqrt(d_lysogeny^2 + d_active^2)
  ) %>%
  select(
    Genus, Phylum, Species_A, Species_B,
    Genomic_Dist_Mean, ANI_Mean, N_Genome_Pairs,
    lys_a, act_a, lys_b, act_b,
    n_iso_a, n_lys_a, n_iso_b, n_lys_b,
    d_lysogeny, d_active, phenotypic_distance
  )

if (!nrow(pairs)) stop("No species pairs remain after filtering.")

message(
  "    Species pairs retained: ", nrow(pairs),
  " / ", nrow(pair_agg),
  " aggregated skani pairs"
)

analyzed_species <- unique(c(pairs$Species_A, pairs$Species_B))
qc_no_pair <- traits %>%
  filter(!Species %in% analyzed_species) %>%
  transmute(Species, Genus, Phylum, n_isolates, n_lysogens,
            Reason = "No qualifying congeneric partner")
qc_excluded <- species_all %>%
  filter(!is.na(exclude_reason)) %>%
  select(Species, Genus, Phylum, n_isolates, n_lysogens, exclude_reason)

write_tsv(pairs, file.path(DIR_OUT_TBL, "Result_Final_Merged_Distances.tsv"))
write_tsv(qc_no_pair, file.path(DIR_OUT_TBL, "Report_Species_Without_Pair.tsv"))
write_tsv(qc_excluded, file.path(DIR_OUT_TBL, "Report_Species_Excluded.tsv"))

message("[3/4] Running within-genus permutation tests...")

safe_rho <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]
  y <- y[ok]
  if (length(x) < 3 || sd(x) == 0 || sd(y) == 0) return(NA_real_)
  unname(cor(x, y, method = "spearman"))
}

asym_p <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]
  y <- y[ok]
  if (length(x) < 3 || sd(x) == 0 || sd(y) == 0) return(NA_real_)
  suppressWarnings(
    cor.test(x, y, method = "spearman", exact = FALSE)$p.value
  )
}

traits <- as.data.frame(traits)
genus_index <- split(seq_len(nrow(traits)), traits$Genus)
lys0 <- traits$lysogeny_prevalence
act0 <- traits$active_carriage_prevalence
row_of <- setNames(seq_len(nrow(traits)), traits$Species)
ia <- unname(row_of[pairs$Species_A])
ib <- unname(row_of[pairs$Species_B])
stopifnot(!anyNA(ia), !anyNA(ib))

geno <- pairs$Genomic_Dist_Mean
phylum_vec <- pairs$Phylum
phyla <- sort(unique(phylum_vec))
phylum_index <- lapply(setNames(phyla, phyla), function(p) which(phylum_vec == p))

obs_d <- pairs$phenotypic_distance
obs_global <- safe_rho(geno, obs_d)
obs_phylum <- sapply(phylum_index, function(k) safe_rho(geno[k], obs_d[k]))

null_global <- rep(NA_real_, N_PERM)
null_phylum <- matrix(
  NA_real_, nrow = N_PERM, ncol = length(phyla),
  dimnames = list(NULL, phyla)
)

for (perm in seq_len(N_PERM)) {
  lys <- lys0
  act <- act0
  for (ii in genus_index) {
    if (length(ii) < 2) next
    shuffled <- ii[sample.int(length(ii))]
    lys[ii] <- lys0[shuffled]
    act[ii] <- act0[shuffled]
  }

  d <- sqrt((lys[ia] - lys[ib])^2 + (act[ia] - act[ib])^2)
  null_global[perm] <- safe_rho(geno, d)
  null_phylum[perm, ] <- sapply(phylum_index, function(k) safe_rho(geno[k], d[k]))

  if (perm %% 100 == 0) message("    Permutation ", perm, " / ", N_PERM)
}

perm_p <- function(obs, null) {
  null <- null[is.finite(null)]
  if (!is.finite(obs) || !length(null)) return(NA_real_)
  (sum(abs(null) >= abs(obs)) + 1) / (length(null) + 1)
}

global_stats <- tibble(
  Phylum = "Global (all pairs)",
  n_pairs = nrow(pairs),
  rho = obs_global,
  p_permutation = perm_p(obs_global, null_global),
  p_asymptotic = asym_p(geno, obs_d),
  p_fdr = NA_real_
)

phylum_stats <- tibble(
  Phylum = phyla,
  n_pairs = sapply(phylum_index, length),
  rho = obs_phylum,
  p_permutation = vapply(phyla, function(p) perm_p(obs_phylum[[p]], null_phylum[, p]), numeric(1)),
  p_asymptotic = sapply(phylum_index, function(k) asym_p(geno[k], obs_d[k]))
) %>%
  filter(n_pairs >= 3, is.finite(rho)) %>%
  arrange(desc(n_pairs)) %>%
  mutate(p_fdr = p.adjust(p_permutation, method = "BH"))

correlation_stats <- bind_rows(global_stats, phylum_stats) %>%
  mutate(
    stat_label = sprintf(
      "%s (n=%d): rho=%.2f, Pperm=%s",
      Phylum, n_pairs, rho, format_p(p_permutation)
    ),
    stat_label = factor(stat_label, levels = stat_label)
  )

write_tsv(correlation_stats, file.path(DIR_OUT_TBL, "spearman_permutation_stats.tsv"))
write_tsv(
  tibble(permutation = seq_len(N_PERM), rho = null_global),
  file.path(DIR_OUT_TBL, "global_permutation_null_rhos.tsv")
)

message("[4/4] Plotting...")

all_phyla <- sort(unique(c(traits$Phylum, pairs$Phylum)))
my_palette <- CUSTOM_PHYLUM_COLORS[intersect(names(CUSTOM_PHYLUM_COLORS), all_phyla)]
missing_phyla <- setdiff(all_phyla, names(my_palette))
if (length(missing_phyla)) {
  base_cols <- pal_npg("nrc")(min(length(missing_phyla), 10))
  extra_cols <- if (length(missing_phyla) > length(base_cols)) {
    colorRampPalette(base_cols)(length(missing_phyla))
  } else {
    base_cols[seq_along(missing_phyla)]
  }
  names(extra_cols) <- missing_phyla
  my_palette <- c(my_palette, extra_cols)
}

plot_species_map <- function(df, title) {
  ellipse_df <- df %>%
    group_by(Phylum) %>%
    filter(
      n() >= 5,
      sd(lysogeny_prevalence) > 1e-8,
      sd(active_carriage_prevalence) > 1e-8
    ) %>%
    ungroup()

  p <- ggplot(df, aes(lysogeny_prevalence, active_carriage_prevalence))
  if (nrow(ellipse_df)) {
    p <- p + stat_ellipse(
      data = ellipse_df,
      aes(color = Phylum),
      type = "t",
      level = 0.90,
      linewidth = 1.1,
      show.legend = FALSE
    )
  }

  p +
    geom_point(
      aes(fill = Phylum, shape = Shape_Group, size = n_isolates),
      color = "black",
      stroke = 0.3,
      alpha = 0.95
    ) +
    scale_shape_manual(values = CUSTOM_SHAPES, drop = FALSE, name = "Phylum group") +
    scale_fill_manual(values = my_palette, name = "Phylum") +
    scale_color_manual(values = my_palette, guide = "none") +
    scale_size_continuous(range = c(2, 9), name = "Isolates (n)") +
    coord_fixed(xlim = c(-0.03, 1.03), ylim = c(-0.03, 1.03)) +
    guides(
      fill = guide_legend(override.aes = list(shape = 21, size = 4), order = 1),
      shape = guide_legend(override.aes = list(size = 4, fill = "grey60"), order = 2),
      size = guide_legend(order = 3)
    ) +
    labs(
      title = title,
      x = "Lysogeny prevalence",
      y = "Active prophage carriage prevalence\n(among lysogens)"
    ) +
    theme_bw(base_size = 14) +
    theme(
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", linewidth = 1.1, fill = NA)
    )
}

p_all <- plot_species_map(
  traits,
  "A. Species-level lysogeny and active prophage carriage"
) +
  labs(subtitle = sprintf(
    "Species with ≥%d isolates and ≥%d lysogens (n=%d); trait–trait Spearman rho=%.2f, P=%s",
    MIN_ISOLATES, MIN_LYSOGENS, nrow(traits),
    unname(trait_cor$estimate), format_p(trait_cor$p.value)
  ))

p_rho <- ggplot(phylum_stats, aes(rho, reorder(Phylum, rho))) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey55") +
  geom_point(aes(color = Phylum, size = n_pairs), alpha = 0.95) +
  scale_color_manual(values = my_palette, guide = "none") +
  scale_size_continuous(range = c(2.5, 8), name = "Species pairs") +
  labs(
    title = "B. Association with genomic distance",
    subtitle = sprintf(
      "Global rho=%.2f; permutation P=%s (%d within-genus permutations)",
      global_stats$rho, format_p(global_stats$p_permutation), N_PERM
    ),
    x = "Spearman rho",
    y = NULL
  ) +
  theme_bw(base_size = 14) +
  theme(
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", linewidth = 1.1, fill = NA)
  )

ggsave(
  file.path(DIR_OUT_FIG, "Species_Phenotype_AllPhyla.pdf"),
  p_all + p_rho + plot_layout(widths = c(1.7, 1)),
  width = 16, height = 7.5, device = cairo_pdf
)

selected_traits <- traits %>% filter(Phylum %in% TARGET_PHYLA)
if (nrow(selected_traits)) {
  ggsave(
    file.path(DIR_OUT_FIG, "Species_Phenotype_Selected.pdf"),
    plot_species_map(selected_traits, "Selected phyla"),
    width = 10, height = 7.5, device = cairo_pdf
  )
}

pt_alpha <- if (nrow(pairs) > 8000) 0.25 else if (nrow(pairs) > 2000) 0.45 else 0.80
pt_size  <- if (nrow(pairs) > 8000) 1.2 else 2.2

p_landscape <- ggplot(pairs, aes(Genomic_Dist_Mean, phenotypic_distance)) +
  geom_point(aes(color = Phylum), alpha = pt_alpha, size = pt_size) +
  scale_color_manual(values = my_palette, name = "Phylum") +
  geom_smooth(
    aes(group = 1),
    method = "lm",
    color = "#1A1A1A",
    linewidth = 1.2,
    fill = "grey60",
    alpha = 0.35
  ) +
  geom_point(
    data = correlation_stats,
    aes(x = min(pairs$Genomic_Dist_Mean), y = min(pairs$phenotypic_distance), shape = stat_label),
    alpha = 0
  ) +
  guides(
    color = guide_legend(order = 1, override.aes = list(size = 4, alpha = 1)),
    shape = guide_legend(
      title = "Spearman permutation test",
      order = 2,
      override.aes = list(alpha = 1, size = 0, stroke = 0)
    )
  ) +
  labs(
    title = "Genomic and phenotypic divergence of congeneric species",
    subtitle = sprintf(
      "%d species pairs | grey line is descriptive OLS only; significance is permutation-based",
      nrow(pairs)
    ),
    x = "Mean genomic distance (1 − ANI)",
    y = "Phenotypic Euclidean distance"
  ) +
  theme_bw(base_size = 14) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "grey95"),
    panel.border = element_rect(color = "black", linewidth = 1.2, fill = NA),
    plot.title = element_text(face = "bold")
  )

ggsave(
  file.path(DIR_OUT_FIG, "Result_Final_Scatter_Plot_Professional.pdf"),
  p_landscape,
  width = 12, height = 7.5, device = cairo_pdf
)

message("Done.")
message("Tables: ", DIR_OUT_TBL)
message("Plots:  ", DIR_OUT_FIG)
