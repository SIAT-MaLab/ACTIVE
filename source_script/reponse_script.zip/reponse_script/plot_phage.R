#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(scales)
  library(stringr)
})

DEFAULT_SPA_DIR       <- ""
DEFAULT_OUT_DIR       <- "./plot_output/genome_dashboards"
DEFAULT_GENOME_DIR    <- ""
DEFAULT_BUFFER        <- 30000L
DEFAULT_FONT          <- "Arial"
DEFAULT_MIN_CONTIG    <- 8000L
DEFAULT_BIN_SIZE      <- 500L
DEFAULT_LOESS_SPAN    <- 0.15
DEFAULT_CONTIG_EXPAND <- 0.9

label_host <- "Host Background"
label_mgs  <- "Host MGS"
label_phag <- "Active Phage"

color_host      <- "#222222"
color_mgs       <- "#377EB8"
color_phag      <- "#E41A1C"
color_contig_hl <- "#EFEFEF"
color_phage_hl  <- "#D0E1F9"

custom_colors <- setNames(
  c(color_host, color_mgs, color_phag),
  c(label_host, label_mgs, label_phag)
)
line_widths <- setNames(
  c(1.6, 0.55, 0.70),
  c(label_host, label_mgs, label_phag)
)

print_help <- function() {
  cat(paste0(
    "Draw SPA depth plots per genome: full genome, contig-focused, and local window+density for each prophage.\n",
    "The full genome plot highlights the contig range and prophage positions.\n\n",
    "Usage:\n",
    "  Rscript plot.final.R -i <SPA_output_dir> -o <plot_dir> [options]\n\n",
    "Options:\n",
    "  -i, --spa-dir DIR     SPA result root directory (contains mapping_results)\n",
    "  -o, --out-dir DIR     Output directory for plots\n",
    "  -g, --genome-dir DIR  Reference fasta/fai directory\n",
    "      --buffer N        Bases flanking prophage window [default: 30000]\n",
    "      --min-contig N    Minimum contig length for full genome plot [default: 8000]\n",
    "      --bin-size N      Bin width (bp) [default: 500; <=1 for per-base]\n",
    "      --loess           Additional LOESS smoothing plot\n",
    "      --no-loess        Disable LOESS smoothing (default)\n",
    "      --loess-span S    LOESS span [default: 0.15]\n",
    "      --font NAME       PDF font [default: Arial]\n",
    "      --list            List tasks only, do not plot\n",
    "  -h, --help            Show this help\n"
  ))
}

parse_args <- function(args) {
  opt <- list(
    spa_dir    = DEFAULT_SPA_DIR,
    out_dir    = DEFAULT_OUT_DIR,
    genome_dir = DEFAULT_GENOME_DIR,
    buffer     = DEFAULT_BUFFER,
    font       = DEFAULT_FONT,
    min_contig = DEFAULT_MIN_CONTIG,
    bin_size   = DEFAULT_BIN_SIZE,
    loess      = FALSE,
    loess_span = DEFAULT_LOESS_SPAN,
    list_only  = FALSE
  )
  if (!length(args)) return(opt)

  i <- 1L
  while (i <= length(args)) {
    a <- args[[i]]
    take <- function() {
      if (i >= length(args)) stop("Argument ", a, " requires a value", call. = FALSE)
      i <<- i + 1L
      args[[i]]
    }
    if (a %in% c("-h", "--help")) {
      print_help(); quit(save = "no", status = 0)
    } else if (a %in% c("-i", "--spa-dir")) {
      opt$spa_dir <- take()
    } else if (a %in% c("-o", "--out-dir")) {
      opt$out_dir <- take()
    } else if (a %in% c("-g", "--genome-dir")) {
      opt$genome_dir <- take()
    } else if (a == "--buffer") {
      opt$buffer <- as.integer(take())
    } else if (a == "--min-contig") {
      opt$min_contig <- as.integer(take())
    } else if (a == "--bin-size") {
      opt$bin_size <- as.integer(take())
    } else if (a == "--loess") {
      opt$loess <- TRUE
    } else if (a == "--no-loess") {
      opt$loess <- FALSE
    } else if (a == "--loess-span") {
      opt$loess_span <- as.numeric(take())
    } else if (a == "--font") {
      opt$font <- take()
    } else if (a == "--list") {
      opt$list_only <- TRUE
    } else {
      stop("Unknown argument: ", a, call. = FALSE)
    }
    i <- i + 1L
  }
  opt
}

opt <- parse_args(commandArgs(trailingOnly = TRUE))
if (!nzchar(opt$spa_dir)) { print_help(); stop("Must specify -i / --spa-dir", call. = FALSE) }

resolve_map_dir <- function(spa_dir) {
  cand <- file.path(spa_dir, "mapping_results")
  if (dir.exists(cand)) return(normalizePath(cand))
  if (dir.exists(spa_dir)) return(normalizePath(spa_dir))
  stop("Cannot find mapping_results: ", spa_dir, call. = FALSE)
}

map_dir    <- resolve_map_dir(opt$spa_dir)
genome_dir <- if (nzchar(opt$genome_dir)) opt$genome_dir else NULL
if (!dir.exists(opt$out_dir)) dir.create(opt$out_dir, recursive = TRUE, showWarnings = FALSE)

summary_contig_file <- file.path(opt$out_dir, "bgcontig_summary.tsv")
summary_filter_file <- file.path(opt$out_dir, "contig_filter_summary.tsv")

find_existing <- function(...) {
  for (p in c(...)) if (!is.null(p) && file.exists(p)) return(p)
  NULL
}

read_depth <- function(path) {
  if (is.null(path) || !file.exists(path)) return(NULL)
  dt <- tryCatch(fread(path, header = FALSE, select = 1:3, col.names = c("contig", "position", "depth")),
                 error = function(e) NULL)
  if (is.null(dt) || !nrow(dt)) return(NULL)
  dt[, `:=`(position = as.numeric(position), depth = as.numeric(depth))]
  dt <- dt[is.finite(position) & is.finite(depth)]
  dt[]
}

parse_phage_filename <- function(path) {
  bn <- sub("\\.gz$", "", basename(path))
  m <- str_match(bn, "^phage_depth_(.+)_([0-9]+)_([0-9]+)\\.txt$")
  if (anyNA(m[1, ])) return(NULL)
  list(contig = m[1, 2], start = as.integer(m[1, 3]), end = as.integer(m[1, 4]))
}

read_fai_lengths <- function(genome_dir, genome) {
  if (is.null(genome_dir)) return(NULL)
  fai <- find_existing(
    file.path(genome_dir, paste0(genome, ".fasta.fai")),
    file.path(genome_dir, paste0(genome, ".fa.fai")),
    file.path(genome_dir, paste0(genome, ".fna.fai")),
    file.path(genome_dir, paste0(genome, ".fai"))
  )
  if (is.null(fai)) return(NULL)
  dt <- fread(fai, header = FALSE, select = 1:2, col.names = c("contig", "length"))
  dt[, length := as.numeric(length)][]
}

read_bed_lengths <- function(data_dir, genome) {
  bed <- file.path(data_dir, paste0(genome, ".all.bed"))
  if (!file.exists(bed)) return(NULL)
  dt <- fread(bed, header = FALSE, select = 1:3, col.names = c("contig", "start0", "end"))
  dt[, .(contig, length = as.numeric(end))]
}

infer_lengths <- function(dt_list) {
  keep <- dt_list[!vapply(dt_list, is.null, logical(1))]
  if (!length(keep)) return(NULL)
  all_dt <- rbindlist(keep, use.names = TRUE, fill = TRUE)
  all_dt[, .(length = max(position)), by = contig]
}

build_offsets <- function(len_dt) {
  len_dt <- copy(len_dt)[is.finite(length) & length > 0]
  if (!nrow(len_dt)) stop("No valid contig lengths")
  len_dt[, offset := c(0, cumsum(length)[-.N])]
  len_dt[, end_global := offset + length]
  len_dt[]
}

add_global_pos <- function(dt, off_dt) {
  if (is.null(dt) || !nrow(dt)) return(dt)
  out <- copy(dt)
  out[off_dt, on = "contig", global_pos := position + i.offset]
  out <- out[!is.na(global_pos)]
  if (nrow(out)) setorder(out, global_pos)
  out[]
}

filter_to_contigs <- function(dt, keep_contigs) {
  if (is.null(dt) || !nrow(dt)) return(dt)
  dt[contig %in% keep_contigs]
}

fmt_int <- function(x) format(as.numeric(x), big.mark = ",", scientific = FALSE, trim = TRUE)
safe_token <- function(x) gsub("[^A-Za-z0-9._-]", "_", as.character(x))

typical_step <- function(pos) {
  d <- diff(pos); d <- d[is.finite(d) & d > 0]
  if (!length(d)) return(1)
  as.numeric(stats::median(d))
}

mark_line_segments <- function(dt, gap = NULL) {
  if (is.null(dt) || !nrow(dt)) return(dt)
  out <- copy(dt)
  setorder(out, global_pos)
  step <- typical_step(out$global_pos)
  if (is.null(gap)) gap <- max(step * 8, 20)
  out[, seg := cumsum(c(0L, as.integer(diff(global_pos) > gap)))]
  out[]
}

downsample_depth <- function(dt, max_points = 80000L) {
  if (is.null(dt) || nrow(dt) <= max_points) return(copy(dt))
  out <- mark_line_segments(copy(dt))
  k <- max(1L, as.integer(ceiling(nrow(out) / max_points)))
  out[, `:=`(i = seq_len(.N), n = .N), by = seg]
  out <- out[i == 1L | i == n | (i %% k == 0L)]
  out[, `:=`(i = NULL, n = NULL, seg = NULL)][]
}

bin_mean_depth <- function(dt, bin_size) {
  if (is.null(dt) || !nrow(dt) || is.na(bin_size) || bin_size <= 1) return(copy(dt))
  out <- copy(dt)
  out[, bin_id := as.integer(floor((pmax(position, 1) - 1) / bin_size))]
  out <- out[, .(position = bin_id[1] * bin_size + (bin_size + 1) / 2,
                 depth = mean(depth, na.rm = TRUE)), by = .(contig, bin_id)]
  out[, bin_id := NULL]
  setorder(out, contig, position)
  out[]
}

prepare_full_track <- function(dt, off_dt, bin_size) {
  if (is.null(dt) || !nrow(dt)) return(NULL)
  binned <- bin_mean_depth(dt[, .(contig, position, depth)], bin_size)
  add_global_pos(binned, off_dt)
}

apply_loess <- function(dt, span = 0.15, gap = NULL) {
  if (is.null(dt) || !nrow(dt)) return(dt)
  out <- mark_line_segments(copy(dt), gap = gap)
  out[, depth_fit := NA_real_]
  keys <- unique(out[, .(contig, seg)])
  for (i in seq_len(nrow(keys))) {
    idx <- out$contig == keys$contig[i] & out$seg == keys$seg[i]
    n <- sum(idx)
    if (n < 7L) { out[idx, depth_fit := depth]; next }
    dsub <- out[idx]
    setorder(dsub, global_pos)
    use_span <- min(1, max(span, 7 / n))
    fit <- tryCatch(
      stats::loess(depth ~ global_pos, data = dsub, span = use_span, degree = 2, surface = "direct"),
      error = function(e) tryCatch(
        stats::loess(depth ~ global_pos, data = dsub, span = min(1, max(use_span, 4 / n)), degree = 1, surface = "direct"),
        error = function(e) NULL
      )
    )
    if (is.null(fit)) out[idx, depth_fit := depth] else out[idx, depth_fit := stats::predict(fit, newdata = dsub)]
  }
  out[is.na(depth_fit), depth_fit := depth]
  out[, depth := pmax(depth_fit, 0)][, `:=`(depth_fit = NULL, seg = NULL)]
  setorder(out, global_pos)
  out[]
}

safe_var_fix <- function(x) {
  if (length(x) >= 2 && (is.na(var(x)) || var(x) == 0)) {
    x[1] <- x[1] + 1e-6; x[2] <- x[2] - 1e-6
  }
  x
}

build_contig_groups <- function(phage_list, len_dt, expand_frac = DEFAULT_CONTIG_EXPAND) {
  if (!length(phage_list) || is.null(len_dt) || !nrow(len_dt)) return(list())
  n <- nrow(len_dt)
  names_all <- len_dt$contig
  groups <- list()

  for (ph in phage_list) {
    idx <- match(ph$contig, names_all)
    if (is.na(idx)) next
    clen <- as.numeric(len_dt$length[idx])
    plen <- as.numeric(ph$end) - as.numeric(ph$start) + 1
    frac <- if (is.finite(clen) && clen > 0) plen / clen else NA_real_
    keep <- idx
    want_expand <- is.finite(frac) && frac >= expand_frac
    if (isTRUE(want_expand)) {
      if (idx > 1L) keep <- c(idx - 1L, keep)
      if (idx < n) keep <- c(keep, idx + 1L)
    }
    keep <- sort(unique(keep))
    contigs <- names_all[keep]
    key <- paste(contigs, collapse = "\001")

    if (is.null(groups[[key]])) {
      groups[[key]] <- list(contigs = contigs, center = ph$contig,
                            expanded = length(contigs) > 1L, wanted_expand = want_expand, phages = list())
    }
    groups[[key]]$phages[[length(groups[[key]]$phages) + 1L]] <- list(
      label = ph$label, contig = ph$contig, start = ph$start, end = ph$end, frac = frac, pretty = ph$pretty
    )
  }
  unname(groups)
}

shared_theme <- function(font, legend = TRUE) {
  theme_classic(base_family = font) +
    theme(
      plot.title    = element_text(hjust = 0.5, face = "bold", size = 13, color = "black"),
      plot.subtitle = element_text(hjust = 0.5, size = 9.5, color = "grey20"),
      axis.title    = element_text(size = 13, face = "bold", color = "black"),
      axis.text     = element_text(size = 11, color = "black"),
      axis.line     = element_line(color = "black", linewidth = 0.8),
      axis.ticks    = element_line(color = "black", linewidth = 0.8),
      legend.position = if (legend) "top" else "none",
      legend.title  = element_blank(),
      legend.text   = element_text(size = 11),
      legend.background = element_blank()
    )
}

prep_line_dt <- function(dt, group, downsample = FALSE, gap = NULL) {
  if (is.null(dt) || !nrow(dt)) return(NULL)
  tmp <- copy(dt)
  if (isTRUE(downsample)) tmp <- downsample_depth(tmp)
  tmp <- mark_line_segments(tmp, gap = gap)
  tmp[, Group := group]
  tmp[, .(global_pos, depth, Group, seg)]
}

make_profile <- function(dt_host, dt_phage, dt_mgs,
                         xmin, xmax, y_lab, title, subtitle,
                         contig_regions, phage_regions, hline_y,
                         font, show_mgs_points = FALSE,
                         show_labels = FALSE, legend = TRUE,
                         downsample_host = FALSE,
                         line_gap = NULL) {
  host_dt  <- prep_line_dt(dt_host, label_host, downsample_host, gap = line_gap)
  phage_dt <- prep_line_dt(dt_phage, label_phag, FALSE, gap = line_gap)

  p <- ggplot()

  if (!is.null(contig_regions) && nrow(contig_regions)) {
    c_sub <- contig_regions[end_g >= xmin & start_g <= xmax]
    if (nrow(c_sub)) {
      p <- p + geom_rect(
        data = c_sub,
        aes(xmin = pmax(start_g, xmin), xmax = pmin(end_g, xmax), ymin = -Inf, ymax = Inf),
        fill = color_contig_hl, color = "grey80", linetype = "dashed", linewidth = 0.4,
        inherit.aes = FALSE
      )
    }
  }

  if (!is.null(phage_regions) && nrow(phage_regions)) {
    p_sub <- phage_regions[end_g >= xmin & start_g <= xmax]
    if (nrow(p_sub)) {
      p <- p + geom_rect(
        data = p_sub,
        aes(xmin = start_g, xmax = end_g, ymin = -Inf, ymax = Inf),
        fill = color_phage_hl, color = NA, inherit.aes = FALSE
      )
    }
  }

  add_line <- function(p, dt) {
    if (is.null(dt) || !nrow(dt)) return(p)
    dt <- dt[global_pos >= xmin & global_pos <= xmax]
    if (!nrow(dt)) return(p)
    dt[, Group := factor(Group, levels = c(label_host, label_mgs, label_phag))]
    p + geom_line(
      data = dt,
      aes(x = global_pos, y = depth, color = Group,
          group = interaction(Group, seg), linewidth = Group),
      lineend = "round", na.rm = TRUE
    )
  }

  p <- add_line(p, phage_dt)
  p <- add_line(p, host_dt)

  if (isTRUE(show_mgs_points) && !is.null(dt_mgs) && nrow(dt_mgs)) {
    mgs_win <- dt_mgs[global_pos >= xmin & global_pos <= xmax]
    if (nrow(mgs_win)) {
      mgs_win[, Group := factor(label_mgs, levels = c(label_host, label_mgs, label_phag))]
      p <- p + geom_point(
        data = mgs_win, aes(x = global_pos, y = depth, color = Group),
        size = 0.45, alpha = 0.75, na.rm = TRUE
      )
    }
  }

  if (is.finite(hline_y)) {
    p <- p + geom_hline(yintercept = hline_y, linetype = "dotted", color = "grey20", linewidth = 0.45)
  }

  if (isTRUE(show_labels) && !is.null(phage_regions) && nrow(phage_regions)) {
    p_sub <- phage_regions[end_g >= xmin & start_g <= xmax]
    if (nrow(p_sub)) {
      p <- p + geom_text(
        data = p_sub, aes(x = (start_g + end_g) / 2, y = Inf, label = label),
        vjust = 1.3, size = 3.1, fontface = "bold", family = font, inherit.aes = FALSE
      )
    }
  }

  p +
    scale_color_manual(values = custom_colors, drop = FALSE) +
    scale_linewidth_manual(values = line_widths, guide = "none") +
    labs(title = title, subtitle = subtitle, x = "Global position (bp)", y = y_lab) +
    shared_theme(font, legend = legend) +
    coord_cartesian(xlim = c(xmin, xmax), expand = FALSE)
}

make_density <- function(dt_host, dt_phage, dt_mgs, x_lab, title, font, legend = TRUE) {
  chunks <- list()
  if (!is.null(dt_host) && nrow(dt_host)) chunks[[length(chunks) + 1L]] <- data.table(depth = dt_host$depth, Group = label_host)
  if (!is.null(dt_mgs) && nrow(dt_mgs))   chunks[[length(chunks) + 1L]] <- data.table(depth = dt_mgs$depth, Group = label_mgs)
  if (!is.null(dt_phage) && nrow(dt_phage)) chunks[[length(chunks) + 1L]] <- data.table(depth = dt_phage$depth, Group = label_phag)
  if (!length(chunks)) return(ggplot() + theme_void() + ggtitle("Density Data Missing"))

  plot_dt <- rbindlist(chunks)[is.finite(depth)]
  plot_dt[, Group := factor(Group, levels = c(label_host, label_mgs, label_phag))]
  plot_dt[, depth := safe_var_fix(depth), by = Group]
  plot_dt[, depth := pmax(depth, 1e-6)]

  ggplot(plot_dt, aes(x = depth, fill = Group)) +
    geom_density(color = "black", alpha = 0.5, linewidth = 0.45, na.rm = TRUE) +
    scale_x_log10(labels = label_scientific()) +
    scale_fill_manual(values = custom_colors, drop = FALSE) +
    labs(title = title, x = x_lab, y = "Density") +
    shared_theme(font, legend = legend)
}

save_pdf <- function(path, plot, width, height, font) {
  ok <- FALSE
  if (isTRUE(capabilities("cairo"))) {
    ok <- tryCatch({
      ggsave(path, plot, width = width, height = height, device = cairo_pdf, family = font)
      TRUE
    }, error = function(e) FALSE)
  }
  if (!ok) ggsave(path, plot, width = width, height = height, device = "pdf")
}

save_overview <- function(h_src, p_src, m_src, off_dt, genome_end,
                          contig_regions, phage_regions, y_lab, title_main, subtitle,
                          hline, opt, out_prefix, show_mgs_points) {
  h_bin <- prepare_full_track(h_src, off_dt, opt$bin_size)
  p_bin <- prepare_full_track(p_src, off_dt, opt$bin_size)
  m_bin <- prepare_full_track(m_src, off_dt, opt$bin_size)
  line_gap <- if (opt$bin_size > 1) 1.5 * opt$bin_size else NULL

  draw_one <- function(h_use, p_use, m_use, extra_note, suffix) {
    p_ov <- make_profile(
      h_use, p_use, m_use, 1, genome_end, y_lab,
      title_main, paste(c(subtitle, extra_note), collapse = "  |  "),
      contig_regions, phage_regions, hline, opt$font,
      show_mgs_points = show_mgs_points,
      show_labels = TRUE,
      legend = TRUE,
      downsample_host = opt$bin_size <= 1,
      line_gap = line_gap
    )
    out_file <- paste0(out_prefix, suffix, ".pdf")
    save_pdf(out_file, p_ov, width = 14, height = 4.8, font = opt$font)
  }

  bin_note <- if (opt$bin_size <= 1) "per-base depth" else sprintf("binned mean %sbp", fmt_int(opt$bin_size))
  draw_one(h_bin, p_bin, m_bin, bin_note, "")

  if (isTRUE(opt$loess)) {
    loess_note <- sprintf("%s + LOESS (span=%.2f)", bin_note, opt$loess_span)
    draw_one(
      apply_loess(h_bin, span = opt$loess_span, gap = line_gap),
      apply_loess(p_bin, span = opt$loess_span, gap = line_gap),
      apply_loess(m_bin, span = opt$loess_span, gap = line_gap),
      loess_note, "_loess"
    )
  }
}

process_genome <- function(job, opt, genome_dir) {
  sample <- job$sample
  genome <- job$genome
  tag <- paste(sample, genome, sep = " | ")

  dt_host_raw <- read_depth(job$host_file)
  dt_mgs_raw  <- read_depth(job$mgs_file)

  phage_list <- list()
  for (ph in job$phages) {
    dt <- read_depth(ph$file)
    if (!is.null(dt) && nrow(dt)) {
      phage_list[[length(phage_list) + 1L]] <- list(
        contig = ph$contig, start = ph$start, end = ph$end, dt = dt
      )
    }
  }
  if (!length(phage_list)) return(invisible(NULL))

  len_dt <- read_fai_lengths(genome_dir, genome)
  if (is.null(len_dt)) len_dt <- read_bed_lengths(job$data_dir, genome)
  if (is.null(len_dt)) len_dt <- infer_lengths(c(list(dt_host_raw, dt_mgs_raw), lapply(phage_list, `[[`, "dt")))

  off_all <- build_offsets(len_dt)
  genome_end_all <- max(off_all$end_global)

  dt_host <- add_global_pos(dt_host_raw, off_all)
  dt_mgs  <- add_global_pos(dt_mgs_raw, off_all)

  for (i in seq_along(phage_list)) {
    phage_list[[i]]$dt <- add_global_pos(phage_list[[i]]$dt, off_all)
    off <- off_all[contig == phage_list[[i]]$contig, offset]
    phage_list[[i]]$start_g <- off + phage_list[[i]]$start
    phage_list[[i]]$end_g   <- off + phage_list[[i]]$end
  }

  o <- order(vapply(phage_list, `[[`, numeric(1), "start_g"))
  phage_list <- phage_list[o]
  for (i in seq_along(phage_list)) {
    phage_list[[i]]$label  <- paste0("P", i)
    phage_list[[i]]$pretty <- sprintf("%s %s:%s-%s", phage_list[[i]]$label, phage_list[[i]]$contig, phage_list[[i]]$start, phage_list[[i]]$end)
  }

  regions_all <- rbindlist(lapply(phage_list, function(ph) {
    data.table(start_g = ph$start_g, end_g = ph$end_g, label = ph$label)
  }))
  dt_phage_all <- rbindlist(lapply(phage_list, `[[`, "dt"), use.names = TRUE, fill = TRUE)

  phage_contigs_unique <- unique(vapply(phage_list, `[[`, character(1), "contig"))
  contig_regions_all <- off_all[contig %in% phage_contigs_unique, .(start_g = offset, end_g = end_global, contig)]

  if (!is.null(dt_host) && nrow(dt_host)) {
    ref_median <- stats::median(dt_host$depth, na.rm = TRUE)
    ref_name <- "host_nonphage"
  } else if (!is.null(dt_mgs) && nrow(dt_mgs)) {
    ref_median <- stats::median(dt_mgs$depth, na.rm = TRUE)
    ref_name <- "MGS"
  } else {
    ref_median <- NA_real_; ref_name <- "none"
  }

  show_mgs_full <- identical(ref_name, "MGS")
  scale_dt <- function(dt, mode) {
    if (is.null(dt) || !nrow(dt)) return(dt)
    out <- copy(dt)
    if (mode == "norm" && is.finite(ref_median) && ref_median > 0) out[, depth := depth / ref_median]
    out[]
  }
  safe_stem <- safe_token(paste(sample, genome, sep = "_"))

  len_keep <- len_dt[is.finite(length) & length >= opt$min_contig]
  if (nrow(len_keep) > 0) {
    off_full <- build_offsets(len_keep)
    genome_end_full <- max(off_full$end_global)
    keep_names <- len_keep$contig

    dt_h_full <- filter_to_contigs(dt_host_raw, keep_names)
    dt_m_full <- filter_to_contigs(dt_mgs_raw, keep_names)
    phage_full <- Filter(function(ph) ph$contig %in% keep_names, phage_list)
    dt_p_full <- if (length(phage_full)) rbindlist(lapply(phage_full, function(ph) ph$dt[, .(contig, position, depth)]), use.names = TRUE, fill = TRUE) else NULL

    regions_full <- if (length(phage_full)) {
      rbindlist(lapply(phage_full, function(ph) {
        off <- off_full[contig == ph$contig, offset]
        data.table(start_g = off + ph$start, end_g = off + ph$end, label = ph$label)
      }))
    } else data.table(start_g = numeric(), end_g = numeric(), label = character())

    contig_regs_full <- off_full[contig %in% phage_contigs_unique, .(start_g = offset, end_g = end_global, contig)]

    for (mode in c("raw", "norm")) {
      if (mode == "norm" && (!is.finite(ref_median) || ref_median <= 0)) next
      y_lab <- if (mode == "raw") "Depth" else paste0("Depth / ", ref_name, " median")
      hline <- if (mode == "raw") ref_median else 1
      save_overview(
        scale_dt(dt_h_full, mode), scale_dt(dt_p_full, mode), scale_dt(dt_m_full, mode),
        off_full, genome_end_full, contig_regs_full, regions_full,
        y_lab, paste0("Genome depth (", mode, "): ", tag),
        sprintf("%s median=%.3f | contigs>=%sbp (shaded: phage-carrying contigs)", ref_name, ref_median, fmt_int(opt$min_contig)),
        hline, opt, file.path(opt$out_dir, paste0(safe_stem, "_full_", mode)), show_mgs_full
      )
    }
  }

  groups <- build_contig_groups(phage_list, len_dt, DEFAULT_CONTIG_EXPAND)
  for (grp in groups) {
    len_sub <- len_dt[contig %in% grp$contigs]
    if (!nrow(len_sub)) next
    off_sub <- build_offsets(len_sub)
    end_sub <- max(off_sub$end_global)

    phage_on <- Filter(function(ph) ph$contig %in% grp$contigs, phage_list)
    p_src_raw <- if (length(phage_on)) rbindlist(lapply(phage_on, function(ph) ph$dt[, .(contig, position, depth)]), use.names = TRUE, fill = TRUE) else NULL

    regions_sub <- if (length(phage_on)) {
      rbindlist(lapply(phage_on, function(ph) {
        off <- off_sub[contig == ph$contig, offset]
        data.table(start_g = off + ph$start, end_g = off + ph$end, label = ph$label)
      }))
    } else data.table(start_g = numeric(), end_g = numeric(), label = character())

    contig_regs_sub <- off_sub[contig %in% grp$center, .(start_g = offset, end_g = end_global, contig)]

    for (mode in c("raw", "norm")) {
      if (mode == "norm" && (!is.finite(ref_median) || ref_median <= 0)) next
      y_lab <- if (mode == "raw") "Depth" else paste0("Depth / ", ref_name, " median")
      hline <- if (mode == "raw") ref_median else 1
      file_tag <- paste0(safe_stem, "_", safe_token(grp$center), if (isTRUE(grp$expanded)) "_plusflank" else "", "_bgcontig_", mode)
      title_main <- paste0("Contig depth (", mode, "): ", tag, " | ", paste(vapply(grp$phages, `[[`, character(1), "label"), collapse = ","))

      save_overview(
        scale_dt(filter_to_contigs(dt_host_raw, grp$contigs), mode),
        scale_dt(p_src_raw, mode),
        scale_dt(filter_to_contigs(dt_mgs_raw, grp$contigs), mode),
        off_sub, end_sub, contig_regs_sub, regions_sub,
        y_lab, title_main,
        sprintf("%s median=%.3f | Host contig: %s", ref_name, ref_median, grp$center),
        hline, opt, file.path(opt$out_dir, file_tag), show_mgs_full
      )
    }
  }

  for (mode in c("raw", "norm")) {
    if (mode == "norm" && (!is.finite(ref_median) || ref_median <= 0)) next
    h_scaled <- scale_dt(dt_host, mode)
    m_scaled <- scale_dt(dt_mgs, mode)
    p_all_sc <- scale_dt(dt_phage_all, mode)

    y_lab  <- if (mode == "raw") "Depth" else paste0("Depth / ", ref_name, " median")
    dens_x <- if (mode == "raw") "Depth (count + 1)" else y_lab
    hline  <- if (mode == "raw") ref_median else 1
    plus1  <- if (mode == "raw") function(d) { if (is.null(d)) return(d); copy(d)[, depth := depth + 1] } else identity

    for (ph in phage_list) {
      win_min <- max(1, ph$start_g - opt$buffer)
      win_max <- min(genome_end_all, ph$end_g + opt$buffer)

      p_win <- make_profile(
        h_scaled, p_all_sc, m_scaled, win_min, win_max, y_lab,
        paste0(ph$pretty, "  window"), sprintf("%s median = %.3f", ref_name, ref_median),
        contig_regions_all, regions_all, hline, opt$font,
        show_mgs_points = FALSE, show_labels = FALSE, legend = TRUE, downsample_host = FALSE
      )

      p_den <- make_density(
        plus1(h_scaled), plus1(scale_dt(ph$dt, mode)), plus1(m_scaled),
        dens_x, paste0(ph$label, "  density (log10)"), opt$font, legend = TRUE
      )

      combined <- (p_win | p_den) +
        plot_annotation(
          title = paste0("Phage depth (", mode, "): ", tag, " | ", ph$pretty),
          theme = theme(plot.title = element_text(size = 15, face = "bold", hjust = 0.5, family = opt$font))
        )

      phage_file <- file.path(opt$out_dir, sprintf("%s_%s_%s_%s_%s_%s.pdf", safe_stem, ph$label, safe_token(ph$contig), ph$start, ph$end, mode))
      save_pdf(phage_file, combined, width = 14, height = 4.6, font = opt$font)
    }
  }
}

discover_genomes <- function(map_dir) {
  sample_dirs <- list.dirs(map_dir, full.names = TRUE, recursive = FALSE)
  sample_dirs <- sample_dirs[dir.exists(file.path(sample_dirs, "depth_to_stat"))]
  jobs <- list()
  for (sd in sample_dirs) {
    sample <- basename(sd)
    genome_dirs <- list.dirs(file.path(sd, "depth_to_stat"), full.names = TRUE, recursive = FALSE)
    for (gd in genome_dirs) {
      genome <- basename(gd)
      phage_files <- list.files(gd, pattern = "^phage_depth_.*\\.txt(\\.gz)?$", full.names = TRUE)
      if (!length(phage_files)) next
      phages <- list()
      for (pf in phage_files) {
        meta <- parse_phage_filename(pf)
        if (!is.null(meta)) phages[[length(phages) + 1L]] <- list(file = pf, contig = meta$contig, start = meta$start, end = meta$end)
      }
      if (length(phages)) {
        jobs[[length(jobs) + 1L]] <- list(
          sample = sample, genome = genome, data_dir = gd,
          host_file = find_existing(file.path(gd, paste0(genome, "_host_nonphage_depth.txt")), file.path(gd, paste0(genome, "_host_nonphage_depth.txt.gz"))),
          mgs_file  = find_existing(file.path(gd, paste0(genome, "_mgs_depth.txt")), file.path(gd, paste0(genome, "_mgs_depth.txt.gz"))),
          phages = phages
        )
      }
    }
  }
  jobs
}

jobs <- discover_genomes(map_dir)
if (!length(jobs)) stop("No prophage depth files found under ", map_dir, call. = FALSE)

if (opt$list_only) {
  for (j in jobs) for (ph in j$phages) cat(sprintf("%s\t%s\t%s\t%d\t%d\n", j$sample, j$genome, ph$contig, ph$start, ph$end))
  quit(save = "no", status = 0)
}

for (j in jobs) {
  tryCatch(process_genome(j, opt, genome_dir),
           error = function(e) warning("Processing failed [", j$sample, " / ", j$genome, "]: ", e$message))
}