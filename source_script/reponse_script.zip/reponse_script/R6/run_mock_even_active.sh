#!/usr/bin/env bash
set -euo pipefail

BASE_DIR=$(cd "$(dirname "$0")" && pwd)
SCRIPT_RUNNER="${BASE_DIR}/active_20260909.sh"
REF_DIR="${BASE_DIR}/ref"
MOCK_DIR="${BASE_DIR}/mock_even"
COORD_FILE="${BASE_DIR}/active_coordinate.tsv"

TMP_INPUT_DIR="${BASE_DIR}/tmp_active_input"
PREP_READS_DIR="${TMP_INPUT_DIR}/reads"
INDEX_FILE="${TMP_INPUT_DIR}/mock_even_competitive_index.tsv"

OUTPUT_DIR="${BASE_DIR}/active_results/mock/even"

THREADS=20
R_THREADS=20

if [ ! -f "$SCRIPT_RUNNER" ]; then
    echo "Error: main script not found: $SCRIPT_RUNNER" >&2
    exit 1
fi
if [ ! -f "$COORD_FILE" ]; then
    echo "Error: coordinate file not found: $COORD_FILE" >&2
    exit 1
fi

mkdir -p "$TMP_INPUT_DIR"
mkdir -p "$PREP_READS_DIR"
mkdir -p "$OUTPUT_DIR"

for fa in "${REF_DIR}"/*.fasta; do
    [ -e "$fa" ] || continue
    if [ ! -f "${fa}.fai" ]; then
        samtools faidx "$fa"
    fi
done

SEEDS=("s11" "s22" "s33")

COVERAGES=()
for f in "${MOCK_DIR}/${SEEDS[0]}"/*_1.fq.gz; do
    [ -e "$f" ] || continue
    cov_name=$(basename "$f" _1.fq.gz)
    COVERAGES+=("$cov_name")
done

for seed in "${SEEDS[@]}"; do
    for cov in "${COVERAGES[@]}"; do
        r1_src="${MOCK_DIR}/${seed}/${cov}_1.fq.gz"
        r2_src="${MOCK_DIR}/${seed}/${cov}_2.fq.gz"

        if [[ -f "$r1_src" && -f "$r2_src" ]]; then
            sample_name="${seed}_${cov}"
            ln -sf "$(realpath "$r1_src")" "${PREP_READS_DIR}/${sample_name}_1_clean.fq.gz"
            ln -sf "$(realpath "$r2_src")" "${PREP_READS_DIR}/${sample_name}_2_clean.fq.gz"
        else
            echo "Warning: missing paired data for ${seed} ${cov}: $r1_src or $r2_src" >&2
        fi
    done
done

echo -e "sample\tref" > "$INDEX_FILE"

mapfile -t REF_LIST < <(find "$REF_DIR" -maxdepth 1 -name "*.fasta" -exec basename {} .fasta \; | sort)

for seed in "${SEEDS[@]}"; do
    for cov in "${COVERAGES[@]}"; do
        sample_name="${seed}_${cov}"
        for ref in "${REF_LIST[@]}"; do
            echo -e "${sample_name}\t${ref}" >> "$INDEX_FILE"
        done
    done
done

bash "$SCRIPT_RUNNER" \
    -g "$REF_DIR" \
    -s "$PREP_READS_DIR" \
    -p "$COORD_FILE" \
    -i "$INDEX_FILE" \
    -o "$OUTPUT_DIR" \
    -t "$THREADS" \
    -r "$R_THREADS" \
    --map-mode competitive

bash "$SCRIPT_RUNNER" \
    -g "$REF_DIR" \
    -s "$PREP_READS_DIR" \
    -p "$COORD_FILE" \
    -i "$INDEX_FILE" \
    -o "$OUTPUT_DIR" \
    -t "$THREADS" \
    -r "$R_THREADS" \
    -c \
    --map-mode competitive