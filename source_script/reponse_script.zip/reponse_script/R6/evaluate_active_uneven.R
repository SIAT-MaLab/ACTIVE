#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(tidyverse)
  library(patchwork)
  library(scales)
})

base_dir     <- getwd()
meta_file    <- file.path(base_dir, "metadata.tsv")
active_root  <- file.path(base_dir, "active_results/mock/uneven/activity_results")
out_dir      <- file.path(base_dir, "evaluation_uneven")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

if (!file.exists(meta_file)) {
  stop("Error: metadata.tsv not found")
}

df_meta <- read_tsv(meta_file, col_types = cols()) %>%
  mutate(
    truth = tolower(trimws(truth)),
    start = as.integer(start),
    stop  = as.integer(stop),
    phage_id = paste(contig, start, stop, sep = "_")
  )

total_meta_phages <- nrow(df_meta)

read_active_mode <- function(mode_name) {
  csv_dir <- file.path(active_root, mode_name, "competitive")
  csv_files <- list.files(csv_dir, pattern = "_phage_depth_stats_summary_final\\.csv$", full.names = TRUE)

  if (length(csv_files) == 0) {
    warning(sprintf("No CSV results found under %s", csv_dir))
    return(tibble())
  }

  df_list <- lapply(csv_files, function(f) {
    df <- read_csv(f, col_types = cols())
    df$Mode <- mode_name
    return(df)
  })

  df_all <- bind_rows(df_list) %>%
    mutate(
      phage_id = str_remove(str_remove(Phage_File, "^phage_depth_"), "\\.txt$"),
      Coverage = as.numeric(Coverage)
    )
  return(df_all)
}

df_precise   <- read_active_mode("precise")
df_sensitive <- read_active_mode("sensitive")

df_results_all <- bind_rows(df_precise, df_sensitive)

depth_levels <- c("original_5pct", "original_10pct", "original_25pct", "original_50pct", "original")

evaluate_data <- function(df_res, mode_val) {
  samples <- unique(df_res$Folder)
  if (length(samples) == 0) return(tibble())

  eval_rows <- list()

  for (s in samples) {
    df_s <- df_res %>% filter(Folder == s, Mode == mode_val)

    merged <- df_meta %>%
      left_join(df_s, by = "phage_id") %>%
      mutate(
        Sample = s,
        Mode = mode_val,
        Coverage = replace_na(Coverage, 0),
        Significant = replace_na(Significant, "No")
      )

    if (mode_val == "precise") {
      merged <- merged %>%
        mutate(
          Delta_Mean = as.numeric(Delta_Mean),
          is_tested = Coverage >= 0.75,
          pred_active = is_tested & (Significant == "Yes") & (!is.na(Delta_Mean) & Delta_Mean >= 0.8)
        )
    } else {
      merged <- merged %>%
        mutate(
          Effect_Size_Value = as.numeric(Effect_Size_Value),
          is_tested = Coverage >= 0.75,
          pred_active = is_tested & (Significant == "Yes") & (!is.na(Effect_Size_Value) & Effect_Size_Value >= 0.8)
        )
    }

    n_total   <- nrow(merged)
    n_tested  <- sum(merged$is_tested)
    missed    <- n_total - n_tested

    TP <- sum(merged$truth == "active"  & merged$pred_active == TRUE)
    FP <- sum(merged$truth == "dormant" & merged$pred_active == TRUE)
    FN <- sum(merged$truth == "active"  & merged$pred_active == FALSE)
    TN <- sum(merged$truth == "dormant" & merged$pred_active == FALSE)

    sens <- ifelse(TP + FN > 0, TP / (TP + FN), NA_real_)
    prec <- ifelse(TP + FP > 0, TP / (TP + FP), 0)
    f1   <- ifelse(!is.na(sens) && !is.na(prec) && (sens + prec > 0),
                   2 * (prec * sens) / (prec + sens), 0)

    eval_rows[[length(eval_rows) + 1]] <- tibble(
      Sample = s,
      Mode = mode_val,
      Total_Phages = n_total,
      Tested_Phages = n_tested,
      Missed_Phages = missed,
      Pass_Coverage_Rate = n_tested / n_total,
      TP = TP, FP = FP, FN = FN, TN = TN,
      Sensitivity = sens,
      Precision = prec,
      F1_Score = f1
    )
  }
  bind_rows(eval_rows)
}

df_eval_precise   <- evaluate_data(df_results_all, "precise")
df_eval_sensitive <- evaluate_data(df_results_all, "sensitive")

df_benchmark <- bind_rows(df_eval_precise, df_eval_sensitive) %>%
  mutate(
    Sample = factor(Sample, levels = depth_levels),
    Mode   = factor(Mode, levels = c("precise", "sensitive"))
  ) %>%
  arrange(Sample, Mode)

summary_tsv <- file.path(out_dir, "uneven_benchmark_summary.tsv")
write_tsv(df_benchmark, summary_tsv)

theme_pub <- theme_bw(base_size = 11) +
  theme(
    panel.grid.minor = element_blank(),
    legend.position = "top",
    strip.background = element_rect(fill = "#EFEFEF", color = NA),
    axis.text.x = element_text(angle = 35, hjust = 1, face = "bold")
  )

palette_mode <- c("precise" = "#2b8cbe", "sensitive" = "#e6550d")

p_cov <- ggplot(df_benchmark, aes(x = Sample, y = Pass_Coverage_Rate, fill = Mode)) +
  geom_col(position = position_dodge(0.7), width = 0.6, alpha = 0.85) +
  geom_text(aes(label = sprintf("%.1f%%", Pass_Coverage_Rate * 100)),
            position = position_dodge(0.7), vjust = -0.5, size = 3) +
  scale_y_continuous(labels = percent_format(), limits = c(0, 1.15)) +
  scale_fill_manual(values = palette_mode) +
  labs(title = "A. Coverage inclusion rate (Coverage >= 0.75)",
       subtitle = "Below 0.75 is excluded as missed testing",
       x = "Dilution gradient", y = "Inclusion rate (%)", fill = "Mode") +
  theme_pub

df_metrics_long <- df_benchmark %>%
  select(Sample, Mode, Precision, Sensitivity, F1_Score) %>%
  pivot_longer(cols = c(Precision, Sensitivity, F1_Score), names_to = "Metric", values_to = "Value") %>%
  mutate(Metric = factor(Metric, levels = c("Sensitivity", "Precision", "F1_Score")))

p_metrics <- ggplot(df_metrics_long, aes(x = Sample, y = Value, color = Mode, group = Mode)) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 2.5) +
  facet_wrap(~ Metric, scales = "free_y") +
  scale_color_manual(values = palette_mode) +
  scale_y_continuous(limits = c(0, 1.05), breaks = seq(0, 1, 0.2)) +
  labs(title = "B. Performance comparison",
       x = "Dilution gradient", y = "Score", color = "Mode") +
  theme_pub

p_fp <- ggplot(df_benchmark, aes(x = Sample, y = FP, fill = Mode)) +
  geom_col(position = position_dodge(0.7), width = 0.6, alpha = 0.85) +
  geom_text(aes(label = FP), position = position_dodge(0.7), vjust = -0.5, size = 3.2) +
  scale_fill_manual(values = palette_mode) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.25))) +
  labs(title = "C. False positives (FP)",
       subtitle = "Dormant misclassified as active",
       x = "Dilution gradient", y = "FP count", fill = "Mode") +
  theme_pub

df_points <- df_meta %>%
  inner_join(df_results_all, by = "phage_id") %>%
  mutate(
    Sample = factor(Folder, levels = depth_levels),
    Metric_Val = ifelse(Mode == "precise", as.numeric(Delta_Mean), as.numeric(Effect_Size_Value))
  ) %>%
  filter(!is.na(Metric_Val), Coverage >= 0.75)

p_dist <- ggplot(df_points, aes(x = Sample, y = Metric_Val, color = truth)) +
  geom_jitter(position = position_jitterdodge(jitter.width = 0.2, dodge.width = 0.6), size = 1.6, alpha = 0.7) +
  geom_hline(yintercept = 0.8, linetype = "dashed", color = "red3", linewidth = 0.7) +
  annotate("text", x = 1, y = 0.83, label = "Active threshold (0.8)", color = "red3", size = 3, hjust = 0) +
  facet_wrap(~ Mode, labeller = as_labeller(c("precise" = "Precise (Delta_Mean)", "sensitive" = "Sensitive (Effect_Size_Value)"))) +
  scale_color_manual(values = c("active" = "#e41a1c", "dormant" = "#4daf4a")) +
  scale_y_continuous(limits = c(-0.1, 1.05), breaks = seq(0, 1, 0.2)) +
  labs(title = "D. Effect size distribution versus truth",
       x = "Dilution gradient", y = "Effect size", color = "Truth") +
  theme_pub

combined_plot <- (p_cov + p_fp) / p_metrics / p_dist +
  plot_layout(heights = c(1, 1.2, 1.3))

plot_pdf <- file.path(out_dir, "active_uneven_benchmark_plots.pdf")
plot_png <- file.path(out_dir, "active_uneven_benchmark_plots.png")

ggsave(plot_pdf, combined_plot, width = 12, height = 13)
ggsave(plot_png, combined_plot, width = 12, height = 13, dpi = 300)