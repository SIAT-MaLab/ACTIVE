#!/usr/bin/env bash
set -euo pipefail

SEED="${SEED:-11}"
THREADS="${THREADS:-24}"
FRACS=(0.05  0.10 0.25 0.50)

mkdir -p mock_unequal

for r in 1 2; do
    if [ ! -s "mock_unequal/original_${r}.fq.gz" ]; then
        echo "Error: mock_unequal/original_${r}.fq.gz is missing or empty" >&2
        echo "Run the mock construction step first" >&2
        exit 1
    fi
done

for frac in "${FRACS[@]}"; do
    pct=$(python3 -c "print(int(round(float('$frac')*100)))")
    r1="mock_unequal/original_${pct}pct_1.fq.gz"
    r2="mock_unequal/original_${pct}pct_2.fq.gz"

    if [ -s "$r1" ] && [ -s "$r2" ]; then
        continue
    fi

    seqkit sample -j "$THREADS" -p "$frac" -s "$SEED" mock_unequal/original_1.fq.gz \
        | pigz -c -p "$THREADS" > "$r1"
    seqkit sample -j "$THREADS" -p "$frac" -s "$SEED" mock_unequal/original_2.fq.gz \
        | pigz -c -p "$THREADS" > "$r2"
done

python3 - << 'PY'
import csv, os, subprocess, sys
from collections import defaultdict

files = sorted(f for f in os.listdir("mock_unequal")
               if f.startswith("original") and f.endswith(".fq.gz"))
if not files:
    raise SystemExit("No original* files under mock_unequal/")

stats = subprocess.check_output(
    ["seqkit", "stats", "-T", "-j", "4"] +
    [f"mock_unequal/{f}" for f in files],
    text=True)

n = defaultdict(dict)
for row in csv.DictReader(stats.splitlines(), delimiter="\t"):
    base = os.path.basename(row["file"])
    if base.endswith("_1.fq.gz"):
        stem, side = base[:-len("_1.fq.gz")], "1"
    elif base.endswith("_2.fq.gz"):
        stem, side = base[:-len("_2.fq.gz")], "2"
    else:
        continue
    n[stem][side] = int(row["num_seqs"])

bad = [k for k, d in n.items() if d.get("1") != d.get("2")]
if bad:
    for k in bad:
        print(f"MISMATCH: {k} R1={n[k].get('1')} R2={n[k].get('2')}",
              file=sys.stderr)
    raise SystemExit(1)
PY