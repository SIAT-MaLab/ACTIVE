#!/usr/bin/env bash
set -euo pipefail

export THREADS_PIGZ=24
export SEEDS="11,22,33"
export TARGET_DEPTHS="5,10,20,50"
export MIN_RATIO=1.2
export MAX_AVG_MEDIAN_RATIO=5.0
export MIN_COVERED=95.0

mkdir -p subsample mock_even mock_unequal

python3 - << 'PY'
import csv, glob, os
from pathlib import Path
seeds = [int(x) for x in os.environ["SEEDS"].split(",")]
targets = [int(x) for x in os.environ["TARGET_DEPTHS"].split(",")]
min_ratio = float(os.environ["MIN_RATIO"])
max_ratio = float(os.environ["MAX_AVG_MEDIAN_RATIO"])
min_covered = float(os.environ["MIN_COVERED"])

index = []
with open("index.tsv") as f:
    for line in f:
        parts = line.strip().split()
        if len(parts) >= 2 and parts[0] != "sample":
            index.append((parts[0], parts[1]))

cov = {}
for path in glob.glob("covstats/*"):
    with open(path) as f:
        header = None
        for line in f:
            if line.startswith("#ID"):
                header = line[1:].strip().split()
                continue
            if not header or not line.strip():
                continue
            row = dict(zip(header, line.strip().split()))
            cov[row["ID"]] = row

def find_cov(ref):
    hits = [v for k, v in cov.items() if k == ref or k.startswith(ref + "_")]
    if len(hits) != 1:
        raise SystemExit(f"Error: {ref} matched {len(hits)} covstats records")
    return hits[0]

manifest = open("subsample/manifest.tsv", "w")
manifest.write("sample\tref\tseed\ttarget_x\tmedian_x\tavg_x\tfrac\tr1_out\tr2_out\n")
accepted_samples = set()

for sample, ref in index:
    row = find_cov(ref)
    median = float(row["Median_fold"])
    avg = float(row["Avg_fold"])
    covered = float(row["Covered_percent"])
    ratio = avg / median if median > 0 else 999.0

    can_50x = (median >= 50 * min_ratio) and (ratio <= max_ratio) and (covered >= min_covered)
    if not can_50x:
        continue

    accepted_samples.add(sample)
    for seed in seeds:
        for t in targets:
            frac = t / median
            if frac >= 1.0:
                continue
            r1_out = f"subsample/s{seed}/{t}x/{sample}_1.fq.gz"
            r2_out = f"subsample/s{seed}/{t}x/{sample}_2.fq.gz"
            manifest.write(f"{sample}\t{ref}\t{seed}\t{t}\t{median:.2f}\t{avg:.2f}\t{frac:.6f}\t{r1_out}\t{r2_out}\n")

manifest.close()

with open("subsample/accepted_samples.txt", "w") as f:
    for s in sorted(accepted_samples):
        f.write(f"{s}\n")
PY

python3 - << 'PY'
import csv, subprocess, os
from pathlib import Path
threads = os.environ.get("THREADS_PIGZ", "4")

with open("subsample/manifest.tsv") as f:
    rows = list(csv.DictReader(f, delimiter="\t"))

for i, row in enumerate(rows, 1):
    s, seed, frac = row["sample"], row["seed"], row["frac"]
    t = row["target_x"]
    r1_out, r2_out = row["r1_out"], row["r2_out"]
    Path(r1_out).parent.mkdir(parents=True, exist_ok=True)

    if os.path.exists(r1_out) and os.path.getsize(r1_out) > 0 and os.path.exists(r2_out) and os.path.getsize(r2_out) > 0:
        continue

    cmd1 = f"seqkit sample -p {frac} -s {seed} seq/{s}_1_clean.fastq.gz | pigz -c -p {threads} > {r1_out}"
    cmd2 = f"seqkit sample -p {frac} -s {seed} seq/{s}_2_clean.fastq.gz | pigz -c -p {threads} > {r2_out}"

    subprocess.run(cmd1, shell=True, check=True)
    subprocess.run(cmd2, shell=True, check=True)
PY

seqkit stats -T -j 8 subsample/s*/*/*.fq.gz > subsample/qc_stats.tsv

python3 - << 'PY'
import csv, os
from collections import defaultdict

n = defaultdict(dict)
for row in csv.DictReader(open("subsample/qc_stats.tsv"), delimiter="\t"):
    fname = os.path.basename(row["file"])
    s = fname.split("_")[0]
    side = "1" if "_1.fq.gz" in fname else "2"
    key = row["file"].rsplit("/", 1)[0] + "/" + s
    n[key][side] = int(row["num_seqs"])

errs = []
for k, counts in n.items():
    if counts.get("1") != counts.get("2"):
        errs.append(f"{k}: R1={counts.get('1')} vs R2={counts.get('2')}")

if errs:
    print("Pairing validation failed:")
    for e in errs:
        print(e)
    raise SystemExit("Error: paired read counts differ")
PY

python3 - << 'PY'
import subprocess, os
from pathlib import Path
seeds = [int(x) for x in os.environ["SEEDS"].split(",")]
targets = [int(x) for x in os.environ["TARGET_DEPTHS"].split(",")]
samples = [line.strip() for line in open("subsample/accepted_samples.txt") if line.strip()]

for seed in seeds:
    for t in targets:
        out_dir = Path(f"mock_even/s{seed}")
        out_dir.mkdir(parents=True, exist_ok=True)
        for side in (1, 2):
            in_files = " ".join([f"subsample/s{seed}/{t}x/{s}_{side}.fq.gz" for s in samples])
            out_file = f"{out_dir}/{t}x_{side}.fq.gz"
            subprocess.run(f"cat {in_files} > {out_file}", shell=True, check=True)

uneq_dir = Path("mock_unequal")
uneq_dir.mkdir(parents=True, exist_ok=True)
for side in (1, 2):
    in_files = " ".join([f"seq/{s}_{side}_clean.fastq.gz" for s in samples])
    out_file = f"{uneq_dir}/original_{side}.fq.gz"
    subprocess.run(f"cat {in_files} > {out_file}", shell=True, check=True)
PY

seqkit stats -T -j 24 mock_even/s11/*_1.fq.gz mock_even/s11/*_2.fq.gz | awk -F'\t' '{printf "%-35s %s\n", $1, $4}'
seqkit stats -T -j 24 mock_unequal/* | awk -F'\t' '{printf "%-35s %s\n", $1, $4}'