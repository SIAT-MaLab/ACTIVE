#!/bin/bash
set +e

BAKTA_DB="/home/huangyan/databaseHY/bakta_db/db"
GENOME_BASE="/home/huangyan/databaseHY/gut_genome"
WORK_DIR="/home/huangyan/experiment/SPA/ori"
TMP_DIR="$WORK_DIR/tmp_bakta"
FINAL_TSV="$WORK_DIR/all_genome_ori.tsv"
LOG_FAIL="$WORK_DIR/failed_genomes.log"
CHECK_REPORT="$WORK_DIR/contig_check_report.tsv"
SINGLE_LIST="$WORK_DIR/single_contig_genomes.list"
MULTI_LIST="$WORK_DIR/multi_contig_genomes.list"
THREADS=26

mkdir -p "$WORK_DIR"

rm -f "$CHECK_REPORT" "$SINGLE_LIST" "$MULTI_LIST" "$FINAL_TSV" "$LOG_FAIL"

declare -A PATTERNS
PATTERNS["$GENOME_BASE/06.3.1.MIMAG/cMAG"]="*.fa"
PATTERNS["$GENOME_BASE/fasta_986"]="*.fa"
PATTERNS["$GENOME_BASE/GMR/GMR_REP/c_genome"]="*.fasta"
PATTERNS["$GENOME_BASE/HRGM2/c_genome"]="*.fna"
PATTERNS["$GENOME_BASE/UHGG"]="*.fasta"
PATTERNS["$GENOME_BASE/SPMP/all/c_genome"]="*.fasta"

ALL_GENOME_LIST="$WORK_DIR/all_genome_list.txt"
> "$ALL_GENOME_LIST"

for path in "${!PATTERNS[@]}"; do
    pattern="${PATTERNS[$path]}"
    if [ ! -d "$path" ]; then
        continue
    fi
    if [ "$path" == "$GENOME_BASE/UHGG" ]; then
        find "$path" -not -path "*/gff/*" -name "$pattern" >> "$ALL_GENOME_LIST"
    else
        find "$path" -name "$pattern" >> "$ALL_GENOME_LIST"
    fi
done

TOTAL_GENOMES=$(wc -l < "$ALL_GENOME_LIST")

TMP_REPORT="$CHECK_REPORT.tmp"
> "$TMP_REPORT"
export TMP_REPORT

cat "$ALL_GENOME_LIST" | parallel -j $THREADS '
    file={}
    name=$(basename "$file" | sed "s/\.[^.]*$//")
    count=$(seqkit seq -n "$file" 2>/dev/null | wc -l)
    printf "%s\t%s\t%s\n" "$name" "$count" "$file" >> "$TMP_REPORT"
'

{
    printf "Genome\tContigCount\tFilePath\n"
    sort -t$'\t' -k1,1 "$TMP_REPORT"
} > "$CHECK_REPORT"
rm -f "$TMP_REPORT"

awk -F'\t' 'NR>1 && $2==1 {print $3}' "$CHECK_REPORT" > "$SINGLE_LIST"
awk -F'\t' 'NR>1 && $2>1  {print $3}' "$CHECK_REPORT" > "$MULTI_LIST"

SINGLE_COUNT=$(wc -l < "$SINGLE_LIST")
MULTI_COUNT=$(wc -l < "$MULTI_LIST")

mkdir -p "$TMP_DIR"

if [ "$SINGLE_COUNT" -gt 0 ]; then
    cat "$SINGLE_LIST" | parallel --joblog "$WORK_DIR/parallel_jobs.log" -j $THREADS '
        genome={}
        name=$(basename "$genome" | sed "s/\.[^.]*$//")
        outdir="'"$TMP_DIR"'/$name"
        bakta "$genome" \
            --db '"$BAKTA_DB"' \
            --complete \
            --threads 1 \
            --skip-trna --skip-tmrna --skip-rrna \
            --skip-ncrna --skip-ncrna-region --skip-crispr \
            --skip-cds --skip-pseudo --skip-sorf --skip-gap \
            --skip-filter --skip-plot \
            --output "$outdir" \
            --prefix "$name" > /dev/null 2>&1
        if [ $? -ne 0 ]; then
            echo "$genome" >> '"$LOG_FAIL"'
        fi
    '
fi

echo -e "Genome\tType\tStart\tStop\tStrand\tLocus Tag\tGene\tProduct\tDbXrefs" > "$FINAL_TSV"

for dir in "$TMP_DIR"/*/; do
    name=$(basename "$dir")
    tsvfile="$dir/${name}.tsv"
    if [ -f "$tsvfile" ]; then
        grep -v '^#' "$tsvfile" | awk -v genome="$name" 'BEGIN{OFS="\t"} {$1=genome; print}' >> "$FINAL_TSV"
    fi
done

rm -rf "$TMP_DIR" "$ALL_GENOME_LIST" "$WORK_DIR/parallel_jobs.log"