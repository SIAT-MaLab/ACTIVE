library(ggplot2)

setwd("~/experiment/SPA/ori")
bed_file <- "prophage/prophage_coordinates.bed"
ori_tsv_file <- "all_genome_ori.tsv"
fasta_dir <- "prophage/host_with_prophage"

bed_df <- read.table(bed_file, sep = "", header = FALSE, stringsAsFactors = FALSE, fill = TRUE)
if(ncol(bed_df) >= 3) {
  bed_df <- bed_df[, 1:3]
} else {
  stop("BED file has fewer than 3 columns.")
}
colnames(bed_df) <- c("Prophage_ID", "Prop_Start", "Prop_End")
bed_df$Host_Genome <- sub("_[0-9]+$", "", bed_df$Prophage_ID)
bed_df$Prop_Mid <- (bed_df$Prop_Start + bed_df$Prop_End) / 2

ori_df <- read.table(ori_tsv_file, sep = "", header = FALSE, skip = 1, 
                     stringsAsFactors = FALSE, quote = "", comment.char = "", fill = TRUE)
if(ncol(ori_df) >= 4) {
  ori_df <- ori_df[, 1:4]
} else {
  stop("Ori TSV file has fewer than 4 columns.")
}
colnames(ori_df) <- c("Genome", "Type", "Start", "Stop")

ori_df <- ori_df[ori_df$Type == "oriC", ]
ori_df$Host_Genome <- gsub("_", ".", ori_df$Genome)
ori_df$Ori_Mid <- (as.numeric(ori_df$Start) + as.numeric(ori_df$Stop)) / 2

target_hosts <- unique(bed_df$Host_Genome)
ori_df <- ori_df[ori_df$Host_Genome %in% target_hosts, ]

fasta_files <- list.files(fasta_dir, pattern = "\\.fasta$", full.names = TRUE)
fasta_names <- sub("\\.fasta$", "", basename(fasta_files))

get_fasta_length <- function(file_path) {
  lines <- readLines(file_path)
  seq_lines <- lines[!grepl("^>", lines)]
  total_len <- sum(nchar(gsub("\\s+", "", seq_lines)))
  return(total_len)
}

genome_lengths <- sapply(fasta_files, get_fasta_length)
len_df <- data.frame(Host_Genome = fasta_names, Genome_Length = as.numeric(genome_lengths), stringsAsFactors = FALSE)

res_df <- merge(bed_df, len_df, by = "Host_Genome", all.x = TRUE)

calculate_min_dist <- function(prop_mid, host_genome, genome_len, ori_data) {
  if (is.na(genome_len)) {
    return(c(NA, NA, NA, "No_Genome_Length"))
  }
  
  oris <- ori_data[ori_data$Host_Genome == host_genome, "Ori_Mid"]
  
  if(length(oris) == 0) {
    return(c(NA, NA, NA, "No_oriC_Found"))
  }
  
  dists <- sapply(oris, function(o) {
    d_abs <- abs(prop_mid - o)
    min(d_abs, genome_len - d_abs)
  })
  
  min_dist <- min(dists)
  rel_dist <- min_dist / (genome_len / 2)
  nearest_ori <- oris[which.min(dists)]
  
  return(c(nearest_ori, min_dist, rel_dist, "Success"))
}

calc_results <- mapply(calculate_min_dist, 
                       res_df$Prop_Mid, 
                       res_df$Host_Genome, 
                       res_df$Genome_Length, 
                       MoreArgs = list(ori_data = ori_df))

res_df$Nearest_Ori_Mid <- as.numeric(calc_results[1,])
res_df$Min_Abs_Distance <- as.numeric(calc_results[2,])
res_df$Rel_Distance <- as.numeric(calc_results[3,])
res_df$Status <- calc_results[4,]

final_df <- res_df[, c("Prophage_ID", "Host_Genome", "Genome_Length", 
                       "Prop_Start", "Prop_End", "Prop_Mid", 
                       "Nearest_Ori_Mid", "Min_Abs_Distance", "Rel_Distance", "Status")]

output_csv <- "prophage_ori_relative_distances.csv"
write.csv(final_df, output_csv, row.names = FALSE)

success_df <- final_df[final_df$Status == "Success" & !is.na(final_df$Rel_Distance), ]

stats_mean <- mean(success_df$Rel_Distance)
stats_median <- median(success_df$Rel_Distance)
stats_q1 <- quantile(success_df$Rel_Distance, 0.25)
stats_q3 <- quantile(success_df$Rel_Distance, 0.75)

p_hist <- ggplot(success_df, aes(x = Rel_Distance)) +
  geom_histogram(binwidth = 0.05, fill = "#4C72B0", color = "white", alpha = 0.8) +
  geom_density(aes(y = after_stat(density) * (nrow(success_df) * 0.05)), color = "#C44E52", linewidth = 1) +
  theme_classic() +
  labs(
    title = "Distribution of Prophage Relative Distance to oriC",
    subtitle = "0 = At oriC (Early replication), 1 = At Ter (Late replication)",
    x = "Relative Distance to oriC",
    y = "Number of Prophages"
  ) +
  scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.1)) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5)
  )

ggsave("prophage_rel_distance_distribution.pdf", plot = p_hist, width = 8, height = 6)

p_box <- ggplot(success_df, aes(x = "All Prophages", y = Rel_Distance)) +
  geom_boxplot(width = 0.2, fill = "lightgray", color = "black", outlier.shape = NA, alpha = 0.5) +
  geom_jitter(width = 0.05, alpha = 0.6, color = "#4C72B0", size = 1.5) +
  annotate("text", x = 1.35, y = 0.95, 
           label = sprintf("Mean: %.3f\nMedian: %.3f\nQ1: %.3f\nQ3: %.3f", 
                           stats_mean, stats_median, stats_q1, stats_q3), 
           hjust = 0, vjust = 1, size = 4, color = "darkred", fontface = "bold") +
  theme_classic() +
  labs(
    title = "Scatter-Boxplot of Prophage Relative Distance to oriC",
    subtitle = "0 = At oriC, 1 = At Ter",
    x = NULL,
    y = "Relative Distance to oriC"
  ) +
  scale_y_continuous(limits = c(0, 1.05), breaks = seq(0, 1, 0.2)) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank()
  )

ggsave("prophage_rel_distance_scatter_box.pdf", plot = p_box, width = 6, height = 6)