#!/bin/bash
set -e

WORK_DIR="/home/huangyan/experiment/SPA/ori"
ORI_TSV="$WORK_DIR/all_genome_ori.tsv"
CHECK_REPORT="$WORK_DIR/contig_check_report.tsv"
GENOME_DIR="$WORK_DIR/genome"
PROPHAGE_DIR="$WORK_DIR/prophage"
GENOMAD_DB="/home/malab/databases_of_malab/genomad_db/genomad_db/"
THREADS=26
COMBINED_FA="$PROPHAGE_DIR/all_genomes_combined.fasta"

mkdir -p "$GENOME_DIR" "$PROPHAGE_DIR"

find "$GENOME_DIR" -maxdepth 1 -type f \( -name '*.fa' -o -name '*.fasta' -o -name '*.fna' \) -delete 2>/dev/null || true
rm -f "$COMBINED_FA"
rm -rf "$PROPHAGE_DIR/genomad_out" 2>/dev/null || true

declare -A GENOME_PATH
while IFS=$'\t' read -r gname count fpath; do
    [ "$gname" = "Genome" ] && continue
    [ -z "$gname" ] && continue
    GENOME_PATH["$gname"]="$fpath"
done < "$CHECK_REPORT"

mapfile -t ORI_GENOMES < <(tail -n +2 "$ORI_TSV" | cut -f1 | sort -u)
TOTAL=${#ORI_GENOMES[@]}

SUCCESS=0
FAIL=0
> "$COMBINED_FA"

for gname in "${ORI_GENOMES[@]}"; do
    fpath="${GENOME_PATH[$gname]:-}"
    if [ -z "$fpath" ] || [ ! -f "$fpath" ]; then
        FAIL=$((FAIL+1))
        continue
    fi

    new_name="${gname//_/.}"
    out_file="$GENOME_DIR/${new_name}.fa"

    awk -v newid="${new_name}_1" '
        /^>/ {
            print ">" newid
            next
        }
        {print}
    ' "$fpath" > "$out_file"

    cat "$out_file" >> "$COMBINED_FA"
    SUCCESS=$((SUCCESS+1))
done

genomad end-to-end \
    "$COMBINED_FA" \
    "$PROPHAGE_DIR/genomad_out" \
    "$GENOMAD_DB" \
    --threads "$THREADS"