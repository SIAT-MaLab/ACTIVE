#!/bin/bash
set -euo pipefail

mkdir -p c_genome
single_files=()
while IFS=$'\t' read -r file num_seqs; do
    if [[ "$num_seqs" == "1" ]]; then
        single_files+=("$file")
    fi
done < <(
    find . -maxdepth 1 -name "*.fasta" -print0 \
    | xargs -0 seqkit stats -j 24 -T \
    | awk 'BEGIN{FS=OFS="\t"} NR>1 {print $1, $4}'
)

if [[ ${#single_files[@]} -gt 0 ]]; then
    mv "${single_files[@]}" c_genome/
else
fi
