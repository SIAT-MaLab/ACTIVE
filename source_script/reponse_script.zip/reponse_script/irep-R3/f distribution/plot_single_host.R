#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(circlize)
  library(tidyverse)
})

calc_circular <- function(L, p, o) {
  d <- abs(p - o)
  min(d, L - d)
}

get_fasta_length <- function(file_path) {
  lines <- readLines(file_path)
  seq_lines <- lines[!grepl("^>", lines)]
  total_len <- sum(nchar(gsub("\\s+", "", seq_lines)))
  return(total_len)
}

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 1) {
  stop("Please provide a genome name, e.g. Rscript plot_single_host.R A142.CMAG.2")
}
target_genome <- args[1]

bed_file  <- "prophage/prophage_coordinates.bed"
ori_file  <- "all_genome_ori.tsv"
fasta_dir <- "prophage/host_with_prophage"
out_pdf   <- paste0(target_genome, "_prophage_ori.pdf")

prophage_raw <- read_tsv(bed_file, col_names = c("contig", "start", "end"),
                         col_types = cols(contig = col_character(),
                                          start = col_double(),
                                          end = col_double())) %>%
  mutate(genome = str_replace(contig, "_\\d+$", ""),
         prophage_id = contig,
         mid = (start + end) / 2)

ori_raw <- read_tsv(ori_file,
                    col_types = cols_only(Type = col_character(),
                                          Genome = col_character(),
                                          Start = col_double(),
                                          Stop = col_double())) %>%
  filter(Type == "oriC") %>%
  mutate(genome = str_replace_all(Genome, "_", "."),
         mid = (Start + Stop) / 2,
         ori_id = paste0(genome, "_ori_", row_number()))

pro_target <- prophage_raw %>% filter(genome == target_genome)
ori_target <- ori_raw %>% filter(genome == target_genome)

if (nrow(pro_target) == 0) stop("No prophages found for ", target_genome)
if (nrow(ori_target) == 0) stop("No oriC found for ", target_genome)

fasta_file <- file.path(fasta_dir, paste0(target_genome, ".fasta"))
if (!file.exists(fasta_file)) {
  fasta_file <- file.path(fasta_dir, paste0(target_genome, ".fa"))
}
if (!file.exists(fasta_file)) stop("Fasta file not found for: ", target_genome, " (checked both .fasta and .fa)")

genome_length <- get_fasta_length(fasta_file)

pro_target <- pro_target %>%
  rowwise() %>%
  mutate(
    distances = list({
      ds <- sapply(ori_target$mid, function(o) calc_circular(genome_length, mid, o))
      tibble(ori_id = ori_target$ori_id, dist = ds)
    }),
    nearest_ori = distances$ori_id[which.min(distances$dist)],
    distance_bp = min(distances$dist),
    relative_dist = distance_bp / (genome_length / 2)
  ) %>%
  ungroup() %>%
  select(-distances)

pdf(file = out_pdf, width = 8, height = 8)

circos.clear()
circos.par(cell.padding = c(0,0,0,0), start.degree = 90)
circos.initialize(factors = "chr", xlim = c(0, genome_length))

circos.track(factors = "chr", ylim = c(0,1), track.height = 0.05,
             bg.border = "gray40", bg.col = "gray95")

phage_cols <- scales::hue_pal()(max(1, nrow(pro_target)))
ori_cols   <- c("red", "orange", "brown")

for (i in seq_len(nrow(ori_target))) {
  ori <- ori_target[i, ]
  draw.sector(start.degree = 360 * ori$Start / genome_length,
              end.degree   = 360 * ori$Stop  / genome_length,
              rou1 = 0.82, rou2 = 0.98,
              col = adjustcolor(ori_cols[i], alpha.f = 0.6),
              border = ori_cols[i])
}

for (i in seq_len(nrow(pro_target))) {
  ph <- pro_target[i, ]
  draw.sector(start.degree = 360 * ph$start / genome_length,
              end.degree   = 360 * ph$end   / genome_length,
              rou1 = 0.82, rou2 = 0.98,
              col = adjustcolor(phage_cols[i], alpha.f = 0.5),
              border = phage_cols[i])
}

for (i in seq_len(nrow(pro_target))) {
  ph <- pro_target[i, ]
  ph_angle <- 360 * ph$mid / genome_length

  idx <- which(ori_target$ori_id == ph$nearest_ori)
  ori_angle <- 360 * ori_target$mid[idx] / genome_length

  diff_angle <- (ph_angle - ori_angle) %% 360
  if (diff_angle <= 180) {
    arc_angles <- seq(ori_angle, ori_angle + diff_angle, length.out = 200)
  } else {
    arc_angles <- seq(ori_angle, ori_angle - (360 - diff_angle), length.out = 200)
  }
  arc_rad <- arc_angles * pi / 180
  points(0.72 * cos(arc_rad), 0.72 * sin(arc_rad),
         type = "l", lty = "dashed", col = phage_cols[i], lwd = 3)
}

lab_rad <- 1.2
for (i in seq_len(nrow(ori_target))) {
  ori <- ori_target[i, ]
  ang <- (360 * ori$mid / genome_length) * pi / 180
  points(0.98 * cos(ang), 0.98 * sin(ang), pch = 21, bg = ori_cols[i], cex = 2)
  text(lab_rad * cos(ang), lab_rad * sin(ang), labels = ori$ori_id,
       col = ori_cols[i], font = 2, cex = 0.9)
}
for (i in seq_len(nrow(pro_target))) {
  ph <- pro_target[i, ]
  ang <- (360 * ph$mid / genome_length) * pi / 180
  points(0.98 * cos(ang), 0.98 * sin(ang), pch = 21, bg = phage_cols[i], cex = 2)
  text(lab_rad * cos(ang), lab_rad * sin(ang), labels = ph$prophage_id,
       col = phage_cols[i], font = 2, cex = min(0.9, 4 / nrow(pro_target)))
}

text(0, 0, labels = sprintf("Genome: %s\nLength: %.1f Mb", target_genome, genome_length/1e6),
     cex = 1.1, font = 2, col = "gray20")
text(0, -0.25, labels = "Dashed arcs = shortest path\nto nearest oriC",
     cex = 0.85, col = "gray40")

legend("bottomleft",
       legend = c(paste0("oriC: ", ori_target$ori_id),
                  paste0("Prophage: ", pro_target$prophage_id)),
       fill = c(adjustcolor(ori_cols[1:nrow(ori_target)], 0.6),
                adjustcolor(phage_cols, 0.5)),
       border = c(ori_cols[1:nrow(ori_target)], phage_cols),
       bty = "n", cex = 0.7, inset = c(-0.1, -0.05))

title(main = paste0("Prophages & oriC on ", target_genome), line = -2, cex.main = 1.2)

circos.clear()
dev.off()