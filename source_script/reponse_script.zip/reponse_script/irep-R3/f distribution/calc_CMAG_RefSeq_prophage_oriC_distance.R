#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)

N_CORES <- 20L

MIN_CONTIG_LENGTH <- 5000
MIN_COMPLETENESS <- 50

CMAG_WORK_DIR <- "/home/huangyan/experiment/SPA/ori"

CMAG_ORI_FILE <- file.path(
  CMAG_WORK_DIR,
  "all_genome_ori.tsv"
)

CMAG_CHECKV_FILE <- file.path(
  CMAG_WORK_DIR,
  "prophage/checkv_out/quality_summary.tsv"
)

CMAG_FASTA_DIR <- file.path(
  CMAG_WORK_DIR,
  "genome"
)

REFSEQ_WORK_DIR <- "/home/huangyan/experiment/SPA/ori/refseq_ori"

REFSEQ_ORI_FILE <- file.path(
  REFSEQ_WORK_DIR,
  "all_genome_ori.tsv"
)

REFSEQ_CHECKV_FILE <- file.path(
  REFSEQ_WORK_DIR,
  "prophage/genomad_results/checkv_results/all_quality_summary.tsv"
)

REFSEQ_FASTA_DIR <- paste0(
  "/home/huangyan/databaseHY/gut_genome/",
  "Microbial_Scope/microbial_scope/c_genome"
)

OUT_DIR <- file.path(
  CMAG_WORK_DIR,
  "CMAG_RefSeq_prophage_oriC_distance"
)

dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

assert_file_exists <- function(file_path) {
  if (!file.exists(file_path)) {
    stop("File not found: ", file_path)
  }
}

assert_dir_exists <- function(dir_path) {
  if (!dir.exists(dir_path)) {
    stop("Directory not found: ", dir_path)
  }
}

write_tsv <- function(x, file_path) {
  write.table(
    x,
    file = file_path,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    na = "NA"
  )
}

normalize_genome_name <- function(x, dataset) {
  x <- trimws(as.character(x))

  if (dataset == "CMAG") {
    return(gsub("_", ".", x, fixed = TRUE))
  }

  return(x)
}

canonical_ori_type <- function(x) {
  x <- trimws(as.character(x))
  low <- tolower(x)

  x[low == "oric"] <- "oriC"
  x[low == "orit"] <- "oriT"
  x[low == "oriv"] <- "oriV"

  return(x)
}

append_reason <- function(reason, condition, label) {
  idx <- which(condition)

  if (length(idx) > 0) {
    reason[idx] <- ifelse(
      reason[idx] == "",
      label,
      paste(reason[idx], label, sep = ";")
    )
  }

  return(reason)
}

parallel_map <- function(X, FUN, n_cores = N_CORES) {
  if (length(X) == 0) {
    return(list())
  }

  workers <- min(as.integer(n_cores), length(X))

  if (.Platform$OS.type == "windows" || workers <= 1L) {
    return(lapply(X, FUN))
  }

  parallel::mclapply(
    X,
    FUN,
    mc.cores = workers,
    mc.preschedule = TRUE
  )
}

circular_feature_midpoint <- function(start, stop, genome_length) {
  mid <- ifelse(
    start <= stop,
    (start + stop) / 2,
    (start + stop + genome_length) / 2
  )

  ((mid - 1) %% genome_length) + 1
}

read_ori_file <- function(file_path, dataset) {

  assert_file_exists(file_path)

  raw <- read.delim(
    file_path,
    header = TRUE,
    sep = "\t",
    quote = "",
    comment.char = "",
    fill = TRUE,
    check.names = FALSE
  )

  required_cols <- c("Genome", "Type", "Start", "Stop")

  if (!all(required_cols %in% colnames(raw))) {
    stop(
      "Ori file is missing required columns: ",
      file_path,
      "\nActual columns: ",
      paste(colnames(raw), collapse = ", ")
    )
  }

  ori <- data.frame(
    Dataset = dataset,
    Genome_Raw = trimws(as.character(raw$Genome)),
    Type_Raw = trimws(as.character(raw$Type)),
    Start = suppressWarnings(as.numeric(raw$Start)),
    Stop = suppressWarnings(as.numeric(raw$Stop)),
    stringsAsFactors = FALSE
  )

  ori <- ori[
    !is.na(ori$Genome_Raw) &
      ori$Genome_Raw != "" &
      !is.na(ori$Type_Raw) &
      ori$Type_Raw != "",
    ,
    drop = FALSE
  ]

  if (nrow(ori) == 0) {
    stop("No valid records in ori file: ", file_path)
  }

  ori$Genome_Normalized <- normalize_genome_name(
    ori$Genome_Raw,
    dataset
  )

  ori$Genome_Key <- paste(
    ori$Dataset,
    ori$Genome_Normalized,
    sep = "::"
  )

  ori$Type_Normalized <- tolower(ori$Type_Raw)
  ori$Type_Canonical <- canonical_ori_type(ori$Type_Raw)

  ori <- ori[
    !duplicated(
      ori[, c(
        "Dataset",
        "Genome_Key",
        "Type_Normalized",
        "Start",
        "Stop"
      )]
    ),
    ,
    drop = FALSE
  ]

  raw_name_groups <- split(
    ori$Genome_Raw,
    ori$Genome_Key
  )

  collision_keys <- names(raw_name_groups)[
    vapply(
      raw_name_groups,
      function(z) length(unique(z)) > 1,
      logical(1)
    )
  ]

  if (length(collision_keys) > 0) {
    stop(
      "Name conflict after ori file normalization:\n",
      paste(collision_keys, collapse = "\n")
    )
  }

  ori <- ori[
    order(
      ori$Dataset,
      ori$Genome_Normalized,
      ori$Start,
      ori$Stop,
      ori$Type_Canonical
    ),
    ,
    drop = FALSE
  ]

  rownames(ori) <- NULL

  return(ori)
}

make_ori_summary <- function(ori) {

  ori_split <- split(
    ori,
    ori$Genome_Key
  )

  summary_list <- lapply(ori_split, function(x) {

    type_set <- sort(unique(x$Type_Canonical))

    data.frame(
      Dataset = x$Dataset[1],
      Genome_Key = x$Genome_Key[1],
      Host_Genome = x$Genome_Normalized[1],
      Ori_Genome_Raw = paste(
        sort(unique(x$Genome_Raw)),
        collapse = ";"
      ),
      Ori_Types = paste(type_set, collapse = ";"),
      Has_Non_oriT = any(x$Type_Normalized != "orit"),
      Has_oriC_Annotation = any(x$Type_Normalized == "oric"),
      OriC_Record_Count = sum(x$Type_Normalized == "oric"),
      stringsAsFactors = FALSE
    )
  })

  out <- do.call(rbind, summary_list)
  rownames(out) <- NULL

  return(out)
}

read_checkv_quality <- function(file_path, dataset) {

  assert_file_exists(file_path)

  raw <- read.delim(
    file_path,
    header = TRUE,
    sep = "\t",
    quote = "",
    comment.char = "",
    fill = TRUE,
    check.names = FALSE
  )

  required_cols <- c(
    "contig_id",
    "contig_length",
    "completeness"
  )

  if (!all(required_cols %in% colnames(raw))) {
    stop(
      "CheckV file is missing required columns: ",
      file_path,
      "\nActual columns: ",
      paste(colnames(raw), collapse = ", ")
    )
  }

  n <- nrow(raw)

  get_text_col <- function(colname) {
    if (colname %in% colnames(raw)) {
      return(trimws(as.character(raw[[colname]])))
    }

    return(rep(NA_character_, n))
  }

  contig_id <- get_text_col("contig_id")

  nonempty_ids <- contig_id[
    !is.na(contig_id) &
      contig_id != ""
  ]

  if (anyDuplicated(nonempty_ids)) {

    duplicated_ids <- unique(
      nonempty_ids[
        duplicated(nonempty_ids)
      ]
    )

    writeLines(
      duplicated_ids,
      file.path(
        OUT_DIR,
        paste0(dataset, "_duplicated_CheckV_contig_ids.txt")
      )
    )

    stop(
      "Duplicated contig_id in CheckV file. Duplicated IDs written to: ",
      file.path(
        OUT_DIR,
        paste0(dataset, "_duplicated_CheckV_contig_ids.txt")
      )
    )
  }

  checkv_contig_length <- suppressWarnings(
    as.numeric(get_text_col("contig_length"))
  )

  completeness <- suppressWarnings(
    as.numeric(get_text_col("completeness"))
  )

  proviral_length <- suppressWarnings(
    as.numeric(get_text_col("proviral_length"))
  )

  contamination <- suppressWarnings(
    as.numeric(get_text_col("contamination"))
  )

  coord_basic_ok <- !is.na(contig_id) &
    grepl(
      "\\|provirus_[0-9]+_[0-9]+$",
      contig_id
    )

  host_contig <- rep(NA_character_, n)
  prop_start <- rep(NA_real_, n)
  prop_end <- rep(NA_real_, n)

  if (any(coord_basic_ok)) {

    host_contig[coord_basic_ok] <- sub(
      "\\|provirus_[0-9]+_[0-9]+$",
      "",
      contig_id[coord_basic_ok]
    )

    prop_start[coord_basic_ok] <- suppressWarnings(
      as.numeric(
        sub(
          "^.*\\|provirus_([0-9]+)_([0-9]+)$",
          "\\1",
          contig_id[coord_basic_ok]
        )
      )
    )

    prop_end[coord_basic_ok] <- suppressWarnings(
      as.numeric(
        sub(
          "^.*\\|provirus_([0-9]+)_([0-9]+)$",
          "\\2",
          contig_id[coord_basic_ok]
        )
      )
    )
  }

  host_contig_suffix_ok <- !is.na(host_contig) &
    grepl("_[0-9]+$", host_contig)

  coord_format_ok <- coord_basic_ok &
    host_contig_suffix_ok &
    !is.na(prop_start) &
    !is.na(prop_end) &
    prop_start >= 1 &
    prop_end >= prop_start

  host_genome <- rep(NA_character_, n)

  if (any(host_contig_suffix_ok)) {
    host_genome[host_contig_suffix_ok] <- sub(
      "_[0-9]+$",
      "",
      host_contig[host_contig_suffix_ok]
    )
  }

  host_genome <- normalize_genome_name(
    host_genome,
    dataset
  )

  host_genome[!coord_format_ok] <- NA_character_

  prop_coord_length <- ifelse(
    coord_format_ok,
    prop_end - prop_start + 1,
    NA_real_
  )

  prop_mid <- ifelse(
    coord_format_ok,
    (prop_start + prop_end) / 2,
    NA_real_
  )

  length_pass <- !is.na(checkv_contig_length) &
    checkv_contig_length > MIN_CONTIG_LENGTH

  completeness_pass <- !is.na(completeness) &
    completeness >= MIN_COMPLETENESS

  quality_filter_pass <- length_pass &
    completeness_pass &
    coord_format_ok

  exclusion_reason <- rep("", n)

  exclusion_reason <- append_reason(
    exclusion_reason,
    !length_pass,
    paste0(
      "CheckV_contig_length_not_>",
      MIN_CONTIG_LENGTH
    )
  )

  exclusion_reason <- append_reason(
    exclusion_reason,
    !completeness_pass,
    paste0(
      "completeness_<",
      MIN_COMPLETENESS
    )
  )

  exclusion_reason <- append_reason(
    exclusion_reason,
    !coord_format_ok,
    "invalid_or_unparseable_provirus_ID"
  )

  length_diff <- checkv_contig_length -
    prop_coord_length

  length_status <- ifelse(
    is.na(length_diff),
    "NA",
    ifelse(
      length_diff == 0,
      "Match",
      "Mismatch"
    )
  )

  out <- data.frame(
    Dataset = dataset,
    Prophage_ID = contig_id,
    Host_Contig = host_contig,
    Host_Genome = host_genome,
    Genome_Key = ifelse(
      is.na(host_genome),
      NA_character_,
      paste(dataset, host_genome, sep = "::")
    ),
    Prop_Start = prop_start,
    Prop_End = prop_end,
    Prop_Mid = prop_mid,
    Prophage_Coord_Length = prop_coord_length,
    CheckV_Contig_Length = checkv_contig_length,
    CheckV_minus_Coord_Length_bp = length_diff,
    Coordinate_Length_Status = length_status,
    CheckV_Provirus = get_text_col("provirus"),
    CheckV_Proviral_Length = proviral_length,
    Gene_Count = suppressWarnings(
      as.numeric(get_text_col("gene_count"))
    ),
    Viral_Genes = suppressWarnings(
      as.numeric(get_text_col("viral_genes"))
    ),
    Host_Genes = suppressWarnings(
      as.numeric(get_text_col("host_genes"))
    ),
    CheckV_Quality = get_text_col("checkv_quality"),
    MIUVIG_Quality = get_text_col("miuvig_quality"),
    Completeness = completeness,
    Completeness_Method = get_text_col(
      "completeness_method"
    ),
    Contamination = contamination,
    CheckV_Warnings = get_text_col("warnings"),
    Contig_Length_Pass = length_pass,
    Completeness_Pass = completeness_pass,
    Provirus_ID_Format_Pass = coord_format_ok,
    Quality_Filter_Pass = quality_filter_pass,
    Quality_Filter_Exclusion_Reason = exclusion_reason,
    stringsAsFactors = FALSE
  )

  return(out)
}

make_checkv_screen_summary <- function(x) {

  split_x <- split(x, x$Dataset)

  out <- lapply(split_x, function(d) {
    data.frame(
      Dataset = d$Dataset[1],
      Total_CheckV_Records = nrow(d),
      Pass_Contig_Length = sum(d$Contig_Length_Pass),
      Pass_Completeness = sum(d$Completeness_Pass),
      Pass_Provirus_ID_Format = sum(
        d$Provirus_ID_Format_Pass
      ),
      Pass_All_Unified_Filters = sum(
        d$Quality_Filter_Pass
      ),
      stringsAsFactors = FALSE
    )
  })

  do.call(rbind, out)
}

build_fasta_manifest <- function(fasta_dir, dataset) {

  assert_dir_exists(fasta_dir)

  fasta_files <- list.files(
    fasta_dir,
    pattern = "\\.(fa|fna|fasta)$",
    full.names = TRUE,
    recursive = FALSE,
    ignore.case = TRUE
  )

  file_info <- file.info(fasta_files)

  fasta_files <- fasta_files[
    !is.na(file_info$isdir) &
      !file_info$isdir
  ]

  if (length(fasta_files) == 0) {
    stop(
      "No FASTA files found in the first level of directory: ",
      fasta_dir
    )
  }

  fasta_stem <- sub(
    "\\.(fa|fna|fasta)$",
    "",
    basename(fasta_files),
    ignore.case = TRUE
  )

  host_genome <- normalize_genome_name(
    fasta_stem,
    dataset
  )

  manifest <- data.frame(
    Dataset = dataset,
    Host_Genome = host_genome,
    Genome_Key = paste(
      dataset,
      host_genome,
      sep = "::"
    ),
    Genome_File = normalizePath(
      fasta_files,
      mustWork = TRUE
    ),
    stringsAsFactors = FALSE
  )

  if (anyDuplicated(manifest$Genome_Key)) {

    duplicated_manifest <- manifest[
      duplicated(manifest$Genome_Key) |
        duplicated(manifest$Genome_Key, fromLast = TRUE),
      ,
      drop = FALSE
    ]

    write_tsv(
      duplicated_manifest,
      file.path(
        OUT_DIR,
        paste0(
          dataset,
          "_duplicated_top_level_fasta_manifest.tsv"
        )
      )
    )

    stop(
      "Duplicate genome file names in the first level of FASTA directory. ",
      "Duplicated manifest written to: ",
      file.path(
        OUT_DIR,
        paste0(
          dataset,
          "_duplicated_top_level_fasta_manifest.tsv"
        )
      )
    )
  }

  manifest <- manifest[
    order(manifest$Host_Genome),
    ,
    drop = FALSE
  ]

  rownames(manifest) <- NULL

  return(manifest)
}

get_fasta_info <- function(fasta_file) {

  tryCatch({

    lines <- readLines(
      fasta_file,
      warn = FALSE
    )

    header_flag <- grepl("^>", lines)
    n_contigs <- sum(header_flag)

    sequence_lines <- lines[!header_flag]
    sequence_lines <- gsub(
      "[[:space:]]+",
      "",
      sequence_lines
    )

    genome_length <- sum(
      nchar(sequence_lines),
      na.rm = TRUE
    )

    read_status <- if (
      n_contigs >= 1 &&
        genome_length > 0
    ) {
      "OK"
    } else {
      "Invalid_or_empty_FASTA"
    }

    data.frame(
      Genome_File = fasta_file,
      Fasta_Read_Status = read_status,
      Fasta_Contig_Count = as.integer(n_contigs),
      Genome_Length = as.numeric(genome_length),
      stringsAsFactors = FALSE
    )

  }, error = function(e) {

    data.frame(
      Genome_File = fasta_file,
      Fasta_Read_Status = paste0(
        "Read_error:",
        gsub(
          "[\t\r\n]",
          " ",
          conditionMessage(e)
        )
      ),
      Fasta_Contig_Count = NA_integer_,
      Genome_Length = NA_real_,
      stringsAsFactors = FALSE
    )
  })
}

calc_distance_one_host <- function(
  genome_key,
  candidate_df,
  ori_df
) {

  d <- candidate_df[
    candidate_df$Genome_Key == genome_key,
    ,
    drop = FALSE
  ]

  set_all_status <- function(status) {
    d$Distance_Status <- status
    return(d)
  }

  if (is.na(d$Has_Non_oriT[1])) {
    return(set_all_status("No_ori_annotation"))
  }

  if (!isTRUE(d$Has_Non_oriT[1])) {
    return(set_all_status("oriT_only_excluded"))
  }

  if (!isTRUE(d$Has_oriC_Annotation[1])) {
    return(set_all_status("No_oriC_annotation"))
  }

  if (
    is.na(d$Genome_File[1]) ||
      d$Genome_File[1] == ""
  ) {
    return(set_all_status("No_matching_genome_FASTA"))
  }

  if (
    is.na(d$Fasta_Read_Status[1]) ||
      d$Fasta_Read_Status[1] != "OK"
  ) {
    return(set_all_status("FASTA_read_failed"))
  }

  if (
    is.na(d$Fasta_Contig_Count[1]) ||
      d$Fasta_Contig_Count[1] != 1
  ) {
    return(set_all_status("Genome_not_single_contig"))
  }

  genome_length <- d$Genome_Length[1]

  if (
    is.na(genome_length) ||
      !is.finite(genome_length) ||
      genome_length <= 0
  ) {
    return(set_all_status("Invalid_genome_length"))
  }

  oriC <- ori_df[
    ori_df$Genome_Key == genome_key &
      ori_df$Type_Normalized == "oric",
    ,
    drop = FALSE
  ]

  valid_oriC <- !is.na(oriC$Start) &
    !is.na(oriC$Stop) &
    oriC$Start >= 1 &
    oriC$Stop >= 1 &
    oriC$Start <= genome_length &
    oriC$Stop <= genome_length

  oriC <- oriC[
    valid_oriC,
    ,
    drop = FALSE
  ]

  if (nrow(oriC) == 0) {
    return(set_all_status("No_valid_oriC_coordinate"))
  }

  oriC <- oriC[
    order(oriC$Start, oriC$Stop),
    ,
    drop = FALSE
  ]

  ori_mid <- circular_feature_midpoint(
    oriC$Start,
    oriC$Stop,
    genome_length
  )

  invalid_prop_coord <- is.na(d$Prop_Start) |
    is.na(d$Prop_End) |
    d$Prop_Start < 1 |
    d$Prop_End < d$Prop_Start |
    d$Prop_End > genome_length

  d$Distance_Status[invalid_prop_coord] <-
    "Prophage_coordinate_out_of_genome_range"

  valid_indices <- which(
    !invalid_prop_coord
  )

  if (length(valid_indices) == 0) {
    return(d)
  }

  for (i in valid_indices) {

    prop_mid <- (
      d$Prop_Start[i] +
        d$Prop_End[i]
    ) / 2

    linear_dist <- abs(
      prop_mid - ori_mid
    )

    circular_dist <- pmin(
      linear_dist,
      genome_length - linear_dist
    )

    nearest_idx <- which.min(
      circular_dist
    )

    d$Prop_Mid[i] <- prop_mid

    d$Nearest_Ori_Type[i] <- "oriC"
    d$Nearest_Ori_Start[i] <- oriC$Start[nearest_idx]
    d$Nearest_Ori_Stop[i] <- oriC$Stop[nearest_idx]
    d$Nearest_Ori_Mid[i] <- ori_mid[nearest_idx]

    d$Linear_Distance_bp[i] <-
      linear_dist[nearest_idx]

    d$Circular_Distance_bp[i] <-
      circular_dist[nearest_idx]

    d$Relative_Distance[i] <-
      circular_dist[nearest_idx] /
      (genome_length / 2)

    d$Distance_Status[i] <- "Success"
  }

  return(d)
}

distribution_statistics <- function(x) {

  x <- as.numeric(x)
  x <- x[is.finite(x)]

  if (length(x) == 0) {
    return(
      data.frame(
        N = 0L,
        Mean = NA_real_,
        Median = NA_real_,
        Q1 = NA_real_,
        Q3 = NA_real_,
        Min = NA_real_,
        Max = NA_real_,
        stringsAsFactors = FALSE
      )
    )
  }

  q <- quantile(
    x,
    probs = c(0.25, 0.75),
    na.rm = TRUE,
    names = FALSE
  )

  data.frame(
    N = length(x),
    Mean = mean(x),
    Median = median(x),
    Q1 = q[1],
    Q3 = q[2],
    Min = min(x),
    Max = max(x),
    stringsAsFactors = FALSE
  )
}

make_summary_row <- function(
  x,
  dataset_label,
  unit_label,
  value_col
) {

  st <- distribution_statistics(
    x[[value_col]]
  )

  data.frame(
    Dataset = dataset_label,
    Statistical_Unit = unit_label,
    N_Units = st$N,
    N_Host_Genomes = length(
      unique(x$Genome_Key)
    ),
    Mean_Relative_Distance = st$Mean,
    Median_Relative_Distance = st$Median,
    Q1_Relative_Distance = st$Q1,
    Q3_Relative_Distance = st$Q3,
    Min_Relative_Distance = st$Min,
    Max_Relative_Distance = st$Max,
    stringsAsFactors = FALSE
  )
}

cmag_ori <- read_ori_file(
  CMAG_ORI_FILE,
  "CMAG"
)

refseq_ori <- read_ori_file(
  REFSEQ_ORI_FILE,
  "RefSeq"
)

ori_all <- rbind(
  cmag_ori,
  refseq_ori
)

ori_summary <- make_ori_summary(
  ori_all
)

write_tsv(
  ori_all,
  file.path(
    OUT_DIR,
    "all_ori_records_normalized.tsv"
  )
)

write_tsv(
  ori_summary,
  file.path(
    OUT_DIR,
    "ori_status_by_genome.tsv"
  )
)

cmag_checkv <- read_checkv_quality(
  CMAG_CHECKV_FILE,
  "CMAG"
)

refseq_checkv <- read_checkv_quality(
  REFSEQ_CHECKV_FILE,
  "RefSeq"
)

checkv_all <- rbind(
  cmag_checkv,
  refseq_checkv
)

checkv_all$Input_Order <- seq_len(
  nrow(checkv_all)
)

write_tsv(
  checkv_all,
  file.path(
    OUT_DIR,
    "all_CheckV_records_with_unified_filter.tsv"
  )
)

checkv_screen_summary <- make_checkv_screen_summary(
  checkv_all
)

write_tsv(
  checkv_screen_summary,
  file.path(
    OUT_DIR,
    "CheckV_unified_filter_summary.tsv"
  )
)

candidates <- checkv_all[
  checkv_all$Quality_Filter_Pass,
  ,
  drop = FALSE
]

if (nrow(candidates) == 0) {
  stop("No prophages passed the unified CheckV filter.")
}

cmag_manifest <- build_fasta_manifest(
  CMAG_FASTA_DIR,
  "CMAG"
)

refseq_manifest <- build_fasta_manifest(
  REFSEQ_FASTA_DIR,
  "RefSeq"
)

fasta_manifest <- rbind(
  cmag_manifest,
  refseq_manifest
)

ori_match <- match(
  candidates$Genome_Key,
  ori_summary$Genome_Key
)

candidates$Ori_Genome_Raw <- ori_summary$Ori_Genome_Raw[
  ori_match
]

candidates$Ori_Types <- ori_summary$Ori_Types[
  ori_match
]

candidates$Has_Non_oriT <- ori_summary$Has_Non_oriT[
  ori_match
]

candidates$Has_oriC_Annotation <- ori_summary$Has_oriC_Annotation[
  ori_match
]

candidates$OriC_Record_Count <- ori_summary$OriC_Record_Count[
  ori_match
]

fasta_match <- match(
  candidates$Genome_Key,
  fasta_manifest$Genome_Key
)

candidates$Genome_File <- fasta_manifest$Genome_File[
  fasta_match
]

fasta_to_measure <- unique(
  candidates$Genome_File[
    !is.na(candidates$Genome_File) &
      candidates$Genome_File != ""
  ]
)

if (length(fasta_to_measure) > 0) {

  active_workers <- min(
    N_CORES,
    length(fasta_to_measure)
  )

  fasta_info_list <- parallel_map(
    fasta_to_measure,
    get_fasta_info,
    N_CORES
  )

  fasta_info <- do.call(
    rbind,
    fasta_info_list
  )

} else {

  fasta_info <- data.frame(
    Genome_File = character(0),
    Fasta_Read_Status = character(0),
    Fasta_Contig_Count = integer(0),
    Genome_Length = numeric(0),
    stringsAsFactors = FALSE
  )
}

manifest_info_match <- match(
  fasta_manifest$Genome_File,
  fasta_info$Genome_File
)

fasta_manifest$Fasta_Read_Status <- fasta_info$Fasta_Read_Status[
  manifest_info_match
]

fasta_manifest$Fasta_Contig_Count <- fasta_info$Fasta_Contig_Count[
  manifest_info_match
]

fasta_manifest$Genome_Length <- fasta_info$Genome_Length[
  manifest_info_match
]

write_tsv(
  fasta_manifest,
  file.path(
    OUT_DIR,
    "genome_fasta_manifest_and_lengths.tsv"
  )
)

candidate_fasta_match <- match(
  candidates$Genome_File,
  fasta_info$Genome_File
)

candidates$Fasta_Read_Status <- fasta_info$Fasta_Read_Status[
  candidate_fasta_match
]

candidates$Fasta_Contig_Count <- fasta_info$Fasta_Contig_Count[
  candidate_fasta_match
]

candidates$Genome_Length <- fasta_info$Genome_Length[
  candidate_fasta_match
]

candidates$Nearest_Ori_Type <- NA_character_
candidates$Nearest_Ori_Start <- NA_real_
candidates$Nearest_Ori_Stop <- NA_real_
candidates$Nearest_Ori_Mid <- NA_real_
candidates$Linear_Distance_bp <- NA_real_
candidates$Circular_Distance_bp <- NA_real_
candidates$Relative_Distance <- NA_real_
candidates$Distance_Status <- NA_character_

host_keys <- unique(
  candidates$Genome_Key
)

distance_one_host_safe <- function(genome_key) {

  tryCatch({

    calc_distance_one_host(
      genome_key = genome_key,
      candidate_df = candidates,
      ori_df = ori_all
    )

  }, error = function(e) {

    d <- candidates[
      candidates$Genome_Key == genome_key,
      ,
      drop = FALSE
    ]

    d$Distance_Status <- paste0(
      "Calculation_error:",
      gsub(
        "[\t\r\n]",
        " ",
        conditionMessage(e)
      )
    )

    return(d)
  })
}

active_workers <- min(
  N_CORES,
  length(host_keys)
)

distance_result_list <- parallel_map(
  host_keys,
  distance_one_host_safe,
  N_CORES
)

distance_result <- do.call(
  rbind,
  distance_result_list
)

distance_result <- distance_result[
  order(distance_result$Input_Order),
  ,
  drop = FALSE
]

rownames(distance_result) <- NULL

write_tsv(
  distance_result,
  file.path(
    OUT_DIR,
    "prophage_oriC_distance_all_QCpass.tsv"
  )
)

success_df <- distance_result[
  distance_result$Distance_Status == "Success",
  ,
  drop = FALSE
]

excluded_df <- distance_result[
  distance_result$Distance_Status != "Success",
  ,
  drop = FALSE
]

oriT_only_df <- distance_result[
  distance_result$Distance_Status == "oriT_only_excluded",
  ,
  drop = FALSE
]

write_tsv(
  success_df,
  file.path(
    OUT_DIR,
    "prophage_oriC_distance_success.tsv"
  )
)

write_tsv(
  excluded_df,
  file.path(
    OUT_DIR,
    "prophages_excluded_from_oriC_distance.tsv"
  )
)

write_tsv(
  oriT_only_df,
  file.path(
    OUT_DIR,
    "prophages_from_oriT_only_hosts.tsv"
  )
)

status_count_list <- lapply(
  split(
    distance_result,
    distance_result$Dataset
  ),
  function(x) {

    tab <- table(
      x$Distance_Status,
      useNA = "ifany"
    )

    data.frame(
      Dataset = x$Dataset[1],
      Distance_Status = names(tab),
      N_Prophages = as.integer(tab),
      stringsAsFactors = FALSE
    )
  }
)

status_count_df <- do.call(
  rbind,
  status_count_list
)

write_tsv(
  status_count_df,
  file.path(
    OUT_DIR,
    "distance_calculation_status_summary.tsv"
  )
)

if (nrow(success_df) == 0) {
  quit(save = "no", status = 0)
}

genome_split <- split(
  success_df,
  success_df$Genome_Key
)

genome_summary_list <- lapply(
  genome_split,
  function(x) {

    st <- distribution_statistics(
      x$Relative_Distance
    )

    data.frame(
      Dataset = x$Dataset[1],
      Genome_Key = x$Genome_Key[1],
      Host_Genome = x$Host_Genome[1],
      Ori_Genome_Raw = x$Ori_Genome_Raw[1],
      Ori_Types = x$Ori_Types[1],
      OriC_Record_Count = x$OriC_Record_Count[1],
      Genome_File = x$Genome_File[1],
      Genome_Length = x$Genome_Length[1],
      N_Prophages = nrow(x),
      Mean_Relative_Distance = st$Mean,
      Median_Relative_Distance = st$Median,
      Q1_Relative_Distance = st$Q1,
      Q3_Relative_Distance = st$Q3,
      Min_Relative_Distance = st$Min,
      Max_Relative_Distance = st$Max,
      stringsAsFactors = FALSE
    )
  }
)

genome_summary_df <- do.call(
  rbind,
  genome_summary_list
)

genome_summary_df <- genome_summary_df[
  order(
    genome_summary_df$Dataset,
    genome_summary_df$Host_Genome
  ),
  ,
  drop = FALSE
]

rownames(genome_summary_df) <- NULL

write_tsv(
  genome_summary_df,
  file.path(
    OUT_DIR,
    "prophage_oriC_distance_by_genome.tsv"
  )
)

dataset_labels <- sort(
  unique(success_df$Dataset)
)

prophage_summary_rows <- lapply(
  dataset_labels,
  function(label) {

    x <- success_df[
      success_df$Dataset == label,
      ,
      drop = FALSE
    ]

    make_summary_row(
      x = x,
      dataset_label = label,
      unit_label = "Prophage",
      value_col = "Relative_Distance"
    )
  }
)

prophage_summary_rows[[length(prophage_summary_rows) + 1]] <-
  make_summary_row(
    x = success_df,
    dataset_label = "Combined",
    unit_label = "Prophage",
    value_col = "Relative_Distance"
  )

prophage_summary_df <- do.call(
  rbind,
  prophage_summary_rows
)

genome_summary_rows <- lapply(
  dataset_labels,
  function(label) {

    x <- genome_summary_df[
      genome_summary_df$Dataset == label,
      ,
      drop = FALSE
    ]

    make_summary_row(
      x = x,
      dataset_label = label,
      unit_label = "Genome_mean",
      value_col = "Mean_Relative_Distance"
    )
  }
)

genome_summary_rows[[length(genome_summary_rows) + 1]] <-
  make_summary_row(
    x = genome_summary_df,
    dataset_label = "Combined",
    unit_label = "Genome_mean",
    value_col = "Mean_Relative_Distance"
  )

genome_level_summary_df <- do.call(
  rbind,
  genome_summary_rows
)

overall_summary_df <- rbind(
  prophage_summary_df,
  genome_level_summary_df
)

write_tsv(
  overall_summary_df,
  file.path(
    OUT_DIR,
    "relative_distance_summary_statistics.tsv"
  )
)

plot_labels <- c(
  "CMAG",
  "RefSeq",
  "Combined"
)

hist_pdf <- file.path(
  OUT_DIR,
  "prophage_relative_distance_histograms.pdf"
)

pdf(
  hist_pdf,
  width = 13,
  height = 4.5
)

par(
  mfrow = c(1, 3),
  mar = c(4.5, 4.5, 3.5, 1)
)

for (label in plot_labels) {

  if (label == "Combined") {
    values <- success_df$Relative_Distance
  } else {
    values <- success_df$Relative_Distance[
      success_df$Dataset == label
    ]
  }

  values <- values[
    is.finite(values)
  ]

  if (length(values) == 0) {

    plot.new()

    title(
      main = paste0(
        label,
        "\nNo successful prophages"
      )
    )

  } else {

    hist(
      values,
      breaks = seq(0, 1, by = 0.05),
      xlim = c(0, 1),
      col = "#4C72B0",
      border = "white",
      main = paste0(
        label,
        "\nN = ",
        length(values)
      ),
      xlab = "Relative distance to nearest oriC",
      ylab = "Number of prophages"
    )

    abline(
      v = median(values),
      col = "#C44E52",
      lwd = 2,
      lty = 2
    )
  }
}

dev.off()

box_pdf <- file.path(
  OUT_DIR,
  "prophage_relative_distance_boxplot.pdf"
)

pdf(
  box_pdf,
  width = 7,
  height = 6
)

plot_groups <- split(
  success_df$Relative_Distance,
  success_df$Dataset
)

plot_groups <- plot_groups[
  names(plot_groups) %in% c(
    "CMAG",
    "RefSeq"
  )
]

plot_groups <- plot_groups[
  vapply(
    plot_groups,
    length,
    integer(1)
  ) > 0
]

if (length(plot_groups) == 0) {

  plot.new()

  title(
    main = "No successful prophage distance results"
  )

} else {

  colors <- c(
    CMAG = "#4C72B0",
    RefSeq = "#55A868"
  )

  boxplot(
    plot_groups,
    ylim = c(0, 1),
    col = colors[names(plot_groups)],
    border = "black",
    ylab = "Relative distance to nearest oriC",
    main = "Prophage relative distance to oriC",
    outline = FALSE
  )

  stripchart(
    plot_groups,
    method = "jitter",
    vertical = TRUE,
    add = TRUE,
    pch = 16,
    cex = 0.6,
    col = grDevices::adjustcolor(
      "black",
      alpha.f = 0.35
    )
  )

  abline(
    h = 0.5,
    col = "gray70",
    lty = 2
  )
}

dev.off()

writeLines(
  c(
    paste0("Run_time: ", Sys.time()),
    paste0("N_CORES: ", N_CORES),
    paste0(
      "MIN_CONTIG_LENGTH: ",
      MIN_CONTIG_LENGTH,
      " (strictly greater than)"
    ),
    paste0(
      "MIN_COMPLETENESS: ",
      MIN_COMPLETENESS,
      " (greater than or equal to)"
    ),
    "Distance_reference: oriC only",
    "oriT_only_hosts: excluded",
    "CheckV_provirus_column: retained as annotation, not hard-filtered",
    "CMAG_FASTA_search: first level of /home/huangyan/experiment/SPA/ori/genome",
    paste0(
      "RefSeq_FASTA_search: first level only of ",
      REFSEQ_FASTA_DIR
    )
  ),
  file.path(
    OUT_DIR,
    "run_parameters.txt"
  )
)