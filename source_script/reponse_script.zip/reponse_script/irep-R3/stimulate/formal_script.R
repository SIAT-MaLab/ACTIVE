library(MASS)
library(dplyr)
library(tibble)
library(ggplot2)
library(foreach)
library(doParallel)

OUT_DIR <- "results"
if (!dir.exists(OUT_DIR)) {
  dir.create(OUT_DIR, recursive = TRUE)
}

GENOME_LEN   <- 3000000
PHAGE_LEN    <- 40000
WINDOW       <- 500
SLIDE        <- 100
C_BASE       <- 100
DISPERSION   <- 25.0

starts       <- seq(0, GENOME_LEN - WINDOW, by = SLIDE)
centers      <- starts + WINDOW / 2
n_windows    <- length(centers)
half_genome  <- GENOME_LEN / 2

dist_to_ori  <- pmin(centers, GENOME_LEN - centers)
f_vals       <- dist_to_ori / half_genome

cliffs_delta <- function(x, y) {
  nx <- length(x)
  ny <- length(y)
  if (nx == 0 || ny == 0) return(NA)
  y_sorted <- sort(y)
  greater  <- sum(findInterval(x, y_sorted, left.open = TRUE))
  less     <- sum(ny - findInterval(x, y_sorted))
  return((greater - less) / (nx * ny))
}

simulate_one <- function(iRep, f_phage, ptoh, seed) {
  set.seed(seed)
  mu_host <- C_BASE * (iRep ^ (-f_vals))
  
  phage_center <- f_phage * half_genome
  dist_to_phage <- pmin(abs(centers - phage_center), GENOME_LEN - abs(centers - phage_center))
  is_phage <- dist_to_phage <= (PHAGE_LEN / 2)
  
  mu <- mu_host
  mu[is_phage] <- mu[is_phage] * ptoh
  
  cov <- rnbinom(n = n_windows, size = DISPERSION, mu = mu)
  phage_cov <- cov[is_phage]
  host_cov  <- cov[!is_phage]
  
  if (length(phage_cov) < 3) return(NA)
  return(cliffs_delta(phage_cov, host_cov))
}

n_cores <- 20
cl <- makeCluster(n_cores)
registerDoParallel(cl)
on.exit(stopCluster(cl), add = TRUE)

export_vars <- c("GENOME_LEN", "PHAGE_LEN", "WINDOW", "SLIDE", "C_BASE", 
                 "DISPERSION", "centers", "n_windows", "half_genome", 
                 "f_vals", "cliffs_delta", "simulate_one")

N_REPLICATES_1 <- 20
iRep_list_1    <- seq(1.05, 3.00, by = 0.05)
delta_list_1   <- seq(0.47, 0.90, by = 0.01)
f_list_1       <- c(0.0, 0.5, 1.0)
ptoh_list_1    <- seq(0.2, 20.0, by = 0.2)

grid_1 <- expand.grid(iRep = iRep_list_1, ptoh = ptoh_list_1, f = f_list_1, rep = 1:N_REPLICATES_1)

results_list_1 <- foreach(i = 1:nrow(grid_1),
                          .combine = 'rbind',
                          .packages = c('MASS', 'dplyr'),
                          .export = export_vars) %dopar% {
  iRep    <- grid_1$iRep[i]
  ptoh    <- grid_1$ptoh[i]
  f_phage <- grid_1$f[i]
  rep     <- grid_1$rep[i]
  seed    <- as.integer(round(f_phage * 1e4)) + rep * 7 + as.integer(round(ptoh * 13)) + as.integer(round(iRep * 100)) * 10
  delta_val <- simulate_one(iRep, f_phage, ptoh, seed)
  data.frame(iRep = iRep, ptoh = ptoh, f = f_phage, delta = delta_val)
}

df_smooth_1 <- as.data.frame(results_list_1) %>%
  filter(!is.na(delta)) %>%
  group_by(iRep, ptoh, f) %>%
  summarise(delta_mean = mean(delta), .groups = 'drop')

df_target_1 <- df_smooth_1 %>%
  group_by(iRep, f) %>%
  group_modify(~ {
    sub <- .x[order(.x$ptoh), ]
    sub$delta_mono <- cummax(sub$delta_mean)
    approx_func <- approxfun(x = sub$delta_mono, y = sub$ptoh, rule = 1)
    req_ptohs <- approx_func(delta_list_1)
    tibble(target_delta = delta_list_1, required_ptoh = req_ptohs)
  }) %>%
  filter(!is.na(required_ptoh))

write.csv(df_target_1, file.path(OUT_DIR, "required_ptoh_multivariate.csv"), row.names = FALSE)

df_target_1$f_label <- factor(df_target_1$f, levels = c(0, 0.5, 1.0),
                              labels = c("f=0 (Ori side)", "f=0.5 (Middle)", "f=1.0 (Ter side)"))

p1 <- ggplot(df_target_1, aes(x = iRep, y = target_delta, z = required_ptoh)) +
  geom_raster(aes(fill = required_ptoh), interpolate = TRUE) +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", midpoint = 1, name = "Required PTOH") +
  geom_contour(breaks = c(1), color = "black", linewidth = 1.1) +
  stat_contour(breaks = c(1), geom = "text", aes(label = "PTOH=1"), color = "black", size = 3.5, check_overlap = TRUE, vjust = -0.2) +
  geom_hline(yintercept = 0.8, color = "darkblue", linewidth = 1.2, linetype = "dashed") +
  annotate("text", x = 1.1, y = 0.82, label = "delta = 0.8", color = "darkblue", size = 3.5, hjust = 0) +
  facet_wrap(~ f_label, ncol = 3) +
  labs(
    title = "Required True Induction (PTOH) across iRep and target Cliff's delta",
    subtitle = "Black solid contour: PTOH=1 (Null line) | Dashed blue horizontal line: Target delta=0.8",
    x = "Host iRep (Replication Rate)",
    y = "Target Cliff's delta"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 10, color = "gray30"),
    legend.position = "right",
    strip.background = element_rect(fill = "grey90", color = NA),
    strip.text = element_text(size = 11, face = "bold")
  )

ggsave(file.path(OUT_DIR, "required_ptoh_multivariate_final.pdf"), p1, width = 12, height = 5)

N_REPLICATES_2 <- 20
iRep_grid_2    <- seq(1.00, 3.00, by = 0.01)
grid_2 <- expand.grid(iRep = iRep_grid_2, rep = 1:N_REPLICATES_2)

results_list_2 <- foreach(i = 1:nrow(grid_2),
                          .combine = 'rbind',
                          .packages = c('MASS'),
                          .export = export_vars) %dopar% {
  iRep <- grid_2$iRep[i]
  rep  <- grid_2$rep[i]
  seed <- rep * 1000 + as.integer(round(iRep * 10000))
  
  delta_val <- simulate_one(iRep = iRep, f_phage = 0.0, ptoh = 1.0, seed = seed)
  data.frame(iRep = iRep, delta = delta_val)
}

df_f0_summary <- results_list_2 %>%
  filter(!is.na(delta)) %>%
  group_by(iRep) %>%
  summarise(
    delta_mean = mean(delta),
    delta_sd   = sd(delta),
    .groups = 'drop'
  )

write.csv(df_f0_summary, file.path(OUT_DIR, "safe_delta_threshold_summary.csv"), row.names = FALSE)

safe_delta_threshold <- max(df_f0_summary$delta_mean)
max_irep_point <- df_f0_summary$iRep[which.max(df_f0_summary$delta_mean)]

cat(sprintf("Max false-positive delta = %.4f at iRep = %.2f\n", safe_delta_threshold, max_irep_point))
cat(sprintf("Minimum safe delta threshold = %.4f\n", safe_delta_threshold))

p2 <- ggplot(df_f0_summary, aes(x = iRep, y = delta_mean)) +
  geom_ribbon(aes(ymin = 0.47, ymax = delta_mean), fill = "#FF6B6B", alpha = 0.25) +
  geom_ribbon(aes(ymin = safe_delta_threshold, ymax = 1.00), fill = "#51CF66", alpha = 0.2) +
  geom_line(color = "#C92A2A", linewidth = 1.2) +
  geom_point(color = "#A81C1C", size = 1.5, alpha = 0.7) +
  geom_hline(yintercept = safe_delta_threshold, linetype = "solid", color = "#00A86B", linewidth = 1.5) +
  geom_hline(yintercept = 0.474, linetype = "dotted", color = "grey40", linewidth = 0.8) +
  geom_hline(yintercept = 0.700, linetype = "dashed", color = "grey40", linewidth = 0.8) +
  geom_hline(yintercept = 0.800, linetype = "dashed", color = "grey40", linewidth = 0.8) +
  annotate("text", x = 1.02, y = safe_delta_threshold + 0.015,
           label = sprintf("★ Absolute Safe Threshold (Min Delta = %.3f)", safe_delta_threshold),
           color = "#006B43", fontface = "bold", hjust = 0, size = 4.5) +
  annotate("text", x = 2.98, y = 0.485, label = "Large Effect Size (0.474)", color = "grey30", hjust = 1, size = 3.5) +
  annotate("text", x = 2.98, y = 0.712, label = "Standard Threshold (0.700)", color = "grey30", hjust = 1, size = 3.5) +
  annotate("text", x = 2.98, y = 0.812, label = "Strict Threshold (0.800)", color = "grey30", hjust = 1, size = 3.5) +
  scale_x_continuous(breaks = seq(1.0, 3.0, by = 0.2), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0.47, 1.00), breaks = seq(0.50, 1.00, by = 0.05), expand = c(0, 0)) +
  labs(
    title = "False Positive Calibration & Safe Threshold Selection (f=0, PTOH=1.0)",
    subtitle = sprintf("Scanning iRep [1.0-3.0] | Green Solid Line: Zero-False-Positive Minimum Delta Threshold (%.3f)", safe_delta_threshold),
    x = "Host iRep (Replication Rate)",
    y = "Resulting False-Positive Cliff's Delta"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 10, color = "grey20"),
    panel.grid.minor = element_blank()
  )

ggsave(file.path(OUT_DIR, "plot3_safe_delta_threshold.pdf"), p2, width = 9.5, height = 6.5)

cat("Done. Output:", OUT_DIR, "\n")