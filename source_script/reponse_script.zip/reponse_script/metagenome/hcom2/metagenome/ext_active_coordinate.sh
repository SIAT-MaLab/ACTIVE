#!/usr/bin/env bash
set -eo pipefail

VIRUS_FASTA=""
HOST_FASTA=""
OUT_DIR=""
THREADS=16

usage() {
    cat << EOF
Usage: $0 -v <virus.fasta> -r <host_bins.fasta> -o <out_dir> [-t <threads>]

Options:
  -v FILE    Input prophage FASTA file (e.g. ami_hy_pp-checkv.fasta)
  -r FILE    Host MAGs/contig reference file (e.g. allhybin.fasta)
  -o DIR     Output directory
  -t INT     Threads (default: 16)
  -h         Help
EOF
    exit 1
}

while getopts "v:r:o:t:h" opt; do
    case $opt in
        v) VIRUS_FASTA="$OPTARG" ;;
        r) HOST_FASTA="$OPTARG" ;;
        o) OUT_DIR="$OPTARG" ;;
        t) THREADS="$OPTARG" ;;
        h|*) usage ;;
    esac
done

if [[ -z "$VIRUS_FASTA" || -z "$HOST_FASTA" || -z "$OUT_DIR" ]]; then
    echo -e "\033[31m[Error] Missing required arguments!\033[0m"
    usage
fi

mkdir -p "${OUT_DIR}/blast_db"
LOG="${OUT_DIR}/pipeline.log"
exec > >(tee -a "${LOG}") 2>&1

echo "========================================================================"
echo "    Prophage Target-Constrained Coordinate Extraction (v3.0)            "
echo "========================================================================"
echo "Start Time    : $(date)"
echo "Virus Input   : ${VIRUS_FASTA}"
echo "Host Input    : ${HOST_FASTA}"
echo "Threads       : ${THREADS}"
echo "Output Dir    : ${OUT_DIR}"
echo "------------------------------------------------------------------------"

DB_PREFIX="${OUT_DIR}/blast_db/host_db"
if [[ ! -f "${DB_PREFIX}.nhr" ]]; then
    echo "[Step 1] Building host BLAST database..."
    makeblastdb -in "${HOST_FASTA}" -dbtype nucl -out "${DB_PREFIX}" -title "host_db"
else
    echo "[Step 1] Existing BLAST database found, reusing."
fi

BLAST_OUT="${OUT_DIR}/prophage_vs_host.blast.tsv"
echo "[Step 2] Running BLASTN..."
blastn \
    -query "${VIRUS_FASTA}" \
    -db "${DB_PREFIX}" \
    -outfmt "6 qseqid sseqid pident length qstart qend sstart send evalue bitscore score" \
    -max_target_seqs 1000 \
    -num_threads "${THREADS}" \
    -out "${BLAST_OUT}"

COORDINATE_TSV="${OUT_DIR}/prophage_coordinates.tsv"
COORDINATE_BED="${OUT_DIR}/prophage_coordinates.bed"
UNMAPPED_TSV="${OUT_DIR}/unmapped_prophages.tsv"

echo "[Step 3] Resolving physical coordinates..."

python3 - "${BLAST_OUT}" "${VIRUS_FASTA}" "${HOST_FASTA}" "${COORDINATE_TSV}" "${COORDINATE_BED}" "${UNMAPPED_TSV}" <<'PYEOF'
import sys

blast_file, virus_fasta, host_fasta, out_tsv, out_bed, out_unmapped = sys.argv[1:7]

host_contigs = set()
with open(host_fasta, 'r') as f:
    for line in f:
        if line.startswith(">"):
            host_contigs.add(line[1:].strip().split()[0])

print(f"  -> Host contigs loaded: {len(host_contigs)}")

def resolve_target_contig(qid, valid_hosts):
    clean_id = (
        qid.split("|")[0].split("__provirus")[0].split("part_")[-1].strip()
    )

    parts = clean_id.split("_")
    if len(parts) >= 2:
        target_id = f"{parts[0]}_{parts[1]}"
        if target_id in valid_hosts:
            return target_id

    return clean_id if clean_id in valid_hosts else clean_id

all_queries = {}
with open(virus_fasta, 'r') as f:
    for line in f:
        if line.startswith(">"):
            qid = line[1:].strip().split()[0]
            target_host = resolve_target_contig(qid, host_contigs)
            all_queries[qid] = target_host

best_hits = {}
with open(blast_file, 'r') as f:
    for line in f:
        parts = line.strip().split('\t')
        if len(parts) < 11:
            continue
        
        qseqid = parts[0]
        sseqid = parts[1]
        sstart = int(parts[6])
        send = int(parts[7])
        bitscore = float(parts[9])

        target_host = all_queries.get(qseqid)
        if not target_host or sseqid != target_host:
            continue

        if qseqid not in best_hits or bitscore > best_hits[qseqid]['bitscore']:
            best_hits[qseqid] = {
                'sseqid': sseqid,
                'sstart': sstart,
                'send': send,
                'bitscore': bitscore
            }

mapped_qids = set(best_hits.keys())
with open(out_tsv, 'w') as f_tsv, open(out_bed, 'w') as f_bed:
    for qid, hit in sorted(best_hits.items()):
        sstart = hit['sstart']
        send = hit['send']
        
        start_coord = min(sstart, send)
        stop_coord = max(sstart, send)
        strand = "+" if sstart <= send else "-"

        f_tsv.write(f"{hit['sseqid']}\t{start_coord}\t{stop_coord}\n")
        
        f_bed.write(f"{hit['sseqid']}\t{start_coord - 1}\t{stop_coord}\t{qid}\t{int(hit['bitscore'])}\t{strand}\n")

with open(out_unmapped, 'w') as f_unmapped:
    f_unmapped.write("prophage_id\ttarget_host_contig\treason\n")
    for qid, target in all_queries.items():
        if qid not in mapped_qids:
            if target not in host_contigs:
                reason = "Host_contig_missing_in_reference_fasta"
            else:
                reason = "BLAST_alignment_below_threshold_or_culled"
            f_unmapped.write(f"{qid}\t{target}\t{reason}\n")

n_total = len(all_queries)
n_mapped = len(mapped_qids)
n_unmapped = len(all_queries) - n_mapped

print(f"\n--- QC Summary ---")
print(f"Total    : {n_total}")
print(f"Mapped   : {n_mapped} ({(n_mapped/n_total)*100:.2f}%)")
print(f"Unmapped : {n_unmapped} ({(n_unmapped/n_total)*100:.2f}%)")

if n_unmapped > 0:
    print(f"Unmapped details: {out_unmapped}")
else:
    print("100% of prophages mapped to host coordinates.")
PYEOF

echo "------------------------------------------------------------------------"
echo "Coordinate extraction complete."
echo "TSV (no header, 3 columns) : ${COORDINATE_TSV}"
echo "BED                        : ${COORDINATE_BED}"
echo "Unmapped report            : ${UNMAPPED_TSV}"
echo "End Time                   : $(date)"
echo "========================================================================"