#!/bin/bash

in=/public/home/huangyan/SPA/metagenome_benchmark/hcom2/metagenome
THREADS=60
OUTDIR="$in/fastq"
mkdir -p ${OUTDIR}
for file in $in/*.lite.1; do
    sample=$(basename "$file" .lite.1)

    echo "Processing: ${sample} ..."

    fasterq-dump --split-3 -e ${THREADS} -O ${OUTDIR} "${file}"

    if [ $? -eq 0 ]; then
        echo "Compressing ${sample} fastq files..."
        pigz -p ${THREADS} ${OUTDIR}/${sample}*.fastq
        echo "${sample} done."
    else
        echo "[ERROR] ${sample} conversion failed!"
    fi
done
echo "All samples processed. Output: ${OUTDIR}"

#!/usr/bin/env bash
set -euo pipefail

THREADS=40
BASE_DIR="/public/home/huangyan/SPA/metagenome_benchmark/hcom2/metagenome"
INPUT_DIR="${BASE_DIR}/fastq"
OUTPUT_DIR="${INPUT_DIR}/clean_data"
LOG_DIR="${INPUT_DIR}/logs"
REF_FA="${BASE_DIR}/GCF_000001635.27_GRCm39_genomic.fna"
REF_MMI="${BASE_DIR}/GCF_000001635.27_GRCm39_genomic.mmi"

mkdir -p "${OUTPUT_DIR}" "${LOG_DIR}"

[[ ! -s "${REF_FA}" && -s "${REF_FA}.gz" ]] && gzip -cd "${REF_FA}.gz" > "${REF_FA}"
[[ ! -s "${REF_MMI}" ]] && minimap2 -t "${THREADS}" -d "${REF_MMI}" "${REF_FA}"

for R1 in "${INPUT_DIR}"/*.lite.1_1.fastq.gz; do
    [[ -e "${R1}" ]] || exit 1
    SAMPLE=$(basename "${R1}" .lite.1_1.fastq.gz)
    R2="${INPUT_DIR}/${SAMPLE}.lite.1_2.fastq.gz"
    
    CLEAN1="${OUTPUT_DIR}/${SAMPLE}_1_clean.fastq.gz"
    CLEAN2="${OUTPUT_DIR}/${SAMPLE}_2_clean.fastq.gz"
    
    [[ -s "${CLEAN1}" && -s "${CLEAN2}" ]] && continue

    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Processing: ${SAMPLE}"

    QC1=$(mktemp "${INPUT_DIR}/${SAMPLE}_qc1_XXXXXX.fq.gz")
    QC2=$(mktemp "${INPUT_DIR}/${SAMPLE}_qc2_XXXXXX.fq.gz")

    fastp -i "${R1}" -I "${R2}" -o "${QC1}" -O "${QC2}" \
          -w "${THREADS}" -q 20 -u 30 -n 0 -l 50 \
          -h "${LOG_DIR}/${SAMPLE}.fastp.html" -j "${LOG_DIR}/${SAMPLE}.fastp.json" \
          > "${LOG_DIR}/${SAMPLE}.fastp.log" 2>&1

    minimap2 -ax sr -t "${THREADS}" "${REF_MMI}" "${QC1}" "${QC2}" 2> "${LOG_DIR}/${SAMPLE}.minimap2.log" | \
    samtools fastq -@ "${THREADS}" -f 12 -n \
        -1 >(pigz -p "${THREADS}" > "${CLEAN1}") \
        -2 >(pigz -p "${THREADS}" > "${CLEAN2}") \
        -0 /dev/null -s /dev/null - 2>> "${LOG_DIR}/${SAMPLE}.minimap2.log"

    rm -f "${QC1}" "${QC2}"
done

#!/bin/bash

BASE_DIR="/public/home/huangyan/SPA/metagenome_benchmark/hcom2/metagenome"
OUTPUT_DIR="${BASE_DIR}/contigs"
LOGFILE="${BASE_DIR}/megahit_echo.log"

if [ -z "$1" ]; then
  echo "Error: input directory required!"
  echo "Usage: bash $0 <input_directory>"
  exit 1
fi

INPUT_DIR=$(readlink -f "$1")

if [ ! -d "$INPUT_DIR" ]; then
  echo "Error: input directory not found -> $INPUT_DIR"
  exit 1
fi

mkdir -p "$OUTPUT_DIR"

if [ ! -f "$LOGFILE" ]; then
  touch "$LOGFILE"
fi

echo "========== Task start: $(date '+%Y-%m-%d %H:%M:%S') ==========" >> "$LOGFILE"
echo "Input: $INPUT_DIR" >> "$LOGFILE"
echo "Output: $OUTPUT_DIR" >> "$LOGFILE"

for file in "${INPUT_DIR}"/*_1_clean.fastq.gz; do
  [ -e "$file" ] || { echo "No *_1_clean.fastq.gz found in $INPUT_DIR" >> "$LOGFILE"; break; }

  filename=$(basename "$file" _1_clean.fastq.gz)
  file2="${INPUT_DIR}/${filename}_2_clean.fastq.gz"

  if [ ! -f "$file2" ]; then
    echo "Warning: missing Read 2: ${file2}, skipping." >> "$LOGFILE"
    continue
  fi

  megahit_out_dir="${OUTPUT_DIR}/${filename}_megahit_tmp"
  output_contigs="${megahit_out_dir}/final.contigs.fa"
  final_contigs="${OUTPUT_DIR}/${filename}_megahit_output.contigs.fa"

  if [ -f "$final_contigs" ]; then
    echo "${final_contigs} already exists. Skipping..." >> "$LOGFILE"
    continue
  fi

  echo "Running megahit for ${filename}..." >> "$LOGFILE"

  [ -d "$megahit_out_dir" ] && rm -rf "$megahit_out_dir"

  megahit -1 "$file" -2 "$file2" -t 100 -o "$megahit_out_dir"

  if [ -f "$output_contigs" ]; then
    mv "$output_contigs" "$final_contigs"
    echo "${final_contigs} success" >> "$LOGFILE"
  else
    echo "${final_contigs} fail" >> "$LOGFILE"
  fi

  if [ -d "${megahit_out_dir}/intermediate_contigs" ]; then
    rm -rf "${megahit_out_dir}/intermediate_contigs"
  fi
done

echo "========== Task complete: $(date '+%Y-%m-%d %H:%M:%S') ==========" >> "$LOGFILE"

#!/usr/bin/env bash
set -euo pipefail

ROOT=/public/home/huangyan/SPA/metagenome_benchmark/hcom2/metagenome

CONTIG_DIR=${ROOT}/contigs
READS_DIR=${ROOT}/fastq/clean_data
OUT=${ROOT}/illumina_bin
DEPTH_DIR=${ROOT}/depth
WORK_DIR=${ROOT}/minimap2_work

mkdir -p "$OUT" "$DEPTH_DIR" "$WORK_DIR"

for file in "$CONTIG_DIR"/*_megahit_output.contigs.fasta; do

    [ -e "$file" ] || { echo "No contig files found in $CONTIG_DIR"; exit 0; }

    sample=$(basename "$file" _megahit_output.contigs.fasta)

    r1=${READS_DIR}/${sample}_1_clean.fastq.gz
    r2=${READS_DIR}/${sample}_2_clean.fastq.gz

    if [[ ! -f "$r1" || ! -f "$r2" ]]; then
        echo "Skip $sample: missing $r1 or $r2" >&2
        continue
    fi

    sam=${WORK_DIR}/minimap2_${sample}.sam
    bam=${WORK_DIR}/${sample}_sorted_minimap2.bam
    depth_txt=${DEPTH_DIR}/depth_${sample}.txt
    out_prefix=${OUT}/${sample}_bin/bin

    mkdir -p "${OUT}/${sample}_bin"

    echo ">>> Processing ${sample}"

    minimap2 -ax sr -t 14 "$file" "$r1" "$r2" > "$sam"

    samtools view -@ 14 -bS "$sam" | samtools sort -@ 20 -o "$bam" -
    samtools index "$bam"

    rm -f "$sam"

    jgi_summarize_bam_contig_depths --outputDepth "$depth_txt" "$bam"

    metabat2 -t 14 -m 2000 -i "$file" -a "$depth_txt" -o "$out_prefix"

    rm -f "$bam" "$bam.bai"
done

echo "complete"