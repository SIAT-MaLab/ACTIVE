#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
})

args    <- commandArgs(trailingOnly = TRUE)
in_file <- if (length(args) >= 1) {
  args[1]
} else if (file.exists("06_assign_mag2iso.all.tsv")) {
  "06_assign_mag2iso.all.tsv"
} else if (file.exists("../06_assign_mag2iso.all.tsv")) {
  "../06_assign_mag2iso.all.tsv"
} else {
  "/home/huangyan/experiment/SPA/metagenome_benchmark/hcom2/prophage_track_hcom2/06_assign_mag2iso.all.tsv"
}
out_dir <- if (length(args) >= 2) args[2] else "plot_out_mag2iso"

if (!file.exists(in_file)) {
  stop(sprintf("Input file not found: %s", in_file))
}
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

df_raw <- read_tsv(in_file, show_col_types = FALSE)

need <- c("sample", "prophage_id", "length", "recovery_stage", "main_class")
miss <- setdiff(need, colnames(df_raw))
if (length(miss) > 0) {
  stop(sprintf("Missing columns in input: %s", paste(miss, collapse = ", ")))
}

df <- df_raw %>%
  mutate(
    sample         = trimws(as.character(sample)),
    prophage_id    = trimws(as.character(prophage_id)),
    length         = suppressWarnings(as.numeric(length)),
    recovery_stage = trimws(as.character(recovery_stage)),
    main_class     = trimws(as.character(main_class)),
    sub_class      = if ("sub_class" %in% colnames(df_raw)) {
      trimws(as.character(sub_class))
    } else {
      NA_character_
    },
    has_owner      = if ("has_owner" %in% colnames(df_raw)) has_owner else NA
  ) %>%
  filter(!is.na(sample), sample != "", !is.na(prophage_id), prophage_id != "")

if (nrow(df) == 0) stop("No rows available after filtering")

n_dup <- df %>%
  count(sample, prophage_id) %>%
  filter(n > 1) %>%
  nrow()
if (n_dup > 0) {
  message(sprintf("Warning: %d sample+prophage_id groups have duplicate rows.", n_dup))
}

df <- df %>%
  mutate(
    stage = case_when(
      grepl("^lost$",     recovery_stage, ignore.case = TRUE) ~ "Lost",
      grepl("partial",    recovery_stage, ignore.case = TRUE) ~ "Partial",
      grepl("^recovered$", recovery_stage, ignore.case = TRUE) ~ "Recovered",
      TRUE ~ recovery_stage
    )
  )

stage_levels <- c(
  "Lost", "Partial", "Recovered",
  sort(setdiff(unique(df$stage), c("Lost", "Partial", "Recovered")))
)
stage_levels <- stage_levels[stage_levels %in% unique(df$stage) |
                               stage_levels %in% c("Lost", "Partial", "Recovered")]

if (!any(df$stage %in% c("Lost", "Partial"))) {
  message("Warning: no Lost/Partial rows; recovery denominator may be incomplete.")
}

df <- df %>%
  mutate(
    class_src = if_else(is.na(main_class) | main_class == "", sub_class, main_class),
    class_clean = case_when(
      grepl("unbinned|no[_ ]?owner|unowned", class_src, ignore.case = TRUE) ~ "Excluded",
      grepl("pure[_ ]?incorrect", class_src, ignore.case = TRUE) ~ "Pure Incorrect",
      grepl("pure[_ ]?correct",   class_src, ignore.case = TRUE) ~ "Pure Correct",
      grepl("mixed",              class_src, ignore.case = TRUE) ~ "Mixed",
      TRUE ~ NA_character_
    )
  )

all_samples <- sort(unique(df$sample))

recovery <- df %>%
  count(sample, stage, name = "n") %>%
  complete(sample = all_samples, stage = stage_levels, fill = list(n = 0)) %>%
  left_join(
    df %>%
      group_by(sample, stage) %>%
      summarise(bp = sum(length, na.rm = TRUE), .groups = "drop"),
    by = c("sample", "stage")
  ) %>%
  mutate(bp = replace_na(bp, 0)) %>%
  group_by(sample) %>%
  mutate(
    total_n  = sum(n),
    total_bp = sum(bp),
    pct_n    = ifelse(total_n  > 0, 100 * n  / total_n,  0),
    pct_bp   = ifelse(total_bp > 0, 100 * bp / total_bp, NA_real_)
  ) %>%
  ungroup() %>%
  mutate(
    stage  = factor(stage,  levels = stage_levels),
    sample = factor(sample, levels = all_samples)
  )

recovery_wide <- recovery %>%
  select(sample, stage, n, bp, pct_n, pct_bp) %>%
  pivot_wider(
    names_from  = stage,
    values_from = c(n, bp, pct_n, pct_bp),
    names_glue  = "{stage}_{.value}"
  )
write_tsv(recovery_wide, file.path(out_dir, "mag2iso_recovery_per_sample.tsv"))

recovery_mean <- recovery %>%
  group_by(stage) %>%
  summarise(
    mean_pct_n   = mean(pct_n),
    median_pct_n = median(pct_n),
    .groups = "drop"
  )
recovery_pooled <- df %>%
  count(stage, name = "n") %>%
  mutate(pct_n = 100 * n / sum(n))

purity_src <- df %>% filter(stage == "Recovered")
n_rec_excluded <- sum(purity_src$class_clean == "Excluded", na.rm = TRUE)
n_rec_unknown  <- sum(is.na(purity_src$class_clean))

target_classes <- c("Pure Correct", "Mixed", "Pure Incorrect")
purity_df <- purity_src %>% filter(class_clean %in% target_classes)

purity <- purity_df %>%
  count(sample, class_clean, name = "n") %>%
  complete(
    sample = all_samples,
    class_clean = target_classes,
    fill = list(n = 0)
  ) %>%
  left_join(
    purity_df %>%
      group_by(sample, class_clean) %>%
      summarise(bp = sum(length, na.rm = TRUE), .groups = "drop"),
    by = c("sample", "class_clean")
  ) %>%
  mutate(bp = replace_na(bp, 0)) %>%
  group_by(sample) %>%
  mutate(
    total_n  = sum(n),
    total_bp = sum(bp),
    pct_n    = ifelse(total_n  > 0, 100 * n  / total_n,  0),
    pct_bp   = ifelse(total_bp > 0, 100 * bp / total_bp, NA_real_)
  ) %>%
  ungroup() %>%
  mutate(class_clean = factor(class_clean, levels = target_classes))

purity_wide <- purity %>%
  filter(total_n > 0) %>%
  select(sample, class_clean, n, bp, pct_n, pct_bp, total_n, total_bp) %>%
  pivot_wider(
    names_from  = class_clean,
    values_from = c(n, bp, pct_n, pct_bp),
    names_glue  = "{class_clean}_{.value}"
  )
write_tsv(purity_wide, file.path(out_dir, "mag2iso_purity_per_sample.tsv"))

purity_mean <- purity %>%
  filter(total_n > 0) %>%
  group_by(class_clean) %>%
  summarise(
    mean_pct_n   = mean(pct_n),
    median_pct_n = median(pct_n),
    .groups = "drop"
  )
purity_pooled <- purity_df %>%
  count(class_clean, name = "n") %>%
  mutate(pct_n = 100 * n / sum(n))

col_stage <- c(
  "Lost"      = "#E57373",
  "Partial"   = "#FFB74D",
  "Recovered" = "#81C784"
)
col_stage_dark <- c(
  "Lost"      = "#C62828",
  "Partial"   = "#EF6C00",
  "Recovered" = "#2E7D32"
)
extra_stages <- setdiff(stage_levels, names(col_stage))
if (length(extra_stages) > 0) {
  extra_cols <- setNames(rep("grey70", length(extra_stages)), extra_stages)
  col_stage <- c(col_stage, extra_cols)
  col_stage_dark <- c(col_stage_dark, setNames(rep("grey40", length(extra_stages)), extra_stages))
}

col_class <- c(
  "Pure Correct"   = "#81C784",
  "Mixed"          = "#FFB74D",
  "Pure Incorrect" = "#E57373"
)
col_class_dark <- c(
  "Pure Correct"   = "#2E7D32",
  "Mixed"          = "#EF6C00",
  "Pure Incorrect" = "#C62828"
)

n_samp <- length(all_samples)
bar_w  <- max(12, n_samp * 0.28)
x_size <- if (n_samp > 40) 7 else 10

theme_bar <- theme_bw(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, size = x_size),
    panel.grid.minor = element_blank(),
    legend.position = "top"
  )

p_rec_bar <- ggplot(recovery, aes(x = sample, y = pct_n, fill = stage)) +
  geom_col(position = "stack", width = 0.75, color = "white", linewidth = 0.2) +
  scale_fill_manual(values = col_stage, drop = FALSE) +
  scale_y_continuous(
    labels = function(x) paste0(x, "%"),
    limits = c(0, 100.1),
    expand = c(0, 0)
  ) +
  labs(
    x = "Sample",
    y = "Proportion of MAG prophages (%)",
    fill = "Status",
    title = "mag→iso recovery per sample",
    subtitle = "Denominator: MAG prophages in 06_assign_mag2iso.all.tsv"
  ) +
  theme_bar

p_rec_box <- ggplot(recovery, aes(x = stage, y = pct_n, fill = stage)) +
  geom_boxplot(outlier.shape = NA, width = 0.45, alpha = 0.7, color = "grey30") +
  geom_jitter(aes(color = stage), width = 0.15, size = 2, alpha = 0.75) +
  scale_fill_manual(values = col_stage, drop = FALSE) +
  scale_color_manual(values = col_stage_dark, drop = FALSE) +
  scale_y_continuous(
    labels = function(x) paste0(x, "%"),
    limits = c(0, 100),
    expand = expansion(mult = c(0.02, 0.05))
  ) +
  labs(
    x = "Status",
    y = "Percentage per sample (%)",
    title = "mag→iso recovery across samples",
    subtitle = sprintf("n = %d samples (each point = one sample)", n_samp)
  ) +
  theme_bw(base_size = 12) +
  theme(panel.grid.minor = element_blank(), legend.position = "none")

ggsave(file.path(out_dir, "mag2iso_01_recovery_stacked_bar.pdf"), p_rec_bar, width = bar_w, height = 6)
ggsave(file.path(out_dir, "mag2iso_01_recovery_stacked_bar.png"), p_rec_bar, width = bar_w, height = 6, dpi = 300)
ggsave(file.path(out_dir, "mag2iso_02_recovery_boxplot.pdf"), p_rec_box, width = 6, height = 6)
ggsave(file.path(out_dir, "mag2iso_02_recovery_boxplot.png"), p_rec_box, width = 6, height = 6, dpi = 300)

purity_plot <- purity %>% filter(total_n > 0)
n_purity_samp <- n_distinct(purity_plot$sample)

if (n_purity_samp == 0) {
  message("No classified Recovered entries; skipping purity plots.")
} else {
  p_pur_bar <- ggplot(purity_plot, aes(x = sample, y = pct_n, fill = class_clean)) +
    geom_col(position = "stack", width = 0.75, color = "white", linewidth = 0.2) +
    scale_fill_manual(values = col_class, drop = FALSE) +
    scale_y_continuous(
      labels = function(x) paste0(x, "%"),
      limits = c(0, 100.1),
      expand = c(0, 0)
    ) +
    labs(
      x = "Sample",
      y = "Proportion of classified Recovered prophages (%)",
      fill = "Classification",
      title = "mag→iso assignment purity per sample",
      subtitle = "Subset: recovery_stage == Recovered; Unbinned/No_owner excluded"
    ) +
    theme_bar

  p_pur_box <- ggplot(purity_plot, aes(x = class_clean, y = pct_n, fill = class_clean)) +
    geom_boxplot(outlier.shape = NA, width = 0.45, alpha = 0.7, color = "grey30") +
    geom_jitter(aes(color = class_clean), width = 0.15, size = 2, alpha = 0.75) +
    scale_fill_manual(values = col_class, drop = FALSE) +
    scale_color_manual(values = col_class_dark, drop = FALSE) +
    scale_y_continuous(
      labels = function(x) paste0(x, "%"),
      limits = c(0, 100),
      expand = expansion(mult = c(0.02, 0.05))
    ) +
    labs(
      x = "Classification",
      y = "Percentage per sample (%)",
      title = "mag→iso purity across samples",
      subtitle = sprintf("n = %d samples with classified Recovered prophages", n_purity_samp)
    ) +
    theme_bw(base_size = 12) +
    theme(panel.grid.minor = element_blank(), legend.position = "none")

  pur_w <- max(12, n_purity_samp * 0.28)
  ggsave(file.path(out_dir, "mag2iso_04_purity_stacked_bar.pdf"), p_pur_bar, width = pur_w, height = 6)
  ggsave(file.path(out_dir, "mag2iso_04_purity_stacked_bar.png"), p_pur_bar, width = pur_w, height = 6, dpi = 300)
  ggsave(file.path(out_dir, "mag2iso_05_purity_boxplot.pdf"), p_pur_box, width = 6, height = 6)
  ggsave(file.path(out_dir, "mag2iso_05_purity_boxplot.png"), p_pur_box, width = 6, height = 6, dpi = 300)
}

if (requireNamespace("patchwork", quietly = TRUE)) {
  library(patchwork)
  p_rec <- p_rec_bar + p_rec_box + plot_layout(widths = c(2.2, 1))
  ggsave(file.path(out_dir, "mag2iso_03_recovery_combined.pdf"), p_rec, width = bar_w + 6, height = 6)
  ggsave(file.path(out_dir, "mag2iso_03_recovery_combined.png"), p_rec, width = bar_w + 6, height = 6, dpi = 300)
  if (n_purity_samp > 0) {
    p_pur <- p_pur_bar + p_pur_box + plot_layout(widths = c(2.2, 1))
    ggsave(file.path(out_dir, "mag2iso_06_purity_combined.pdf"), p_pur, width = pur_w + 6, height = 6)
    ggsave(file.path(out_dir, "mag2iso_06_purity_combined.png"), p_pur, width = pur_w + 6, height = 6, dpi = 300)
  }
} else {
  message("patchwork not installed; skipping combined plots.")
}

lines <- c(
  sprintf("input: %s", normalizePath(in_file)),
  sprintf("rows: %d | samples: %d | prophages: %d",
          nrow(df), n_distinct(df$sample), n_distinct(df$prophage_id)),
  sprintf("duplicate sample+prophage_id groups: %d", n_dup),
  "",
  "===== Recovery: mean of per-sample percentages (each sample equal) =====",
  paste(utils::capture.output(print(as.data.frame(recovery_mean), row.names = FALSE)),
        collapse = "\n"),
  "",
  "===== Recovery: pooled over all MAG prophages =====",
  paste(utils::capture.output(print(as.data.frame(recovery_pooled), row.names = FALSE)),
        collapse = "\n"),
  "",
  sprintf("Recovered rows excluded from purity (Unbinned/No_owner): %d", n_rec_excluded),
  sprintf("Recovered rows with unrecognized class: %d", n_rec_unknown),
  "",
  "===== Purity: mean of per-sample percentages =====",
  paste(utils::capture.output(print(as.data.frame(purity_mean), row.names = FALSE)),
        collapse = "\n"),
  "",
  "===== Purity: pooled over classified Recovered prophages =====",
  paste(utils::capture.output(print(as.data.frame(purity_pooled), row.names = FALSE)),
        collapse = "\n")
)
writeLines(lines, file.path(out_dir, "mag2iso_overall_summary.txt"))