
suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
})

in_file <- if (file.exists("07_summary_iso2mag.tsv")) {
  "07_summary_iso2mag.tsv"
} else if (file.exists("../07_summary_iso2mag.tsv")) {
  "../07_summary_iso2mag.tsv"
} else {
  "/home/huangyan/experiment/SPA/metagenome_benchmark/hcom2/prophage_track_hcom2/07_summary_iso2mag.tsv"
}

out_dir <- "plot_out"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

df <- read_tsv(in_file, show_col_types = FALSE)

# 转换成长格式
df_long <- df %>%
  select(sample, pct_lost, pct_partial, pct_recovered) %>%
  pivot_longer(
    cols = c(pct_lost, pct_partial, pct_recovered),
    names_to = "category",
    values_to = "pct"
  ) %>%
  mutate(
    category = factor(
      category,
      levels = c("pct_lost", "pct_partial", "pct_recovered"),
      labels = c("Lost", "Partial", "Recovered")
    ),
    sample = factor(sample, levels = unique(df$sample))
  )

col_map <- c(
  "Lost"      = "#E57373",
  "Partial"   = "#FFB74D",
  "Recovered" = "#81C784"
)
col_dark <- c(
  "Lost"      = "#C62828",
  "Partial"   = "#EF6C00",
  "Recovered" = "#2E7D32"
)

p1 <- ggplot(df_long, aes(x = sample, y = pct, fill = category)) +
  geom_col(position = "stack", width = 0.75, color = "white", linewidth = 0.2) +
  scale_fill_manual(values = col_map) +
  scale_y_continuous(
    labels = function(x) paste0(x, "%"),
    limits = c(0, 100.1),
    expand = c(0, 0)
  ) +
  labs(
    x = "Sample",
    y = "Proportion (%)",
    fill = "Status",
    title = "Per-sample composition of Lost / Partial / Recovered queries"
  ) +
  theme_bw(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
    panel.grid.minor = element_blank(),
    legend.position = "top"
  )

ggsave(file.path(out_dir, "04_iso2mag_stacked_bar.pdf"), p1, width = 12, height = 6)
ggsave(file.path(out_dir, "04_iso2mag_stacked_bar.png"), p1, width = 12, height = 6, dpi = 300)

p2 <- ggplot(df_long, aes(x = category, y = pct, fill = category)) +
  geom_boxplot(outlier.shape = NA, width = 0.45, alpha = 0.7, color = "grey30") +
  geom_jitter(aes(color = category), width = 0.15, size = 2, alpha = 0.75) +
  scale_fill_manual(values = col_map) +
  scale_color_manual(values = col_dark) +
  scale_y_continuous(
    labels = function(x) paste0(x, "%"),
    limits = c(0, 100),
    expand = expansion(mult = c(0.02, 0.05))
  ) +
  labs(
    x = "Status",
    y = "Percentage (%)",
    title = "Overall distribution across all samples",
    subtitle = sprintf("n = %d samples (each point = one sample)", n_distinct(df$sample))
  ) +
  theme_bw(base_size = 12) +
  theme(
    panel.grid.minor = element_blank(),
    legend.position = "none"
  )

ggsave(file.path(out_dir, "05_iso2mag_status_boxplot.pdf"), p2, width = 6, height = 6)
ggsave(file.path(out_dir, "05_iso2mag_status_boxplot.png"), p2, width = 6, height = 6, dpi = 300)

if (requireNamespace("patchwork", quietly = TRUE)) {
  library(patchwork)
  p_combo <- p1 + p2 + plot_layout(widths = c(2.2, 1))
  ggsave(file.path(out_dir, "06_iso2mag_combined.pdf"), p_combo, width = 16, height = 6)
  ggsave(file.path(out_dir, "06_iso2mag_combined.png"), p_combo, width = 16, height = 6, dpi = 300)
}

