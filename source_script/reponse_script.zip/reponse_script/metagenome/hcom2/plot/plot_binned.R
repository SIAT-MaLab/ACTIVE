#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
})

in_file <- if (file.exists("06_assign_iso2mag.all.tsv")) {
  "06_assign_iso2mag.all.tsv"
} else if (file.exists("../06_assign_iso2mag.all.tsv")) {
  "../06_assign_iso2mag.all.tsv"
} else {
  "/home/huangyan/experiment/SPA/metagenome_benchmark/hcom2/prophage_track_hcom2/06_assign_iso2mag.all.tsv"
}

out_dir <- "plot_out"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

df_raw <- read_tsv(in_file, show_col_types = FALSE)

df_sub <- df_raw %>%
  mutate(
    recovery_stage = trimws(recovery_stage),
    main_class     = trimws(main_class),
    sample         = trimws(sample)
  ) %>%
  filter(
    tolower(recovery_stage) == "recovered",
    !grepl("unbinned", main_class, ignore.case = TRUE)
  ) %>%
  mutate(
    class_clean = case_when(
      grepl("pure_correct",   main_class, ignore.case = TRUE) ~ "Pure Correct",
      grepl("pure_incorrect", main_class, ignore.case = TRUE) ~ "Pure Incorrect",
      grepl("mixed",          main_class, ignore.case = TRUE) ~ "Mixed",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(class_clean))

all_samples    <- sort(unique(df_raw$sample))
target_classes <- c("Pure Correct", "Mixed", "Pure Incorrect")

sample_stats <- df_sub %>%
  count(sample, class_clean, name = "count") %>%
  complete(sample = all_samples, class_clean = target_classes, fill = list(count = 0)) %>%
  group_by(sample) %>%
  mutate(
    total_recovered = sum(count),
    pct = ifelse(total_recovered > 0, count / total_recovered * 100, 0)
  ) %>%
  ungroup() %>%
  mutate(
    class_clean = factor(class_clean, levels = target_classes)
  )

stat_wide <- sample_stats %>%
  select(sample, class_clean, count, pct) %>%
  pivot_wider(
    names_from = class_clean,
    values_from = c(count, pct),
    names_glue = "{class_clean}_{.value}"
  )
write_tsv(stat_wide, file.path(out_dir, "07_recovered_class_summary_per_sample.tsv"))

col_map <- c(
  "Pure Correct"   = "#81C784",
  "Mixed"          = "#FFB74D",
  "Pure Incorrect" = "#E57373"
)
col_dark <- c(
  "Pure Correct"   = "#2E7D32",
  "Mixed"          = "#EF6C00",
  "Pure Incorrect" = "#C62828"
)

plot_df <- sample_stats %>% filter(total_recovered > 0)

p1 <- ggplot(plot_df, aes(x = sample, y = pct, fill = class_clean)) +
  geom_col(position = "stack", width = 0.75, color = "white", linewidth = 0.2) +
  scale_fill_manual(values = col_map) +
  scale_y_continuous(
    labels = function(x) paste0(x, "%"),
    limits = c(0, 100.1),
    expand = c(0, 0)
  ) +
  labs(
    x = "Sample",
    y = "Proportion (%)",
    fill = "Classification",
    title = "Placement purity of Recovered prophages per sample",
    subtitle = "Subset: recovery_stage == 'Recovered' & main_class != 'Unbinned_Host'"
  ) +
  theme_bw(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
    panel.grid.minor = element_blank(),
    legend.position = "top"
  )

ggsave(file.path(out_dir, "07_recovered_purity_stacked_bar.pdf"), p1, width = 12, height = 6)
ggsave(file.path(out_dir, "07_recovered_purity_stacked_bar.png"), p1, width = 12, height = 6, dpi = 300)

p2 <- ggplot(plot_df, aes(x = class_clean, y = pct, fill = class_clean)) +
  geom_boxplot(outlier.shape = NA, width = 0.45, alpha = 0.7, color = "grey30") +
  geom_jitter(aes(color = class_clean), width = 0.15, size = 2, alpha = 0.75) +
  scale_fill_manual(values = col_map) +
  scale_color_manual(values = col_dark) +
  scale_y_continuous(
    labels = function(x) paste0(x, "%"),
    limits = c(0, 100),
    expand = expansion(mult = c(0.02, 0.05))
  ) +
  labs(
    x = "Classification",
    y = "Percentage per sample (%)",
    title = "Overall purity distribution",
    subtitle = sprintf("n = %d samples (each point = one sample)", n_distinct(plot_df$sample))
  ) +
  theme_bw(base_size = 12) +
  theme(
    panel.grid.minor = element_blank(),
    legend.position = "none"
  )

ggsave(file.path(out_dir, "08_recovered_purity_boxplot.pdf"), p2, width = 6, height = 6)
ggsave(file.path(out_dir, "08_recovered_purity_boxplot.png"), p2, width = 6, height = 6, dpi = 300)

if (requireNamespace("patchwork", quietly = TRUE)) {
  library(patchwork)
  p_combo <- p1 + p2 + plot_layout(widths = c(2.2, 1))
  ggsave(file.path(out_dir, "09_recovered_purity_combined.pdf"), p_combo, width = 16, height = 6)
  ggsave(file.path(out_dir, "09_recovered_purity_combined.png"), p_combo, width = 16, height = 6, dpi = 300)
}