#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hCom2: isolate-genome truth vs Illumina MAG/contig prophage tracking.

L0 presence: minimap2 competitive mapping, breadth_1x >= 75%
L1 iso2mag:  Host vs Foreign classification (Pure Correct / Pure Incorrect / Mixed / Lost)
L2 asm:      Assembly attribution for lost/partial prophages (Unbinned rescue vs Not assembled)
rev mag2iso: Active MAG calls -> isolate genomes verification
"""
import argparse
import csv
import hashlib
import os
import re
import shutil
import subprocess
import sys
from collections import defaultdict
from datetime import datetime

ROOT_DEFAULT = "/public/home/huangyan/SPA/metagenome_benchmark/hcom2"
CHECKV_DB_DEFAULT = "/public/home/huangyan/database/checkvdb/checkv-db-v1.5"
TEST_SAMPLE = "SRR29255411"

SRR_RE = re.compile(r"(SRR\d+)")
MAG_RE = re.compile(r"^(SRR\d+)\.bin\.(\d+)", re.I)
FA_EXTS = (".fasta.gz", ".fna.gz", ".fa.gz", ".fasta", ".fna", ".fa")
CV_COLS = [
    "checkv_quality", "provirus", "completeness", "completeness_method",
    "contamination", "kmer_freq", "viral_genes", "host_genes",
    "gene_count", "warnings",
]
COMP = str.maketrans("ACGTNacgtn", "TGCANtgcan")
NOISE_FLOOR = 5.0  # 5% 噪声地板 (百分比)


def log(msg):
    print("[%s] %s" % (datetime.now().strftime("%H:%M:%S"), msg), flush=True)


def die(msg):
    sys.exit("ERROR: " + msg)


def need_exe(name):
    if shutil.which(name) is None:
        die("找不到命令: %s" % name)


def run_cmd(cmd):
    log("CMD: " + " ".join(cmd))
    r = subprocess.run(cmd)
    if r.returncode != 0:
        die("命令失败 (%d): %s" % (r.returncode, " ".join(cmd)))


def strip_ext(fn):
    fn = os.path.basename(fn)
    for ext in FA_EXTS:
        if fn.endswith(ext):
            return fn[:-len(ext)]
    return fn


def is_fasta(fn):
    fn = fn.lower()
    return fn.endswith((".fa", ".fasta", ".fna", ".fa.gz", ".fasta.gz", ".fna.gz"))


def md5_seq(seq):
    return hashlib.md5(seq.upper().encode("ascii", "ignore")).hexdigest()


def revcomp(seq):
    return seq.translate(COMP)[::-1]


def pct(n, d):
    return ("%.2f" % (100.0 * n / d)) if d else "NA"


def genome_of_contig(contig):
    c = str(contig).split()[0]
    if "_" not in c:
        return c
    return c.rsplit("_", 1)[0]


def mag_id_of(name):
    return strip_ext(name)


def is_mag_id(name):
    return bool(MAG_RE.match(strip_ext(name)))


def sample_of_id(name, samples):
    m = SRR_RE.search(os.path.basename(str(name)))
    if not m:
        return None
    srr = m.group(1)
    return srr if srr in samples else None


def merge_intervals(intervals):
    if not intervals:
        return []
    iv = sorted((min(s, e), max(s, e)) for s, e in intervals)
    merged = [[iv[0][0], iv[0][1]]]
    for s, e in iv[1:]:
        if s <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    return merged


def covered_bp(merged):
    return sum(e - s + 1 for s, e in merged)


def subtract_intervals(a, b):
    a = merge_intervals(a)
    b = merge_intervals(b)
    out = []
    for s, e in a:
        cs = s
        for bs, be in b:
            if be < cs:
                continue
            if bs > e:
                break
            if bs > cs:
                out.append([cs, min(e, bs - 1)])
            cs = max(cs, be + 1)
            if cs > e:
                break
        if cs <= e:
            out.append([cs, e])
    return merge_intervals(out)


def intersect_bp(a, b):
    a, b = merge_intervals(a), merge_intervals(b)
    bp = 0
    for s, e in a:
        for bs, be in b:
            i0, i1 = max(s, bs), min(e, be)
            if i0 <= i1:
                bp += i1 - i0 + 1
    return bp


def fmt_iv(iv):
    return ";".join("%d-%d" % (s, e) for s, e in merge_intervals(iv))


def parse_iv(s):
    if not s:
        return []
    out = []
    for p in str(s).split(";"):
        p = p.strip()
        if not p or "-" not in p:
            continue
        a, b = p.split("-", 1)
        out.append((int(a), int(b)))
    return out


def write_table(path, rows, fields=None):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not rows:
        with open(path, "w") as out:
            if fields:
                out.write("\t".join(fields) + "\n")
        return
    fields = fields or list(rows[0].keys())
    with open(path, "w", newline="") as out:
        w = csv.DictWriter(out, fieldnames=fields, delimiter="\t", extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def iter_fasta(path):
    name, chunks = None, []
    with open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith(">"):
                if name is not None:
                    yield name, "".join(chunks)
                name = line[1:].split()[0]
                chunks = []
            else:
                chunks.append(line.strip())
        if name is not None:
            yield name, "".join(chunks)


def write_fasta(path, records, wrap=60):
    n = 0
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as out:
        for sid, seq in records:
            out.write(">%s\n" % sid)
            for i in range(0, len(seq), wrap):
                out.write(seq[i:i + wrap] + "\n")
            n += 1
    return n


def is_mq_plus_cv(q):
    return q in ("Complete", "High-quality", "Medium-quality")


def has_viral_gene(r):
    v = str(r.get("viral_genes") or "").strip()
    if (not v) or v.upper() in ("NA", "NAN", "N/A", "NONE", "NULL", "."):
        return False
    try:
        return float(v) >= 1
    except ValueError:
        return False


def filter_checkv_record(r, mode):
    if mode == "all":
        return True
    if mode == "viral_gene":
        return has_viral_gene(r)
    if mode == "mq_5k":
        try:
            L = int(float(r.get("length") or 0))
        except ValueError:
            L = 0
        return L >= 5000 and is_mq_plus_cv(r.get("checkv_quality", ""))
    return True


# ---------------- deps ----------------
def diamond_ver():
    exe = shutil.which("diamond")
    if not exe:
        return None, ""
    r = subprocess.run([exe, "version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    txt = (r.stdout or "").strip()
    m = re.search(r"(\d+\.\d+\.\d+)", txt)
    return (m.group(1) if m else txt), txt


def ensure_prodigal(out_dir):
    if shutil.which("prodigal"):
        return "prodigal"
    pg = shutil.which("prodigal-gv")
    if not pg:
        return ""
    bindir = os.path.join(out_dir, ".localbin")
    os.makedirs(bindir, exist_ok=True)
    dest = os.path.join(bindir, "prodigal")
    if os.path.islink(dest) or os.path.exists(dest):
        os.remove(dest)
    os.symlink(pg, dest)
    os.environ["PATH"] = bindir + os.pathsep + os.environ.get("PATH", "")
    log("WARN: 环境无 prodigal，已 symlink prodigal-gv -> %s" % dest)
    return dest


def check_deps(out_dir, skip_checkv):
    rows = []

    def add(name, ok, note=""):
        rows.append((name, "OK" if ok else "MISSING", note))

    for exe in ("python3", "minimap2", "samtools", "skani", "blastn", "makeblastdb"):
        add(exe, shutil.which(exe) is not None, shutil.which(exe) or "")
    add("checkv", shutil.which("checkv") is not None, shutil.which("checkv") or "")
    add("hmmer/hmmsearch", shutil.which("hmmsearch") is not None, shutil.which("hmmsearch") or "")
    prod = shutil.which("prodigal")
    pgv = shutil.which("prodigal-gv")
    add("prodigal", prod is not None, prod or "将尝试 prodigal-gv")
    add("prodigal-gv", pgv is not None, pgv or "")
    dv, dtxt = diamond_ver()
    d_ok = False
    d_note = "未安装"
    if dv:
        parts = dv.split(".")
        try:
            d_ok = tuple(int(x) for x in parts[:2]) >= (0, 9)
        except ValueError:
            d_ok = False
        d_note = dv + ("" if d_ok else "  (<0.9, CheckV 可能失败)")
    add("diamond", shutil.which("diamond") is not None, d_note)
    log("依赖检查:")
    for n, st, note in rows:
        log("  %-18s %s  %s" % (n, st, note))
    must = ["minimap2", "samtools", "skani", "blastn", "makeblastdb"]
    miss = [m for m in must if shutil.which(m) is None]
    if miss:
        die("缺少: " + ", ".join(miss))
    if not skip_checkv:
        if shutil.which("checkv") is None:
            die("缺少 checkv（或加 --skip-checkv）")
        ensure_prodigal(out_dir)
        if shutil.which("prodigal") is None:
            die("缺少 prodigal / prodigal-gv")
        if not d_ok:
            log("WARN: diamond 版本偏旧或缺失，CheckV contamination 步可能失败")


# ---------------- paths / discovery ----------------
def paths_of(root):
    return {
        "root": root,
        "iso_fa": os.path.join(root, "isolate_seq", "hcom2_isolate.genome.fasta"),
        "iso_coords": os.path.join(root, "isolate_seq", "prophage_coordinates.tsv"),
        "fq_dir": os.path.join(root, "metagenome", "fastq", "clean_data"),
        "ctg_dir": os.path.join(root, "metagenome", "contigs"),
        "bin_dir": os.path.join(root, "metagenome", "illumina_bin"),
        "rename": os.path.join(root, "metagenome", "illumina_bin", "contig_rename_index.csv"),
        "checkm_dir": os.path.join(root, "metagenome", "illumina_bin", "checkm2_results"),
        "active_coords": os.path.join(root, "metagenome", "pp_coordinate", "active_coordinate.tsv"),
    }


def discover_samples(P):
    fq, ct, bn = set(), set(), set()
    if os.path.isdir(P["fq_dir"]):
        for fn in os.listdir(P["fq_dir"]):
            m = re.match(r"(SRR\d+)_1_clean\.fastq\.gz$", fn)
            if not m:
                continue
            s = m.group(1)
            if os.path.isfile(os.path.join(P["fq_dir"], s + "_2_clean.fastq.gz")):
                fq.add(s)
    if os.path.isdir(P["ctg_dir"]):
        for fn in os.listdir(P["ctg_dir"]):
            m = re.match(r"(SRR\d+)_megahit_output\.contigs\.fasta$", fn)
            if m:
                ct.add(m.group(1))
    if os.path.isdir(P["bin_dir"]):
        for fn in os.listdir(P["bin_dir"]):
            if fn.endswith("_bin") and os.path.isdir(os.path.join(P["bin_dir"], fn)):
                bn.add(fn[:-4])
    ok = sorted(fq & ct & bn)
    miss = {
        "fastq_only": sorted(fq - ct - bn),
        "no_fastq": sorted((ct & bn) - fq),
        "no_contig": sorted((fq & bn) - ct),
        "no_bin": sorted((fq & ct) - bn),
    }
    log("discover samples: fastq=%d contig=%d bin=%d intersection=%d" % (
        len(fq), len(ct), len(bn), len(ok)))
    for k, v in miss.items():
        if v:
            log("WARN %s n=%d e.g. %s" % (k, len(v), ",".join(v[:5])))
    if not ok:
        die("fastq ∩ contig ∩ bin 为空，检查目录")
    return ok


def fq_pair(P, sample):
    r1 = os.path.join(P["fq_dir"], sample + "_1_clean.fastq.gz")
    r2 = os.path.join(P["fq_dir"], sample + "_2_clean.fastq.gz")
    if not os.path.isfile(r1) or not os.path.isfile(r2):
        die("fastq 缺失: %s" % sample)
    return r1, r2


def contig_fa(P, sample):
    p = os.path.join(P["ctg_dir"], sample + "_megahit_output.contigs.fasta")
    if not os.path.isfile(p):
        die("找不到 contig: " + p)
    return p


def list_bin_fastas(folder):
    out = []
    if not os.path.isdir(folder):
        return out
    for fn in sorted(os.listdir(folder)):
        if fn.startswith(".") or fn.startswith("all"):
            continue
        if not is_fasta(fn):
            continue
        path = os.path.join(folder, fn)
        if os.path.isfile(path):
            out.append(path)
    return out


def bin_dir(P, sample):
    return os.path.join(P["bin_dir"], sample + "_bin")


def checkm_path(P, sample):
    p = os.path.join(P["checkm_dir"], sample + "_bin", "quality_report.tsv")
    if not os.path.isfile(p):
        p2 = os.path.join(P["checkm_dir"], sample, "quality_report.tsv")
        if os.path.isfile(p2):
            return p2
    return p


# ---------------- isolate / checkm / coords / rename ----------------
def split_isolates(iso_fa, outdir):
    os.makedirs(outdir, exist_ok=True)
    by = defaultdict(list)
    contig_len = {}
    for name, seq in iter_fasta(iso_fa):
        g = genome_of_contig(name)
        by[g].append((name, seq))
        contig_len[name] = len(seq)
    rows = []
    paths = {}
    for g, recs in sorted(by.items()):
        path = os.path.join(outdir, g + ".fa")
        write_fasta(path, recs)
        paths[g] = path
        total = sum(len(s) for _, s in recs)
        rows.append({
            "genome": g, "n_contigs": str(len(recs)), "length": str(total),
            "multicontig": "TRUE" if len(recs) > 1 else "FALSE",
            "fasta": path,
        })
    log("isolates: %d genomes, %d contigs -> %s" % (len(rows), len(contig_len), outdir))
    return rows, paths, contig_len


def load_checkm2_file(path):
    out = {}
    if not path or not os.path.isfile(path):
        return out
    with open(path, newline="") as fh:
        rdr = csv.DictReader(fh, delimiter="\t")
        if not rdr.fieldnames:
            return out
        fmap = {k.lower().strip(): k for k in rdr.fieldnames}
        c_name = fmap.get("name") or fmap.get("bin") or rdr.fieldnames[0]
        c_comp = fmap.get("completeness")
        c_cont = fmap.get("contamination")
        if not c_comp or not c_cont:
            die("CheckM2 缺 Completeness/Contamination: " + path)
        for r in rdr:
            name = mag_id_of(r[c_name].strip())
            try:
                comp = float(r[c_comp])
                cont = float(r[c_cont])
            except (TypeError, ValueError):
                continue
            out[name] = {"name": name, "completeness": comp, "contamination": cont}
    return out


def load_all_checkm(P, samples, min_comp, max_cont):
    all_rows = []
    mq = set()
    nfile = 0
    for sample in samples:
        path = checkm_path(P, sample)
        cm = load_checkm2_file(path)
        if cm:
            nfile += 1
        elif os.path.isfile(path) is False:
            log("WARN 无 CheckM2: %s" % path)
        for name, r in cm.items():
            is_mq = r["completeness"] >= min_comp and r["contamination"] < max_cont
            if is_mq:
                mq.add(name)
            all_rows.append({
                "sample": sample, "mag": name,
                "completeness": "%.2f" % r["completeness"],
                "contamination": "%.2f" % r["contamination"],
                "mq": "TRUE" if is_mq else "FALSE",
            })
    log("CheckM2 files=%d bins=%d MQ+=%d (comp>=%.0f cont<%.0f)" % (
        nfile, len(all_rows), len(mq), min_comp, max_cont))
    return all_rows, mq


def parse_coord_file(path):
    rows = []
    if not os.path.isfile(path):
        die("坐标文件不存在: " + path)
    with open(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 3:
                continue
            if parts[0].lower() in ("contig", "contig_id", "seqid"):
                continue
            if not parts[1].replace("-", "", 1).isdigit():
                continue
            try:
                contig, start, end = parts[0], int(parts[1]), int(parts[2])
            except ValueError:
                continue
            rows.append((contig, start, end))
    log("coords: %d rows from %s" % (len(rows), path))
    return rows


def sniff_delim(sample):
    tabs, commas = sample.count("\t"), sample.count(",")
    return "\t" if tabs >= commas else ","


def parse_rename_csv(path, samples):
    recs = []
    if not path or not os.path.isfile(path):
        return recs
    with open(path, newline="") as fh:
        peek = fh.read(8192)
        fh.seek(0)
        delim = sniff_delim(peek)
        first = peek.splitlines()[0] if peek.splitlines() else ""
        has_header = bool(re.search(r"[A-Za-z]", first)) and not re.match(
            r"^SRR\d+", first.strip()
        )
        if has_header:
            rdr = csv.DictReader(fh, delimiter=delim)
            fields = rdr.fieldnames or []
            rows = list(rdr)
        else:
            rdr = csv.reader(fh, delimiter=delim)
            rows, fields = [], []
            for p in rdr:
                if p:
                    rows.append(p)

    def looks_asm(s):
        s = str(s).strip()
        return bool(re.match(r"^SRR\d+_\S+$", s) and ".bin." not in s)

    def looks_magc(s):
        s = str(s).strip()
        return bool(MAG_RE.match(s))

    def mag_from_contig(c):
        m = MAG_RE.match(c)
        if not m:
            return ""
        return "%s.bin.%s" % (m.group(1), m.group(2))

    if fields:
        fmap = {k.lower().strip(): k for k in fields}
        c_asm = c_magc = c_mag = None
        for k, orig in fmap.items():
            if k in ("asm", "asm_contig", "old", "old_id", "original", "orig",
                     "contig", "old_contig", "assembly_contig"):
                c_asm = orig
            if k in ("new", "new_id", "new_contig", "mag_contig", "renamed",
                     "bin_contig"):
                c_magc = orig
            if k in ("bin", "mag", "bin_id", "mag_id", "genome"):
                c_mag = orig
        for r in rows:
            if not isinstance(r, dict):
                continue
            vals = [str(v).strip() for v in r.values() if str(v).strip()]
            asm = (r.get(c_asm) or "").strip() if c_asm else ""
            magc = (r.get(c_magc) or "").strip() if c_magc else ""
            mag = mag_id_of(r.get(c_mag) or "") if c_mag else ""
            if not asm or not looks_asm(asm):
                for v in vals:
                    if looks_asm(v):
                        asm = v
                        break
            if not magc or not looks_magc(magc):
                for v in vals:
                    if looks_magc(v):
                        magc = v
                        break
            if magc and not mag:
                mag = mag_from_contig(magc)
            if not asm or not magc:
                continue
            samp = sample_of_id(asm, samples) or sample_of_id(magc, samples)
            recs.append((asm, mag, magc, samp or "", "rename"))
    else:
        for p in rows:
            p = [x.strip() for x in p if str(x).strip()]
            if len(p) < 2:
                continue
            asm = magc = ""
            for v in p:
                if looks_asm(v):
                    asm = v
                elif looks_magc(v):
                    magc = v
            if not asm or not magc:
                continue
            recs.append((asm, mag_from_contig(magc), magc,
                         sample_of_id(asm, samples) or "", "rename"))
    log("rename table %s: %d mapped rows" % (path, len(recs)))
    return recs


def heuristic_asm_of_mag_contig(mag_contig):
    m = re.match(r"^(SRR\d+)\.bin\.\d+_(.+)$", mag_contig)
    if m:
        return "%s_%s" % (m.group(1), m.group(2))
    return None


def load_mag_index(files):
    target = {}
    for path in files:
        mag = mag_id_of(path)
        for cid, seq in iter_fasta(path):
            if cid in target:
                die("重复 contig %s\n  %s\n  %s" % (cid, path, target[cid][3]))
            target[cid] = (seq, mag, path)
    return target


def load_iso_index(iso_fa):
    target = {}
    for cid, seq in iter_fasta(iso_fa):
        g = genome_of_contig(cid)
        target[cid] = (seq, g, iso_fa)
    return target


def build_contig_maps(sample, mag_files, asm_fa, rename_recs, outdir, samples):
    mag_contigs = []
    for path in mag_files:
        mag = mag_id_of(path)
        for cid, seq in iter_fasta(path):
            mag_contigs.append((mag, cid, seq, len(seq)))

    asm_ids = []
    asm_hash = {}
    asm_len = {}
    for cid, seq in iter_fasta(asm_fa):
        asm_ids.append(cid)
        asm_len[cid] = len(seq)
        h = md5_seq(seq)
        asm_hash.setdefault(h, []).append(cid)
        hr = md5_seq(revcomp(seq))
        if hr != h:
            asm_hash.setdefault(hr, []).append(cid + "|rc")

    asm_set = set(asm_ids)
    mapped = {}
    methods = defaultdict(int)
    conflicts = []

    def accept(mag, magc, asm, method, strand="+"):
        if not asm or asm not in asm_set:
            return False
        prev = mapped.get(magc)
        rec = {
            "sample": sample, "mag": mag, "mag_contig": magc,
            "asm_contig": asm, "method": method, "strand": strand,
        }
        if prev and prev["asm_contig"] != asm:
            conflicts.append((magc, prev["asm_contig"], asm, prev["method"], method))
            if method == "hash":
                mapped[magc] = rec
                return True
            return False
        if prev:
            return True
        mapped[magc] = rec
        methods[method] += 1
        return True

    for mag, magc, seq, n in mag_contigs:
        asm = heuristic_asm_of_mag_contig(magc)
        if asm:
            accept(mag, magc, asm, "heuristic")

    for asm, mag, magc, samp, _ in rename_recs:
        if samp and samp != sample:
            continue
        if not magc:
            continue
        accept(mag, magc, asm, "rename")

    n_hash = 0
    for mag, magc, seq, n in mag_contigs:
        h = md5_seq(seq)
        hits = asm_hash.get(h, [])
        strand = "+"
        if not hits:
            hits = asm_hash.get(md5_seq(revcomp(seq)), [])
            strand = "-"
        clean = []
        for x in hits:
            if x.endswith("|rc"):
                clean.append((x[:-3], "-"))
            else:
                clean.append((x, strand if strand == "+" else "+"))
        uniq = list({c for c, _ in clean})
        if len(uniq) == 1:
            st = [s for c, s in clean if c == uniq[0]][0]
            if magc not in mapped:
                n_hash += 1
            accept(mag, magc, uniq[0], "hash", st)
        elif len(uniq) > 1:
            conflicts.append((magc, ",".join(uniq), "ambiguous_hash", "", "hash"))

    methods["hash_fill"] = n_hash
    n_magc = len(mag_contigs)
    n_map = len(mapped)
    binned_asm = {}
    multi_bin = []
    for rec in mapped.values():
        a = rec["asm_contig"]
        if a in binned_asm and binned_asm[a] != rec["mag"]:
            multi_bin.append((a, binned_asm[a], rec["mag"]))
        binned_asm[a] = rec["mag"]

    unbinned = [c for c in asm_ids if c not in binned_asm]
    rows = []
    for mag, magc, seq, n in mag_contigs:
        rec = mapped.get(magc)
        rows.append({
            "sample": sample, "mag": mag, "mag_contig": magc,
            "mag_contig_len": str(n),
            "asm_contig": rec["asm_contig"] if rec else "",
            "asm_contig_len": str(asm_len.get(rec["asm_contig"], "")) if rec else "",
            "method": rec["method"] if rec else "unmapped",
            "strand": rec["strand"] if rec else "",
        })
    write_table(os.path.join(outdir, "contig_to_bin.%s.tsv" % sample), rows)
    ub_rows = [{"sample": sample, "asm_contig": c, "length": str(asm_len[c])} for c in unbinned]
    write_table(os.path.join(outdir, "unbinned_contigs.%s.tsv" % sample), ub_rows)

    rate = (100.0 * n_map / n_magc) if n_magc else 0.0
    log(("%s contig∈bin: MAG_contigs=%d mapped=%d (%.1f%%) heuristic=%d "
         "rename=%d hash_fill=%d unbinned_asm=%d/%d conflicts=%d multi_bin=%d") % (
            sample, n_magc, n_map, rate, methods.get("heuristic", 0),
            methods.get("rename", 0), methods.get("hash_fill", 0),
            len(unbinned), len(asm_ids), len(conflicts), len(multi_bin)))
    if n_magc and rate < 50:
        die("%s MAG contig 映射率 <50%%，先检查 contig_rename_index / 是否同一套组装" % sample)
    if n_magc and rate < 90:
        log("WARN %s 映射率 <90%%，L2 的 binned/unbinned 会有噪声" % sample)
    return {
        "asm_to_mag": binned_asm,
        "unbinned": set(unbinned),
        "asm_len": asm_len,
        "n_mag_contigs": n_magc,
        "n_mapped": n_map,
        "n_asm": len(asm_ids),
        "n_unbinned": len(unbinned),
    }


# ---------------- L0 mapping ----------------
def build_mmi(iso_fa, mmi, threads, reuse):
    if reuse and os.path.isfile(mmi) and os.path.getsize(mmi) > 0:
        log("reuse minimap2 index " + mmi)
        return
    need_exe("minimap2")
    run_cmd(["minimap2", "-x", "sr", "-d", mmi, "-t", str(threads), iso_fa])


def parse_samtools_coverage(path):
    rows = []
    if not os.path.isfile(path):
        return rows
    with open(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            p = line.rstrip("\n").split("\t")
            if len(p) < 7:
                continue
            try:
                rname = p[0]
                endpos = int(float(p[2]))
                numreads = int(float(p[3]))
                covbases = int(float(p[4]))
                meandepth = float(p[6])
            except ValueError:
                continue
            rows.append((rname, endpos, covbases, meandepth, numreads))
    return rows


def breadth5_from_depth(bam, contig_len, threads=1):
    need_exe("samtools")
    p = subprocess.Popen(
        ["samtools", "depth", "-@", str(threads), "-q", "1", bam],
        stdout=subprocess.PIPE, text=True)
    cov5 = defaultdict(int)
    for line in p.stdout:
        if not line.strip():
            continue
        sp = line.split()
        if len(sp) < 3:
            continue
        try:
            d = int(sp[2])
        except ValueError:
            continue
        if d >= 5:
            cov5[sp[0]] += 1
    rc = p.wait()
    if rc != 0:
        log("WARN samtools depth 退出码 %d" % rc)
        return {}
    by_g_bp = defaultdict(int)
    glen = defaultdict(int)
    for c, L in contig_len.items():
        g = genome_of_contig(c)
        glen[g] += L
        by_g_bp[g] += cov5.get(c, 0)
    out = {}
    for g, L in glen.items():
        out[g] = 100.0 * by_g_bp[g] / L if L else 0.0
    return out


def map_presence_sample(sample, r1, r2, mmi, iso_rows, contig_len, out_cov,
                        threads, tmp_root, keep_bam):
    need_exe("minimap2")
    need_exe("samtools")
    s_tmp = os.path.join(tmp_root, sample)
    if os.path.isdir(s_tmp):
        shutil.rmtree(s_tmp, ignore_errors=True)
    os.makedirs(s_tmp, exist_ok=True)
    bam = os.path.join(s_tmp, sample + ".bam")
    logf = os.path.join(s_tmp, "minimap2.log")
    mm = ["minimap2", "-ax", "sr", "--secondary=no", "-t", str(threads), mmi, r1, r2]
    st = ["samtools", "sort", "-@", str(threads),
          "-T", os.path.join(s_tmp, sample + ".sort"), "-o", bam]
    log("CMD: minimap2 -ax sr --secondary=no | samtools sort  [%s]" % sample)
    try:
        with open(logf, "w") as lf:
            p1 = subprocess.Popen(mm, stdout=subprocess.PIPE, stderr=lf)
            p2 = subprocess.Popen(st, stdin=p1.stdout, stdout=subprocess.DEVNULL, stderr=lf)
            p1.stdout.close()
            rc2 = p2.wait()
            rc1 = p1.wait()
        if rc1 != 0 or rc2 != 0:
            die("minimap2/samtools 失败 %s 见 %s" % (sample, logf))
        run_cmd(["samtools", "coverage", "-q", "1", "-o", out_cov, bam])
        b5 = breadth5_from_depth(bam, contig_len, threads=threads)
        cov_rows = parse_samtools_coverage(out_cov)
        acc = defaultdict(lambda: {"len": 0, "covbases": 0, "depth_sum": 0.0, "nreads": 0})
        seen_ctg = set()
        for rname, endpos, covbases, meandepth, numreads in cov_rows:
            g = genome_of_contig(rname)
            L = contig_len.get(rname, endpos)
            acc[g]["len"] += L
            acc[g]["covbases"] += covbases
            acc[g]["depth_sum"] += meandepth * L
            acc[g]["nreads"] += numreads
            seen_ctg.add(rname)
        for c, L in contig_len.items():
            if c in seen_ctg:
                continue
            g = genome_of_contig(c)
            acc[g]["len"] += L
        by_g_len = {r["genome"]: int(r["length"]) for r in iso_rows}
        out = []
        for r in iso_rows:
            g = r["genome"]
            L = by_g_len.get(g, acc[g]["len"] or 1)
            covb = acc[g]["covbases"]
            b1 = 100.0 * covb / L if L else 0.0
            md = (acc[g]["depth_sum"] / acc[g]["len"]) if acc[g]["len"] else 0.0
            out.append({
                "sample": sample, "genome": g,
                "genome_bp": str(L),
                "covbases_1x": str(covb),
                "breadth_1x": "%.4f" % b1,
                "breadth_5x": "%.4f" % b5.get(g, 0.0),
                "mean_depth": "%.4f" % md,
                "n_reads": str(acc[g]["nreads"]),
                "n_contigs": r["n_contigs"],
                "multicontig": r["multicontig"],
            })
        return out
    finally:
        if keep_bam:
            log("keep bam " + bam)
        else:
            shutil.rmtree(s_tmp, ignore_errors=True)
            log("removed mapping tmp %s" % s_tmp)


# ---------------- skani & Host/Foreign definitions ----------------
def parse_skani_tsv(path):
    rows = []
    if not os.path.isfile(path) or os.path.getsize(path) == 0:
        return rows
    with open(path, newline="") as f:
        head = f.readline()
        if not head:
            return rows
        peek = head.lstrip()
        has_header = peek.lower().startswith("ref") or "ani" in peek.lower()
        f.seek(0)
        if has_header:
            rdr = csv.DictReader(f, delimiter="\t")
            for r in rdr:
                key = {k.lower().strip(): k for k in r}

                def get(*cands):
                    for c in cands:
                        if c in key:
                            return r[key[c]]
                    return None

                a = get("ref_file", "ref", "reference")
                b = get("query_file", "query")
                ani = get("ani")
                af_r = get("align_fraction_ref", "af_ref", "align_fraction_ref(%)")
                af_q = get("align_fraction_query", "af_query", "align_fraction_query(%)")
                if a is None or b is None or ani is None:
                    continue
                rows.append((a, b, float(ani), float(af_r or 0), float(af_q or 0)))
        else:
            for line in f:
                if not line.strip() or line.startswith("#"):
                    continue
                p = line.rstrip("\n").split("\t")
                if len(p) < 3:
                    continue
                ani = float(p[2])
                af_r = float(p[3]) if len(p) > 3 else 0.0
                af_q = float(p[4]) if len(p) > 4 else 0.0
                rows.append((p[0], p[1], ani, af_r, af_q))
    return rows


def run_skani_sample(sample, files, outdir, threads, min_len, force, reuse):
    need_exe("skani")
    list_dir = os.path.join(outdir, "skani_lists")
    skani_dir = os.path.join(outdir, "skani")
    log_dir = os.path.join(outdir, "skani_logs")
    os.makedirs(list_dir, exist_ok=True)
    os.makedirs(skani_dir, exist_ok=True)
    os.makedirs(log_dir, exist_ok=True)
    list_path = os.path.join(list_dir, sample + ".txt")
    with open(list_path, "w") as w:
        w.write("\n".join(files) + "\n")
    out_tsv = os.path.join(skani_dir, sample + ".skani.tsv")
    logf = os.path.join(log_dir, sample + ".log")
    if len(files) < 2:
        log("[skani skip] %s 只有 %d 个 fasta" % (sample, len(files)))
        open(out_tsv, "w").close()
        return out_tsv
    if os.path.isfile(out_tsv) and os.path.getsize(out_tsv) > 0 and not force and reuse:
        log("[skani reuse] %s" % sample)
        return out_tsv
    if os.path.isfile(out_tsv) and os.path.getsize(out_tsv) > 0 and not force:
        log("[skani skip existing] %s  (加 --force 重跑)" % sample)
        return out_tsv
    cmd = [
        "skani", "triangle", "--sparse",
        "-t", str(threads), "-m", str(min_len),
        "-l", list_path, "-o", out_tsv,
    ]
    log("CMD: " + " ".join(cmd))
    with open(logf, "w") as lf:
        r = subprocess.run(cmd, stdout=lf, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        log("WARN skani 失败 %s ，见 %s" % (sample, logf))
        open(out_tsv, "w").close()
    return out_tsv


def collect_iso_mag_pairs(sample, skani_tsv, isolate_ids):
    rows = []
    seen = set()
    for a, b, ani, af_r, af_q in parse_skani_tsv(skani_tsv):
        id1, id2 = mag_id_of(a), mag_id_of(b)
        if id1 == id2:
            continue
        r1 = "iso" if id1 in isolate_ids else ("mag" if is_mag_id(id1) else "other")
        r2 = "iso" if id2 in isolate_ids else ("mag" if is_mag_id(id2) else "other")
        if {r1, r2} != {"iso", "mag"}:
            continue
        if r1 == "iso":
            iso, mag, af_iso, af_mag = id1, id2, af_r, af_q
        else:
            mag, iso, af_mag, af_iso = id1, id2, af_r, af_q
        key = (iso, mag)
        if key in seen:
            continue
        seen.add(key)
        rows.append({
            "sample": sample, "isolate": iso, "mag": mag,
            "ANI": "%.4f" % ani,
            "AF_isolate": "%.3f" % af_iso,
            "AF_MAG": "%.3f" % af_mag,
            "min_AF": "%.3f" % min(af_iso, af_mag),
        })
    return rows


def build_sample_host_maps(ani_rows, pair_ani, pair_af_mag):
    """
    按样本独立构建 Host MAG 归属。
    门槛：ANI >= pair_ani 且 AF_MAG >= pair_af_mag
    若多个 isolate 争夺同一 MAG，归属给 ANI 最高者（平局则 AF_MAG 最高者）。
    """
    by_sample_cands = defaultdict(lambda: defaultdict(list))
    for r in ani_rows:
        ani = float(r["ANI"])
        af_mag = float(r["AF_MAG"])
        if ani >= pair_ani and af_mag >= pair_af_mag:
            samp, iso, mag = r["sample"], r["isolate"], r["mag"]
            by_sample_cands[samp][mag].append((iso, ani, af_mag))

    sample_iso_hosts = defaultdict(lambda: defaultdict(set))
    sample_mag_owner = defaultdict(dict)
    host_table_rows = []

    for samp, mag_dict in by_sample_cands.items():
        for mag, cands in mag_dict.items():
            cands.sort(key=lambda x: (x[1], x[2]), reverse=True)
            best_iso, best_ani, best_af = cands[0]
            sample_iso_hosts[samp][best_iso].add(mag)
            sample_mag_owner[samp][mag] = best_iso
            host_table_rows.append({
                "sample": samp, "isolate": best_iso, "mag": mag,
                "ANI": "%.4f" % best_ani, "AF_MAG": "%.3f" % best_af,
                "competitor_isolates": str(len(cands) - 1)
            })

    log("Host MAG mapping complete: %d sample-MAG pairs assigned (ANI>=%.2f, AF_MAG>=%.2f)" % (
        len(host_table_rows), pair_ani, pair_af_mag))
    return sample_iso_hosts, sample_mag_owner, host_table_rows


# ---------------- extract / blast / checkv ----------------
def extract_queries(coords, index, out_fa, out_meta, missing_path, source_label,
                    id_field, allowed_ids=None, sample=None, samples=None,
                    require_sample=False):
    records, meta, missing = [], [], []
    n_skip = 0
    for contig, start, end in coords:
        if require_sample:
            if sample_of_id(contig, samples) != sample:
                continue
        if contig not in index:
            missing.append((contig, start, end, "contig_not_in_fasta"))
            continue
        seq, src, _ = index[contig]
        if allowed_ids is not None and src not in allowed_ids:
            n_skip += 1
            continue
        s, e = start, end
        if s > e:
            s, e = e, s
        if s < 1 or e > len(seq):
            log("WARN clip %s:%d-%d to 1-%d" % (contig, start, end, len(seq)))
            s = max(1, s)
            e = min(len(seq), e)
        if e < s:
            missing.append((contig, start, end, "empty_after_clip"))
            continue
        sub = seq[s - 1:e]
        pid = "%s_%d_%d" % (contig, s, e)
        records.append((pid, sub))
        whole = "TRUE" if s <= 1 and e >= max(1, len(seq) - 1) else "FALSE"
        meta.append({
            "prophage_id": pid, "contig": contig, "start": str(s), "end": str(e),
            "length": str(len(sub)), id_field: src, "source": source_label,
            "sample": sample or "",
            "whole_contig_call": whole,
            "source_contig_len": str(len(seq)),
        })
    write_fasta(out_fa, records)
    write_table(out_meta, meta)
    with open(missing_path, "w") as out:
        out.write("contig\tstart\tend\treason\n")
        for r in missing:
            out.write("%s\t%s\t%s\t%s\n" % r)
    log("extract %s %s: %d seq, %d missing, %d skipped_not_allowed" % (
        sample or ".", source_label, len(records), len(missing), n_skip))
    return meta


def concat_mags(index, out_fa):
    recs = [("%s___%s" % (mag, cid), seq) for cid, (seq, mag, _) in index.items()]
    recs.sort(key=lambda x: x[0])
    n = write_fasta(out_fa, recs)
    nmag = len(set(v[1] for v in index.values()))
    log("concat %d MAG / %d contigs -> %s" % (nmag, n, out_fa))
    return n


def run_checkv(query_fa, outdir, db, threads, reuse):
    summary = os.path.join(outdir, "quality_summary.tsv")
    if reuse and os.path.isfile(summary):
        log("reuse CheckV " + summary)
        return summary
    if not os.path.isfile(query_fa) or os.path.getsize(query_fa) == 0:
        log("WARN skip CheckV, empty query " + query_fa)
        return ""
    need_exe("checkv")
    if not db:
        die("需要 --checkv-db")
    if os.path.isdir(outdir):
        shutil.rmtree(outdir)
    run_cmd(["checkv", "end_to_end", os.path.abspath(query_fa),
             os.path.abspath(outdir), "-d", db, "-t", str(threads)])
    return summary if os.path.isfile(summary) else ""


def run_makeblastdb(fa, out_prefix, reuse, parse_seqids=True):
    if reuse and os.path.isfile(out_prefix + ".nhr"):
        log("reuse blastdb " + out_prefix)
        return
    if not os.path.isfile(fa) or os.path.getsize(fa) == 0:
        log("WARN skip makeblastdb, empty " + fa)
        return
    need_exe("makeblastdb")
    cmd = ["makeblastdb", "-in", fa, "-dbtype", "nucl", "-out", out_prefix]
    if parse_seqids:
        cmd.append("-parse_seqids")
    run_cmd(cmd)


def run_blastn(query, db, out_tsv, threads, reuse):
    if reuse and os.path.isfile(out_tsv) and os.path.getsize(out_tsv) > 0:
        log("reuse BLAST " + out_tsv)
        return
    if not os.path.isfile(query) or os.path.getsize(query) == 0:
        open(out_tsv, "w").close()
        return
    need_exe("blastn")
    run_cmd([
        "blastn", "-task", "megablast",
        "-query", query, "-db", db,
        "-num_threads", str(threads),
        "-evalue", "1e-5",
        "-max_target_seqs", "1000",
        "-outfmt", "6 qseqid sseqid pident length qstart qend qlen sstart send slen bitscore",
        "-out", out_tsv,
    ])


def load_checkv(summary_tsv):
    out = {}
    if not summary_tsv or not os.path.isfile(summary_tsv):
        return out
    with open(summary_tsv) as fh:
        for row in csv.DictReader(fh, delimiter="\t"):
            out[row["contig_id"]] = row
    return out


def parse_sseqid_mag(sseqid):
    if "___" not in sseqid:
        return sseqid, sseqid
    mag, contig = sseqid.split("___", 1)
    return mag, contig


def parse_blast(blast_tsv, min_pident, key_mode="mag"):
    hits = defaultdict(list)
    qlen_blast = {}
    n_all = n_keep = 0
    if not os.path.isfile(blast_tsv) or os.path.getsize(blast_tsv) == 0:
        return hits, qlen_blast
    with open(blast_tsv) as fh:
        for line in fh:
            if not line.strip():
                continue
            n_all += 1
            p = line.rstrip("\n").split("\t")
            if len(p) < 10:
                continue
            qseqid, sseqid = p[0], p[1]
            pident = float(p[2])
            length = int(p[3])
            qstart, qend, qlen_s = int(p[4]), int(p[5]), int(float(p[6]))
            sstart, send, slen = int(p[7]), int(p[8]), int(float(p[9]))
            if pident < min_pident:
                continue
            n_keep += 1
            if key_mode == "mag":
                key = parse_sseqid_mag(sseqid)[0]
            elif key_mode == "genome":
                key = genome_of_contig(sseqid)
            else:
                key = sseqid
            hits[(qseqid, key)].append({
                "qstart": qstart, "qend": qend, "pident": pident, "length": length,
                "sstart": sstart, "send": send, "slen": slen, "sseqid": sseqid,
            })
            qlen_blast[qseqid] = qlen_s
    log("blast %s: %d HSP, %d pident>=%.2f" % (
        os.path.basename(blast_tsv), n_all, n_keep, min_pident))
    return hits, qlen_blast


def coverage_from_hsps(hsp_list, qlen):
    qiv = merge_intervals([(h["qstart"], h["qend"]) for h in hsp_list])
    siv = merge_intervals([(h["sstart"], h["send"]) for h in hsp_list])
    bp = covered_bp(qiv)
    cov = 100.0 * bp / qlen if qlen else 0.0
    if cov > 100.0:
        cov = 100.0
    w = sum(h["pident"] * h["length"] for h in hsp_list)
    Lsum = sum(h["length"] for h in hsp_list)
    slen = max(h["slen"] for h in hsp_list) if hsp_list else 0
    return {
        "covered_bp": bp, "cov_pct": cov, "n_hsp": len(hsp_list),
        "n_merged": len(qiv), "weighted_pident": (w / Lsum) if Lsum else 0.0,
        "q_intervals": qiv, "s_intervals": siv, "slen": slen,
        "hsps": hsp_list,
    }


def union_from_stats(mag_stats, qlen):
    iv = []
    for st in mag_stats.values():
        iv.extend(st.get("q_intervals") or [])
    merged = merge_intervals(iv)
    bp = covered_bp(merged)
    cov = 100.0 * bp / qlen if qlen else 0.0
    if cov > 100.0:
        cov = 100.0
    return cov, bp, merged


# ---------------- L1 Host/Foreign Classification Engine ----------------
def classify_prophage_hcom2(cov_H, cov_X, union_all, is_binned_iso, rec_full_thresh):
    """
    四格互斥主类 + 嵌套细分
    """
    if not is_binned_iso:
        if union_all == 0:
            rec_stage = "Lost"
            sub_cls = "unbinned_lost"
        elif union_all < rec_full_thresh:
            rec_stage = "Partial"
            sub_cls = "unbinned_partial"
        else:
            rec_stage = "Recovered"
            sub_cls = "unbinned_recovered"
        return {
            "recovery_stage": rec_stage,
            "main_class": "Unbinned_Host",
            "sub_class": sub_cls,
            "mixed_type": "NA",
        }

    # Binned Iso
    if union_all == 0 or (cov_H == 0 and cov_X == 0):
        return {
            "recovery_stage": "Lost",
            "main_class": "Lost",
            "sub_class": "lost",
            "mixed_type": "NA",
        }

    rec_stage = "Recovered" if union_all >= rec_full_thresh else "Partial"

    if cov_H > 0 and cov_X == 0:
        main_cls = "Pure_Correct"
        sub_cls = "pure_correct_recovered" if cov_H >= rec_full_thresh else "pure_correct_partial"
        mixed_type = "NA"
    elif cov_X > 0 and cov_H == 0:
        main_cls = "Pure_Incorrect"
        sub_cls = "pure_incorrect_recovered" if cov_X >= rec_full_thresh else "pure_incorrect_partial"
        mixed_type = "NA"
    else:  # cov_H > 0 and cov_X > 0
        main_cls = "Mixed"
        if cov_H >= rec_full_thresh and cov_X >= rec_full_thresh:
            mixed_type = "both_full"
            sub_cls = "mixed_both_full"
        elif cov_H >= cov_X:
            mixed_type = "host_major"
            sub_cls = "mixed_host_major"
        else:
            mixed_type = "foreign_major"
            sub_cls = "mixed_foreign_major"

    return {
        "recovery_stage": rec_stage,
        "main_class": main_cls,
        "sub_class": sub_cls,
        "mixed_type": mixed_type,
    }


def assign_iso2mag_sample(sample, meta, host_mags, blast_tsv, checkv_tsv,
                          out_cov, out_assign, args):
    checkv = load_checkv(checkv_tsv)
    hits, qlen_blast = parse_blast(blast_tsv, args.min_pident, key_mode="mag")
    meta_by_id = {m["prophage_id"]: m for m in meta}

    query_hits = defaultdict(dict)
    cov_rows = []
    for (qid, mag), hsps in hits.items():
        ql = qlen_blast.get(qid) or int(meta_by_id[qid]["length"])
        st = coverage_from_hsps(hsps, ql)
        query_hits[qid][mag] = st
        cov_rows.append({
            "sample": sample, "prophage_id": qid, "mag": mag,
            "covered_bp": str(st["covered_bp"]),
            "cov_pct": "%.3f" % st["cov_pct"],
            "n_hsp": str(st["n_hsp"]),
            "weighted_pident": "%.3f" % st["weighted_pident"],
            "q_intervals": fmt_iv(st["q_intervals"]),
        })
    cov_rows.sort(key=lambda r: (r["prophage_id"], -float(r["cov_pct"])))
    write_table(out_cov, cov_rows)

    out_rows = []
    mag_qiv = {}
    counts = defaultdict(int)

    for m in meta:
        qid = m["prophage_id"]
        iso = m["source_genome"]
        qlen = int(m["length"])
        cv = checkv.get(qid, {})

        # CheckV Filter 门禁
        if not filter_checkv_record(cv, args.checkv_filter):
            continue

        hosts = host_mags.get(iso, set())
        is_binned = len(hosts) > 0
        stats = query_hits.get(qid, {})

        # 分离 Host 与 Foreign hits
        host_stats = {mag: st for mag, st in stats.items() if mag in hosts}
        foreign_stats = {mag: st for mag, st in stats.items() if mag not in hosts}

        raw_H, bp_H, iv_H = union_from_stats(host_stats, qlen)
        raw_union_all, bp_all, iv_all = union_from_stats(stats, qlen)
        mag_qiv[qid] = iv_all

        # Foreign max
        max_X_mag = ""
        raw_X = 0.0
        for mag, st in foreign_stats.items():
            if st["cov_pct"] > raw_X:
                raw_X = st["cov_pct"]
                max_X_mag = mag

        # 施加 0.05 (5%) 噪声地板
        cov_H = 0.0 if raw_H < NOISE_FLOOR else raw_H
        cov_X = 0.0 if raw_X < NOISE_FLOOR else raw_X
        union_all = 0.0 if raw_union_all < NOISE_FLOOR else raw_union_all

        # 收集命中的有效 MAG 列表
        h_hit_details = ["%s:%.1f" % (m, st["cov_pct"]) for m, st in host_stats.items() if st["cov_pct"] >= NOISE_FLOOR]
        f_hit_details = ["%s:%.1f" % (m, st["cov_pct"]) for m, st in foreign_stats.items() if st["cov_pct"] >= NOISE_FLOOR]

        cls = classify_prophage_hcom2(cov_H, cov_X, union_all, is_binned, args.rec_full)
        counts[cls["main_class"]] += 1

        row = {
            "sample": sample, "prophage_id": qid, "isolate": iso,
            "contig": m["contig"], "start": m["start"], "end": m["end"], "length": m["length"],
            "iso_status": "binned" if is_binned else "unbinned",
            "n_host_mags_defined": str(len(hosts)),
            "host_mags_defined": ";".join(sorted(hosts)),
            "cov_H_pct": "%.3f" % cov_H,
            "cov_X_pct": "%.3f" % cov_X,
            "max_foreign_mag": max_X_mag,
            "union_all_pct": "%.3f" % union_all,
            "recovery_stage": cls["recovery_stage"],
            "main_class": cls["main_class"],
            "sub_class": cls["sub_class"],
            "mixed_type": cls["mixed_type"],
            "n_host_bins_hit": str(len(h_hit_details)),
            "n_foreign_bins_hit": str(len(f_hit_details)),
            "n_total_bins_hit": str(len(h_hit_details) + len(f_hit_details)),
            "host_bins_detail": ";".join(h_hit_details),
            "foreign_bins_detail": ";".join(f_hit_details),
            "q_intervals_all": fmt_iv(iv_all),
        }
        for c in CV_COLS:
            row[c] = cv.get(c, "")
        out_rows.append(row)

    write_table(out_assign, out_rows)
    log("[%s iso2mag] total=%d binned_iso=%d classes=%s" % (
        sample, len(out_rows), sum(1 for r in out_rows if r["iso_status"] == "binned"), dict(counts)))
    return out_rows, mag_qiv


# ---------------- L2 Assembly Analysis ----------------
def assign_asm_sample(sample, meta, mag_rows, mag_qiv, blast_tsv, cmap, out_cov, out_assign, args):
    hits, qlen_blast = parse_blast(blast_tsv, args.min_pident, key_mode="contig")
    meta_by = {m["prophage_id"]: m for m in meta}
    mag_by = {r["prophage_id"]: r for r in mag_rows}
    query_ctg = defaultdict(dict)
    cov_rows = []

    for (qid, contig), hsps in hits.items():
        ql = qlen_blast.get(qid) or int(meta_by.get(qid, {}).get("length", 0))
        if not ql:
            continue
        st = coverage_from_hsps(hsps, ql)
        query_ctg[qid][contig] = st
        in_bin = contig in cmap["asm_to_mag"]
        cov_rows.append({
            "sample": sample, "prophage_id": qid, "contig": contig,
            "in_bin": "TRUE" if in_bin else "FALSE",
            "subject_mag": cmap["asm_to_mag"].get(contig, ""),
            "covered_bp": str(st["covered_bp"]),
            "cov_pct": "%.3f" % st["cov_pct"],
            "n_hsp": str(st["n_hsp"]),
            "q_intervals": fmt_iv(st["q_intervals"]),
        })
    cov_rows.sort(key=lambda r: (r["prophage_id"], -float(r["cov_pct"])))
    write_table(out_cov, cov_rows)

    out_rows = []
    for m in meta:
        qid = m["prophage_id"]
        if qid not in mag_by:
            continue
        qlen = int(m["length"])
        mag_row = mag_by[qid]
        stats = query_ctg.get(qid, {})

        binned, unbinned = {}, {}
        for ctg, st in stats.items():
            if ctg in cmap["asm_to_mag"]:
                binned[ctg] = st
            else:
                unbinned[ctg] = st

        asm_cov, asm_bp, asm_iv = union_from_stats(stats, qlen)
        b_cov, b_bp, b_iv = union_from_stats(binned, qlen)
        u_cov, u_bp, u_iv = union_from_stats(unbinned, qlen)

        # 施加噪声地板
        asm_cov = 0.0 if asm_cov < NOISE_FLOOR else asm_cov
        u_cov = 0.0 if u_cov < NOISE_FLOOR else u_cov
        b_cov = 0.0 if b_cov < NOISE_FLOOR else b_cov

        # L2 归因分类
        if u_cov >= args.rec_full:
            asm_fate = "unbinned_rescue"
        elif asm_cov == 0:
            asm_fate = "not_assembled"
        elif asm_cov < args.rec_full:
            asm_fate = "asm_partial"
        else:
            asm_fate = "in_binned_contigs" if b_cov >= args.rec_full else "split_binned_unbinned"

        out_rows.append({
            "sample": sample, "prophage_id": qid, "isolate": mag_row.get("isolate", ""),
            "length": m["length"], "iso_status": mag_row.get("iso_status", ""),
            "main_class_mag": mag_row.get("main_class", ""),
            "sub_class_mag": mag_row.get("sub_class", ""),
            "recovery_mag": mag_row.get("recovery_stage", ""),
            "asm_fate": asm_fate,
            "asm_union_cov_pct": "%.3f" % asm_cov,
            "binned_contig_cov_pct": "%.3f" % b_cov,
            "unbinned_contig_cov_pct": "%.3f" % u_cov,
            "n_asm_contigs_hit": str(len(stats)),
            "n_unbinned_contigs_hit": str(len(unbinned)),
            "asm_q_intervals": fmt_iv(asm_iv),
            "unbinned_q_intervals": fmt_iv(u_iv),
        })

    write_table(out_assign, out_rows)
    log("[%s L2] annotated=%d" % (sample, len(out_rows)))
    return out_rows


# ---------------- Reverse mag2iso Tracking ----------------
def assign_mag2iso_sample(sample, meta, mag_owners, blast_tsv, checkv_tsv,
                          out_cov, out_assign, args):
    checkv = load_checkv(checkv_tsv)
    hits, qlen_blast = parse_blast(blast_tsv, args.min_pident, key_mode="genome")
    meta_by_id = {m["prophage_id"]: m for m in meta}

    query_hits = defaultdict(dict)
    cov_rows = []
    for (qid, iso), hsps in hits.items():
        ql = qlen_blast.get(qid) or int(meta_by_id[qid]["length"])
        st = coverage_from_hsps(hsps, ql)
        query_hits[qid][iso] = st
        cov_rows.append({
            "sample": sample, "prophage_id": qid, "isolate": iso,
            "covered_bp": str(st["covered_bp"]),
            "cov_pct": "%.3f" % st["cov_pct"],
            "n_hsp": str(st["n_hsp"]),
        })
    write_table(out_cov, cov_rows)

    out_rows = []
    for m in meta:
        qid = m["prophage_id"]
        mag = m["source_mag"]
        qlen = int(m["length"])
        cv = checkv.get(qid, {})

        if not filter_checkv_record(cv, args.checkv_filter):
            continue

        owner_iso = mag_owners.get(mag, "")
        stats = query_hits.get(qid, {})

        host_stats = {iso: st for iso, st in stats.items() if iso == owner_iso} if owner_iso else {}
        foreign_stats = {iso: st for iso, st in stats.items() if iso != owner_iso}

        raw_H, bp_H, iv_H = union_from_stats(host_stats, qlen)
        raw_union_all, bp_all, iv_all = union_from_stats(stats, qlen)

        max_X_iso = ""
        raw_X = 0.0
        for iso, st in foreign_stats.items():
            if st["cov_pct"] > raw_X:
                raw_X = st["cov_pct"]
                max_X_iso = iso

        cov_H = 0.0 if raw_H < NOISE_FLOOR else raw_H
        cov_X = 0.0 if raw_X < NOISE_FLOOR else raw_X
        union_all = 0.0 if raw_union_all < NOISE_FLOOR else raw_union_all

        cls = classify_prophage_hcom2(cov_H, cov_X, union_all, bool(owner_iso), args.rec_full)

        row = {
            "sample": sample, "prophage_id": qid, "source_mag": mag,
            "assigned_owner_isolate": owner_iso,
            "has_owner": "TRUE" if owner_iso else "FALSE",
            "length": m["length"],
            "cov_H_pct": "%.3f" % cov_H, "cov_X_pct": "%.3f" % cov_X,
            "max_foreign_isolate": max_X_iso,
            "union_all_pct": "%.3f" % union_all,
            "recovery_stage": cls["recovery_stage"],
            "main_class": cls["main_class"],
            "sub_class": cls["sub_class"],
        }
        for c in CV_COLS:
            row[c] = cv.get(c, "")
        out_rows.append(row)

    write_table(out_assign, out_rows)
    return out_rows


# ---------------- Summary Tables ----------------
def make_l1_summary(rows, out_tsv):
    recs = []
    by_sample = defaultdict(list)
    for r in rows:
        by_sample[r["sample"]].append(r)

    for sample, srows in sorted(by_sample.items()):
        binned = [r for r in srows if r.get("iso_status") == "binned"]
        unbinned = [r for r in srows if r.get("iso_status") != "binned"]
        D = len(binned)

        n_lost = sum(1 for r in binned if r["main_class"] == "Lost")
        n_part = sum(1 for r in binned if r["recovery_stage"] == "Partial")
        n_rec = sum(1 for r in binned if r["recovery_stage"] == "Recovered")

        n_pure_corr = sum(1 for r in binned if r["main_class"] == "Pure_Correct")
        n_pure_inc = sum(1 for r in binned if r["main_class"] == "Pure_Incorrect")
        n_mixed = sum(1 for r in binned if r["main_class"] == "Mixed")

        n_mix_host = sum(1 for r in binned if r["sub_class"] == "mixed_host_major")
        n_mix_foreign = sum(1 for r in binned if r["sub_class"] == "mixed_foreign_major")
        n_mix_both = sum(1 for r in binned if r["sub_class"] == "mixed_both_full")

        recs.append({
            "sample": sample,
            "n_total_queries": str(len(srows)),
            "n_unbinned_iso_queries": str(len(unbinned)),
            "n_binned_iso_queries_D": str(D),
            "n_lost": str(n_lost),
            "pct_lost": pct(n_lost, D),
            "n_partial": str(n_part),
            "pct_partial": pct(n_part, D),
            "n_recovered": str(n_rec),
            "pct_recovered": pct(n_rec, D),
            "n_pure_correct": str(n_pure_corr),
            "pct_pure_correct": pct(n_pure_corr, D),
            "n_pure_incorrect": str(n_pure_inc),
            "pct_pure_incorrect": pct(n_pure_inc, D),
            "n_mixed": str(n_mixed),
            "pct_mixed": pct(n_mixed, D),
            "n_mixed_host_major": str(n_mix_host),
            "n_mixed_foreign_major": str(n_mix_foreign),
            "n_mixed_both_full": str(n_mix_both),
            "correct_placement_rate": pct(n_pure_corr + n_mix_host, D),
            "incorrect_placement_rate": pct(n_pure_inc + n_mix_foreign, D),
        })
    write_table(out_tsv, recs)
    log("L1 summary -> " + out_tsv)


def make_l2_summary(asm_rows, out_tsv):
    recs = []
    by_sample = defaultdict(list)
    for r in asm_rows:
        by_sample[r["sample"]].append(r)

    for sample, rows in sorted(by_sample.items()):
        lost_rows = [r for r in rows if r.get("main_class_mag") == "Lost"]
        n_lost = len(lost_rows)
        n_rescue = sum(1 for r in lost_rows if r["asm_fate"] == "unbinned_rescue")
        n_not_asm = sum(1 for r in lost_rows if r["asm_fate"] == "not_assembled")
        n_asm_part = sum(1 for r in lost_rows if r["asm_fate"] == "asm_partial")

        recs.append({
            "sample": sample,
            "n_total_annotated": str(len(rows)),
            "n_lost_in_mag": str(n_lost),
            "n_lost_unbinned_rescue": str(n_rescue),
            "pct_lost_unbinned_rescue": pct(n_rescue, n_lost),
            "n_lost_not_assembled": str(n_not_asm),
            "pct_lost_not_assembled": pct(n_not_asm, n_lost),
            "n_lost_asm_partial": str(n_asm_part),
            "pct_lost_asm_partial": pct(n_asm_part, n_lost),
        })
    write_table(out_tsv, recs)
    log("L2 summary -> " + out_tsv)


def make_main_numbers(l1_rows, l2_rows, presence_rows, out_tsv):
    rows = []
    n_pres = sum(1 for r in presence_rows if r.get("present") == "TRUE")
    rows.append({
        "metric_block": "L0_presence",
        "total": str(len(presence_rows)),
        "count": str(n_pres),
        "percentage": pct(n_pres, len(presence_rows)),
        "description": "Isolates present in samples (breadth_1x >= min_breadth)"
    })

    binned = [r for r in l1_rows if r.get("iso_status") == "binned"]
    D = len(binned)
    n_pure_corr = sum(1 for r in binned if r["main_class"] == "Pure_Correct")
    n_pure_inc = sum(1 for r in binned if r["main_class"] == "Pure_Incorrect")
    n_mix_host = sum(1 for r in binned if r["sub_class"] == "mixed_host_major")
    n_mix_foreign = sum(1 for r in binned if r["sub_class"] == "mixed_foreign_major")
    n_lost = sum(1 for r in binned if r["main_class"] == "Lost")

    rows.append({"metric_block": "L1_binned_queries_D", "total": str(D), "count": str(D), "percentage": "100.00", "description": "Prophages from binned isolates"})
    rows.append({"metric_block": "L1_pure_correct", "total": str(D), "count": str(n_pure_corr), "percentage": pct(n_pure_corr, D), "description": "Pure correct placement (Host only)"})
    rows.append({"metric_block": "L1_pure_incorrect", "total": str(D), "count": str(n_pure_inc), "percentage": pct(n_pure_inc, D), "description": "Pure incorrect placement (Foreign only)"})
    rows.append({"metric_block": "L1_overall_correct_rate", "total": str(D), "count": str(n_pure_corr + n_mix_host), "percentage": pct(n_pure_corr + n_mix_host, D), "description": "Pure correct + Mixed host major"})
    rows.append({"metric_block": "L1_overall_incorrect_rate", "total": str(D), "count": str(n_pure_inc + n_mix_foreign), "percentage": pct(n_pure_inc + n_mix_foreign, D), "description": "Pure incorrect + Mixed foreign major"})
    rows.append({"metric_block": "L1_lost_in_mag", "total": str(D), "count": str(n_lost), "percentage": pct(n_lost, D), "description": "Prophages lost in all MAGs"})

    if l2_rows:
        lost_l2 = [r for r in l2_rows if r.get("main_class_mag") == "Lost"]
        n_l_l2 = len(lost_l2)
        n_resc = sum(1 for r in lost_l2 if r.get("asm_fate") == "unbinned_rescue")
        n_noasm = sum(1 for r in lost_l2 if r.get("asm_fate") == "not_assembled")
        rows.append({"metric_block": "L2_lost_unbinned_rescue", "total": str(n_l_l2), "count": str(n_resc), "percentage": pct(n_resc, n_l_l2), "description": "Lost in MAG but complete in unbinned contigs"})
        rows.append({"metric_block": "L2_lost_not_assembled", "total": str(n_l_l2), "count": str(n_noasm), "percentage": pct(n_noasm, n_l_l2), "description": "Lost in MAG because not assembled"})

    write_table(out_tsv, rows)
    log("Main numbers -> " + out_tsv)


# ---------------- pipeline execution ----------------
def prep_all(args, P, samples, iso_rows):
    rename_recs = parse_rename_csv(P["rename"], set(samples))
    maps = {}
    all_c2b, all_ub = [], []
    for sample in samples:
        sdir = os.path.join(args.out_dir, "by_sample", sample)
        os.makedirs(sdir, exist_ok=True)
        mag_files = list_bin_fastas(bin_dir(P, sample))
        if not mag_files:
            log("WARN skip contig map %s: no MAG" % sample)
            continue
        cmap = build_contig_maps(
            sample, mag_files, contig_fa(P, sample), rename_recs, sdir, set(samples))
        maps[sample] = cmap
        p1 = os.path.join(sdir, "contig_to_bin.%s.tsv" % sample)
        p2 = os.path.join(sdir, "unbinned_contigs.%s.tsv" % sample)
        if os.path.isfile(p1):
            with open(p1) as fh:
                all_c2b.extend(csv.DictReader(fh, delimiter="\t"))
        if os.path.isfile(p2):
            with open(p2) as fh:
                all_ub.extend(csv.DictReader(fh, delimiter="\t"))
    write_table(os.path.join(args.out_dir, "contig_to_bin.tsv"), all_c2b)
    write_table(os.path.join(args.out_dir, "unbinned_contigs.tsv"), all_ub)
    write_table(os.path.join(args.out_dir, "isolate_index.tsv"), iso_rows)
    return maps


def load_presence_table(path):
    if not os.path.isfile(path):
        return []
    with open(path) as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def present_by_sample(presence_rows, min_breadth):
    out = defaultdict(set)
    for r in presence_rows:
        try:
            b = float(r["breadth_1x"])
        except (KeyError, ValueError):
            b = 0.0
        flag = b >= min_breadth
        r["present"] = "TRUE" if flag else "FALSE"
        if flag:
            out[r["sample"]].add(r["genome"])
    return out


def track_sample(sample, P, args, iso_fa, iso_idx, iso_coords, active_coords,
                 present, host_mags, mag_owners, mq, cmap, iso_blast_prefix):
    sdir = os.path.join(args.out_dir, "by_sample", sample)
    os.makedirs(sdir, exist_ok=True)
    mag_files = list_bin_fastas(bin_dir(P, sample))
    mag_idx = load_mag_index(mag_files)
    log("%s MAG files=%d contigs=%d present_isolates=%d" % (
        sample, len(mag_files), len(mag_idx), len(present)))

    layers = set(x.strip() for x in args.layers.split(",") if x.strip())
    out = {"iso2mag": [], "l2": [], "mag2iso": []}
    mag_qiv = {}
    iso_meta = []

    iso_fa_q = os.path.join(sdir, "01_iso_prophages.fna")
    if "iso2mag" in layers or "asm" in layers:
        iso_meta = extract_queries(
            iso_coords, iso_idx, iso_fa_q,
            os.path.join(sdir, "01_iso_prophage_meta.tsv"),
            os.path.join(sdir, "01_iso_missing.tsv"),
            "isolate", "source_genome",
            allowed_ids=present, sample=sample, samples=set([sample]),
            require_sample=False)
        if os.path.isfile(os.path.join(sdir, "01_iso_prophage_meta.tsv")):
            with open(os.path.join(sdir, "01_iso_prophage_meta.tsv")) as fh:
                iso_meta = list(csv.DictReader(fh, delimiter="\t"))
            for r in iso_meta:
                r["sample"] = sample

    iso_cv = ""
    if iso_meta and not args.skip_checkv:
        iso_cv = run_checkv(iso_fa_q, os.path.join(sdir, "02_checkv_iso"),
                            args.checkv_db, args.threads, args.reuse)

    if "iso2mag" in layers and iso_meta:
        concat_mags(mag_idx, os.path.join(sdir, "03_mags.fna"))
        run_makeblastdb(os.path.join(sdir, "03_mags.fna"),
                        os.path.join(sdir, "03_mags"), args.reuse, True)
        blast_i2m = os.path.join(sdir, "04_blast_iso2mag.tsv")
        run_blastn(iso_fa_q, os.path.join(sdir, "03_mags"), blast_i2m,
                   args.threads, args.reuse)
        out["iso2mag"], mag_qiv = assign_iso2mag_sample(
            sample, iso_meta, host_mags, blast_i2m, iso_cv,
            os.path.join(sdir, "05_cov_iso2mag.tsv"),
            os.path.join(sdir, "06_assign_iso2mag.tsv"), args)

    if "asm" in layers and iso_meta:
        if not cmap:
            die("%s 无 contig map，先跑 --only prep" % sample)
        run_makeblastdb(contig_fa(P, sample), os.path.join(sdir, "03_contigs"),
                        args.reuse, False)
        blast_asm = os.path.join(sdir, "04_blast_iso2asm.tsv")
        run_blastn(iso_fa_q, os.path.join(sdir, "03_contigs"), blast_asm,
                   args.threads, args.reuse)
        if not out["iso2mag"] and os.path.isfile(os.path.join(sdir, "06_assign_iso2mag.tsv")):
            with open(os.path.join(sdir, "06_assign_iso2mag.tsv")) as fh:
                out["iso2mag"] = list(csv.DictReader(fh, delimiter="\t"))
        out["l2"] = assign_asm_sample(
            sample, iso_meta, out["iso2mag"], mag_qiv, blast_asm, cmap,
            os.path.join(sdir, "08_asm_cov_iso2mag.tsv"),
            os.path.join(sdir, "08_asm_assign_iso2mag.tsv"), args)

    if "mag2iso" in layers:
        mag_fa_q = os.path.join(sdir, "01_mag_prophages.fna")
        mq_here = set(x for x in mq if sample_of_id(x, set([sample])) == sample or x.startswith(sample + ".bin."))
        mag_meta = extract_queries(
            active_coords, mag_idx, mag_fa_q,
            os.path.join(sdir, "01_mag_prophage_meta.tsv"),
            os.path.join(sdir, "01_mag_missing.tsv"),
            "illumina_mag", "source_mag",
            allowed_ids=mq_here, sample=sample, samples=set([sample]),
            require_sample=True)
        if os.path.isfile(os.path.join(sdir, "01_mag_prophage_meta.tsv")):
            with open(os.path.join(sdir, "01_mag_prophage_meta.tsv")) as fh:
                mag_meta = list(csv.DictReader(fh, delimiter="\t"))
            for r in mag_meta:
                r["sample"] = sample
        mag_cv = ""
        if mag_meta and not args.skip_checkv:
            mag_cv = run_checkv(mag_fa_q, os.path.join(sdir, "02_checkv_mag"),
                                args.checkv_db, args.threads, args.reuse)
        elif args.skip_checkv:
            mag_cv = os.path.join(sdir, "02_checkv_mag", "quality_summary.tsv")
        blast_m2i = os.path.join(sdir, "04_blast_mag2iso.tsv")
        if mag_meta:
            run_blastn(mag_fa_q, iso_blast_prefix, blast_m2i, args.threads, args.reuse)
            out["mag2iso"] = assign_mag2iso_sample(
                sample, mag_meta, mag_owners, blast_m2i, mag_cv,
                os.path.join(sdir, "05_cov_mag2iso.tsv"),
                os.path.join(sdir, "06_assign_mag2iso.tsv"), args)
    return out


def main():
    ap = argparse.ArgumentParser(
        description="hCom2 isolate-truth prophage tracking (L0/L1 Host-Foreign/L2 assembly)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--root", default=ROOT_DEFAULT)
    ap.add_argument("-o", "--out-dir", default="")
    ap.add_argument("-t", "--threads", type=int, default=40)
    ap.add_argument("--test", action="store_true", help="只跑样本 %s" % TEST_SAMPLE)
    ap.add_argument("--sample", default="", help="只跑指定 SRR")
    ap.add_argument("--only", choices=["all", "prep", "presence", "skani", "track"], default="all")
    ap.add_argument("--layers", default="iso2mag,asm,mag2iso")
    ap.add_argument("--checkv-db", default=CHECKV_DB_DEFAULT)
    ap.add_argument("--checkv-filter", choices=["viral_gene", "all", "mq_5k"], default="viral_gene",
                    help="前噬菌体真值过滤门禁: viral_gene (viral_genes>=1), all, mq_5k (MQ+且>=5kb)")
    ap.add_argument("--min-completeness", type=float, default=50.0)
    ap.add_argument("--max-contamination", type=float, default=5.0)
    ap.add_argument("--min-breadth", type=float, default=75.0, help="L0 mapping 判定在场最小 breadth_1x (%%)")
    ap.add_argument("--min-len", type=int, default=10000)
    ap.add_argument("--pair-ani", type=float, default=99.0, help="Host MAG 认定 ANI 门槛")
    ap.add_argument("--pair-af-mag", type=float, default=95.0, help="Host MAG 认定 AF_MAG 门槛")
    ap.add_argument("--min-pident", type=float, default=99.0, help="BLASTN 最小 pident")
    ap.add_argument("--rec-full", type=float, default=75.0, help="前噬菌体完整找回覆盖度门槛 (%%)")
    ap.add_argument("--skip-checkv", action="store_true")
    ap.add_argument("--reuse", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--keep-bam", action="store_true")
    args = ap.parse_args()

    P = paths_of(os.path.abspath(args.root))
    args.out_dir = os.path.abspath(args.out_dir or os.path.join(P["root"], "prophage_track_hcom2"))
    os.makedirs(args.out_dir, exist_ok=True)
    check_deps(args.out_dir, args.skip_checkv)

    for k in ("iso_fa", "iso_coords", "active_coords"):
        if not os.path.isfile(P[k]):
            die("缺少文件: " + P[k])

    samples = discover_samples(P)
    if args.test and args.sample:
        die("--test 与 --sample 不要同时用")
    if args.test:
        args.sample = TEST_SAMPLE
    if args.sample:
        if args.sample not in samples:
            die("未知样本 %s" % args.sample)
        samples = [args.sample]
        log("限制样本: " + args.sample)

    iso_split_dir = os.path.join(args.out_dir, "ref", "isolates")
    iso_rows, iso_paths, contig_len = split_isolates(P["iso_fa"], iso_split_dir)
    isolate_ids = set(r["genome"] for r in iso_rows)
    iso_idx = load_iso_index(P["iso_fa"])
    iso_coords = parse_coord_file(P["iso_coords"])
    active_coords = parse_coord_file(P["active_coords"])

    checkm_rows, mq = load_all_checkm(P, samples, args.min_completeness, args.max_contamination)
    write_table(os.path.join(args.out_dir, "mq_illumina_bins.tsv"), checkm_rows)

    maps = prep_all(args, P, samples, iso_rows)
    if args.only == "prep":
        log("DONE prep")
        return

    # L0
    presence_path = os.path.join(args.out_dir, "00_presence.tsv")
    presence_rows = []
    need_map = True
    if args.reuse and os.path.isfile(presence_path) and not args.force:
        old = load_presence_table(presence_path)
        have = set(r["sample"] for r in old)
        if set(samples) <= have:
            presence_rows = [r for r in old if r["sample"] in set(samples)]
            need_map = False
            log("reuse presence " + presence_path)
        else:
            presence_rows = old
    if need_map:
        mmi = os.path.join(args.out_dir, "ref", "isolates.sr.mmi")
        os.makedirs(os.path.join(args.out_dir, "ref"), exist_ok=True)
        build_mmi(P["iso_fa"], mmi, args.threads, args.reuse and not args.force)
        tmp_root = os.path.join(args.out_dir, "tmp_map")
        os.makedirs(tmp_root, exist_ok=True)
        mapped = {r["sample"] for r in presence_rows}
        for sample in samples:
            if sample in mapped and args.reuse and not args.force:
                continue
            r1, r2 = fq_pair(P, sample)
            cov = os.path.join(args.out_dir, "by_sample", sample, "00_coverage.tsv")
            os.makedirs(os.path.dirname(cov), exist_ok=True)
            part = map_presence_sample(
                sample, r1, r2, mmi, iso_rows, contig_len, cov,
                args.threads, tmp_root, args.keep_bam)
            presence_rows = [r for r in presence_rows if r["sample"] != sample]
            presence_rows.extend(part)
        if not args.keep_bam:
            shutil.rmtree(tmp_root, ignore_errors=True)

    present_map = present_by_sample(presence_rows, args.min_breadth)
    for r in presence_rows:
        try:
            r["present"] = "TRUE" if float(r["breadth_1x"]) >= args.min_breadth else "FALSE"
        except ValueError:
            r["present"] = "FALSE"
    write_table(presence_path, presence_rows)

    pres_list = []
    for sample in samples:
        gs = sorted(present_map.get(sample, []))
        log("%s present genomes: %d / %d (breadth_1x>=%.1f)" % (
            sample, len(gs), len(isolate_ids), args.min_breadth))
        for g in gs:
            pres_list.append({"sample": sample, "genome": g})
    write_table(os.path.join(args.out_dir, "00_present_genomes.by_sample.tsv"), pres_list)
    if args.only == "presence":
        log("DONE presence")
        return

    # skani & Host assignment
    ani_all = []
    for sample in samples:
        mag_files = list_bin_fastas(bin_dir(P, sample))
        iso_files = [iso_paths[g] for g in sorted(present_map.get(sample, [])) if g in iso_paths]
        files = mag_files + iso_files
        tsv = run_skani_sample(
            sample, files, args.out_dir, args.threads, args.min_len, args.force, args.reuse)
        ani_all.extend(collect_iso_mag_pairs(sample, tsv, isolate_ids))
    write_table(os.path.join(args.out_dir, "ani_pairs_all.tsv"), ani_all)

    sample_iso_hosts, sample_mag_owner, host_table_rows = build_sample_host_maps(
        ani_all, args.pair_ani, args.pair_af_mag)
    write_table(os.path.join(args.out_dir, "isolate_mag_hosts.tsv"), host_table_rows)
    if args.only == "skani":
        log("DONE skani")
        return

    # Tracking
    iso_blast = os.path.join(args.out_dir, "ref", "isolates")
    run_makeblastdb(P["iso_fa"], iso_blast, args.reuse, False)

    all_rows = defaultdict(list)
    for sample in samples:
        log("==== %s ====" % sample)
        part = track_sample(
            sample, P, args, P["iso_fa"], iso_idx, iso_coords, active_coords,
            present_map.get(sample, set()), sample_iso_hosts.get(sample, {}),
            sample_mag_owner.get(sample, {}), mq, maps.get(sample), iso_blast)
        for k, rows in part.items():
            all_rows[k].extend(rows)

    write_table(os.path.join(args.out_dir, "06_assign_iso2mag.all.tsv"), all_rows["iso2mag"])
    write_table(os.path.join(args.out_dir, "06_assign_mag2iso.all.tsv"), all_rows["mag2iso"])
    make_l1_summary(all_rows["iso2mag"], os.path.join(args.out_dir, "07_summary_iso2mag.tsv"))

    if all_rows["l2"]:
        write_table(os.path.join(args.out_dir, "08_asm_assign_iso2mag.all.tsv"), all_rows["l2"])
        make_l2_summary(all_rows["l2"], os.path.join(args.out_dir, "08_l2_summary.tsv"))

    make_main_numbers(
        all_rows["iso2mag"], all_rows["l2"], presence_rows,
        os.path.join(args.out_dir, "10_main_numbers.tsv"))

    log("ALL DONE")
    log("Host MAG mapping: %s/isolate_mag_hosts.tsv" % args.out_dir)
    log("iso2mag output:   %s/06_assign_iso2mag.all.tsv" % args.out_dir)
    log("L1 summary:       %s/07_summary_iso2mag.tsv" % args.out_dir)
    log("L2 summary:       %s/08_l2_summary.tsv" % args.out_dir)
    log("Main numbers:     %s/10_main_numbers.tsv" % args.out_dir)


if __name__ == "__main__":
    main()
