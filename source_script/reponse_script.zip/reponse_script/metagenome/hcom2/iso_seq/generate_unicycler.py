import os
import pandas as pd

base_dir = "/public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq"
tsv_file = os.path.join(base_dir, "sra_info.tsv")
data_dir = os.path.join(base_dir, "fastq/clean_data")

out_dir_base = os.path.join(base_dir, "isolate_genome")
final_fasta_dir = os.path.join(out_dir_base, "final_fastas")

threads = 35

df = pd.read_csv(tsv_file, sep="\t")

with open("run_unicycler.sh", "w") as f_out:
    f_out.write("#!/bin/bash\n")
    f_out.write("set -e\n\n")
    f_out.write(f"mkdir -p {final_fasta_dir}\n\n")

    for strain, group in df.groupby("Strain"):
        illumina_row = group[group["Platform"] == "ILLUMINA"]
        ont_row = group[group["Platform"] == "OXFORD_NANOPORE"]

        if illumina_row.empty or ont_row.empty:
            continue

        il_run = illumina_row.iloc[0]["Run"]
        ont_run = ont_row.iloc[0]["Run"]

        fq1 = os.path.join(data_dir, f"{il_run}_clean_1.fastq.gz")
        fq2 = os.path.join(data_dir, f"{il_run}_clean_2.fastq.gz")
        ont_fq = os.path.join(data_dir, f"{ont_run}_clean.fastq.gz")

        assembly_name = il_run  
        strain_out = os.path.join(out_dir_base, assembly_name)
        final_fasta = os.path.join(final_fasta_dir, f"{assembly_name}.fasta")

  
        cmd = (
            f"echo '========== Start assembling: {strain} (ID: {assembly_name}) =========='\n"
            f"unicycler -1 {fq1} -2 {fq2} -l {ont_fq} "
            f"-o {strain_out} -t {threads} --mode normal --no_correct\n"
            f"if [ -f {strain_out}/assembly.fasta ]; then\n"
            f"    cp {strain_out}/assembly.fasta {final_fasta}\n"
            f"    echo 'Finished: Saved to {final_fasta}'\n"
            f"else\n"
            f"    echo 'Assembly failed for {assembly_name}' >&2\n"
            f"fi\n\n"
        )
        f_out.write(cmd)


