#!/bin/bash
set -e

mkdir -p /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas

echo '========== Start assembling: Acidaminococcus-fermentans-DSM-20731 (ID: SRR24651294) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651294_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651294_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651293_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651294 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651294/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651294/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651294.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651294.fasta'
else
    echo 'Assembly failed for SRR24651294' >&2
fi

echo '========== Start assembling: Akkermansia-muciniphila-ATCC-BAA-835 (ID: SRR24651269) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651269_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651269_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651268_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651269 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651269/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651269/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651269.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651269.fasta'
else
    echo 'Assembly failed for SRR24651269' >&2
fi

echo '========== Start assembling: Alistipes-putredinis-DSM-17216 (ID: SRR24651328) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651328_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651328_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651327_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651328 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651328/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651328/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651328.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651328.fasta'
else
    echo 'Assembly failed for SRR24651328' >&2
fi

echo '========== Start assembling: Anaerobutyricum-hallii-DSM-3353 (ID: SRR24651193) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651193_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651193_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651192_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651193 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651193/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651193/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651193.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651193.fasta'
else
    echo 'Assembly failed for SRR24651193' >&2
fi

echo '========== Start assembling: Bacteroides-cellulosilyticus-DSM-14838 (ID: SRR24651173) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651173_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651173_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651172_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651173 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651173/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651173/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651173.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651173.fasta'
else
    echo 'Assembly failed for SRR24651173' >&2
fi

echo '========== Start assembling: Bacteroides-coprocola-DSM-17136 (ID: SRR24651224) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651224_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651224_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651223_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651224 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651224/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651224/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651224.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651224.fasta'
else
    echo 'Assembly failed for SRR24651224' >&2
fi

echo '========== Start assembling: Bacteroides-coprophilus-DSM-18228 (ID: SRR24651308) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651308_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651308_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651222_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651308 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651308/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651308/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651308.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651308.fasta'
else
    echo 'Assembly failed for SRR24651308' >&2
fi

echo '========== Start assembling: Bacteroides-dorei-5-1-36-D4 (ID: SRR24651211) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651211_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651211_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651200_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651211 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651211/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651211/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651211.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651211.fasta'
else
    echo 'Assembly failed for SRR24651211' >&2
fi

echo '========== Start assembling: Bacteroides-finegoldii-DSM-17565 (ID: SRR24651187) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651187_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651187_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651176_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651187 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651187/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651187/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651187.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651187.fasta'
else
    echo 'Assembly failed for SRR24651187' >&2
fi

echo '========== Start assembling: Bacteroides-fragilis-2-1-16 (ID: SRR24651307) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651307_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651307_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651306_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651307 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651307/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651307/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651307.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651307.fasta'
else
    echo 'Assembly failed for SRR24651307' >&2
fi

echo '========== Start assembling: Bacteroides-fragilis-3-1-12 (ID: SRR24651295) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651295_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651295_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651284_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651295 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651295/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651295/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651295.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651295.fasta'
else
    echo 'Assembly failed for SRR24651295' >&2
fi

echo '========== Start assembling: Bacteroides-intestinalis-DSM-17393 (ID: SRR24651326) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651326_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651326_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651265_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651326 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651326/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651326/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651326.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651326.fasta'
else
    echo 'Assembly failed for SRR24651326' >&2
fi

echo '========== Start assembling: Bacteroides-plebeius-DSM-17135 (ID: SRR24651301) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651301_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651301_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651225_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651301 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651301/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651301/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651301.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651301.fasta'
else
    echo 'Assembly failed for SRR24651301' >&2
fi

echo '========== Start assembling: Bacteroides-rodentium-JCM-16496 (ID: SRR24651325) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651325_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651325_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651324_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651325 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651325/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651325/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651325.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651325.fasta'
else
    echo 'Assembly failed for SRR24651325' >&2
fi

echo '========== Start assembling: Bacteroides-sp-2-1-22 (ID: SRR24651232) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651232_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651232_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651321_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651232 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651232/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651232/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651232.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651232.fasta'
else
    echo 'Assembly failed for SRR24651232' >&2
fi

echo '========== Start assembling: Bacteroides-sp-3-1-19 (ID: SRR24651312) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651312_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651312_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651311_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651312 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651312/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651312/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651312.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651312.fasta'
else
    echo 'Assembly failed for SRR24651312' >&2
fi

echo '========== Start assembling: Bacteroides-sp-9-1-42FAA (ID: SRR24651310) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651310_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651310_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651309_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651310 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651310/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651310/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651310.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651310.fasta'
else
    echo 'Assembly failed for SRR24651310' >&2
fi

echo '========== Start assembling: Bacteroides-thetaiotaomicron-1-1-6 (ID: SRR24651254) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651254_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651254_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651243_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651254 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651254/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651254/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651254.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651254.fasta'
else
    echo 'Assembly failed for SRR24651254' >&2
fi

echo '========== Start assembling: Bacteroides-thetaiotaomicron-VPI-5482 (ID: SRR24651305) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651305_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651305_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651304_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651305 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651305/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651305/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651305.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651305.fasta'
else
    echo 'Assembly failed for SRR24651305' >&2
fi

echo '========== Start assembling: Bacteroides-xylanisolvens-SD-CC-1b (ID: SRR24651303) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651303_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651303_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651302_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651303 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651303/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651303/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651303.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651303.fasta'
else
    echo 'Assembly failed for SRR24651303' >&2
fi

echo '========== Start assembling: Bifidobacterium-adolescentis-L2-32 (ID: SRR24651267) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651267_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651267_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651266_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651267 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651267/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651267/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651267.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651267.fasta'
else
    echo 'Assembly failed for SRR24651267' >&2
fi

echo '========== Start assembling: Bifidobacterium-breve-JCM-1192 (ID: SRR24651247) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651247_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651247_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651246_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651247 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651247/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651247/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651247.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651247.fasta'
else
    echo 'Assembly failed for SRR24651247' >&2
fi

echo '========== Start assembling: Bifidobacterium-catenulatum-JCM-1194 (ID: SRR24651256) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651256_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651256_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651255_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651256 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651256/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651256/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651256.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651256.fasta'
else
    echo 'Assembly failed for SRR24651256' >&2
fi

echo '========== Start assembling: Bifidobacterium-longum-ATCC-15697 (ID: SRR24651279) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651279_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651279_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651278_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651279 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651279/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651279/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651279.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651279.fasta'
else
    echo 'Assembly failed for SRR24651279' >&2
fi

echo '========== Start assembling: Bifidobacterium-pseudocatenulatum-JCM-1200 (ID: SRR24651264) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651264_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651264_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651263_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651264 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651264/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651264/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651264.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651264.fasta'
else
    echo 'Assembly failed for SRR24651264' >&2
fi

echo '========== Start assembling: Bilophila-wadsworthia-ATCC-49260 (ID: SRR24651234) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651234_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651234_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651233_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651234 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651234/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651234/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651234.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651234.fasta'
else
    echo 'Assembly failed for SRR24651234' >&2
fi

echo '========== Start assembling: Blautia-hydrogenotrophica-DSM-10507 (ID: SRR24651182) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651182_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651182_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651181_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651182 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651182/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651182/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651182.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651182.fasta'
else
    echo 'Assembly failed for SRR24651182' >&2
fi

echo '========== Start assembling: Burkholderiales-bacterium-1-1-47 (ID: SRR24651323) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651323_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651323_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651322_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651323 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651323/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651323/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651323.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651323.fasta'
else
    echo 'Assembly failed for SRR24651323' >&2
fi

echo '========== Start assembling: Catenibacterium-mitsuokai-DSM-15897 (ID: SRR24651299) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651299_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651299_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651298_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651299 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651299/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651299/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651299.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651299.fasta'
else
    echo 'Assembly failed for SRR24651299' >&2
fi

echo '========== Start assembling: Clostridiales-bacterium-VE202-14 (ID: SRR24651242) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651242_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651242_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651241_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651242 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651242/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651242/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651242.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651242.fasta'
else
    echo 'Assembly failed for SRR24651242' >&2
fi

echo '========== Start assembling: Clostridiales-bacterium-VE202-27 (ID: SRR24651240) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651240_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651240_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651239_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651240 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651240/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651240/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651240.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651240.fasta'
else
    echo 'Assembly failed for SRR24651240' >&2
fi

echo '========== Start assembling: Clostridium-hylemonae-DSM-15053 (ID: SRR24651171) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651171_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651171_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651300_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651171 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651171/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651171/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651171.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651171.fasta'
else
    echo 'Assembly failed for SRR24651171' >&2
fi

echo '========== Start assembling: Clostridium-leptum-DSM-753 (ID: SRR24651206) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651206_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651206_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651205_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651206 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651206/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651206/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651206.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651206.fasta'
else
    echo 'Assembly failed for SRR24651206' >&2
fi

echo '========== Start assembling: Clostridium-scindens-ATCC-35704 (ID: SRR24651217) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651217_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651217_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651216_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651217 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651217/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651217/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651217.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651217.fasta'
else
    echo 'Assembly failed for SRR24651217' >&2
fi

echo '========== Start assembling: Clostridium-sp-ATCC-29733 (ID: SRR24651236) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651236_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651236_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651235_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651236 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651236/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651236/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651236.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651236.fasta'
else
    echo 'Assembly failed for SRR24651236' >&2
fi

echo '========== Start assembling: Clostridium-sp-D5 (ID: SRR24651318) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651318_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651318_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651317_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651318 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651318/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651318/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651318.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651318.fasta'
else
    echo 'Assembly failed for SRR24651318' >&2
fi

echo '========== Start assembling: Clostridium-sp-L2-50 (ID: SRR24651215) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651215_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651215_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651214_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651215 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651215/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651215/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651215.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651215.fasta'
else
    echo 'Assembly failed for SRR24651215' >&2
fi

echo '========== Start assembling: Clostridium-sp-M62-1 (ID: SRR24651213) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651213_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651213_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651212_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651213 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651213/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651213/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651213.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651213.fasta'
else
    echo 'Assembly failed for SRR24651213' >&2
fi

echo '========== Start assembling: Clostridium-sporogenes-ATCC-15579 (ID: SRR24651258) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651258_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651258_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651257_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651258 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651258/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651258/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651258.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651258.fasta'
else
    echo 'Assembly failed for SRR24651258' >&2
fi

echo '========== Start assembling: Collinsella-aerofaciens-ATCC-25986 (ID: SRR24651297) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651297_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651297_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651296_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651297 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651297/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651297/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651297.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651297.fasta'
else
    echo 'Assembly failed for SRR24651297' >&2
fi

echo '========== Start assembling: Desulfovibrio-piger-ATCC-29098 (ID: SRR24651271) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651271_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651271_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651270_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651271 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651271/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651271/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651271.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651271.fasta'
else
    echo 'Assembly failed for SRR24651271' >&2
fi

echo '========== Start assembling: Dialister-invisus-DSM-15470 (ID: SRR24651277) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651277_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651277_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651276_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651277 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651277/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651277/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651277.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651277.fasta'
else
    echo 'Assembly failed for SRR24651277' >&2
fi

echo '========== Start assembling: Eggerthella-lenta-DSM-2243 (ID: SRR24651175) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651175_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651175_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651174_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651175 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651175/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651175/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651175.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651175.fasta'
else
    echo 'Assembly failed for SRR24651175' >&2
fi

echo '========== Start assembling: Enterocloster-bolteae-ATCC-BAA-613 (ID: SRR24651210) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651210_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651210_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651209_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651210 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651210/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651210/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651210.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651210.fasta'
else
    echo 'Assembly failed for SRR24651210' >&2
fi

echo '========== Start assembling: Faecalibacterium-prausnitzii-A2-165 (ID: SRR24651198) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651198_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651198_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651196_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651198 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651198/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651198/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651198.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651198.fasta'
else
    echo 'Assembly failed for SRR24651198' >&2
fi

echo '========== Start assembling: Holdemanella-biformis-DSM-3989 (ID: SRR24651184) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651184_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651184_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651183_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651184 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651184/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651184/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651184.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651184.fasta'
else
    echo 'Assembly failed for SRR24651184' >&2
fi

echo '========== Start assembling: Holdemania-filiformis-DSM-12042 (ID: SRR24651186) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651186_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651186_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651185_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651186 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651186/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651186/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651186.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651186.fasta'
else
    echo 'Assembly failed for SRR24651186' >&2
fi

echo '========== Start assembling: Hungatella-hathewayi-DSM-13479 (ID: SRR24651208) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651208_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651208_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651207_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651208 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651208/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651208/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651208.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651208.fasta'
else
    echo 'Assembly failed for SRR24651208' >&2
fi

echo '========== Start assembling: Intestinibacter-bartlettii-DSM-16795 (ID: SRR24651292) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651292_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651292_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651291_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651292 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651292/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651292/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651292.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651292.fasta'
else
    echo 'Assembly failed for SRR24651292' >&2
fi

echo '========== Start assembling: Intestinimonas-butyriciproducens-DSM-26588 (ID: SRR24651229) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651229_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651229_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651228_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651229 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651229/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651229/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651229.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651229.fasta'
else
    echo 'Assembly failed for SRR24651229' >&2
fi

echo '========== Start assembling: Lachnospira-eligens-ATCC-27750 (ID: SRR24651189) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651189_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651189_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651188_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651189 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651189/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651189/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651189.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651189.fasta'
else
    echo 'Assembly failed for SRR24651189' >&2
fi

echo '========== Start assembling: Lacrimispora-saccharolytica-WM1 (ID: SRR24651180) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651180_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651180_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651179_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651180 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651180/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651180/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651180.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651180.fasta'
else
    echo 'Assembly failed for SRR24651180' >&2
fi

echo '========== Start assembling: Lactococcus-lactis-DSMZ-20729 (ID: SRR24651260) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651260_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651260_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651259_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651260 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651260/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651260/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651260.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651260.fasta'
else
    echo 'Assembly failed for SRR24651260' >&2
fi

echo '========== Start assembling: Megasphaera-DSMZ-102144 (ID: SRR24651245) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651245_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651245_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651244_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651245 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651245/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651245/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651245.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651245.fasta'
else
    echo 'Assembly failed for SRR24651245' >&2
fi

echo '========== Start assembling: Mitsuokella-multacida-DSM-20544 (ID: SRR24651286) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651286_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651286_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651285_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651286 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651286/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651286/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651286.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651286.fasta'
else
    echo 'Assembly failed for SRR24651286' >&2
fi

echo '========== Start assembling: Odoribacter-splanchnicus-DSM-20712 (ID: SRR24651227) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651227_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651227_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651226_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651227 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651227/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651227/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651227.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651227.fasta'
else
    echo 'Assembly failed for SRR24651227' >&2
fi

echo '========== Start assembling: Olsenella-uli-DSM-7084 (ID: SRR24651283) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651283_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651283_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651282_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651283 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651283/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651283/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651283.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651283.fasta'
else
    echo 'Assembly failed for SRR24651283' >&2
fi

echo '========== Start assembling: Oscillibacter-sp-KLE-1728 (ID: SRR24651238) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651238_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651238_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651237_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651238 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651238/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651238/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651238.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651238.fasta'
else
    echo 'Assembly failed for SRR24651238' >&2
fi

echo '========== Start assembling: Parabacteroides-distasonis-ATCC-8503 (ID: SRR24651178) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651178_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651178_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651177_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651178 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651178/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651178/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651178.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651178.fasta'
else
    echo 'Assembly failed for SRR24651178' >&2
fi

echo '========== Start assembling: Parabacteroides-sp-D13 (ID: SRR24651195) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651195_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651195_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651194_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651195 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651195/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651195/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651195.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651195.fasta'
else
    echo 'Assembly failed for SRR24651195' >&2
fi

echo '========== Start assembling: Peptostreptococcus-anaerobius-ATCC-27337 (ID: SRR24651320) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651320_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651320_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651319_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651320 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651320/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651320/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651320.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651320.fasta'
else
    echo 'Assembly failed for SRR24651320' >&2
fi

echo '========== Start assembling: Peptostreptococcus-sp-CC14N-HM-1051 (ID: SRR24651314) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651314_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651314_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651313_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651314 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651314/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651314/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651314.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651314.fasta'
else
    echo 'Assembly failed for SRR24651314' >&2
fi

echo '========== Start assembling: Prevotella-buccae-D17 (ID: SRR24651288) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651288_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651288_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651287_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651288 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651288/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651288/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651288.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651288.fasta'
else
    echo 'Assembly failed for SRR24651288' >&2
fi

echo '========== Start assembling: Roseburia-intestinalis-L1-82 (ID: SRR24651202) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651202_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651202_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651201_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651202 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651202/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651202/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651202.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651202.fasta'
else
    echo 'Assembly failed for SRR24651202' >&2
fi

echo '========== Start assembling: Roseburia-inulinivorans-DSM-16841 (ID: SRR24651191) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651191_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651191_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651190_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651191 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651191/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651191/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651191.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651191.fasta'
else
    echo 'Assembly failed for SRR24651191' >&2
fi

echo '========== Start assembling: Ruminococcus-albus-8 (ID: SRR24651253) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651253_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651253_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651252_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651253 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651253/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651253/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651253.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651253.fasta'
else
    echo 'Assembly failed for SRR24651253' >&2
fi

echo '========== Start assembling: Ruminococcus-bromii-ATCC-27255 (ID: SRR24651251) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651251_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651251_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651250_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651251 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651251/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651251/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651251.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651251.fasta'
else
    echo 'Assembly failed for SRR24651251' >&2
fi

echo '========== Start assembling: Ruminococcus-gnavus-ATCC-29149 (ID: SRR24651221) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651221_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651221_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651220_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651221 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651221/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651221/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651221.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651221.fasta'
else
    echo 'Assembly failed for SRR24651221' >&2
fi

echo '========== Start assembling: Ruminococcus-torques-ATCC-27756 (ID: SRR24651204) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651204_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651204_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651203_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651204 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651204/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651204/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651204.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651204.fasta'
else
    echo 'Assembly failed for SRR24651204' >&2
fi

echo '========== Start assembling: Slackia-exigua-ATCC-700122 (ID: SRR24651275) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651275_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651275_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651274_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651275 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651275/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651275/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651275.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651275.fasta'
else
    echo 'Assembly failed for SRR24651275' >&2
fi

echo '========== Start assembling: Slackia-heliotrinireducens-DSM-20476 (ID: SRR24651281) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651281_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651281_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651280_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651281 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651281/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651281/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651281.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651281.fasta'
else
    echo 'Assembly failed for SRR24651281' >&2
fi

echo '========== Start assembling: Solobacterium-moorei-DSM-22971 (ID: SRR24651262) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651262_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651262_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651261_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651262 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651262/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651262/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651262.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651262.fasta'
else
    echo 'Assembly failed for SRR24651262' >&2
fi

echo '========== Start assembling: Streptococcus-thermophilus-LMD-9 (ID: SRR24651273) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651273_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651273_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651272_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651273 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651273/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651273/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651273.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651273.fasta'
else
    echo 'Assembly failed for SRR24651273' >&2
fi

echo '========== Start assembling: Subdoligranulum-sp-4-3-54A2FAA (ID: SRR24651231) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651231_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651231_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651230_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651231 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651231/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651231/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651231.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651231.fasta'
else
    echo 'Assembly failed for SRR24651231' >&2
fi

echo '========== Start assembling: Turicibacter-sanguinis-DSM-14220 (ID: SRR24651316) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651316_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651316_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651315_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651316 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651316/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651316/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651316.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651316.fasta'
else
    echo 'Assembly failed for SRR24651316' >&2
fi

echo '========== Start assembling: Tyzzerella-nexilis-DSM-1787 (ID: SRR24651219) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651219_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651219_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651218_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651219 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651219/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651219/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651219.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651219.fasta'
else
    echo 'Assembly failed for SRR24651219' >&2
fi

echo '========== Start assembling: Veillonella-dispar-ATCC-17748 (ID: SRR24651290) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651290_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651290_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651289_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651290 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651290/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651290/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651290.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651290.fasta'
else
    echo 'Assembly failed for SRR24651290' >&2
fi

echo '========== Start assembling: Veillonella-sp-3-1-44 (ID: SRR24651249) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651249_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651249_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651248_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651249 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651249/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651249/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651249.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651249.fasta'
else
    echo 'Assembly failed for SRR24651249' >&2
fi

echo '========== Start assembling: Veillonella-sp-6-1-27 (ID: SRR24651199) =========='
unicycler -1 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651199_clean_1.fastq.gz -2 /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651199_clean_2.fastq.gz -l /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/fastq/clean_data/SRR24651197_clean.fastq.gz -o /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651199 -t 35 --mode normal --no_correct
if [ -f /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651199/assembly.fasta ]; then
    cp /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/SRR24651199/assembly.fasta /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651199.fasta
    echo 'Finished: Saved to /public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq/isolate_genome/final_fastas/SRR24651199.fasta'
else
    echo 'Assembly failed for SRR24651199' >&2
fi

