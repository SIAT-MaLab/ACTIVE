#!/bin/bash
set -u

ABS_DIR="/public/home/huangyan/SPA/metagenome_benchmark/hcom2/isolate_seq"
THREADS=60
OUTDIR="${ABS_DIR}/fastq"
TMPDIR="${ABS_DIR}/fasterq_tmp"
LOGDIR="${ABS_DIR}/logs"
SRA_INFO="${ABS_DIR}/sra_info.tsv"

mkdir -p "${OUTDIR}" "${TMPDIR}" "${LOGDIR}"

STAMP="$(date +%Y%m%d_%H%M%S)"
LOG="${LOGDIR}/convert_${STAMP}.log"
SUMMARY="${LOGDIR}/convert_summary_${STAMP}.tsv"
FAILLOG="${LOGDIR}/convert_fail_${STAMP}.txt"

exec > >(tee -a "${LOG}") 2>&1

if ! command -v fasterq-dump >/dev/null 2>&1; then
    echo "[FATAL] fasterq-dump not found (load sra-toolkit)"
    exit 1
fi
if command -v pigz >/dev/null 2>&1; then
    COMPRESS=(pigz -p "${THREADS}")
else
    echo "[WARN] pigz not found, fallback to gzip"
    COMPRESS=(gzip)
fi

printf "sample\tplatform\tlayout\tmodel\toriginal_file\ttry_lite1\ttry_sra\ttry_dot1\tfinal_file\tfinal_format\tstatus\tfastq_gz\tnotes\n" > "${SUMMARY}"

lookup_meta() {
    local srr="$1"
    awk -F '\t' -v srr="${srr}" 'NR>1 && $5==srr {print $8 "\t" $7 "\t" $9; found=1; exit}
                                 END{if(!found) print "NA\tNA\tNA"}' "${SRA_INFO}"
}

clean_partial() {
    local sample="$1"
    rm -rf "${TMPDIR}/${sample}_work" "${TMPDIR}/${sample}_tmp"
    rm -f \
        "${OUTDIR}/${sample}.fastq" \
        "${OUTDIR}/${sample}_1.fastq" \
        "${OUTDIR}/${sample}_2.fastq" \
        "${OUTDIR}/${sample}_3.fastq" \
        "${OUTDIR}/${sample}.lite.fastq" \
        "${OUTDIR}/${sample}.lite_1.fastq" \
        "${OUTDIR}/${sample}.lite_2.fastq"
}

normalize_outputs() {
    local sample="$1"
    local f
    shopt -s nullglob
    for f in "${OUTDIR}/${sample}"*.fastq; do
        local base
        base="$(basename "${f}")"
        local new="${base}"
        new="${new/${sample}.lite.1/${sample}}"
        new="${new/${sample}.lite/${sample}}"
        new="${new/${sample}.sra/${sample}}"
        if [[ "${new}" != "${base}" ]]; then
            mv -f "${f}" "${OUTDIR}/${new}"
        fi
    done
    shopt -u nullglob
}

list_fastq() {
    local sample="$1"
    local out=()
    local cand
    for cand in \
        "${OUTDIR}/${sample}.fastq" \
        "${OUTDIR}/${sample}_1.fastq" \
        "${OUTDIR}/${sample}_2.fastq" \
        "${OUTDIR}/${sample}_3.fastq"
    do
        [[ -s "${cand}" ]] && out+=("${cand}")
    done
    printf '%s\n' "${out[@]+"${out[@]}"}"
}

already_done() {
    local sample="$1"
    local gz
    for gz in \
        "${OUTDIR}/${sample}.fastq.gz" \
        "${OUTDIR}/${sample}_1.fastq.gz" \
        "${OUTDIR}/${sample}_2.fastq.gz"
    do
        [[ -s "${gz}" ]] && return 0
    done
    return 1
}

try_dump() {
    local infile="$1"
    local sample="$2"
    local work="${TMPDIR}/${sample}_work"
    local tmp="${TMPDIR}/${sample}_tmp"

    mkdir -p "${work}" "${tmp}"
    local stage_name
    stage_name="$(basename "${infile}")"
    ln -f "${infile}" "${work}/${stage_name}"

    if ! fasterq-dump \
            --split-3 \
            --skip-technical \
            --force \
            -e "${THREADS}" \
            -O "${OUTDIR}" \
            -t "${tmp}" \
            "${work}/${stage_name}"
    then
        rm -rf "${work}" "${tmp}"
        return 1
    fi

    normalize_outputs "${sample}"
    local produced
    produced="$(list_fastq "${sample}")"
    rm -rf "${work}" "${tmp}"

    if [[ -z "${produced}" ]]; then
        return 1
    fi
    return 0
}

compress_fastq() {
    local sample="$1"
    local f
    while IFS= read -r f; do
        [[ -n "${f}" ]] || continue
        "${COMPRESS[@]}" "${f}"
    done < <(list_fastq "${sample}")
}

process_sample() {
    local sample="$1"
    local meta platform layout model
    meta="$(lookup_meta "${sample}")"
    platform="$(printf '%s' "${meta}" | cut -f1)"
    layout="$(printf '%s' "${meta}" | cut -f2)"
    model="$(printf '%s' "${meta}" | cut -f3)"

    local f_lite="${ABS_DIR}/${sample}.lite.1"
    local f_sra="${ABS_DIR}/${sample}.sra"
    local f_dot1="${ABS_DIR}/${sample}.1"

    local original="" current=""
    if   [[ -f "${f_lite}" ]]; then original="${f_lite}"; current="${f_lite}"
    elif [[ -f "${f_sra}"  ]]; then original="${f_sra}";  current="${f_sra}"
    elif [[ -f "${f_dot1}" ]]; then original="${f_dot1}"; current="${f_dot1}"
    else
        return
    fi

    local orig_base
    orig_base="$(basename "${original}")"

    if already_done "${sample}"; then
        printf "%s\t%s\t%s\t%s\t%s\tNA\tNA\tNA\t%s\tkeep\tskip_exists\t%s\talready gzipped\n" \
            "${sample}" "${platform}" "${layout}" "${model}" "${orig_base}" \
            "$(basename "${current}")" "$(ls -1 "${OUTDIR}/${sample}"*.fastq.gz 2>/dev/null | tr '\n' ';' )" \
            >> "${SUMMARY}"
        return
    fi

    local try_lite1="NA" try_sra="NA" try_dot1="NA"
    local status="fail" final_fmt="none" notes="" final_file=""
    local ok=0

    attempt() {
        local fmt="$1" src="$2"
        clean_partial "${sample}"
        if try_dump "${src}" "${sample}"; then
            eval "try_${fmt}=success"
            if compress_fastq "${sample}"; then
                status="success"
                final_fmt="${fmt}"
                final_file="$(basename "${src}")"
                ok=1
                notes="converted_as_${fmt}"
                return 0
            else
                eval "try_${fmt}=compress_fail"
                notes="dump_ok_but_pigz_failed"
                return 1
            fi
        else
            eval "try_${fmt}=fail"
            return 1
        fi
    }

    case "${current}" in
        *.lite.1)
            if attempt lite1 "${current}"; then
                :
            else
                mv -f "${current}" "${f_sra}"
                current="${f_sra}"
                if attempt sra "${current}"; then
                    :
                else
                    mv -f "${current}" "${f_dot1}"
                    current="${f_dot1}"
                    attempt dot1 "${current}" || notes="all_three_formats_failed"
                fi
            fi
            ;;
        *.sra)
            if attempt sra "${current}"; then
                :
            else
                mv -f "${current}" "${f_dot1}"
                current="${f_dot1}"
                attempt dot1 "${current}" || notes="sra_and_dot1_failed"
            fi
            ;;
        *.1)
            attempt dot1 "${current}" || notes="dot1_failed"
            ;;
    esac

    if [[ "${ok}" -ne 1 ]]; then
        clean_partial "${sample}"
        echo "[ERROR] ${sample}: all formats failed" | tee -a "${FAILLOG}"
        status="fail"
        final_file="$(basename "${current}")"
        final_fmt="$(echo "${current}" | awk -F. '{if($NF=="1" && $(NF-1)=="lite") print "lite1"; else print $NF}')"
    fi

    local gzlist
    gzlist="$(ls -1 "${OUTDIR}/${sample}".fastq.gz "${OUTDIR}/${sample}"_[123].fastq.gz 2>/dev/null | xargs -r -n1 basename | tr '\n' ';')"

    printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "${sample}" "${platform}" "${layout}" "${model}" "${orig_base}" \
        "${try_lite1}" "${try_sra}" "${try_dot1}" \
        "${final_file}" "${final_fmt}" "${status}" "${gzlist}" "${notes}" \
        >> "${SUMMARY}"
}

shopt -s nullglob
declare -A SAMPLES
for f in "${ABS_DIR}"/SRR*.lite.1 "${ABS_DIR}"/SRR*.sra "${ABS_DIR}"/SRR*.1; do
    [[ -f "${f}" ]] || continue
    b="$(basename "${f}")"
    srr="${b%%.*}"
    [[ "${srr}" =~ ^SRR[0-9]+$ ]] || continue
    SAMPLES["${srr}"]=1
done
shopt -u nullglob

if [[ ${#SAMPLES[@]} -eq 0 ]]; then
    echo "[FATAL] no SRR*.lite.1 / SRR*.sra / SRR*.1 in ${ABS_DIR}"
    exit 1
fi

echo "Samples: ${#SAMPLES[@]}"
for sample in $(printf '%s\n' "${!SAMPLES[@]}" | sort); do
    process_sample "${sample}"
done

echo "FASTQ   : ${OUTDIR}"
echo "SUMMARY : ${SUMMARY}"
echo "LOG     : ${LOG}"
echo "FAILS   : ${FAILLOG}"
echo "Status:"
awk -F '\t' 'NR>1{s[$11]++} END{for(k in s) printf "  %s: %d\n", k, s[k]}' "${SUMMARY}"
echo "Formats (success):"
awk -F '\t' 'NR>1 && $11=="success"{s[$10]++} END{for(k in s) printf "  %s: %d\n", k, s[k]}' "${SUMMARY}"