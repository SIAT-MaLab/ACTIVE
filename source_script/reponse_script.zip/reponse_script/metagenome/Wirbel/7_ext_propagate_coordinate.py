#!/usr/bin/env python3
import argparse
import re
import sys

import pandas as pd

CONTIG_RE = re.compile(r"^(.*)_(\d+)$")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate propagate_coordinates.tsv from active_coordinate.tsv (real + fake coords)"
    )
    parser.add_argument(
        "-i", "--input",
        default="active_coordinate.tsv",
        help="input coordinate file",
    )
    parser.add_argument(
        "-o", "--output",
        default="propagate_coordinates.tsv",
        help="output file",
    )
    parser.add_argument(
        "-r", "--host-fasta",
        default=None,
        help="optional host FASTA; uses its max contig number to build fake coords",
    )
    parser.add_argument("--fake-start", type=int, default=3000, help="fake start (default 3000)")
    parser.add_argument("--fake-stop", type=int, default=5000, help="fake stop (default 5000)")
    return parser.parse_args()


def looks_like_header(fields):
    joined = "\t".join(fields).lower()
    return ("contig" in joined or "scaffold" in joined) and "start" in joined


def read_coordinates(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        first = f.readline()
        if not first.strip():
            raise ValueError(f"empty input: {path}")
        fields = first.rstrip("\n").split("\t")

    if looks_like_header(fields):
        df = pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False)
        colmap = {c.strip().lower(): c for c in df.columns}

        contig_col = colmap.get("contig") or colmap.get("scaffold")
        start_col = colmap.get("start") or colmap.get("prophage start")
        stop_col = colmap.get("stop") or colmap.get("prophage stop")
        name_col = colmap.get("prophage_name") or colmap.get("fragment") or colmap.get("name")
        genome_col = colmap.get("genome") or colmap.get("genome_id")

        if contig_col is None or start_col is None or stop_col is None:
            raise ValueError(
                "header requires contig/scaffold, start, stop columns."
                f" got: {list(df.columns)}"
            )

        out = pd.DataFrame({
            "scaffold": df[contig_col].astype(str).str.strip(),
            "start": df[start_col].astype(str),
            "stop": df[stop_col].astype(str),
        })
        if name_col is not None:
            out["fragment"] = df[name_col].astype(str).str.strip()
        else:
            out["fragment"] = ""
        if genome_col is not None:
            out["genome_id"] = df[genome_col].astype(str).str.strip()
        else:
            out["genome_id"] = ""
        return out

    df = pd.read_csv(
        path,
        sep="\t",
        header=None,
        dtype=str,
        keep_default_na=False,
        usecols=range(min(4, len(fields))),
    )
    df.columns = ["scaffold", "start", "stop"] + (
        ["fragment"] if df.shape[1] >= 4 else []
    )
    if "fragment" not in df.columns:
        df["fragment"] = ""
    df["genome_id"] = ""
    df["scaffold"] = df["scaffold"].str.strip()
    return df[["scaffold", "start", "stop", "fragment", "genome_id"]]


def fasta_headers(path):
    names = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith(">"):
                names.append(line[1:].strip().split()[0])
    return names


def max_contig_from_host(host_fasta):
    genome_max = {}
    bad = []
    for name in fasta_headers(host_fasta):
        m = CONTIG_RE.match(name)
        if not m:
            bad.append(name)
            continue
        genome, num = m.group(1), int(m.group(2))
        if genome not in genome_max or num > genome_max[genome]:
            genome_max[genome] = num
    if bad:
        print(f"warning: {len(bad)} contigs not matching genome_N in host FASTA, ignored. e.g. {bad[:5]}")
    return genome_max


def main():
    args = parse_args()
    if args.fake_stop < args.fake_start:
        raise ValueError("fake-stop must be >= fake-start")

    df = read_coordinates(args.input)
    df = df[df["scaffold"].str.strip() != ""].copy()
    if df.empty:
        raise ValueError("no valid records")

    for col in ["start", "stop"]:
        df[col] = df[col].astype(str).str.replace(",", "", regex=False).str.strip()

    try:
        df["start"] = pd.to_numeric(df["start"], errors="raise").astype(int)
        df["stop"] = pd.to_numeric(df["stop"], errors="raise").astype(int)
    except ValueError as e:
        for col in ["start", "stop"]:
            bad = df[pd.to_numeric(df[col], errors="coerce").isna() & (df[col] != "")]
            if not bad.empty:
                print(f"column {col} has unparseable coordinates, e.g.:")
                print(bad[["scaffold", col]].head(10).to_string(index=False))
        raise e

    swap = df["stop"] < df["start"]
    if swap.any():
        df.loc[swap, ["start", "stop"]] = df.loc[swap, ["stop", "start"]].values

    if (df["start"] < 1).any():
        raise ValueError("found start < 1")

    extracted = df["scaffold"].str.extract(r"^(.*)_(\d+)$")
    if extracted.isna().any().any():
        bad_scaffolds = df.loc[extracted.isna().any(axis=1), "scaffold"].unique()
        raise ValueError(
            "cannot parse as genome_contigNumber:\n"
            + "\n".join(map(str, bad_scaffolds))
        )

    df["_genome_prefix"] = extracted[0]
    df["_contig_number"] = extracted[1].astype(int)

    df["genome_id"] = df["genome_id"].fillna("").astype(str).str.strip()
    df.loc[df["genome_id"] == "", "genome_id"] = df["_genome_prefix"]

    prefix_count = df.groupby("genome_id")["_genome_prefix"].nunique()
    if (prefix_count > 1).any():
        bad_genomes = prefix_count[prefix_count > 1].index.tolist()
        raise ValueError(
            "genomes mapping to multiple contig prefixes:\n"
            + "\n".join(bad_genomes)
        )

    empty_frag = df["fragment"].fillna("").astype(str).str.strip() == ""
    df.loc[empty_frag, "fragment"] = (
        df.loc[empty_frag, "scaffold"]
        + "|provirus_"
        + df.loc[empty_frag, "start"].astype(str)
        + "_"
        + df.loc[empty_frag, "stop"].astype(str)
    )

    real_coordinates = (
        df[["scaffold", "fragment", "start", "stop"]]
        .drop_duplicates()
        .copy()
    )

    genome_info = (
        df.groupby("genome_id", sort=False)
        .agg(
            genome_prefix=("_genome_prefix", "first"),
            max_contig=("_contig_number", "max"),
        )
        .reset_index()
    )

    host_max = None
    if args.host_fasta:
        host_max = max_contig_from_host(args.host_fasta)
        missing_in_host = [
            g for g in genome_info["genome_prefix"] if g not in host_max
        ]
        if missing_in_host:
            print(
                f"warning: {len(missing_in_host)} genomes not in host FASTA; "
                f"using max contig from coordinate file. e.g. {missing_in_host[:5]}"
            )

    fake_rows = []
    for _, row in genome_info.iterrows():
        genome_id = row["genome_id"]
        genome_prefix = row["genome_prefix"]
        max_contig = int(row["max_contig"])
        if host_max and genome_prefix in host_max:
            max_contig = int(host_max[genome_prefix])
        fake_rows.append({
            "scaffold": f"{genome_prefix}_{max_contig + 1}",
            "fragment": f"{genome_id}_fakepp",
            "start": args.fake_start,
            "stop": args.fake_stop,
        })

    fake_coordinates = pd.DataFrame(
        fake_rows, columns=["scaffold", "fragment", "start", "stop"]
    )
    result = pd.concat([real_coordinates, fake_coordinates], ignore_index=True)
    result.to_csv(args.output, sep="\t", index=False)

    print(f"output: {args.output}")
    print(f"real coords: {len(real_coordinates)}")
    print(f"fake coords: {len(fake_coordinates)}")
    print(f"total coords: {len(result)}")
    if args.host_fasta:
        print("fake max contig from host FASTA")
    else:
        print("note: no host FASTA; fake contigs may collide with real ones")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[Error] {exc}", file=sys.stderr)
        sys.exit(1)