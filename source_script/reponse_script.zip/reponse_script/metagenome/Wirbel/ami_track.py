#!/usr/bin/env python3
"""
AMI hybrid-truth vs Illumina MAG/contig prophage tracking (hCom2-style).

Single-entry, no run_*.sh, no --layers.
Forward hy2il: MQ+ hybrid prophage -> Illumina MAG (Host/Foreign) + assembly attribution + contig prediction overlap
Reverse il2hy: MQ+ Illumina MAG prophage -> hybrid MAG (shares same Host table)
"""
from __future__ import print_function

import argparse
import csv
import hashlib
import os
import re
import shutil
import subprocess
import sys
from collections import defaultdict
from datetime import datetime

HY_MAG_RE = re.compile(r"^(D\d+)\.bin\.(\d+)", re.I)
IL_MAG_RE = re.compile(r"^(ERR\d+)\.bin\.(\d+)", re.I)
ERR_RE = re.compile(r"(ERR\d+)", re.I)
DXX_RE = re.compile(r"(D\d+)", re.I)
FA_EXTS = (".fasta.gz", ".fna.gz", ".fa.gz", ".fasta", ".fna", ".fa")
CV_COLS = [
    "checkv_quality", "provirus", "completeness", "completeness_method",
    "contamination", "kmer_freq", "viral_genes", "host_genes",
    "gene_count", "warnings",
]
COMP = str.maketrans("ACGTNacgtn", "TGCANtgcan")
NOISE_FLOOR = 5.0
CHECKV_DB_DEFAULT = "/home/huangyan/databaseHY/checkv-db-v1.5"


def log(msg):
    print("[%s] %s" % (datetime.now().strftime("%H:%M:%S"), msg), flush=True)


def die(msg):
    sys.exit("ERROR: " + msg)


def need_exe(name):
    if shutil.which(name) is None:
        die("command not found: %s" % name)


def run_cmd(cmd):
    log("CMD: " + " ".join(cmd))
    r = subprocess.run(cmd)
    if r.returncode != 0:
        die("command failed (%d): %s" % (r.returncode, " ".join(cmd)))


def strip_ext(fn):
    fn = os.path.basename(fn)
    for ext in FA_EXTS:
        if fn.endswith(ext):
            return fn[: -len(ext)]
    return fn


def is_fasta(fn):
    fn = fn.lower()
    return fn.endswith((".fa", ".fasta", ".fna", ".fa.gz", ".fasta.gz", ".fna.gz"))


def md5_seq(seq):
    return hashlib.md5(seq.upper().encode("ascii", "ignore")).hexdigest()


def revcomp(seq):
    return seq.translate(COMP)[::-1]


def pct(n, d):
    return ("%.2f" % (100.0 * n / d)) if d else "NA"


def mag_id_of(name):
    return strip_ext(name)


def is_hybrid_mag(name):
    return bool(HY_MAG_RE.match(strip_ext(name)))


def merge_intervals(intervals):
    if not intervals:
        return []
    iv = sorted((min(s, e), max(s, e)) for s, e in intervals)
    merged = [[iv[0][0], iv[0][1]]]
    for s, e in iv[1:]:
        if s <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    return merged


def covered_bp(merged):
    return sum(e - s + 1 for s, e in merged)


def intersect_bp(a, b):
    a, b = merge_intervals(a), merge_intervals(b)
    bp = 0
    for s, e in a:
        for bs, be in b:
            i0, i1 = max(s, bs), min(e, be)
            if i0 <= i1:
                bp += i1 - i0 + 1
    return bp


def fmt_iv(iv):
    return ";".join("%d-%d" % (s, e) for s, e in merge_intervals(iv))


def parse_iv(s):
    if not s:
        return []
    out = []
    for p in str(s).split(";"):
        p = p.strip()
        if not p or "-" not in p:
            continue
        a, b = p.split("-", 1)
        out.append((int(a), int(b)))
    return out


def write_table(path, rows, fields=None):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not rows:
        with open(path, "w") as out:
            if fields:
                out.write("\t".join(fields) + "\n")
        return
    fields = fields or list(rows[0].keys())
    with open(path, "w", newline="") as out:
        w = csv.DictWriter(out, fieldnames=fields, delimiter="\t", extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def iter_fasta(path):
    name, chunks = None, []
    with open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith(">"):
                if name is not None:
                    yield name, "".join(chunks)
                name = line[1:].split()[0]
                chunks = []
            else:
                chunks.append(line.strip())
        if name is not None:
            yield name, "".join(chunks)


def write_fasta(path, records, wrap=60):
    n = 0
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as out:
        for sid, seq in records:
            out.write(">%s\n" % sid)
            for i in range(0, len(seq), wrap):
                out.write(seq[i:i + wrap] + "\n")
            n += 1
    return n


def is_mq_plus_cv(q):
    return q in ("Complete", "High-quality", "Medium-quality")


def has_viral_gene(r):
    v = str(r.get("viral_genes") or "").strip()
    if (not v) or v.upper() in ("NA", "NAN", "N/A", "NONE", "NULL", "."):
        return False
    try:
        return float(v) >= 1
    except ValueError:
        return False


def filter_checkv_record(r, mode):
    if mode == "all":
        return True
    if mode == "viral_gene":
        return has_viral_gene(r)
    if mode == "mq_5k":
        try:
            L = int(float(r.get("length") or 0))
        except ValueError:
            L = 0
        return L >= 5000 and is_mq_plus_cv(r.get("checkv_quality", ""))
    return True


class TeeIO(object):
    def __init__(self, *files):
        self.files = files

    def write(self, data):
        for f in self.files:
            f.write(data)
            f.flush()

    def flush(self):
        for f in self.files:
            f.flush()

    def isatty(self):
        return False


def diamond_ver():
    exe = shutil.which("diamond")
    if not exe:
        return None, ""
    r = subprocess.run(
        [exe, "version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    txt = (r.stdout or "").strip()
    m = re.search(r"(\d+\.\d+\.\d+)", txt)
    return (m.group(1) if m else txt), txt


def ensure_prodigal(out_dir):
    if shutil.which("prodigal"):
        return "prodigal"
    pg = shutil.which("prodigal-gv")
    if not pg:
        return ""
    bindir = os.path.join(out_dir, ".localbin")
    os.makedirs(bindir, exist_ok=True)
    dest = os.path.join(bindir, "prodigal")
    if os.path.islink(dest) or os.path.exists(dest):
        os.remove(dest)
    os.symlink(pg, dest)
    os.environ["PATH"] = bindir + os.pathsep + os.environ.get("PATH", "")
    log("WARN: no prodigal in PATH, symlinked prodigal-gv -> %s" % dest)
    return dest


def check_deps(out_dir, skip_checkv):
    rows = []

    def add(name, ok, note=""):
        rows.append((name, "OK" if ok else "MISSING", note))

    for exe in ("python3", "skani", "blastn", "makeblastdb"):
        add(exe, shutil.which(exe) is not None, shutil.which(exe) or "")
    add("checkv", shutil.which("checkv") is not None, shutil.which("checkv") or "")
    add("hmmer/hmmsearch", shutil.which("hmmsearch") is not None, shutil.which("hmmsearch") or "")
    prod = shutil.which("prodigal")
    pgv = shutil.which("prodigal-gv")
    add("prodigal", prod is not None, prod or "will try prodigal-gv")
    add("prodigal-gv", pgv is not None, pgv or "")
    dv, dtxt = diamond_ver()
    d_ok = False
    d_note = "not installed"
    if dv:
        parts = dv.split(".")
        try:
            d_ok = tuple(int(x) for x in parts[:2]) >= (0, 9)
        except ValueError:
            d_ok = False
        d_note = dv + ("" if d_ok else "  (<0.9, CheckV may fail)")
    add("diamond", shutil.which("diamond") is not None, d_note)
    log("Dependency check:")
    for n, st, note in rows:
        log("  %-18s %s  %s" % (n, st, note))
    miss = [m for m in ("skani", "blastn", "makeblastdb") if shutil.which(m) is None]
    if miss:
        die("missing: " + ", ".join(miss))
    if not skip_checkv:
        if shutil.which("checkv") is None:
            die("missing checkv (or use --skip-checkv)")
        ensure_prodigal(out_dir)
        if shutil.which("prodigal") is None:
            die("missing prodigal / prodigal-gv")
        if not d_ok:
            log("WARN: outdated or missing diamond, CheckV contamination step may fail")


def load_sample_index(path):
    if not os.path.isfile(path):
        die("index not found: " + path)
    with open(path, newline="") as fh:
        raw = fh.read()
    raw = raw.replace("\r\n", "\n").replace("\r", "\n")
    rdr = csv.DictReader(raw.splitlines(), delimiter="\t")
    if not rdr.fieldnames:
        die("index has no header: " + path)
    fmap = {k.lower().strip(): k for k in rdr.fieldnames}

    def col(*cands):
        for c in cands:
            if c in fmap:
                return fmap[c]
        return None

    c_sample = col("sample", "dxx", "id")
    c_short = col("short", "illumina", "err_short", "short_run")
    c_long = col("long", "nanopore", "hybrid_run", "long_run")
    if not c_sample or not c_short:
        die("index requires sample + short columns, got: %s" % rdr.fieldnames)
    rows = []
    for r in rdr:
        sample = r[c_sample].strip()
        short = r[c_short].strip()
        longv = r[c_long].strip() if c_long else ""
        if not sample or not short:
            continue
        m = DXX_RE.search(sample)
        sample = m.group(1).upper() if m else sample
        ms = ERR_RE.search(short)
        short = ms.group(1).upper() if ms else short
        if longv:
            ml = ERR_RE.search(longv)
            longv = ml.group(1).upper() if ml else longv
        rows.append({"sample": sample, "long": longv, "short": short})
    if not rows:
        die("index is empty")
    err_to_sample = {}
    sample_to_err = {}
    sample_to_long = {}
    for r in rows:
        if r["short"] in err_to_sample and err_to_sample[r["short"]] != r["sample"]:
            die("duplicate short-run mapping: %s" % r["short"])
        err_to_sample[r["short"]] = r["sample"]
        sample_to_err[r["sample"]] = r["short"]
        sample_to_long[r["sample"]] = r["long"]
    log("index: %d samples %s" % (len(rows), ",".join(r["sample"] for r in rows)))
    return {
        "rows": rows,
        "err_to_sample": err_to_sample,
        "sample_to_err": sample_to_err,
        "sample_to_long": sample_to_long,
        "samples": [r["sample"] for r in rows],
    }


def sample_of_id(name, idx):
    bn = os.path.basename(str(name))
    m = HY_MAG_RE.match(bn) or DXX_RE.match(bn)
    if m:
        dxx = m.group(1).upper()
        if dxx in idx["sample_to_err"]:
            return dxx
    m = ERR_RE.search(bn)
    if m:
        err = m.group(1).upper()
        if err in idx["err_to_sample"]:
            return idx["err_to_sample"][err]
    return None


def load_checkm2(path):
    out = {}
    if not path or not os.path.isfile(path):
        die("CheckM2 not found: " + str(path))
    with open(path, newline="") as fh:
        rdr = csv.DictReader(fh, delimiter="\t")
        if not rdr.fieldnames:
            die("CheckM2 has empty header: " + path)
        fmap = {k.lower().strip(): k for k in rdr.fieldnames}
        c_name = fmap.get("name") or fmap.get("bin") or rdr.fieldnames[0]
        c_comp = fmap.get("completeness")
        c_cont = fmap.get("contamination")
        if not c_comp or not c_cont:
            die("CheckM2 missing Completeness/Contamination: " + path)
        for r in rdr:
            name = mag_id_of(r[c_name].strip())
            try:
                comp = float(r[c_comp])
                cont = float(r[c_cont])
            except (TypeError, ValueError):
                continue
            out[name] = {
                "name": name, "completeness": comp, "contamination": cont, "raw": r
            }
    log("CheckM2 %s: %d bins" % (path, len(out)))
    return out


def mq_bins(checkm, min_comp, max_cont):
    keep = []
    for name, r in sorted(checkm.items()):
        if r["completeness"] >= min_comp and r["contamination"] < max_cont:
            keep.append(name)
    return keep


def parse_coord_file(path):
    rows = []
    if not os.path.isfile(path):
        die("coordinate file not found: " + path)
    with open(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 3:
                continue
            if parts[0].lower() in ("contig", "contig_id", "seqid"):
                continue
            if not parts[1].replace("-", "", 1).isdigit():
                continue
            try:
                contig, start, end = parts[0], int(parts[1]), int(parts[2])
            except ValueError:
                continue
            rows.append((contig, start, end))
    log("coords: %d rows from %s" % (len(rows), path))
    return rows


def sniff_delim(sample):
    tabs, commas = sample.count("\t"), sample.count(",")
    return "\t" if tabs >= commas else ","


def parse_rename_csv(path, idx):
    recs = []
    if not path or not os.path.isfile(path):
        return recs
    with open(path, newline="") as fh:
        peek = fh.read(8192)
        fh.seek(0)
        delim = sniff_delim(peek)
        first = peek.splitlines()[0] if peek.splitlines() else ""
        has_header = bool(re.search(r"[A-Za-z]", first)) and not re.match(
            r"^(ERR|D)\d+", first.strip()
        )
        if has_header:
            rdr = csv.DictReader(fh, delimiter=delim)
            fields = rdr.fieldnames or []
            rows = list(rdr)
        else:
            rdr = csv.reader(fh, delimiter=delim)
            rows, fields = [], []
            for p in rdr:
                if p:
                    rows.append(p)

    def looks_asm(s):
        s = str(s).strip()
        return bool(re.match(r"^ERR\d+_\S+$", s) and ".bin." not in s)

    def looks_magc(s):
        s = str(s).strip()
        return bool(HY_MAG_RE.match(s) or IL_MAG_RE.match(s))

    def mag_from_contig(c):
        m = HY_MAG_RE.match(c) or IL_MAG_RE.match(c)
        if not m:
            return ""
        return "%s.bin.%s" % (m.group(1), m.group(2))

    if fields:
        fmap = {k.lower().strip(): k for k in fields}
        c_asm = c_magc = c_mag = None
        for k, orig in fmap.items():
            if k in ("asm", "asm_contig", "old", "old_id", "original", "orig",
                     "contig", "old_contig", "assembly_contig"):
                c_asm = orig
            if k in ("new", "new_id", "new_contig", "mag_contig", "renamed",
                     "bin_contig"):
                c_magc = orig
            if k in ("bin", "mag", "bin_id", "mag_id", "genome"):
                c_mag = orig
        for r in rows:
            if not isinstance(r, dict):
                continue
            vals = [str(v).strip() for v in r.values() if str(v).strip()]
            asm = (r.get(c_asm) or "").strip() if c_asm else ""
            magc = (r.get(c_magc) or "").strip() if c_magc else ""
            mag = mag_id_of(r.get(c_mag) or "") if c_mag else ""
            if not asm or not looks_asm(asm):
                for v in vals:
                    if looks_asm(v):
                        asm = v
                        break
            if not magc or not looks_magc(magc):
                for v in vals:
                    if looks_magc(v):
                        magc = v
                        break
            if magc and not mag:
                mag = mag_from_contig(magc)
            if not asm or not magc:
                continue
            samp = sample_of_id(asm, idx) or sample_of_id(magc, idx)
            recs.append((asm, mag, magc, samp or "", "rename"))
    else:
        for p in rows:
            p = [x.strip() for x in p if str(x).strip()]
            if len(p) < 2:
                continue
            asm = magc = ""
            for v in p:
                if looks_asm(v):
                    asm = v
                elif looks_magc(v):
                    magc = v
            if not asm or not magc:
                continue
            recs.append((asm, mag_from_contig(magc), magc,
                         sample_of_id(asm, idx) or "", "rename"))
    log("rename table %s: %d mapped rows" % (path, len(recs)))
    return recs


def heuristic_asm_of_mag_contig(mag_contig):
    m = re.match(r"^(ERR\d+)\.bin\.\d+_(.+)$", mag_contig)
    if m:
        return "%s_%s" % (m.group(1), m.group(2))
    return None


def list_bin_fastas(folder):
    out = []
    if not os.path.isdir(folder):
        return out
    for fn in sorted(os.listdir(folder)):
        if fn.startswith(".") or fn.startswith("all"):
            continue
        if not is_fasta(fn):
            continue
        path = os.path.join(folder, fn)
        if os.path.isfile(path):
            out.append(path)
    return out


def discover_bins(hy_bin_dir, il_bin_dir, idx):
    groups = {}
    for sample in idx["samples"]:
        err = idx["sample_to_err"][sample]
        hy_dir = os.path.join(hy_bin_dir, sample)
        il_dir = os.path.join(il_bin_dir, err + "_bin")
        hy = list_bin_fastas(hy_dir)
        il = list_bin_fastas(il_dir)
        if not hy and os.path.isdir(hy_bin_dir):
            hy = [p for p in list_bin_fastas(hy_bin_dir)
                  if sample_of_id(p, idx) == sample]
        groups[sample] = {"hy": hy, "il": il, "err": err}
        log("discover %s: hybrid=%d illumina=%d (%s)" % (
            sample, len(hy), len(il), err))
        if not hy:
            log("WARN %s has no hybrid MAG: %s" % (sample, hy_dir))
        if not il:
            log("WARN %s has no illumina MAG: %s" % (sample, il_dir))
    return groups


def load_mag_index(files):
    target = {}
    for path in files:
        mag = mag_id_of(path)
        for cid, seq in iter_fasta(path):
            if cid in target:
                die("duplicate contig %s\n  %s\n  %s" % (cid, path, target[cid][2]))
            target[cid] = (seq, mag, path)
    return target


def assembly_path(il_contig_dir, err):
    for ext in (".fasta", ".fa", ".fna", ".fasta.gz", ".fa.gz"):
        p = os.path.join(il_contig_dir, err + ext)
        if os.path.isfile(p):
            return p
    die("short-read assembly not found: %s/{%s}.fasta" % (il_contig_dir, err))


def build_contig_maps(sample, err, il_files, asm_fa, rename_recs, outdir):
    mag_contigs = []
    for path in il_files:
        mag = mag_id_of(path)
        for cid, seq in iter_fasta(path):
            mag_contigs.append((mag, cid, seq, len(seq)))

    asm_ids = []
    asm_hash = {}
    asm_len = {}
    for cid, seq in iter_fasta(asm_fa):
        asm_ids.append(cid)
        asm_len[cid] = len(seq)
        h = md5_seq(seq)
        asm_hash.setdefault(h, []).append(cid)
        hr = md5_seq(revcomp(seq))
        if hr != h:
            asm_hash.setdefault(hr, []).append(cid + "|rc")

    asm_set = set(asm_ids)
    mapped = {}
    methods = defaultdict(int)
    conflicts = []

    def accept(mag, magc, asm, method, strand="+"):
        if not asm or asm not in asm_set:
            return False
        prev = mapped.get(magc)
        rec = {
            "sample": sample, "short": err, "mag": mag, "mag_contig": magc,
            "asm_contig": asm, "method": method, "strand": strand,
        }
        if prev and prev["asm_contig"] != asm:
            conflicts.append((magc, prev["asm_contig"], asm, prev["method"], method))
            if method == "hash":
                mapped[magc] = rec
                return True
            return False
        if prev:
            return True
        mapped[magc] = rec
        methods[method] += 1
        return True

    for mag, magc, seq, n in mag_contigs:
        asm = heuristic_asm_of_mag_contig(magc)
        if asm:
            accept(mag, magc, asm, "heuristic")

    for asm, mag, magc, samp, _ in rename_recs:
        if samp and samp != sample:
            continue
        if not magc:
            continue
        accept(mag, magc, asm, "rename")

    n_hash = 0
    for mag, magc, seq, n in mag_contigs:
        h = md5_seq(seq)
        hits = asm_hash.get(h, [])
        strand = "+"
        if not hits:
            hits = asm_hash.get(md5_seq(revcomp(seq)), [])
            strand = "-"
        clean = []
        for x in hits:
            if x.endswith("|rc"):
                clean.append((x[:-3], "-"))
            else:
                clean.append((x, strand if strand == "+" else "+"))
        uniq = list({c for c, _ in clean})
        if len(uniq) == 1:
            st = [s for c, s in clean if c == uniq[0]][0]
            if magc not in mapped:
                n_hash += 1
            accept(mag, magc, uniq[0], "hash", st)
        elif len(uniq) > 1:
            conflicts.append((magc, ",".join(uniq), "ambiguous_hash", "", "hash"))

    methods["hash_fill"] = n_hash
    n_magc = len(mag_contigs)
    n_map = len(mapped)
    binned_asm = {}
    multi_bin = []
    for rec in mapped.values():
        a = rec["asm_contig"]
        if a in binned_asm and binned_asm[a] != rec["mag"]:
            multi_bin.append((a, binned_asm[a], rec["mag"]))
        binned_asm[a] = rec["mag"]

    unbinned = [c for c in asm_ids if c not in binned_asm]
    rows = []
    for mag, magc, seq, n in mag_contigs:
        rec = mapped.get(magc)
        rows.append({
            "sample": sample, "short": err, "mag": mag, "mag_contig": magc,
            "mag_contig_len": str(n),
            "asm_contig": rec["asm_contig"] if rec else "",
            "asm_contig_len": str(asm_len.get(rec["asm_contig"], "")) if rec else "",
            "method": rec["method"] if rec else "unmapped",
            "strand": rec["strand"] if rec else "",
        })
    write_table(os.path.join(outdir, "contig_to_bin.%s.tsv" % sample), rows)
    ub_rows = [{"sample": sample, "short": err, "asm_contig": c,
                "length": str(asm_len[c])} for c in unbinned]
    write_table(os.path.join(outdir, "unbinned_contigs.%s.tsv" % sample), ub_rows)

    rate = (100.0 * n_map / n_magc) if n_magc else 0.0
    log(("%s contig-to-bin: MAG_contigs=%d mapped=%d (%.1f%%) heuristic=%d "
         "rename=%d hash_fill=%d unbinned_asm=%d/%d conflicts=%d multi_bin=%d") % (
            sample, n_magc, n_map, rate, methods.get("heuristic", 0),
            methods.get("rename", 0), methods.get("hash_fill", 0),
            len(unbinned), len(asm_ids), len(conflicts), len(multi_bin)))
    if n_magc and rate < 50:
        die("%s MAG contig mapping rate <50%%, check contig_rename_index / whether same assembly" % sample)
    if n_magc and rate < 90:
        log("WARN %s mapping rate <90%%, L2 binned/unbinned may be noisy" % sample)
    if conflicts[:8]:
        for c in conflicts[:8]:
            log("WARN map conflict %s" % (c,))
    return {
        "asm_to_mag": binned_asm,
        "unbinned": set(unbinned),
        "asm_len": asm_len,
        "n_mag_contigs": n_magc,
        "n_mapped": n_map,
        "n_asm": len(asm_ids),
        "n_unbinned": len(unbinned),
    }


def parse_skani_tsv(path):
    rows = []
    if not os.path.isfile(path) or os.path.getsize(path) == 0:
        return rows
    with open(path, newline="") as f:
        head = f.readline()
        if not head:
            return rows
        peek = head.lstrip()
        has_header = peek.lower().startswith("ref") or "ani" in peek.lower()
        f.seek(0)
        if has_header:
            rdr = csv.DictReader(f, delimiter="\t")
            for r in rdr:
                key = {k.lower().strip(): k for k in r}

                def get(*cands):
                    for c in cands:
                        if c in key:
                            return r[key[c]]
                    return None

                a = get("ref_file", "ref", "reference")
                b = get("query_file", "query")
                ani = get("ani")
                af_r = get("align_fraction_ref", "af_ref", "align_fraction_ref(%)")
                af_q = get("align_fraction_query", "af_query", "align_fraction_query(%)")
                if a is None or b is None or ani is None:
                    continue
                rows.append((a, b, float(ani), float(af_r or 0), float(af_q or 0)))
        else:
            for line in f:
                if not line.strip() or line.startswith("#"):
                    continue
                p = line.rstrip("\n").split("\t")
                if len(p) < 3:
                    continue
                ani = float(p[2])
                af_r = float(p[3]) if len(p) > 3 else 0.0
                af_q = float(p[4]) if len(p) > 4 else 0.0
                rows.append((p[0], p[1], ani, af_r, af_q))
    return rows


def run_skani_sample(sample, files, outdir, threads, min_len, force, reuse):
    need_exe("skani")
    list_dir = os.path.join(outdir, "skani_lists")
    skani_dir = os.path.join(outdir, "skani")
    log_dir = os.path.join(outdir, "skani_logs")
    os.makedirs(list_dir, exist_ok=True)
    os.makedirs(skani_dir, exist_ok=True)
    os.makedirs(log_dir, exist_ok=True)
    list_path = os.path.join(list_dir, sample + ".txt")
    with open(list_path, "w") as w:
        w.write("\n".join(files) + "\n")
    out_tsv = os.path.join(skani_dir, sample + ".skani.tsv")
    logf = os.path.join(log_dir, sample + ".log")
    if len(files) < 2:
        log("[skani skip] %s has only %d fasta" % (sample, len(files)))
        open(out_tsv, "w").close()
        return out_tsv
    if os.path.isfile(out_tsv) and os.path.getsize(out_tsv) > 0 and not force and reuse:
        log("[skani reuse] %s" % sample)
        return out_tsv
    if os.path.isfile(out_tsv) and os.path.getsize(out_tsv) > 0 and not force:
        log("[skani skip existing] %s  (use --force to rerun)" % sample)
        return out_tsv
    cmd = [
        "skani", "triangle", "--sparse",
        "-t", str(threads), "-m", str(min_len),
        "-l", list_path, "-o", out_tsv,
    ]
    log("CMD: " + " ".join(cmd))
    with open(logf, "w") as lf:
        r = subprocess.run(cmd, stdout=lf, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        log("WARN skani failed %s, see %s" % (sample, logf))
        open(out_tsv, "w").close()
    return out_tsv


def collect_hy_il_pairs(sample, skani_tsv):
    """Split AF_HY / AF_IL by file identity. skani AF_ref belongs to ref file, not min_AF."""
    rows = []
    seen = set()
    for a, b, ani, af_r, af_q in parse_skani_tsv(skani_tsv):
        id1, id2 = mag_id_of(a), mag_id_of(b)
        if id1 == id2:
            continue
        hy1, hy2 = is_hybrid_mag(id1), is_hybrid_mag(id2)
        if hy1 == hy2:
            continue
        if hy1:
            hy, il, af_hy, af_il = id1, id2, af_r, af_q
        else:
            hy, il, af_hy, af_il = id2, id1, af_q, af_r
        key = (hy, il)
        if key in seen:
            continue
        seen.add(key)
        rows.append({
            "sample": sample, "hybrid": hy, "mag": il,
            "ANI": "%.4f" % ani,
            "AF_HY": "%.3f" % af_hy,
            "AF_IL": "%.3f" % af_il,
            "min_AF": "%.3f" % min(af_hy, af_il),
        })
    return rows


def build_sample_host_maps(ani_rows, pair_ani, pair_af_il, hy_mq, il_mq):
    """
    Host: ANI>=pair_ani and AF_IL>=pair_af_il; owner only MQ+ hybrid.
    One MAG at most one owner (ANI priority, tie AF_IL); one hybrid may have multiple Host MAGs.
    """
    hy_mq_set = set(hy_mq)
    il_mq_set = set(il_mq)
    by_sample_cands = defaultdict(lambda: defaultdict(list))
    for r in ani_rows:
        hy = r["hybrid"]
        if hy not in hy_mq_set:
            continue
        ani = float(r["ANI"])
        af_il = float(r["AF_IL"])
        if ani >= pair_ani and af_il >= pair_af_il:
            by_sample_cands[r["sample"]][r["mag"]].append(
                (hy, ani, af_il, float(r["AF_HY"])))

    sample_hy_hosts = defaultdict(lambda: defaultdict(set))
    sample_mag_owner = defaultdict(dict)
    host_table_rows = []

    for samp, mag_dict in by_sample_cands.items():
        for mag, cands in mag_dict.items():
            cands.sort(key=lambda x: (x[1], x[2]), reverse=True)
            best_hy, best_ani, best_af, best_af_hy = cands[0]
            sample_hy_hosts[samp][best_hy].add(mag)
            sample_mag_owner[samp][mag] = best_hy
            host_table_rows.append({
                "sample": samp, "hybrid": best_hy, "mag": mag,
                "ANI": "%.4f" % best_ani,
                "AF_IL": "%.3f" % best_af,
                "AF_HY": "%.3f" % best_af_hy,
                "host_is_mq": "TRUE" if mag in il_mq_set else "FALSE",
                "n_owner_candidates": str(len(cands)),
            })

    log("Host MAG mapping: %d pairs (ANI>=%.2f, AF_IL>=%.2f, owner=MQ+ hybrid)" % (
        len(host_table_rows), pair_ani, pair_af_il))
    return sample_hy_hosts, sample_mag_owner, host_table_rows


def extract_prophages(coords, index, sample, idx, out_fa, out_meta, missing_path,
                      source_label, id_field, allowed_mags=None):
    records, meta, missing = [], [], []
    n_skip = 0
    for contig, start, end in coords:
        if sample_of_id(contig, idx) != sample:
            continue
        if contig not in index:
            missing.append((contig, start, end, "contig_not_in_fasta"))
            continue
        seq, mag, _ = index[contig]
        if allowed_mags is not None and mag not in allowed_mags:
            n_skip += 1
            continue
        s, e = start, end
        if s > e:
            s, e = e, s
        if s < 1 or e > len(seq):
            log("WARN clip %s:%d-%d to 1-%d" % (contig, start, end, len(seq)))
            s = max(1, s)
            e = min(len(seq), e)
        if e < s:
            missing.append((contig, start, end, "empty_after_clip"))
            continue
        sub = seq[s - 1:e]
        pid = "%s_%d_%d" % (contig, s, e)
        records.append((pid, sub))
        whole = "TRUE" if s <= 1 and e >= max(1, len(seq) - 1) else "FALSE"
        meta.append({
            "prophage_id": pid, "contig": contig, "start": str(s), "end": str(e),
            "length": str(len(sub)), id_field: mag, "source": source_label,
            "sample": sample,
            "whole_contig_call": whole,
            "source_contig_len": str(len(seq)),
        })
    write_fasta(out_fa, records)
    write_table(out_meta, meta)
    with open(missing_path, "w") as out:
        out.write("contig\tstart\tend\treason\n")
        for r in missing:
            out.write("%s\t%s\t%s\t%s\n" % r)
    log("extract %s %s: %d seq, %d missing, %d skipped_not_allowed" % (
        sample, source_label, len(records), len(missing), n_skip))
    return meta


def concat_mags(index, out_fa):
    recs = [("%s___%s" % (mag, cid), seq) for cid, (seq, mag, _) in index.items()]
    recs.sort(key=lambda x: x[0])
    n = write_fasta(out_fa, recs)
    nmag = len(set(v[1] for v in index.values()))
    log("concat %d MAG / %d contigs -> %s" % (nmag, n, out_fa))
    return n


def run_checkv(query_fa, outdir, db, threads, reuse):
    summary = os.path.join(outdir, "quality_summary.tsv")
    if reuse and os.path.isfile(summary):
        log("reuse CheckV " + summary)
        return summary
    if not os.path.isfile(query_fa) or os.path.getsize(query_fa) == 0:
        log("WARN skip CheckV, empty query " + query_fa)
        return ""
    need_exe("checkv")
    if not db:
        die("--checkv-db required")
    if os.path.isdir(outdir):
        shutil.rmtree(outdir)
    run_cmd(["checkv", "end_to_end", os.path.abspath(query_fa),
             os.path.abspath(outdir), "-d", db, "-t", str(threads)])
    return summary if os.path.isfile(summary) else ""


def run_makeblastdb(fa, out_prefix, reuse, parse_seqids=True):
    if reuse and os.path.isfile(out_prefix + ".nhr"):
        log("reuse blastdb " + out_prefix)
        return
    if not os.path.isfile(fa) or os.path.getsize(fa) == 0:
        log("WARN skip makeblastdb, empty " + fa)
        return
    need_exe("makeblastdb")
    cmd = ["makeblastdb", "-in", fa, "-dbtype", "nucl", "-out", out_prefix]
    if parse_seqids:
        cmd.append("-parse_seqids")
    run_cmd(cmd)


def run_blastn(query, db, out_tsv, threads, reuse):
    if reuse and os.path.isfile(out_tsv) and os.path.getsize(out_tsv) > 0:
        log("reuse BLAST " + out_tsv)
        return
    if not os.path.isfile(query) or os.path.getsize(query) == 0:
        open(out_tsv, "w").close()
        return
    need_exe("blastn")
    run_cmd([
        "blastn", "-task", "megablast",
        "-query", query, "-db", db,
        "-num_threads", str(threads),
        "-evalue", "1e-5",
        "-max_target_seqs", "1000",
        "-outfmt", "6 qseqid sseqid pident length qstart qend qlen sstart send slen bitscore",
        "-out", out_tsv,
    ])


def load_checkv(summary_tsv):
    out = {}
    if not summary_tsv or not os.path.isfile(summary_tsv):
        return out
    with open(summary_tsv) as fh:
        for row in csv.DictReader(fh, delimiter="\t"):
            out[row["contig_id"]] = row
    return out


def parse_sseqid_mag(sseqid):
    if "___" not in sseqid:
        return sseqid, sseqid
    mag, contig = sseqid.split("___", 1)
    return mag, contig


def parse_blast(blast_tsv, min_pident, key_mode="mag"):
    hits = defaultdict(list)
    qlen_blast = {}
    n_all = n_keep = 0
    if not os.path.isfile(blast_tsv) or os.path.getsize(blast_tsv) == 0:
        return hits, qlen_blast
    with open(blast_tsv) as fh:
        for line in fh:
            if not line.strip():
                continue
            n_all += 1
            p = line.rstrip("\n").split("\t")
            if len(p) < 10:
                continue
            qseqid, sseqid = p[0], p[1]
            pident = float(p[2])
            length = int(p[3])
            qstart, qend, qlen_s = int(p[4]), int(p[5]), int(float(p[6]))
            sstart, send, slen = int(p[7]), int(p[8]), int(float(p[9]))
            if pident < min_pident:
                continue
            n_keep += 1
            if key_mode == "mag":
                key = parse_sseqid_mag(sseqid)[0]
            else:
                key = sseqid
            hits[(qseqid, key)].append({
                "qstart": qstart, "qend": qend, "pident": pident, "length": length,
                "sstart": sstart, "send": send, "slen": slen, "sseqid": sseqid,
            })
            qlen_blast[qseqid] = qlen_s
    log("blast %s: %d HSP, %d pident>=%.2f" % (
        os.path.basename(blast_tsv), n_all, n_keep, min_pident))
    return hits, qlen_blast


def coverage_from_hsps(hsp_list, qlen):
    qiv = merge_intervals([(h["qstart"], h["qend"]) for h in hsp_list])
    siv = merge_intervals([(h["sstart"], h["send"]) for h in hsp_list])
    bp = covered_bp(qiv)
    cov = 100.0 * bp / qlen if qlen else 0.0
    if cov > 100.0:
        cov = 100.0
    w = sum(h["pident"] * h["length"] for h in hsp_list)
    Lsum = sum(h["length"] for h in hsp_list)
    slen = max(h["slen"] for h in hsp_list) if hsp_list else 0
    return {
        "covered_bp": bp, "cov_pct": cov, "n_hsp": len(hsp_list),
        "n_merged": len(qiv), "weighted_pident": (w / Lsum) if Lsum else 0.0,
        "q_intervals": qiv, "s_intervals": siv, "slen": slen,
    }


def union_from_stats(mag_stats, qlen):
    iv = []
    for st in mag_stats.values():
        iv.extend(st.get("q_intervals") or [])
    merged = merge_intervals(iv)
    bp = covered_bp(merged)
    cov = 100.0 * bp / qlen if qlen else 0.0
    if cov > 100.0:
        cov = 100.0
    return cov, bp, merged


def apply_floor(x):
    return 0.0 if x < NOISE_FLOOR else x


def classify_prophage_hcom2(cov_H, cov_X, union_all, is_binned, rec_full_thresh):
    if not is_binned:
        if union_all == 0:
            rec_stage, sub_cls = "Lost", "unbinned_lost"
        elif union_all < rec_full_thresh:
            rec_stage, sub_cls = "Partial", "unbinned_partial"
        else:
            rec_stage, sub_cls = "Recovered", "unbinned_recovered"
        return {
            "recovery_stage": rec_stage,
            "main_class": "Unbinned_Host",
            "sub_class": sub_cls,
            "mixed_type": "NA",
        }

    if union_all == 0 or (cov_H == 0 and cov_X == 0):
        return {
            "recovery_stage": "Lost",
            "main_class": "Lost",
            "sub_class": "lost",
            "mixed_type": "NA",
        }

    rec_stage = "Recovered" if union_all >= rec_full_thresh else "Partial"

    if cov_H > 0 and cov_X == 0:
        main_cls = "Pure_Correct"
        sub_cls = "pure_correct_recovered" if cov_H >= rec_full_thresh else "pure_correct_partial"
        mixed_type = "NA"
    elif cov_X > 0 and cov_H == 0:
        main_cls = "Pure_Incorrect"
        sub_cls = "pure_incorrect_recovered" if cov_X >= rec_full_thresh else "pure_incorrect_partial"
        mixed_type = "NA"
    else:
        main_cls = "Mixed"
        if cov_H >= rec_full_thresh and cov_X >= rec_full_thresh:
            mixed_type, sub_cls = "both_full", "mixed_both_full"
        elif cov_H >= cov_X:
            mixed_type, sub_cls = "host_major", "mixed_host_major"
        else:
            mixed_type, sub_cls = "foreign_major", "mixed_foreign_major"

    return {
        "recovery_stage": rec_stage,
        "main_class": main_cls,
        "sub_class": sub_cls,
        "mixed_type": mixed_type,
    }


def require_checkv_if_filtered(checkv, meta, checkv_filter, tag):
    if checkv_filter != "all" and meta and not checkv:
        die("%s has no CheckV result but --checkv-filter=%s; remove --skip-checkv or use --checkv-filter all"
            % (tag, checkv_filter))


def assign_hy2il_sample(sample, meta, host_mags, blast_tsv, checkv_tsv,
                        out_cov, out_assign, args):
    checkv = load_checkv(checkv_tsv)
    require_checkv_if_filtered(checkv, meta, args.checkv_filter, "%s hy2il" % sample)
    hits, qlen_blast = parse_blast(blast_tsv, args.min_pident, key_mode="mag")
    meta_by_id = {m["prophage_id"]: m for m in meta}

    query_hits = defaultdict(dict)
    cov_rows = []
    for (qid, mag), hsps in hits.items():
        ql = qlen_blast.get(qid) or int(meta_by_id.get(qid, {}).get("length") or 0)
        if not ql:
            continue
        st = coverage_from_hsps(hsps, ql)
        query_hits[qid][mag] = st
        cov_rows.append({
            "sample": sample, "prophage_id": qid, "mag": mag,
            "covered_bp": str(st["covered_bp"]),
            "cov_pct": "%.3f" % st["cov_pct"],
            "n_hsp": str(st["n_hsp"]),
            "weighted_pident": "%.3f" % st["weighted_pident"],
            "q_intervals": fmt_iv(st["q_intervals"]),
        })
    cov_rows.sort(key=lambda r: (r["prophage_id"], -float(r["cov_pct"])))
    write_table(out_cov, cov_rows)

    out_rows = []
    mag_qiv = {}
    counts = defaultdict(int)

    for m in meta:
        qid = m["prophage_id"]
        hy = m["source_hybrid"]
        qlen = int(m["length"])
        cv = checkv.get(qid, {})
        cv_row = dict(cv)
        cv_row["length"] = m["length"]
        if not filter_checkv_record(cv_row, args.checkv_filter):
            continue

        hosts = host_mags.get(hy, set())
        is_binned = len(hosts) > 0
        stats = query_hits.get(qid, {})
        host_stats = {mag: st for mag, st in stats.items() if mag in hosts}
        foreign_stats = {mag: st for mag, st in stats.items() if mag not in hosts}

        raw_H, bp_H, iv_H = union_from_stats(host_stats, qlen)
        raw_union_all, bp_all, iv_all = union_from_stats(stats, qlen)
        mag_qiv[qid] = iv_all

        max_X_mag, raw_X = "", 0.0
        for mag, st in foreign_stats.items():
            if st["cov_pct"] > raw_X:
                raw_X = st["cov_pct"]
                max_X_mag = mag

        cov_H = apply_floor(raw_H)
        cov_X = apply_floor(raw_X)
        union_all = apply_floor(raw_union_all)

        h_hit = ["%s:%.1f" % (mg, st["cov_pct"]) for mg, st in host_stats.items()
                 if st["cov_pct"] >= NOISE_FLOOR]
        f_hit = ["%s:%.1f" % (mg, st["cov_pct"]) for mg, st in foreign_stats.items()
                 if st["cov_pct"] >= NOISE_FLOOR]

        cls = classify_prophage_hcom2(cov_H, cov_X, union_all, is_binned, args.rec_full)
        counts[cls["main_class"]] += 1

        row = {
            "sample": sample, "direction": "hy2il", "prophage_id": qid,
            "source_hybrid": hy, "contig": m["contig"],
            "start": m["start"], "end": m["end"], "length": m["length"],
            "hy_status": "binned" if is_binned else "unbinned",
            "n_host_mags_defined": str(len(hosts)),
            "host_mags_defined": ";".join(sorted(hosts)),
            "cov_H_pct": "%.3f" % cov_H,
            "cov_X_pct": "%.3f" % cov_X,
            "max_foreign_mag": max_X_mag,
            "union_all_pct": "%.3f" % union_all,
            "recovery_stage": cls["recovery_stage"],
            "main_class": cls["main_class"],
            "sub_class": cls["sub_class"],
            "mixed_type": cls["mixed_type"],
            "n_host_bins_hit": str(len(h_hit)),
            "n_foreign_bins_hit": str(len(f_hit)),
            "n_total_bins_hit": str(len(h_hit) + len(f_hit)),
            "host_bins_detail": ";".join(h_hit),
            "foreign_bins_detail": ";".join(f_hit),
            "q_intervals_all": fmt_iv(iv_all),
        }
        for c in CV_COLS:
            row[c] = cv.get(c, "")
        out_rows.append(row)

    write_table(out_assign, out_rows)
    log("[%s hy2il] total=%d binned_hy=%d classes=%s" % (
        sample, len(out_rows),
        sum(1 for r in out_rows if r["hy_status"] == "binned"), dict(counts)))
    return out_rows, mag_qiv


def assign_il2hy_sample(sample, meta, mag_owners, blast_tsv, checkv_tsv,
                        out_cov, out_assign, args):
    checkv = load_checkv(checkv_tsv)
    require_checkv_if_filtered(checkv, meta, args.checkv_filter, "%s il2hy" % sample)
    hits, qlen_blast = parse_blast(blast_tsv, args.min_pident, key_mode="mag")
    meta_by_id = {m["prophage_id"]: m for m in meta}

    query_hits = defaultdict(dict)
    cov_rows = []
    for (qid, hy), hsps in hits.items():
        ql = qlen_blast.get(qid) or int(meta_by_id.get(qid, {}).get("length") or 0)
        if not ql:
            continue
        st = coverage_from_hsps(hsps, ql)
        query_hits[qid][hy] = st
        cov_rows.append({
            "sample": sample, "prophage_id": qid, "hybrid": hy,
            "covered_bp": str(st["covered_bp"]),
            "cov_pct": "%.3f" % st["cov_pct"],
            "n_hsp": str(st["n_hsp"]),
            "weighted_pident": "%.3f" % st["weighted_pident"],
        })
    cov_rows.sort(key=lambda r: (r["prophage_id"], -float(r.get("cov_pct") or 0)))
    write_table(out_cov, cov_rows)

    out_rows = []
    counts = defaultdict(int)
    for m in meta:
        qid = m["prophage_id"]
        mag = m["source_mag"]
        qlen = int(m["length"])
        cv = checkv.get(qid, {})
        cv_row = dict(cv)
        cv_row["length"] = m["length"]
        if not filter_checkv_record(cv_row, args.checkv_filter):
            continue

        owner = mag_owners.get(mag, "")
        is_binned = bool(owner)
        stats = query_hits.get(qid, {})
        host_stats = {hy: st for hy, st in stats.items() if hy == owner} if owner else {}
        foreign_stats = {hy: st for hy, st in stats.items() if hy != owner}

        raw_H, bp_H, iv_H = union_from_stats(host_stats, qlen)
        raw_union_all, bp_all, iv_all = union_from_stats(stats, qlen)

        max_X_hy, raw_X = "", 0.0
        for hy, st in foreign_stats.items():
            if st["cov_pct"] > raw_X:
                raw_X = st["cov_pct"]
                max_X_hy = hy

        cov_H = apply_floor(raw_H)
        cov_X = apply_floor(raw_X)
        union_all = apply_floor(raw_union_all)

        cls = classify_prophage_hcom2(cov_H, cov_X, union_all, is_binned, args.rec_full)
        counts[cls["main_class"]] += 1

        row = {
            "sample": sample, "direction": "il2hy", "prophage_id": qid,
            "source_mag": mag,
            "assigned_owner_hybrid": owner,
            "has_owner": "TRUE" if owner else "FALSE",
            "mag_status": "binned" if is_binned else "unbinned",
            "contig": m["contig"], "start": m["start"], "end": m["end"],
            "length": m["length"],
            "cov_H_pct": "%.3f" % cov_H,
            "cov_X_pct": "%.3f" % cov_X,
            "max_foreign_hybrid": max_X_hy,
            "union_all_pct": "%.3f" % union_all,
            "recovery_stage": cls["recovery_stage"],
            "main_class": cls["main_class"],
            "sub_class": cls["sub_class"],
            "mixed_type": cls["mixed_type"],
            "q_intervals_all": fmt_iv(iv_all),
        }
        for c in CV_COLS:
            row[c] = cv.get(c, "")
        out_rows.append(row)

    write_table(out_assign, out_rows)
    log("[%s il2hy] total=%d binned_mag=%d classes=%s" % (
        sample, len(out_rows),
        sum(1 for r in out_rows if r["mag_status"] == "binned"), dict(counts)))
    return out_rows


def assign_asm_sample(sample, meta, mag_rows, mag_qiv, blast_tsv, cmap,
                      out_cov, out_assign, args):
    hits, qlen_blast = parse_blast(blast_tsv, args.min_pident, key_mode="contig")
    meta_by = {m["prophage_id"]: m for m in meta}
    mag_by = {r["prophage_id"]: r for r in mag_rows}
    query_ctg = defaultdict(dict)
    cov_rows = []

    for (qid, contig), hsps in hits.items():
        ql = qlen_blast.get(qid) or int(meta_by.get(qid, {}).get("length", 0))
        if not ql:
            continue
        st = coverage_from_hsps(hsps, ql)
        query_ctg[qid][contig] = st
        in_bin = contig in cmap["asm_to_mag"]
        cov_rows.append({
            "sample": sample, "prophage_id": qid, "contig": contig,
            "in_bin": "TRUE" if in_bin else "FALSE",
            "subject_mag": cmap["asm_to_mag"].get(contig, ""),
            "covered_bp": str(st["covered_bp"]),
            "cov_pct": "%.3f" % st["cov_pct"],
            "n_hsp": str(st["n_hsp"]),
            "slen": str(st["slen"]),
            "q_intervals": fmt_iv(st["q_intervals"]),
            "s_intervals": fmt_iv(st["s_intervals"]),
        })
    cov_rows.sort(key=lambda r: (r["prophage_id"], -float(r["cov_pct"])))
    write_table(out_cov, cov_rows)

    out_rows = []
    n_lt = 0
    for m in meta:
        qid = m["prophage_id"]
        if qid not in mag_by:
            continue
        qlen = int(m["length"])
        mag_row = mag_by[qid]
        stats = query_ctg.get(qid, {})

        binned, unbinned = {}, {}
        for ctg, st in stats.items():
            if ctg in cmap["asm_to_mag"]:
                binned[ctg] = st
            else:
                unbinned[ctg] = st

        asm_cov, asm_bp, asm_iv = union_from_stats(stats, qlen)
        b_cov, b_bp, b_iv = union_from_stats(binned, qlen)
        u_cov, u_bp, u_iv = union_from_stats(unbinned, qlen)

        asm_cov_f = apply_floor(asm_cov)
        u_cov_f = apply_floor(u_cov)
        b_cov_f = apply_floor(b_cov)

        if u_cov_f >= args.rec_full:
            asm_fate = "unbinned_rescue"
        elif asm_cov_f == 0:
            asm_fate = "not_assembled"
        elif asm_cov_f < args.rec_full:
            asm_fate = "asm_partial"
        else:
            asm_fate = "in_binned_contigs" if b_cov_f >= args.rec_full else "split_binned_unbinned"

        flags = []
        try:
            mag_cov = float(mag_row.get("union_all_pct") or 0)
        except ValueError:
            mag_cov = 0.0
        if mag_cov > asm_cov_f + 1.0:
            flags.append("ASM_LT_MAG")
            n_lt += 1

        out_rows.append({
            "sample": sample, "prophage_id": qid,
            "source_hybrid": mag_row.get("source_hybrid", ""),
            "length": m["length"],
            "hy_status": mag_row.get("hy_status", ""),
            "main_class_mag": mag_row.get("main_class", ""),
            "sub_class_mag": mag_row.get("sub_class", ""),
            "recovery_mag": mag_row.get("recovery_stage", ""),
            "asm_fate": asm_fate,
            "asm_union_cov_pct": "%.3f" % asm_cov_f,
            "binned_contig_cov_pct": "%.3f" % b_cov_f,
            "unbinned_contig_cov_pct": "%.3f" % u_cov_f,
            "n_asm_contigs_hit": str(len(stats)),
            "n_unbinned_contigs_hit": str(len(unbinned)),
            "qc_flag": ",".join(flags),
            "asm_q_intervals": fmt_iv(asm_iv),
            "unbinned_q_intervals": fmt_iv(u_iv),
        })

    write_table(out_assign, out_rows)
    log("[%s L2] annotated=%d ASM_LT_MAG=%d" % (sample, len(out_rows), n_lt))
    return out_rows, cov_rows


def assign_tool(sample, asm_cov_rows, asm_assign, preds, contig_len, out_detail,
                out_assign, t_overlap):
    pred_by = defaultdict(list)
    for contig, s, e in preds:
        pred_by[contig].append((s, e))
    by_q = defaultdict(list)
    for r in asm_cov_rows:
        by_q[r["prophage_id"]].append(r)
    details = []
    summaries = []
    for row in asm_assign:
        qid = row["prophage_id"]
        hits = by_q.get(qid, [])
        u_true = u_ov = b_true = b_ov = 0
        n_u = n_u_rec = n_b = n_b_rec = 0
        n_u_whole = 0
        for h in hits:
            contig = h["contig"]
            siv = parse_iv(h.get("s_intervals", ""))
            true_bp = covered_bp(siv)
            if true_bp <= 0:
                continue
            piv = merge_intervals(pred_by.get(contig, []))
            ov = intersect_bp(siv, piv)
            slen = int(float(h.get("slen") or 0)) or contig_len.get(contig, 0)
            whole = False
            for s, e in piv:
                if slen and s <= 1 and e >= max(1, slen - 1):
                    whole = True
                    break
            rec = 100.0 * ov / true_bp if true_bp else 0.0
            recalled = rec >= t_overlap
            in_bin = h["in_bin"] == "TRUE"
            details.append({
                "sample": sample, "prophage_id": qid, "contig": contig,
                "in_bin": h["in_bin"], "subject_mag": h.get("subject_mag", ""),
                "true_s_bp": str(true_bp), "pred_overlap_bp": str(ov),
                "recall_pct": "%.3f" % rec,
                "recalled": "TRUE" if recalled else "FALSE",
                "n_pred_on_contig": str(len(pred_by.get(contig, []))),
                "whole_contig_call": "TRUE" if whole else "FALSE",
                "slen": str(slen),
                "true_s_intervals": h.get("s_intervals", ""),
                "pred_intervals": fmt_iv(piv),
            })
            if in_bin:
                n_b += 1
                b_true += true_bp
                b_ov += ov
                n_b_rec += int(recalled)
            else:
                n_u += 1
                u_true += true_bp
                u_ov += ov
                n_u_rec += int(recalled)
                n_u_whole += int(whole)
        summaries.append({
            "sample": sample, "prophage_id": qid,
            "source_hybrid": row.get("source_hybrid", ""),
            "hy_status": row.get("hy_status", ""),
            "main_class": row.get("main_class_mag", ""),
            "asm_fate": row.get("asm_fate", ""),
            "n_unbinned_contig_hit": str(n_u),
            "n_unbinned_recalled": str(n_u_rec),
            "unbinned_true_bp": str(u_true),
            "unbinned_pred_overlap_bp": str(u_ov),
            "unbinned_recall_pct": pct(u_ov, u_true),
            "unbinned_any_recall": "TRUE" if n_u_rec else "FALSE",
            "unbinned_whole_contig_calls": str(n_u_whole),
            "n_binned_contig_hit": str(n_b),
            "n_binned_recalled": str(n_b_rec),
            "binned_true_bp": str(b_true),
            "binned_pred_overlap_bp": str(b_ov),
            "binned_recall_pct": pct(b_ov, b_true),
            "note": "overlap_with_contig_prediction_only; pred_overlap_not_prophage_label",
        })
    write_table(out_detail, details)
    write_table(out_assign, summaries)
    log("[%s L3] detail=%d queries=%d" % (sample, len(details), len(summaries)))
    return summaries


def _l1_block(sample, srows, status_key, binned_val):
    binned = [r for r in srows if r.get(status_key) == binned_val]
    unbinned = [r for r in srows if r.get(status_key) != binned_val]
    D = len(binned)
    n_lost = sum(1 for r in binned if r["main_class"] == "Lost")
    n_part = sum(1 for r in binned if r["recovery_stage"] == "Partial")
    n_rec = sum(1 for r in binned if r["recovery_stage"] == "Recovered")
    n_pure_corr = sum(1 for r in binned if r["main_class"] == "Pure_Correct")
    n_pure_inc = sum(1 for r in binned if r["main_class"] == "Pure_Incorrect")
    n_mixed = sum(1 for r in binned if r["main_class"] == "Mixed")
    n_mix_host = sum(1 for r in binned if r["sub_class"] == "mixed_host_major")
    n_mix_foreign = sum(1 for r in binned if r["sub_class"] == "mixed_foreign_major")
    n_mix_both = sum(1 for r in binned if r["sub_class"] == "mixed_both_full")
    return {
        "sample": sample,
        "n_total_queries": str(len(srows)),
        "n_unbinned_queries": str(len(unbinned)),
        "n_binned_queries_D": str(D),
        "n_lost": str(n_lost),
        "pct_lost": pct(n_lost, D),
        "n_partial": str(n_part),
        "pct_partial": pct(n_part, D),
        "n_recovered": str(n_rec),
        "pct_recovered": pct(n_rec, D),
        "n_pure_correct": str(n_pure_corr),
        "pct_pure_correct": pct(n_pure_corr, D),
        "n_pure_incorrect": str(n_pure_inc),
        "pct_pure_incorrect": pct(n_pure_inc, D),
        "n_mixed": str(n_mixed),
        "pct_mixed": pct(n_mixed, D),
        "n_mixed_host_major": str(n_mix_host),
        "n_mixed_foreign_major": str(n_mix_foreign),
        "n_mixed_both_full": str(n_mix_both),
        "correct_placement_rate": pct(n_pure_corr + n_mix_host, D),
        "incorrect_placement_rate": pct(n_pure_inc + n_mix_foreign, D),
    }


def make_l1_summary(rows, out_tsv, status_key, binned_val):
    recs = []
    by_sample = defaultdict(list)
    for r in rows:
        by_sample[r["sample"]].append(r)
    for sample, srows in sorted(by_sample.items()):
        recs.append(_l1_block(sample, srows, status_key, binned_val))
    write_table(out_tsv, recs)
    log("L1 summary -> " + out_tsv)


def make_l2_summary(asm_rows, out_tsv):
    recs = []
    by_sample = defaultdict(list)
    for r in asm_rows:
        by_sample[r["sample"]].append(r)
    for sample, rows in sorted(by_sample.items()):
        lost_rows = [r for r in rows if r.get("main_class_mag") == "Lost"]
        n_lost = len(lost_rows)
        n_rescue = sum(1 for r in lost_rows if r["asm_fate"] == "unbinned_rescue")
        n_not_asm = sum(1 for r in lost_rows if r["asm_fate"] == "not_assembled")
        n_asm_part = sum(1 for r in lost_rows if r["asm_fate"] == "asm_partial")
        recs.append({
            "sample": sample,
            "n_total_annotated": str(len(rows)),
            "n_lost_in_mag": str(n_lost),
            "n_lost_unbinned_rescue": str(n_rescue),
            "pct_lost_unbinned_rescue": pct(n_rescue, n_lost),
            "n_lost_not_assembled": str(n_not_asm),
            "pct_lost_not_assembled": pct(n_not_asm, n_lost),
            "n_lost_asm_partial": str(n_asm_part),
            "pct_lost_asm_partial": pct(n_asm_part, n_lost),
            "n_ASM_LT_MAG": str(sum(1 for r in rows if "ASM_LT_MAG" in (r.get("qc_flag") or ""))),
        })
    write_table(out_tsv, recs)
    log("L2 summary -> " + out_tsv)


def _append_l1_metrics(rows_out, prefix, l1_rows, status_key, binned_val):
    binned = [r for r in l1_rows if r.get(status_key) == binned_val]
    D = len(binned)
    n_pure_corr = sum(1 for r in binned if r["main_class"] == "Pure_Correct")
    n_pure_inc = sum(1 for r in binned if r["main_class"] == "Pure_Incorrect")
    n_mix = sum(1 for r in binned if r["main_class"] == "Mixed")
    n_mix_host = sum(1 for r in binned if r["sub_class"] == "mixed_host_major")
    n_mix_foreign = sum(1 for r in binned if r["sub_class"] == "mixed_foreign_major")
    n_mix_both = sum(1 for r in binned if r["sub_class"] == "mixed_both_full")
    n_lost = sum(1 for r in binned if r["main_class"] == "Lost")
    n_unb = sum(1 for r in l1_rows if r.get(status_key) != binned_val)

    def add(block, total, count, desc):
        rows_out.append({
            "metric_block": block, "total": str(total), "count": str(count),
            "percentage": pct(count, total), "description": desc,
        })

    add(prefix + "binned_queries_D", D, D,
        "passes CheckV gate and source genome has Host/owner")
    add(prefix + "pure_correct", D, n_pure_corr, "hits Host only")
    add(prefix + "pure_incorrect", D, n_pure_inc, "hits Foreign only")
    add(prefix + "mixed", D, n_mix, "hits both Host and Foreign")
    add(prefix + "mixed_host_major", D, n_mix_host, "Mixed host_major")
    add(prefix + "mixed_foreign_major", D, n_mix_foreign, "Mixed foreign_major")
    add(prefix + "mixed_both_full", D, n_mix_both, "Mixed both_full")
    add(prefix + "overall_correct_rate", D, n_pure_corr + n_mix_host,
        "Pure_Correct + Mixed host_major")
    add(prefix + "overall_incorrect_rate", D, n_pure_inc + n_mix_foreign,
        "Pure_Incorrect + Mixed foreign_major")
    add(prefix + "lost_in_mag", D, n_lost,
        "has Host/owner, MAG coverage after noise floor is 0")
    add(prefix + "unbinned_host", len(l1_rows), n_unb,
        "passing queries whose source genome has no Host/owner (denominator = all passing queries)")


def make_main_numbers(l1_hy, l1_il, l2_rows, l3_rows, out_tsv):
    rows = []
    _append_l1_metrics(rows, "L1_", l1_hy, "hy_status", "binned")
    _append_l1_metrics(rows, "L1rev_", l1_il, "mag_status", "binned")

    if l2_rows:
        lost_l2 = [r for r in l2_rows if r.get("main_class_mag") == "Lost"]
        n_l = len(lost_l2)
        n_resc = sum(1 for r in lost_l2 if r.get("asm_fate") == "unbinned_rescue")
        n_noasm = sum(1 for r in lost_l2 if r.get("asm_fate") == "not_assembled")
        n_part = sum(1 for r in lost_l2 if r.get("asm_fate") == "asm_partial")
        rows.append({
            "metric_block": "L2_lost_unbinned_rescue", "total": str(n_l),
            "count": str(n_resc), "percentage": pct(n_resc, n_l),
            "description": "L1 Lost but unbinned contig union >= rec_full",
        })
        rows.append({
            "metric_block": "L2_lost_not_assembled", "total": str(n_l),
            "count": str(n_noasm), "percentage": pct(n_noasm, n_l),
            "description": "L1 Lost and assembly coverage after noise floor is 0",
        })
        rows.append({
            "metric_block": "L2_lost_asm_partial", "total": str(n_l),
            "count": str(n_part), "percentage": pct(n_part, n_l),
            "description": "L1 Lost and assembly has coverage but < rec_full",
        })

        l3_by = {(r["sample"], r["prophage_id"]): r for r in l3_rows}
        rescue = [r for r in lost_l2 if r.get("asm_fate") == "unbinned_rescue"]
        n_hit = n_ov = 0
        for r in rescue:
            t = l3_by.get((r["sample"], r["prophage_id"]), {})
            try:
                nh = int(float(t.get("n_unbinned_contig_hit") or 0))
            except ValueError:
                nh = 0
            if nh:
                n_hit += 1
                if t.get("unbinned_any_recall") == "TRUE":
                    n_ov += 1
        rows.append({
            "metric_block": "L3_lost_rescue_unbinned_pred_overlap",
            "total": str(n_hit), "count": str(n_ov),
            "percentage": pct(n_ov, n_hit),
            "description": "among Lost∩unbinned_rescue with unbinned contig hit, "
                           "contig prediction overlap>=t_overlap; pred_overlap_not_prophage_label",
        })

    write_table(out_tsv, rows)
    log("Main numbers -> " + out_tsv)


def write_mq_tables(hy_cm, il_cm, hy_mq, il_mq, outdir):
    hy_set, il_set = set(hy_mq), set(il_mq)
    hy_rows = [{"mag": k, "completeness": "%.2f" % v["completeness"],
                "contamination": "%.2f" % v["contamination"],
                "mq": "TRUE" if k in hy_set else "FALSE"}
               for k, v in sorted(hy_cm.items())]
    il_rows = [{"mag": k, "completeness": "%.2f" % v["completeness"],
                "contamination": "%.2f" % v["contamination"],
                "mq": "TRUE" if k in il_set else "FALSE"}
               for k, v in sorted(il_cm.items())]
    write_table(os.path.join(outdir, "mq_hybrid_bins.tsv"), hy_rows)
    write_table(os.path.join(outdir, "mq_illumina_bins.tsv"), il_rows)
    with open(os.path.join(outdir, "hy_qualified_ids.txt"), "w") as w:
        w.write("\n".join(hy_mq) + ("\n" if hy_mq else ""))
    with open(os.path.join(outdir, "illu_qualified_ids.txt"), "w") as w:
        w.write("\n".join(il_mq) + ("\n" if il_mq else ""))
    log("MQ+ hybrid=%d / %d   illumina=%d / %d" % (
        len(hy_mq), len(hy_cm), len(il_mq), len(il_cm)))


def prep_all(args, idx, groups, hy_cm, il_cm, hy_mq, il_mq):
    os.makedirs(args.out_dir, exist_ok=True)
    write_table(os.path.join(args.out_dir, "sample_map.tsv"), idx["rows"])
    write_mq_tables(hy_cm, il_cm, hy_mq, il_mq, args.out_dir)
    rename_recs = parse_rename_csv(args.il_rename, idx)
    maps = {}
    all_c2b, all_ub = [], []
    for sample, g in groups.items():
        sdir = os.path.join(args.out_dir, "by_sample", sample)
        os.makedirs(sdir, exist_ok=True)
        if not g["il"]:
            log("WARN skip contig map %s: no IL MAG" % sample)
            continue
        asm = assembly_path(args.il_contig_dir, g["err"])
        cmap = build_contig_maps(sample, g["err"], g["il"], asm, rename_recs, sdir)
        maps[sample] = cmap
        p1 = os.path.join(sdir, "contig_to_bin.%s.tsv" % sample)
        p2 = os.path.join(sdir, "unbinned_contigs.%s.tsv" % sample)
        if os.path.isfile(p1):
            with open(p1) as fh:
                all_c2b.extend(csv.DictReader(fh, delimiter="\t"))
        if os.path.isfile(p2):
            with open(p2) as fh:
                all_ub.extend(csv.DictReader(fh, delimiter="\t"))
    write_table(os.path.join(args.out_dir, "contig_to_bin.tsv"), all_c2b)
    write_table(os.path.join(args.out_dir, "unbinned_contigs.tsv"), all_ub)
    return maps


def read_meta(path):
    if not os.path.isfile(path) or os.path.getsize(path) == 0:
        return []
    with open(path) as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def track_sample(sample, g, idx, hy_coords, il_coords, ilc_coords,
                 hy_hosts, mag_owners, hy_mq, il_mq, cmap, args):
    sdir = os.path.join(args.out_dir, "by_sample", sample)
    os.makedirs(sdir, exist_ok=True)
    hy_idx = load_mag_index(g["hy"])
    il_idx = load_mag_index(g["il"])
    log("%s MAG: hybrid=%d illumina=%d" % (
        sample,
        len(set(v[1] for v in hy_idx.values())),
        len(set(v[1] for v in il_idx.values()))))

    hy_fa = os.path.join(sdir, "01_hy_prophages.fna")
    il_fa = os.path.join(sdir, "01_il_prophages.fna")
    hy_meta = extract_prophages(
        hy_coords, hy_idx, sample, idx, hy_fa,
        os.path.join(sdir, "01_hy_prophage_meta.tsv"),
        os.path.join(sdir, "01_hy_missing.tsv"),
        "hybrid", "source_hybrid", allowed_mags=set(hy_mq))
    il_meta = extract_prophages(
        il_coords, il_idx, sample, idx, il_fa,
        os.path.join(sdir, "01_il_prophage_meta.tsv"),
        os.path.join(sdir, "01_il_missing.tsv"),
        "illumina", "source_mag", allowed_mags=set(il_mq))

    hy_cv = il_cv = ""
    if not args.skip_checkv:
        if hy_meta:
            hy_cv = run_checkv(hy_fa, os.path.join(sdir, "02_checkv_hy"),
                               args.checkv_db, args.threads, args.reuse)
        if il_meta:
            il_cv = run_checkv(il_fa, os.path.join(sdir, "02_checkv_il"),
                               args.checkv_db, args.threads, args.reuse)
    else:
        hy_cv = os.path.join(sdir, "02_checkv_hy", "quality_summary.tsv")
        il_cv = os.path.join(sdir, "02_checkv_il", "quality_summary.tsv")

    hy_meta = read_meta(os.path.join(sdir, "01_hy_prophage_meta.tsv"))
    il_meta = read_meta(os.path.join(sdir, "01_il_prophage_meta.tsv"))

    out = {"hy2il": [], "il2hy": [], "l2": [], "l3": []}
    mag_qiv = {}
    l2_cov = []

    if hy_meta and il_idx:
        concat_mags(il_idx, os.path.join(sdir, "03_il_mags.fna"))
        run_makeblastdb(os.path.join(sdir, "03_il_mags.fna"),
                        os.path.join(sdir, "03_il_mags"), args.reuse, True)
        blast_hy2il = os.path.join(sdir, "04_blast_hy2il.tsv")
        run_blastn(hy_fa, os.path.join(sdir, "03_il_mags"), blast_hy2il,
                   args.threads, args.reuse)
        out["hy2il"], mag_qiv = assign_hy2il_sample(
            sample, hy_meta, hy_hosts, blast_hy2il, hy_cv,
            os.path.join(sdir, "05_cov_hy2il.tsv"),
            os.path.join(sdir, "06_assign_hy2il.tsv"), args)

    if hy_meta:
        if not cmap:
            die("%s has no contig map, run --only prep first" % sample)
        asm = assembly_path(args.il_contig_dir, g["err"])
        run_makeblastdb(asm, os.path.join(sdir, "03_il_contigs"), args.reuse, False)
        blast_asm = os.path.join(sdir, "04_blast_hy2asm.tsv")
        run_blastn(hy_fa, os.path.join(sdir, "03_il_contigs"), blast_asm,
                   args.threads, args.reuse)
        out["l2"], l2_cov = assign_asm_sample(
            sample, hy_meta, out["hy2il"], mag_qiv, blast_asm, cmap,
            os.path.join(sdir, "08_asm_cov_hy2il.tsv"),
            os.path.join(sdir, "08_asm_assign_hy2il.tsv"), args)

        preds = [(c, s, e) for c, s, e in ilc_coords if sample_of_id(c, idx) == sample]
        out["l3"] = assign_tool(
            sample, l2_cov, out["l2"], preds, cmap.get("asm_len") or {},
            os.path.join(sdir, "09_tool_overlap_hy2il.tsv"),
            os.path.join(sdir, "09_tool_assign_hy2il.tsv"),
            args.t_overlap)

    if il_meta and hy_idx:
        concat_mags(hy_idx, os.path.join(sdir, "03_hy_mags.fna"))
        run_makeblastdb(os.path.join(sdir, "03_hy_mags.fna"),
                        os.path.join(sdir, "03_hy_mags"), args.reuse, True)
        blast_il2hy = os.path.join(sdir, "04_blast_il2hy.tsv")
        run_blastn(il_fa, os.path.join(sdir, "03_hy_mags"), blast_il2hy,
                   args.threads, args.reuse)
        out["il2hy"] = assign_il2hy_sample(
            sample, il_meta, mag_owners, blast_il2hy, il_cv,
            os.path.join(sdir, "05_cov_il2hy.tsv"),
            os.path.join(sdir, "06_assign_il2hy.tsv"), args)
    return out


def resolve_ami_paths(args):
    ami = os.path.abspath(args.ami or os.path.dirname(os.path.abspath(__file__)))
    args.ami = ami

    def fill(cur, default_rel):
        return os.path.abspath(cur) if cur else os.path.join(ami, default_rel)

    args.index = fill(args.index, "short-long.index.tsv")
    args.hy_bin_dir = fill(args.hy_bin_dir, "hy_bins")
    args.il_bin_dir = fill(args.il_bin_dir, "illumina_bin")
    args.il_contig_dir = fill(args.il_contig_dir, "illumina_contig")
    args.hy_coords = fill(args.hy_coords, "prophage_hybin/coordinate/prophage_coordinates.tsv")
    args.il_coords = fill(args.il_coords, "prophage_illubin/coordinate/prophage_coordinates.tsv")
    args.il_contig_coords = fill(
        args.il_contig_coords, "prophage_illucontig/coordinate/prophage_coordinates.tsv")
    args.hy_checkm = fill(args.hy_checkm, "hy_bins/checkm2_summary.tsv")
    args.il_checkm = fill(args.il_checkm, "illumina_bin/checkm2_summary.tsv")
    args.il_rename = fill(args.il_rename, "illumina_bin/contig_rename_index.csv")
    if not args.checkv_db:
        args.checkv_db = CHECKV_DB_DEFAULT
    args.out_dir = os.path.abspath(
        args.out_dir or os.path.join(ami, "prophage_track_ami_hcom2"))
    return args


def check_inputs(args):
    required = [
        args.index, args.hy_bin_dir, args.il_bin_dir, args.il_contig_dir,
        args.hy_coords, args.il_coords, args.il_contig_coords,
        args.hy_checkm, args.il_checkm,
    ]
    for p in required:
        if not os.path.exists(p):
            die("does not exist: %s" % p)
    if not os.path.isfile(args.il_rename):
        log("WARN: no rename table %s, will use heuristic filenames + sequence hash" % args.il_rename)
    if (not args.skip_checkv) and (not os.path.isdir(args.checkv_db)):
        die("CheckV DB not found: %s" % args.checkv_db)


def main():
    ap = argparse.ArgumentParser(
        description="AMI hybrid-truth Host/Foreign prophage tracking (single-entry, no layers)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--ami", default="", help="AMI root dir, default = script directory")
    ap.add_argument("--index", default="")
    ap.add_argument("--hy-bin-dir", default="")
    ap.add_argument("--il-bin-dir", default="")
    ap.add_argument("--il-contig-dir", default="")
    ap.add_argument("--hy-coords", default="")
    ap.add_argument("--il-coords", default="")
    ap.add_argument("--il-contig-coords", default="")
    ap.add_argument("--hy-checkm", default="")
    ap.add_argument("--il-checkm", default="")
    ap.add_argument("--il-rename", default="")
    ap.add_argument("-o", "--out-dir", default="")
    ap.add_argument("-t", "--threads", type=int, default=int(os.environ.get("THREADS", "20")))
    ap.add_argument("--sample", default="", help="run only one Dxx or ERR")
    ap.add_argument("--checkv-db", default="")
    ap.add_argument("--checkv-filter", choices=["viral_gene", "all", "mq_5k"],
                    default="viral_gene",
                    help="pre-classification gate: viral_gene (viral_genes>=1), all, mq_5k")
    ap.add_argument("--min-completeness", type=float, default=50.0)
    ap.add_argument("--max-contamination", type=float, default=5.0)
    ap.add_argument("--min-len", type=int, default=10000, help="skani -m")
    ap.add_argument("--pair-ani", type=float, default=99.0)
    ap.add_argument("--pair-af-il", type=float, default=95.0,
                    help="Host definition: AF of Illumina MAG covered by hybrid")
    ap.add_argument("--min-pident", type=float, default=99.0)
    ap.add_argument("--rec-full", type=float, default=75.0)
    ap.add_argument("--t-overlap", type=float, default=75.0,
                    help="L3 recall threshold: predicted interval vs true subject overlap")
    ap.add_argument("--only", choices=["all", "prep", "skani"], default="all")
    ap.add_argument("--skip-checkv", action="store_true")
    ap.add_argument("--reuse", action="store_true")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    args = resolve_ami_paths(args)
    os.makedirs(args.out_dir, exist_ok=True)
    os.makedirs(os.path.join(args.out_dir, "logs"), exist_ok=True)
    log_path = os.path.join(
        args.out_dir, "logs",
        "run.%s.%s.log" % (args.only, datetime.now().strftime("%Y%m%d_%H%M%S")))
    log_fh = open(log_path, "w")
    sys.stdout = TeeIO(sys.__stdout__, log_fh)
    sys.stderr = TeeIO(sys.__stderr__, log_fh)

    if args.force:
        args.reuse = False

    log("AMI root: %s" % args.ami)
    log("out:      %s" % args.out_dir)
    log("only=%s checkv_filter=%s rec_full=%.1f t_overlap=%.1f pair_af_il=%.1f"
        % (args.only, args.checkv_filter, args.rec_full, args.t_overlap, args.pair_af_il))
    check_inputs(args)
    check_deps(args.out_dir, args.skip_checkv)

    idx = load_sample_index(args.index)
    if args.sample:
        key = args.sample.strip()
        if key.upper() in idx["err_to_sample"]:
            key = idx["err_to_sample"][key.upper()]
        else:
            m = DXX_RE.search(key.upper())
            key = m.group(1).upper() if m else key.upper()
        if key not in idx["sample_to_err"]:
            die("unknown sample: %s  (options %s)" % (args.sample, ",".join(idx["samples"])))
        idx["samples"] = [key]
        idx["rows"] = [r for r in idx["rows"] if r["sample"] == key]
        log("limiting to sample: " + key)

    groups = discover_bins(args.hy_bin_dir, args.il_bin_dir, idx)
    hy_cm = load_checkm2(args.hy_checkm)
    il_cm = load_checkm2(args.il_checkm)
    hy_mq = mq_bins(hy_cm, args.min_completeness, args.max_contamination)
    il_mq = mq_bins(il_cm, args.min_completeness, args.max_contamination)

    maps = prep_all(args, idx, groups, hy_cm, il_cm, hy_mq, il_mq)
    if args.only == "prep":
        log("DONE prep")
        log("prep QC: %s/contig_to_bin.tsv" % args.out_dir)
        return

    ani_all = []
    for sample, g in sorted(groups.items()):
        files = g["hy"] + g["il"]
        tsv = run_skani_sample(
            sample, files, args.out_dir, args.threads, args.min_len,
            args.force, args.reuse)
        ani_all.extend(collect_hy_il_pairs(sample, tsv))
    write_table(os.path.join(args.out_dir, "ani_pairs_all.tsv"), ani_all)

    sample_hy_hosts, sample_mag_owner, host_table_rows = build_sample_host_maps(
        ani_all, args.pair_ani, args.pair_af_il, hy_mq, il_mq)
    write_table(os.path.join(args.out_dir, "hybrid_mag_hosts.tsv"), host_table_rows)
    if args.only == "skani":
        log("DONE skani")
        log("Host table: %s/hybrid_mag_hosts.tsv" % args.out_dir)
        return

    hy_coords = parse_coord_file(args.hy_coords)
    il_coords = parse_coord_file(args.il_coords)
    ilc_coords = parse_coord_file(args.il_contig_coords)

    all_rows = defaultdict(list)
    for sample, g in sorted(groups.items()):
        log("==== %s (%s) ====" % (sample, g["err"]))
        part = track_sample(
            sample, g, idx, hy_coords, il_coords, ilc_coords,
            sample_hy_hosts.get(sample, {}),
            sample_mag_owner.get(sample, {}),
            hy_mq, il_mq, maps.get(sample), args)
        for k, rows in part.items():
            all_rows[k].extend(rows)

    write_table(os.path.join(args.out_dir, "06_assign_hy2il.all.tsv"), all_rows["hy2il"])
    write_table(os.path.join(args.out_dir, "06_assign_il2hy.all.tsv"), all_rows["il2hy"])
    make_l1_summary(all_rows["hy2il"], os.path.join(args.out_dir, "07_summary.tsv"),
                    "hy_status", "binned")
    make_l1_summary(all_rows["il2hy"], os.path.join(args.out_dir, "07_summary_il2hy.tsv"),
                    "mag_status", "binned")
    if all_rows["l2"]:
        write_table(os.path.join(args.out_dir, "08_asm_assign_hy2il.all.tsv"), all_rows["l2"])
        make_l2_summary(all_rows["l2"], os.path.join(args.out_dir, "08_l2_summary.tsv"))
    if all_rows["l3"]:
        write_table(os.path.join(args.out_dir, "09_tool_assign_hy2il.all.tsv"), all_rows["l3"])
    make_main_numbers(
        all_rows["hy2il"], all_rows["il2hy"], all_rows["l2"], all_rows["l3"],
        os.path.join(args.out_dir, "10_main_numbers.tsv"))

    log("ALL DONE")
    log("Host MAG:        %s/hybrid_mag_hosts.tsv" % args.out_dir)
    log("L1 hy2il:        %s/06_assign_hy2il.all.tsv" % args.out_dir)
    log("L1 il2hy:        %s/06_assign_il2hy.all.tsv" % args.out_dir)
    log("L1 summary:      %s/07_summary.tsv" % args.out_dir)
    log("L1 rev:          %s/07_summary_il2hy.tsv" % args.out_dir)
    log("L2 summary:      %s/08_l2_summary.tsv" % args.out_dir)
    log("main numbers:    %s/10_main_numbers.tsv" % args.out_dir)
    log("run log:         %s" % log_path)


if __name__ == "__main__":
    main()