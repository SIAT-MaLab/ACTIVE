AMI=$(pwd -P)
STAGED=$AMI/active_input
mkdir -p "$STAGED"/{genomes,seq}

find "$AMI/hy_bins" -mindepth 2 -maxdepth 2 -name '*.fa' | while read -r fa; do
  base=$(basename "$fa" .fa)
  ln -sfn "$fa" "$STAGED/genomes/${base}.fasta"
done

tail -n +2 "$AMI/short-long.index.tsv" | while IFS=$'\t' read -r sample long short _; do
  sample=${sample%$'\r'}
  long=${long%$'\r'}
  short=${short%$'\r'}
  [ -z "$sample" ] && continue

  r1=$AMI/cleanseq/2/${short}_clean_1.fastq.gz
  r2=$AMI/cleanseq/2/${short}_clean_2.fastq.gz
  ont=$AMI/cleanseq/3/${long}_clean.fastq.gz

  [ -f "$r1" ]  && ln -sfn "$r1"  "$STAGED/seq/${sample}_1_clean.fastq.gz"
  [ -f "$r2" ]  && ln -sfn "$r2"  "$STAGED/seq/${sample}_2_clean.fastq.gz"
  [ -f "$ont" ] && ln -sfn "$ont" "$STAGED/seq/${sample}_ont.fastq.gz"

  [ -f "$r1" ]  || echo "Missing PE R1: $sample $r1"
  [ -f "$r2" ]  || echo "Missing PE R2: $sample $r2"
  [ -f "$ont" ] || echo "Missing ONT: $sample $ont"
done

echo -e "sample\tref" > "$STAGED/sample_ref_index.tsv"
tail -n +2 "$AMI/short-long.index.tsv" | while IFS=$'\t' read -r sample _ _; do
  sample=${sample%$'\r'}
  [ -z "$sample" ] && continue
  for fa in "$AMI/hy_bins/$sample"/*.fa; do
    [ -e "$fa" ] || continue
    printf '%s\t%s\n' "$sample" "$(basename "$fa" .fa)"
  done
done >> "$STAGED/sample_ref_index.tsv"

echo "genomes: $(ls "$STAGED/genomes"/*.fasta | wc -l)"
echo "PE pairs: $(ls "$STAGED/seq"/*_1_clean.fastq.gz | wc -l)"
echo "ONT:      $(ls "$STAGED/seq"/*_ont.fastq.gz | wc -l)"
echo "index rows: $(($(wc -l < "$STAGED/sample_ref_index.tsv") - 1))"
head "$STAGED/sample_ref_index.tsv"
ls -l "$STAGED/seq/D02"*