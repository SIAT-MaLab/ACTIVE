#!/usr/bin/env Rscript
# -*- coding: utf-8 -*-

# 依赖检查与加载
suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(tidyr)
  library(ggplot2)
})

# ==============================================================================
# 1. 路径设置 (根据实际路径调整)
# ==============================================================================
activity_file <- "prophage_activity/hy-hy_precise.csv"
track_file    <- "prophage_track_ami_hcom2/06_assign_hy2il.all.tsv"
l2_file       <- "prophage_track_ami_hcom2/08_asm_assign_hy2il.all.tsv" # 可选：用于L2机制深入
out_dir       <- "activity_track_stats"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

message(">>> 正在读取数据...")

# ==============================================================================
# 2. 读取并清洗数据
# ==============================================================================
# 2.1 活性表清洗
df_act <- read_csv(activity_file, show_col_types = FALSE) %>%
  mutate(
    Coverage   = as.numeric(Coverage),
    Delta_Mean = as.numeric(Delta_Mean),
    # 提取标准化 phage_id (去掉前缀 phage_depth_ 和后缀 .txt)
    clean_id   = str_remove(Phage_File, "^phage_depth_"),
    clean_id   = str_remove(clean_id, "\\.txt$")
  ) %>%
  # 排除 Coverage <= 0.75
  filter(Coverage > 0.75) %>%
  # 定义活跃状态：Delta_Mean >= 0.8
  mutate(
    is_active = if_else(!is.na(Delta_Mean) & Delta_Mean >= 0.8, "Active", "Inactive"),
    is_active = factor(is_active, levels = c("Inactive", "Active"))
  )

message(sprintf("活性表清洗后剩余: %d 条记录 (Active: %d, Inactive: %d)", 
                nrow(df_act), sum(df_act$is_active == "Active"), sum(df_act$is_active == "Inactive")))

# 2.2 追踪结果表清洗
df_track <- read_tsv(track_file, show_col_types = FALSE)

# 2.3 匹配合并 (兼容 prophage_id 可能带或不带 Genome 前缀的情况)
df_merged <- df_track %>%
  mutate(
    # 构建可能用于匹配的两种 ID 模式
    match_id1 = prophage_id,
    match_id2 = paste0(source_hybrid, "_", prophage_id)
  ) %>%
  left_join(df_act, by = c("match_id1" = "clean_id")) %>%
  # 如果第一种没匹配上，尝试第二种
  left_join(df_act, by = c("match_id2" = "clean_id"), suffix = c("", ".y")) %>%
  mutate(
    is_active  = coalesce(is_active, is_active.y),
    Delta_Mean = coalesce(Delta_Mean, Delta_Mean.y),
    Coverage   = coalesce(Coverage, Coverage.y)
  ) %>%
  select(-ends_with(".y")) %>%
  # 必须有活性结果，且仅分析来源基因组在二代中有 Host 的前噬菌体 (hy_status == 'binned')
  filter(!is.na(is_active)) %>%
  filter(hy_status == "binned")

message(sprintf("成功与追踪表匹配且合格的噬菌体数: %d 条", nrow(df_merged)))

# ==============================================================================
# 3. 统计检验核心函数 (Fisher's Exact Test)
# ==============================================================================
run_fisher_test <- f <- function(data, group_col, target_group, ref_group, test_name) {
  sub_df <- data %>%
    filter(!!sym(group_col) %in% c(target_group, ref_group)) %>%
    mutate(Group = factor(!!sym(group_col), levels = c(ref_group, target_group)))
  
  # 构建 2x2 列联表
  tbl <- table(sub_df$Group, sub_df$is_active)
  cat("\n=======================================================\n")
  cat(paste("【分析检验】:", test_name, "\n"))
  print(tbl)
  
  # 计算百分比
  pct_df <- sub_df %>%
    group_by(Group, is_active) %>%
    summarise(n = n(), .groups = "drop_last") %>%
    mutate(pct = round(100 * n / sum(n), 2))
  print(pct_df)
  
  # Fisher 检验
  ft <- fisher.test(tbl)
  
  res <- tibble(
    Test               = test_name,
    Ref_Group          = ref_group,
    Target_Group       = target_group,
    Ref_Active_Pct     = pct_df %>% filter(Group == ref_group, is_active == "Active") %>% pull(pct) %>% {if(length(.)==0) 0 else .},
    Target_Active_Pct  = pct_df %>% filter(Group == target_group, is_active == "Active") %>% pull(pct) %>% {if(length(.)==0) 0 else .},
    Odds_Ratio         = as.numeric(ft$estimate),
    CI_95_lower        = ft$conf.int[1],
    CI_95_upper        = ft$conf.int[2],
    P_value            = ft$p.value,
    Significance       = case_when(
      ft$p.value < 0.001 ~ "***",
      ft$p.value < 0.01  ~ "**",
      ft$p.value < 0.05  ~ "*",
      TRUE ~ "NS"
    )
  )
  return(list(summary = res, data = sub_df))
}

# ==============================================================================
# 4. 执行假设检验
# ==============================================================================
# ------------------------------------------------------------------------------
# 假设 1: Lost 是否比 Recovered 显著富集活跃前噬菌体？
# ------------------------------------------------------------------------------
res_q1 <- run_fisher_test(
  data         = df_merged,
  group_col    = "recovery_stage",
  target_group = "Lost",
  ref_group    = "Recovered",
  test_name    = "Hypothesis 1: Lost vs Recovered"
)

# ------------------------------------------------------------------------------
# 假设 2: Misbinned (Pure_Incorrect) 是否比 Correct (Pure_Correct) 显著富集活跃噬菌体？
# ------------------------------------------------------------------------------
res_q2 <- run_fisher_test(
  data         = df_merged,
  group_col    = "main_class",
  target_group = "Pure_Incorrect",
  ref_group    = "Pure_Correct",
  test_name    = "Hypothesis 2: Misbinned (Pure_Incorrect) vs Correct (Pure_Correct)"
)

# 输出统计表
final_stats <- bind_rows(res_q1$summary, res_q2$summary)
print(final_stats)
write_tsv(final_stats, file.path(out_dir, "statistical_test_summary.tsv"))

# ==============================================================================
# 5. 可视化出图 (ggplot2 出版级柱状图)
# ==============================================================================
message(">>> 正在绘制统计图表...")

# 5.1 整合绘图数据
plot_data <- bind_rows(
  res_q1$data %>% mutate(Comparison = "Lost vs Recovered", Group_Label = as.character(Group)),
  res_q2$data %>% mutate(Comparison = "Misbinned vs Correct", Group_Label = as.character(Group))
) %>%
  group_by(Comparison, Group_Label, is_active) %>%
  summarise(count = n(), .groups = "drop_last") %>%
  mutate(prop = count / sum(count)) %>%
  filter(is_active == "Active")

# 绘图
p <- ggplot(plot_data, aes(x = Group_Label, y = prop * 100, fill = Group_Label)) +
  geom_col(width = 0.55, color = "black", alpha = 0.85, show.legend = FALSE) +
  geom_text(aes(label = sprintf("%.1f%%\n(%d)", prop * 100, count)), 
            vjust = -0.3, size = 3.8, fontface = "bold") +
  facet_wrap(~ Comparison, scales = "free_x") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.2))) +
  scale_fill_manual(values = c(
    "Recovered"      = "#4575b4",
    "Lost"           = "#d73027",
    "Pure_Correct"   = "#74add1",
    "Pure_Incorrect" = "#f46d43"
  )) +
  labs(
    title = "Prophage Activity Enrichment in Tracking Categories",
    subtitle = "Active defined as Delta_Mean >= 0.8 (Coverage > 0.75)",
    x = "Prophage Fate Category",
    y = "Active Prophages Proportion (%)"
  ) +
  theme_bw(base_size = 13) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5, color = "gray30"),
    strip.text = element_text(face = "bold", size = 12),
    strip.background = element_rect(fill = "#f0f0f0"),
    panel.grid.minor = element_blank()
  )

ggsave(file.path(out_dir, "activity_enrichment_barplot.pdf"), p, width = 7, height = 5)
ggsave(file.path(out_dir, "activity_enrichment_barplot.png"), p, width = 7, height = 5, dpi = 300)

message(">>> 全部统计与绘图完成！结果已存至: ", out_dir)
