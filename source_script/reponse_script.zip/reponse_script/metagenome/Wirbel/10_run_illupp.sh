#!/bin/bash
set -euo pipefail

AMI=$(pwd -P)
echo ">>> Root: $AMI"

SCRIPT="$AMI/active_for_metagenomic_20260908.sh"
COORD="$AMI/prophage_illubin/coordinate/prophage_coordinates.tsv"

STAGED="$AMI/active_input_illu"
GENOMES="$STAGED/genomes"
SEQS="$STAGED/seq"
INDEX="$STAGED/sample_ref_index.tsv"
OUT="$AMI/activity_out/illu"

THREADS=20
R_THREADS=20
MGS_SCORE=150

if [ ! -f "$SCRIPT" ]; then
    echo "Error: missing $SCRIPT"
    exit 1
fi

if [ ! -f "$COORD" ]; then
    echo "Error: missing $COORD"
    exit 1
fi

echo ">>> Preparing inputs"
mkdir -p "$GENOMES" "$SEQS"

find "$AMI/illumina_bin" -name '*.fa' | while read -r fa; do
    base=$(basename "$fa" .fa)
    ln -sfn "$fa" "$GENOMES/${base}.fasta"
done

echo -e "sample\tref" > "$INDEX"

for bin_dir in "$AMI/illumina_bin"/ERR*_bin; do
    [ -d "$bin_dir" ] || continue

    sample=$(basename "$bin_dir" | sed 's/_bin//')

    r1="$AMI/cleanseq/2/${sample}_clean_1.fastq.gz"
    r2="$AMI/cleanseq/2/${sample}_clean_2.fastq.gz"

    if [ -f "$r1" ] && [ -f "$r2" ]; then
        ln -sfn "$r1" "$SEQS/${sample}_1_clean.fastq.gz"
        ln -sfn "$r2" "$SEQS/${sample}_2_clean.fastq.gz"
    else
        echo "Warning: no reads for $sample"
        continue
    fi

    for fa in "$bin_dir"/*.fa; do
        [ -e "$fa" ] || continue
        ref=$(basename "$fa" .fa)
        printf '%s\t%s\n' "$sample" "$ref" >> "$INDEX"
    done
done

echo "genomes: $(ls "$GENOMES"/*.fasta 2>/dev/null | wc -l)"
echo "PE pairs: $(ls "$SEQS"/*_1_clean.fastq.gz 2>/dev/null | wc -l)"
echo "index rows: $(($(wc -l < "$INDEX") - 1))"

echo ">>> Sensitive mode"
bash "$SCRIPT" \
  -g "$GENOMES" \
  -s "$SEQS" \
  -p "$COORD" \
  -o "$OUT" \
  -i "$INDEX" \
  --map-mode competitive \
  -t "$THREADS" -r "$R_THREADS" -m "$MGS_SCORE"

echo ">>> Precise mode"
bash "$SCRIPT" \
  -g "$GENOMES" \
  -s "$SEQS" \
  -p "$COORD" \
  -o "$OUT" \
  -i "$INDEX" \
  --map-mode competitive \
  -c \
  -t "$THREADS" -r "$R_THREADS" -m "$MGS_SCORE"

echo ">>> Done: $OUT"