#!/bin/bash
set -euo pipefail

WORKDIR=$(pwd -P)
echo ">>> Working dir: $WORKDIR"

SCRIPT="$WORKDIR/active_20260909.sh"

GENOMES="$WORKDIR/active_input/genomes"
SEQS="$WORKDIR/active_input/seq"
INDEX="$WORKDIR/active_input/sample_ref_index.tsv"
COORD="$WORKDIR/prophage_hybin/coordinate/prophage_coordinates.tsv"

OUT_HYBRID="$WORKDIR/activity_out/hy/hybrid"
OUT_SHORT="$WORKDIR/activity_out/hy/short"

THREADS=20
R_THREADS=20
MGS_SCORE=150

echo ">>> Hybrid sensitive"
bash "$SCRIPT" \
  -g "$GENOMES" \
  -s "$SEQS" \
  -p "$COORD" \
  -o "$OUT_HYBRID" \
  -i "$INDEX" \
  --map-mode competitive \
  -t "$THREADS" -r "$R_THREADS" -m "$MGS_SCORE"

echo ">>> Hybrid precise"
bash "$SCRIPT" \
  -g "$GENOMES" \
  -s "$SEQS" \
  -p "$COORD" \
  -o "$OUT_HYBRID" \
  -i "$INDEX" \
  --map-mode competitive \
  -c \
  -t "$THREADS" -r "$R_THREADS" -m "$MGS_SCORE"

mkdir -p "$OUT_SHORT"
if [ -d "$OUT_HYBRID/prodigal_results" ] && [ ! -d "$OUT_SHORT/prodigal_results" ]; then
    cp -r "$OUT_HYBRID/prodigal_results" "$OUT_SHORT/"
fi

if [ -d "$OUT_HYBRID/fetchmgs_results" ] && [ ! -d "$OUT_SHORT/fetchmgs_results" ]; then
    cp -r "$OUT_HYBRID/fetchmgs_results" "$OUT_SHORT/"
fi

echo ">>> Short sensitive"
bash "$SCRIPT" \
  -g "$GENOMES" \
  -s "$SEQS" \
  -p "$COORD" \
  -o "$OUT_SHORT" \
  -i "$INDEX" \
  --map-mode competitive \
  -t "$THREADS" -r "$R_THREADS" -m "$MGS_SCORE"

echo ">>> Short precise"
bash "$SCRIPT" \
  -g "$GENOMES" \
  -s "$SEQS" \
  -p "$COORD" \
  -o "$OUT_SHORT" \
  -i "$INDEX" \
  --map-mode competitive \
  -c \
  -t "$THREADS" -r "$R_THREADS" -m "$MGS_SCORE"

echo ">>> Done"