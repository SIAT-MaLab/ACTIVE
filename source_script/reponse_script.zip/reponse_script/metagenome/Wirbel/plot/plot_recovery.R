#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(scales)
})

out_dir <- "plot_out"
if (!dir.exists(out_dir)) {
  dir.create(out_dir, recursive = TRUE)
}

input_file <- "../06_assign_hy2il.all.tsv"

df <- read_tsv(input_file, col_types = cols())

plot_data <- df %>%
  filter(hy_status == "binned") %>%
  mutate(
    stage_group = case_when(
      recovery_stage == "Recovered" ~ "Recovered",
      recovery_stage %in% c("Partial_binned", "Partial_unbinned", "Partial") ~ "Partial",
      recovery_stage == "Lost" ~ "Lost",
      TRUE ~ recovery_stage
    )
  ) %>%
  count(sample, stage_group) %>%
  group_by(sample) %>%
  mutate(percentage = n / sum(n) * 100) %>%
  ungroup() %>%
  complete(sample, stage_group = c("Lost", "Partial", "Recovered"), fill = list(percentage = 0, n = 0)) %>%
  mutate(
    stage_group = factor(stage_group, levels = c("Lost", "Partial", "Recovered"))
  )

stage_colors <- c(
  "Lost"      = "#D95F5F",
  "Partial"   = "#F28E2B",
  "Recovered" = "#59A14F"
)

p <- ggplot(plot_data, aes(x = stage_group, y = percentage)) +
  theme_bw(base_size = 12) +
  geom_boxplot(aes(fill = stage_group), 
               alpha = 0.4, 
               width = 0.45, 
               outlier.shape = NA, 
               color = "black", 
               size = 0.6) +
  geom_jitter(aes(color = stage_group), 
              width = 0.15, 
              size = 2, 
              alpha = 0.75, 
              stroke = 0) +
  scale_fill_manual(values = stage_colors) +
  scale_color_manual(values = stage_colors) +
  scale_y_continuous(
    limits = c(-2, 102),
    breaks = seq(0, 100, 25),
    labels = function(x) paste0(x, "%"),
    expand = c(0, 0)
  ) +
  labs(
    x = NULL,
    y = "Percentage (%)"
  ) +
  theme(
    legend.position = "none",
    panel.grid.major = element_line(color = "grey92", size = 0.5),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "grey60", fill = NA, size = 0.8),
    axis.text.x = element_text(size = 11, face = "plain", color = "grey20"),
    axis.text.y = element_text(size = 10, color = "grey20"),
    axis.title.y = element_text(size = 11, margin = margin(r = 8)),
    plot.margin = margin(t = 15, r = 15, b = 15, l = 15)
  )

pdf_path <- file.path(out_dir, "binned_recovery_stage_distribution.pdf")
png_path <- file.path(out_dir, "binned_recovery_stage_distribution.png")

ggsave(pdf_path, p, width = 4.5, height = 4.2)
ggsave(png_path, p, width = 4.5, height = 4.2, dpi = 300)

rec_wide <- plot_data %>%
  pivot_wider(
    names_from = stage_group,
    values_from = c(n, percentage),
    names_glue = "{stage_group}_{.value}"
  ) %>%
  mutate(total_binned = Lost_n + Partial_n + Recovered_n)
write_tsv(rec_wide, file.path(out_dir, "07_binned_recovery_stage_per_sample.tsv"))