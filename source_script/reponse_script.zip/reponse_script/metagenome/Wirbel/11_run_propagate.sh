#!/usr/bin/env bash
set -uo pipefail

AMI=$(pwd -P)
echo ">>> Root: $AMI"

THREADS=20
PROP_THREADS=20
MIN_PID=0.95

PROP_OUT_ROOT="$AMI/propagate_benchmark_out"
mkdir -p "$PROP_OUT_ROOT"

LOG_DIR="$PROP_OUT_ROOT/logs"
mkdir -p "$LOG_DIR"

DATASETS=(
    "short|$AMI/activity_out/hy/short|$AMI/prophage_hybin/coordinate/propagate_coordinate.tsv"
)

run_dataset() {
    local DNAME="$1"
    local ACT_DIR="$2"
    local COORD_TSV="$3"

    echo ">>> [$DNAME] input=$ACT_DIR coord=$COORD_TSV"

    if [ ! -d "$ACT_DIR" ]; then
        echo ">>> [$DNAME] skipping, missing dir: $ACT_DIR"
        return 0
    fi
    if [ ! -s "$COORD_TSV" ]; then
        echo ">>> [$DNAME] skipping, missing coord: $COORD_TSV"
        return 0
    fi

    local BAM_DIR="$ACT_DIR/mapping_results/competitive"
    local REF_DIR="$ACT_DIR/competitive_refs"
    local OUT_DIR="$PROP_OUT_ROOT/$DNAME"
    mkdir -p "$OUT_DIR"

    local bam_list
    bam_list=$(find "$BAM_DIR" -maxdepth 2 -name "*_competitive.bam" 2>/dev/null | sort || true)

    if [ -z "$bam_list" ]; then
        echo ">>> [$DNAME] no *_competitive.bam in $BAM_DIR"
        return 0
    fi

    local total_samples
    total_samples=$(echo "$bam_list" | wc -l)
    echo ">>> [$DNAME] $total_samples samples"

    local current=0
    for bam in $bam_list; do
        current=$((current + 1))
        local sample_id
        sample_id=$(basename "$(dirname "$bam")")
        local ref_fasta="$REF_DIR/${sample_id}.fasta"
        local sample_out="$OUT_DIR/${sample_id}"
        local sample_log="$LOG_DIR/${DNAME}_${sample_id}.log"

        echo -ne "    [$current/$total_samples] ${sample_id} ... "

        if [ ! -s "$ref_fasta" ]; then
            echo -e "\033[33m[skip: missing $ref_fasta]\033[0m"
            continue
        fi

        if [ ! -f "${bam}.bai" ] || [ "$bam" -nt "${bam}.bai" ]; then
            samtools index -@ "$THREADS" "$bam" 2>/dev/null || true
        fi

        if [ -d "$sample_out" ]; then
            local valid_res
            valid_res=$(find "$sample_out" -name "*results*.tsv" -size +0c 2>/dev/null | head -n 1 || true)
            if [ -n "$valid_res" ]; then
                echo -e "\033[32m[skip: existing result]\033[0m"
                continue
            else
                rm -rf "$sample_out"
            fi
        fi

        if Propagate \
            -f "$ref_fasta" \
            -b "$bam" \
            -v "$COORD_TSV" \
            -o "$sample_out" \
            -p "$MIN_PID" \
            -t "$PROP_THREADS" > "$sample_log" 2>&1; then
            echo -e "\033[32m[done]\033[0m"
        else
            echo -e "\033[31m[failed, log: logs/${DNAME}_${sample_id}.log]\033[0m"
        fi

    done

    echo ">>> [$DNAME] summarizing"
    python3 - <<PYEOF
import os
import glob
import pandas as pd

out_dir = "${OUT_DIR}"
dname = "${DNAME}"
summary_file = os.path.join("${PROP_OUT_ROOT}", f"propagate_{dname}_all_summary.tsv")

dfs = []
for f in glob.glob(os.path.join(out_dir, "**", "*.tsv"), recursive=True):
    fname = os.path.basename(f)
    if "results" in fname.lower() and not fname.endswith("_all_summary.tsv"):
        sample = os.path.basename(os.path.dirname(f))
        try:
            df = pd.read_csv(f, sep='\t')
            if not df.empty and ("prophage" in [c.lower() for c in df.columns] or "fragment" in [c.lower() for c in df.columns]):
                df.insert(0, 'Sample_ID', sample)
                df.insert(1, 'Dataset', dname)
                if 'prophage' in df.columns:
                    df = df[~df['prophage'].str.contains("fakepp", na=False)]
                elif 'fragment' in df.columns:
                    df = df[~df['fragment'].str.contains("fakepp", na=False)]
                dfs.append(df)
        except Exception as e:
            pass

if dfs:
    res = pd.concat(dfs, ignore_index=True)
    res.to_csv(summary_file, sep='\t', index=False)
    print(f"    summary: {summary_file} ({len(res)} rows)")
else:
    print(f"    no valid results")
PYEOF
}

for ds in "${DATASETS[@]}"; do
    IFS='|' read -r name act_path coord_path <<< "$ds"
    run_dataset "$name" "$act_path" "$coord_path"
done

echo ">>> Master summary"

python3 - <<PYEOF
import os
import pandas as pd

root_dir = "${PROP_OUT_ROOT}"
master_file = os.path.join(root_dir, "propagate_master_summary.tsv")

summary_files = [
    os.path.join(root_dir, "propagate_hybrid_all_summary.tsv"),
    os.path.join(root_dir, "propagate_short_all_summary.tsv"),
    os.path.join(root_dir, "propagate_illu_all_summary.tsv")
]

all_dfs = []
for f in summary_files:
    if os.path.exists(f):
        try:
            df = pd.read_csv(f, sep='\t')
            all_dfs.append(df)
            print(f"  -> loaded: {os.path.basename(f)} ({len(df)} rows)")
        except Exception as e:
            print(f"  -> failed {f}: {e}")

if all_dfs:
    master_df = pd.concat(all_dfs, ignore_index=True)
    master_df.to_csv(master_file, sep='\t', index=False)
    print(f"\nmaster: {master_file} ({len(master_df)} rows)")
else:
    print("\nno summary files found")
PYEOF

echo ">>> Done: $PROP_OUT_ROOT"