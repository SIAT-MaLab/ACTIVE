#!/usr/bin/env bash
set -euo pipefail

ROOT=$(pwd)
INPUT_DIR="${ROOT}/checkm2_input"
OUTPUT_DIR="${ROOT}/checkm2_output"
SUMMARY="${ROOT}/checkm2_summary.tsv"

mkdir -p "${INPUT_DIR}" "${OUTPUT_DIR}"

find "${ROOT}" \
    -mindepth 2 \
    -maxdepth 2 \
    -type f \
    -path "${ROOT}/D*/*.bin.*.fa" \
    -print0 |
while IFS= read -r -d '' fasta; do
    filename=$(basename "${fasta}")
    link="${INPUT_DIR}/${filename}"

    if [[ -e "${link}" || -L "${link}" ]]; then
        exit 1
    fi

    ln -s "${fasta}" "${link}"
done

n_bins=$(find "${INPUT_DIR}" -maxdepth 1 -type l -name '*.fa' | wc -l)

if [[ "${n_bins}" -eq 0 ]]; then
    exit 1
fi

checkm2 predict \
    --input "${INPUT_DIR}" \
    --output-directory "${OUTPUT_DIR}" \
    --threads 24 \
    --extension fa \
    --force

if [[ -f "${OUTPUT_DIR}/quality_report.tsv" ]]; then
    cp "${OUTPUT_DIR}/quality_report.tsv" "${SUMMARY}"
else
    exit 1
fi