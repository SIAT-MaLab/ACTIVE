#!/usr/bin/env python3

from pathlib import Path
import re
import csv
import os
import tempfile


ROOT = Path.cwd()
INDEX_FILE = ROOT / "contig_rename_index.csv"


def read_fasta(fasta_file):
    records = []
    header = None
    seq_parts = []

    with fasta_file.open("r") as f:
        for line_number, line in enumerate(f, start=1):
            line = line.rstrip("\n\r")

            if not line:
                continue

            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_parts)))

                header = line[1:].strip()
                seq_parts = []
            else:
                if header is None:
                    raise ValueError(
                        f"{fasta_file}: line {line_number} contains sequence "
                        "before the first FASTA header"
                    )
                seq_parts.append(line.strip())

    if header is not None:
        records.append((header, "".join(seq_parts)))

    return records


def contig_sort_key(record):
    old_header = record[0]
    old_id = old_header.split()[0]
    last_part = old_id.rsplit("_", 1)[-1]

    if last_part.isdigit():
        return (0, int(last_part), old_id)

    return (1, last_part.lower(), old_id)


def get_new_contig_id(old_header, sample, bin_number):
    old_id = old_header.split()[0]
    suffix = old_id.rsplit("_", 1)[-1]

    return f"{sample}.bin.{bin_number}_{suffix}"


def wrap_sequence(sequence, width=80):
    return "\n".join(
        sequence[i:i + width]
        for i in range(0, len(sequence), width)
    )


def write_sorted_renamed_fasta(records, output_file, sample, bin_number):
    records = sorted(records, key=contig_sort_key)

    index_rows = []
    seen_new_ids = set()

    with output_file.open("w") as out:
        for old_header, sequence in records:
            old_id = old_header.split()[0]

            new_id = get_new_contig_id(
                old_header=old_header,
                sample=sample,
                bin_number=bin_number
            )

            if new_id in seen_new_ids:
                raise ValueError(
                    f"Duplicated renamed contig ID: {new_id}"
                )

            seen_new_ids.add(new_id)

            out.write(f">{new_id}\n")
            out.write(wrap_sequence(sequence))
            out.write("\n")

            index_rows.append(
                {
                    "old_contig": old_id,
                    "renamed_contig": new_id
                }
            )

    return index_rows


def main():
    all_index_rows = []

    sample_dirs = sorted(
        p for p in ROOT.iterdir()
        if p.is_dir() and any(p.glob("bin.*.fa"))
    )

    if not sample_dirs:
        raise RuntimeError(
            f"No directory containing 'bin.*.fa' found under {ROOT}"
        )

    for sample_dir in sample_dirs:
        sample = sample_dir.name

        bin_files = sorted(
            sample_dir.glob("bin.*.fa"),
            key=lambda p: (
                int(re.match(r"^bin\.(\d+)\.fa$", p.name).group(1))
                if re.match(r"^bin\.(\d+)\.fa$", p.name)
                else 10**18,
                p.name
            )
        )

        for source_file in bin_files:
            match = re.match(r"^bin\.(\d+)\.fa$", source_file.name)

            if match is None:
                continue

            bin_number = match.group(1)
            output_file = sample_dir / f"{sample}.bin.{bin_number}.fa"

            records = read_fasta(source_file)

            with tempfile.NamedTemporaryFile(
                mode="w",
                dir=sample_dir,
                prefix=f".{output_file.name}.",
                suffix=".tmp",
                delete=False
            ) as tmp:
                tmp_file = Path(tmp.name)

            try:
                index_rows = write_sorted_renamed_fasta(
                    records=records,
                    output_file=tmp_file,
                    sample=sample,
                    bin_number=bin_number
                )

                os.replace(tmp_file, output_file)

            except Exception:
                if tmp_file.exists():
                    tmp_file.unlink()
                raise

            source_file.unlink()

            bin_source = str(source_file.relative_to(ROOT))

            for row in index_rows:
                all_index_rows.append(
                    {
                        "bin_source": bin_source,
                        "old_contig": row["old_contig"],
                        "renamed_contig": row["renamed_contig"]
                    }
                )

    with INDEX_FILE.open("w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "bin_source",
                "old_contig",
                "renamed_contig"
            ]
        )
        writer.writeheader()
        writer.writerows(all_index_rows)


if __name__ == "__main__":
    main()