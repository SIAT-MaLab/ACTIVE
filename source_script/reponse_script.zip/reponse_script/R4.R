library(dplyr)
library(ggplot2)
library(patchwork)

meta_path <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
out_dir   <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/basic_stats"

meta <- read.delim(meta_path, sep = "\t", header = TRUE, check.names = FALSE, stringsAsFactors = FALSE)

plot_df <- meta %>%
  filter(Region == "phage") %>%
  mutate(
    Activity_Score = as.numeric(Activity_Score),
    Ratio = as.numeric(Ratio)
  ) %>%
  filter(!is.na(Activity_Score), !is.na(Ratio), Ratio > 0)

high_df <- plot_df %>% filter(Activity_Score >= 0.8)

base_theme <- theme_bw(base_size = 12) +
  theme(
    legend.position = "bottom",
    plot.title = element_text(face = "bold", hjust = 0.5)
  )

p1 <- ggplot(plot_df, aes(x = Activity_Score, y = Ratio)) +
  geom_point(size = 1.8, alpha = 0.55, color = "#3C5488") +
  geom_vline(xintercept = 0.8, linetype = "dashed", color = "grey50") +
  geom_hline(yintercept = 1, linetype = "dotted", color = "black") +
  scale_y_log10() +
  annotation_logticks(sides = "l") +
  labs(
    title = "All Phages",
    x = "Activity Score (\u0394-Mean)",
    y = expression(log[10] ~ "(Phage Mean / Host Median)")
  ) +
  base_theme

p2 <- ggplot(high_df, aes(x = Activity_Score, y = Ratio)) +
  geom_point(size = 2.2, alpha = 0.7, color = "#E64B35") +
  geom_hline(yintercept = 1, linetype = "dotted", color = "black") +
  scale_y_log10() +
  annotation_logticks(sides = "l") +
  labs(
    title = "Activity Score \u2265 0.95",
    x = "Activity Score (\u0394-Mean)",
    y = expression(log[10] ~ "(Phage Mean / Host Median)")
  ) +
  base_theme

combined_plot <- p1 + p2

ggsave(
  filename = file.path(out_dir, "Phage_ActivityScore_vs_Ratio_log10.pdf"),
  plot = combined_plot,
  width = 12,
  height = 5.5,
  device = cairo_pdf
)

cat("n all =", nrow(plot_df), "; n >= 0.95 =", nrow(high_df), "\n")
