library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)

meta_path <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
out_dir   <- "."
threshold <- 0.8

df <- read.delim(meta_path, sep = "\t", header = TRUE, stringsAsFactors = FALSE) %>%
  filter(Region == "phage") %>%
  mutate(
    Activity_Score = as.numeric(Activity_Score),
    is_active = ifelse(!is.na(Activity_Score) & Activity_Score >= threshold, "Active", "Inactive")
  )

clean_taxa <- function(x) {
  ifelse(is.na(x) | x %in% c("", "NA", "Unclassified", "o__Unclassified", "f__Unclassified"), "Unknown", x)
}

df <- df %>%
  mutate(
    host_Phylum = clean_taxa(host_Phylum),
    host_Family = clean_taxa(host_Family),
    vFAM        = clean_taxa(vFAM),
    vOTU        = clean_taxa(vOTU)
  )

calc_stats <- function(data, group_col, top_n = 10) {
  data %>%
    filter(.data[[group_col]] != "Unknown") %>%
    group_by(.data[[group_col]]) %>%
    summarise(
      Total_Prophages = n(),
      Active_Prophages = sum(is_active == "Active"),
      Active_Rate_pct = round(Active_Prophages / Total_Prophages * 100, 2),
      .groups = "drop"
    ) %>%
    arrange(desc(Active_Prophages), desc(Active_Rate_pct)) %>%
    slice_head(n = top_n)
}

phylum_stat <- calc_stats(df, "host_Phylum", top_n = 8)
family_stat <- calc_stats(df, "host_Family", top_n = 12)
vfam_stat   <- calc_stats(df, "vFAM", top_n = 15)
votu_stat   <- calc_stats(df, "vOTU", top_n = 15)

write.table(phylum_stat, file.path(out_dir, "Active_phages_by_host_Phylum.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(family_stat, file.path(out_dir, "Active_phages_by_host_Family.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(vfam_stat,   file.path(out_dir, "Active_phages_by_viral_vFAM.tsv"),   sep = "\t", quote = FALSE, row.names = FALSE)
write.table(votu_stat,   file.path(out_dir, "Active_phages_by_viral_vOTU.tsv"),   sep = "\t", quote = FALSE, row.names = FALSE)

plot_rank <- function(stat_df, col_name, fill_col = "#3C5488", title_prefix = "") {
  ggplot(stat_df, aes(x = reorder(.data[[col_name]], Active_Prophages), y = Active_Prophages)) +
    geom_col(fill = fill_col, width = 0.7) +
    geom_text(aes(label = paste0(Active_Prophages, " (", Active_Rate_pct, "%)")), 
              hjust = -0.1, size = 3.2) +
    coord_flip() +
    scale_y_continuous(expand = expansion(mult = c(0, 0.25))) +
    labs(
      title = paste0(title_prefix, col_name),
      x = NULL,
      y = "Active Prophage Count (Rate %)"
    ) +
    theme_bw(base_size = 11) +
    theme(
      plot.title = element_text(face = "bold", size = 12),
      axis.text.y = element_text(face = "italic")
    )
}

p_phylum <- plot_rank(phylum_stat, "host_Phylum", fill_col = "#00A087FF", title_prefix = "Host ")
p_family <- plot_rank(family_stat, "host_Family", fill_col = "#4DBBD5FF", title_prefix = "Host ")

p_vfam <- plot_rank(vfam_stat, "vFAM", fill_col = "#E64B35FF", title_prefix = "Viral ")
p_votu <- plot_rank(votu_stat, "vOTU", fill_col = "#F39B7FFF", title_prefix = "Viral ")

p_host <- p_phylum / p_family + plot_annotation(title = "Host Distribution of Active Prophages (Activity Score >= 0.8)")
p_virus <- p_vfam / p_votu + plot_annotation(title = "Viral Lineage/Cluster of Active Prophages (Activity Score >= 0.8)")

ggsave(file.path(out_dir, "Host_Distribution_Active_Phages.pdf"), p_host, width = 8, height = 9, device = cairo_pdf)
ggsave(file.path(out_dir, "Viral_Lineage_Active_Phages.pdf"), p_virus, width = 8, height = 9, device = cairo_pdf)

library(dplyr)
library(ggplot2)
library(ggrepel)
library(patchwork)

meta_path <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
out_dir   <- "."
threshold <- 0.8

PHYLUM_COLORS <- c(
  "Bacillota_A"       = "#dce8ef", 
  "Bacillota_C"       = "#add2e5", 
  "Bacillota_I"       = "#34666b", 
  "Bacillota"         = "#7abbce",
  "Bacillota_B"       = "#769499", 
  "Actinomycetota"    = "#f5cfa6", 
  "Bacteroidota"      = "#efe3ef", 
  "Verrucomicrobiota" = "#d4d68a",
  "Pseudomonadota"    = "#e68f9f", 
  "Desulfobacterota"  = "#d5d5d6", 
  "Fusobacteriota"    = "#b7a3c9", 
  "Synergistota"      = "#414141"
)

clean_taxa <- function(x) {
  ifelse(is.na(x) | x %in% c("", "NA", "Unclassified", "o__Unclassified", "f__Unclassified"), "Unknown", x)
}
df <- read.delim(meta_path, sep = "\t", header = TRUE, stringsAsFactors = FALSE) %>%
  filter(Region == "phage") %>%
  mutate(
    Activity_Score = as.numeric(Activity_Score),
    is_active = ifelse(!is.na(Activity_Score) & Activity_Score >= threshold, 1, 0),
    host_Phylum = clean_taxa(host_Phylum),
    host_Family = clean_taxa(host_Family)
  )

bg_active <- sum(df$is_active == 1)
bg_total  <- nrow(df)
bg_rate   <- bg_active / bg_total

family_stat <- df %>%
  filter(host_Family != "Unknown" & host_Phylum != "Unknown") %>%
  group_by(host_Phylum, host_Family) %>%
  summarise(
    Total_Genomes    = n_distinct(Genome),
    Total_Prophages  = n(),
    Active_Prophages = sum(is_active == 1),
    Active_Rate_pct  = (Active_Prophages / Total_Prophages) * 100,
    .groups = "drop"
  ) %>%
  filter(Total_Prophages >= 15) %>%
  rowwise() %>%
  mutate(
    Odds_Ratio = (Active_Prophages / (Total_Prophages - Active_Prophages + 1e-5)) /
                 ((bg_active + 1e-5) / (bg_total - bg_active + 1e-5))
  ) %>%
  ungroup() %>%
  arrange(desc(Active_Rate_pct))

top10_odds_label <- family_stat %>%
  arrange(desc(Odds_Ratio)) %>%
  slice_head(n = 10)

p_bubble <- ggplot(family_stat, aes(x = Total_Genomes, y = Active_Rate_pct)) +
  geom_hline(yintercept = bg_rate * 100, linetype = "dashed", color = "grey40", linewidth = 0.8) +
  annotate("text", x = max(family_stat$Total_Genomes), y = bg_rate * 100 + 1.5, 
           label = paste0("Global Average: ", round(bg_rate * 100, 1), "%"), hjust = 1, size = 3.5, color = "grey30") +
  geom_point(aes(size = Active_Prophages, fill = Odds_Ratio), shape = 21, color = "black") +
  scale_fill_viridis_c(option = "viridis", name = "Odds Ratio") +
  scale_size_continuous(range = c(3, 12), name = "Active Count") +
  scale_x_log10() +
  geom_text_repel(
    data = top10_odds_label,
    aes(label = host_Family),
    size = 3.5,
    fontface = "bold",
    box.padding = 0.5,
    point.padding = 0.3,
    max.overlaps = Inf
  ) +
  labs(
    title = "Prophage Activation vs. Host Sampling Bias (Family Level)",
    subtitle = "Color mapped to Odds Ratio; Text labels show Top 10 Families by Odds Ratio",
    x = expression(log[10] ~ "(Total Host Genomes Sampled)"),
    y = "Active Prophage Rate (%)"
  ) +
  theme_bw(base_size = 12) +
  theme(plot.title = element_text(face = "bold"))

top_fam <- family_stat %>% slice_head(n = 15)
p_bar <- ggplot(top_fam, aes(x = reorder(host_Family, Active_Rate_pct), y = Active_Rate_pct, fill = host_Phylum)) +
  geom_col(width = 0.7, color = "black", linewidth = 0.3) +
  geom_text(aes(label = sprintf("%.1f%% (n=%d/%d)", Active_Rate_pct, Active_Prophages, Total_Prophages)),
            hjust = -0.05, size = 3) +
  coord_flip() +
  scale_fill_manual(values = PHYLUM_COLORS, name = "Host Phylum", na.value = "grey80") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.3))) +
  labs(
    title = "Top 15 Host Families by Activation Rate",
    x = NULL,
    y = "Active Rate (%) [Active / Total Prophages]"
  ) +
  theme_bw(base_size = 11) +
  theme(
    axis.text.y = element_text(face = "italic"),
    plot.title = element_text(face = "bold"),
    legend.position = "right"
  )

ggsave(file.path(out_dir, "Host_Family_Activation_Bubble.pdf"), p_bubble, width = 10, height = 6.5, device = cairo_pdf)
ggsave(file.path(out_dir, "Host_Family_Activation_Rate_Bar.pdf"), p_bar, width = 9.5, height = 6, device = cairo_pdf)