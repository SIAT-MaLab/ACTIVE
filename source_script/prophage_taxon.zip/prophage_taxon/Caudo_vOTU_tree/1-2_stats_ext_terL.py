import pandas as pd
from Bio import SeqIO
import matplotlib.pyplot as plt
import sys

MAP_FILE = "../vOTU/genome_to_vOTU.tsv"
ANNOT_FILE = "../../metadata/allpharokka_annot.tsv"
CLASS_FILE = "../../metadata/uhgv_allpp_taxon_info.tsv"
FASTA_FILE = "allterL.faa"

OUTPUT_FASTA = "vOTU_terL_for_tree.faa"
OUTPUT_TSV = "vOTU_selection_summary.tsv"

PLOT1_PREFIX = "1_caudoviricetes_terL_annotation_rate"
PLOT2_PREFIX = "2_vOTU_terL_extraction_pie"

plt.rcParams['font.sans-serif'] = 'DejaVu Sans'
plt.rcParams['axes.edgecolor'] = 'black'
plt.rcParams['axes.linewidth'] = 1.2

def plot_caudoviricetes_bar(genome_count, total_genomes, votu_count, total_votus):
    levels = ['Genome Level', 'vOTU Level']
    counts = [genome_count, votu_count]
    totals = [total_genomes, total_votus]
    percentages = [(c / t * 100) if t > 0 else 0 for c, t in zip(counts, totals)]
    colors = ['#4E84C4', '#D16103']

    fig, ax = plt.subplots(figsize=(6, 5.5))
    bars = ax.bar(levels, percentages, color=colors, width=0.5, edgecolor='black', linewidth=1)

    for bar, pct, cnt, tot in zip(bars, percentages, counts, totals):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2., height + 2,
                f"{pct:.1f}%\n({cnt}/{tot})",
                ha='center', va='bottom', fontsize=11, fontweight='bold', color='black')

    ax.set_ylim(0, 115)
    ax.set_ylabel("TerL Annotation Rate (%)", fontsize=12, fontweight='bold')
    ax.set_title("TerL Annotation Rate in Caudoviricetes", fontsize=14, fontweight='bold', pad=25)
    plt.suptitle(f"Total Genomes: {total_genomes} | Total vOTUs: {total_votus}", 
                 fontsize=10, color='gray', y=0.91)

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=11)

    plt.tight_layout()
    plt.savefig(f"{PLOT1_PREFIX}.pdf")
    plt.savefig(f"{PLOT1_PREFIX}.png", dpi=300)
    plt.close()

def plot_extraction_pie(success_cnt, rep_cnt, rescue_cnt, no_terl_cnt, multi_cnt, error_cnt):
    labels = [
        f"Successfully extracted\n(Total: {success_cnt} | Rep: {rep_cnt}, Rescue: {rescue_cnt})",
        f"No TerL\n(n = {no_terl_cnt})",
        f"Multicopy TerL\n(n = {multi_cnt})"
    ]
    sizes = [success_cnt, no_terl_cnt, multi_cnt]
    colors = ['#2b8cbe', '#bdbdbd', '#e34a33']
    explode = (0.03, 0, 0)

    if error_cnt > 0:
        labels.append(f"Missing in FASTA\n(n = {error_cnt})")
        sizes.append(error_cnt)
        colors.append('#feb24c')
        explode = (0.03, 0, 0, 0)

    filtered_data = [(l, s, c, e) for l, s, c, e in zip(labels, sizes, colors, explode) if s > 0]
    labels, sizes, colors, explode = zip(*filtered_data)

    fig, ax = plt.subplots(figsize=(8, 6))
    wedges, texts, autotexts = ax.pie(
        sizes, 
        explode=explode, 
        labels=None,
        autopct='%1.1f%%',
        pctdistance=0.65,
        startangle=140, 
        colors=colors,
        wedgeprops={'edgecolor': 'white', 'linewidth': 1.5},
        textprops={'fontsize': 11, 'fontweight': 'bold', 'color': 'white'}
    )

    for autotext, color in zip(autotexts, colors):
        if color == '#bdbdbd':
            autotext.set_color('black')

    ax.legend(wedges, labels, title="vOTU Categories", loc="center left", 
              bbox_to_anchor=(0.95, 0.5), fontsize=10.5, title_fontsize=11, frameon=False)

    total_votus = sum(sizes)
    ax.set_title(f"vOTU TerL Extraction Summary (Total vOTUs = {total_votus})", 
                 fontsize=14, fontweight='bold', pad=15)

    plt.tight_layout()
    plt.savefig(f"{PLOT2_PREFIX}.pdf", bbox_inches='tight')
    plt.savefig(f"{PLOT2_PREFIX}.png", dpi=300, bbox_inches='tight')
    plt.close()

def main():
    df_map = pd.read_csv(MAP_FILE, sep='\t', header=None, names=['Genome', 'vOTU', 'Rep'], dtype=str)
    for col in ['Genome', 'vOTU', 'Rep']:
        df_map[col] = df_map[col].str.replace('-', '_', regex=False)

    votu_dict = {}
    for genome, votu, rep in zip(df_map['Genome'], df_map['vOTU'], df_map['Rep']):
        if votu not in votu_dict:
            votu_dict[votu] = {'rep': rep, 'members': []}
        if genome != rep:
            votu_dict[votu]['members'].append(genome)

    df_annot = pd.read_csv(ANNOT_FILE, sep='\t', usecols=['gene', 'contig', 'annot'], dtype=str)
    mask = df_annot['annot'].str.contains("terminase large", case=False, na=False)
    df_terl = df_annot[mask].copy()

    df_terl['gene'] = df_terl['gene'].str.replace('-', '_', regex=False)
    df_terl['contig'] = df_terl['contig'].str.replace('-', '_', regex=False)

    genome_terl_map = {}
    valid_genes = set()
    for genome, gene_id in zip(df_terl['contig'], df_terl['gene']):
        if genome not in genome_terl_map:
            genome_terl_map[genome] = []
        genome_terl_map[genome].append(gene_id)
        valid_genes.add(gene_id)

    df_class = pd.read_csv(CLASS_FILE, sep='\t', usecols=['genome_id', 'ictv_lineage'], dtype=str)
    df_class['genome_id'] = df_class['genome_id'].str.replace('-', '_', regex=False)

    caudo_genomes_set = set(
        df_class[df_class['ictv_lineage'].str.contains("Caudoviricetes", case=False, na=False)]['genome_id']
    )

    df_map_caudo = df_map[df_map['Genome'].isin(caudo_genomes_set)].copy()
    df_map_caudo['has_terL'] = df_map_caudo['Genome'].isin(genome_terl_map)

    total_caudo_genomes = df_map_caudo['Genome'].nunique()
    caudo_genome_terl_cnt = df_map_caudo[df_map_caudo['has_terL']]['Genome'].nunique()

    votu_caudo_stats = df_map_caudo.groupby('vOTU')['has_terL'].any()
    total_caudo_votus = len(votu_caudo_stats)
    caudo_votu_terl_cnt = votu_caudo_stats.sum()

    plot_caudoviricetes_bar(caudo_genome_terl_cnt, total_caudo_genomes, caudo_votu_terl_cnt, total_caudo_votus)

    seq_dict = {}
    try:
        for record in SeqIO.parse(FASTA_FILE, "fasta"):
            clean_id = record.id.replace('-', '_')
            if clean_id in valid_genes:
                seq_dict[clean_id] = str(record.seq)
    except FileNotFoundError:
        sys.exit(1)

    summary_records = []
    fasta_records = []

    for votu, info in votu_dict.items():
        rep_genome = info['rep']
        members = info['members']

        selected_gene = None
        selected_genome = None
        selection_type = None
        category = None
        note = ""

        rep_terls = genome_terl_map.get(rep_genome, [])

        if len(rep_terls) == 1:
            selected_gene = rep_terls[0]
            selected_genome = rep_genome
            selection_type = "Representative"
            note = "Pass: Representative has unique TerL"
        else:
            failure_reason = "Rep has 0 TerL" if len(rep_terls) == 0 else f"Rep has {len(rep_terls)} TerLs"
            found_rescue = False

            for member in members:
                mem_terls = genome_terl_map.get(member, [])
                if len(mem_terls) == 1:
                    selected_gene = mem_terls[0]
                    selected_genome = member
                    selection_type = "Member_Rescue"
                    note = f"Pass: {failure_reason}, found valid member"
                    found_rescue = True
                    break

            if not found_rescue:
                selection_type = "Failed"
                all_counts = [len(rep_terls)] + [len(genome_terl_map.get(m, [])) for m in members]
                if max(all_counts) == 0:
                    category = "No_TerL"
                    note = "Fail: 0 TerL across rep and all members"
                else:
                    category = "Multicopy_TerL"
                    note = f"Fail: {failure_reason}, only multicopy (or 0) TerL in members"

        if selected_gene:
            if selected_gene in seq_dict:
                header = f"{votu} original_id={selected_gene} source={selection_type}"
                fasta_records.append(f">{header}\n{seq_dict[selected_gene]}\n")
                summary_records.append({
                    'vOTU': votu,
                    'Status': 'Selected',
                    'Category': 'Successfully_Extracted',
                    'Selection_Type': selection_type,
                    'Selected_Genome': selected_genome,
                    'Selected_Gene': selected_gene,
                    'Note': note
                })
            else:
                summary_records.append({
                    'vOTU': votu,
                    'Status': 'Error',
                    'Category': 'Missing_in_FASTA',
                    'Selection_Type': selection_type,
                    'Selected_Genome': selected_genome,
                    'Selected_Gene': selected_gene,
                    'Note': "Gene found in annot but missing in FASTA file"
                })
        else:
            summary_records.append({
                'vOTU': votu,
                'Status': 'Not_Found',
                'Category': category,
                'Selection_Type': 'None',
                'Selected_Genome': 'None',
                'Selected_Gene': 'None',
                'Note': note
            })

    df_summary = pd.DataFrame(summary_records)
    cols = ['vOTU', 'Status', 'Category', 'Selection_Type', 'Selected_Genome', 'Selected_Gene', 'Note']
    df_summary = df_summary[cols]
    df_summary.to_csv(OUTPUT_TSV, sep='\t', index=False)

    with open(OUTPUT_FASTA, 'w') as f:
        f.writelines(fasta_records)

    success_cnt = (df_summary['Category'] == 'Successfully_Extracted').sum()
    rep_cnt = ((df_summary['Category'] == 'Successfully_Extracted') & (df_summary['Selection_Type'] == 'Representative')).sum()
    rescue_cnt = ((df_summary['Category'] == 'Successfully_Extracted') & (df_summary['Selection_Type'] == 'Member_Rescue')).sum()
    no_terl_cnt = (df_summary['Category'] == 'No_TerL').sum()
    multi_cnt = (df_summary['Category'] == 'Multicopy_TerL').sum()
    error_cnt = (df_summary['Category'] == 'Missing_in_FASTA').sum()

    plot_extraction_pie(success_cnt, rep_cnt, rescue_cnt, no_terl_cnt, multi_cnt, error_cnt)

if __name__ == "__main__":
    main()