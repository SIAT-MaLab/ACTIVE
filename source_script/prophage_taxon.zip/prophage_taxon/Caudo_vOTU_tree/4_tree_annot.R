library(tidyverse)

user_metadata_path <- "../../metadata/allpp_metadata.tsv"
user_fasta         <- "vOTU_terL_for_tree.faa"
ictv_fasta         <- "refseq_viral_terL_detected.faa"

read_fasta_ids <- function(fasta) {
  readLines(fasta) %>%
    keep(~str_starts(.x, ">")) %>%
    str_remove("^>") %>%
    str_split(" ") %>%
    map_chr(1) %>%
    unique()
}

user_tree_ids <- read_fasta_ids(user_fasta)
ictv_tree_ids <- read_fasta_ids(ictv_fasta)

user_meta <- read_tsv(
  user_metadata_path,
  na = c("", "NA", "na", "Unclassified", "NULL"),
  show_col_types = FALSE
) %>%
  mutate(vOTU_clean = str_replace_all(vOTU, "-", "_"))

ictv_tax_cols <- c("ictv_Order", "ictv_Family", "ictv_Subfamily", "ictv_Genus")
missing_cols  <- setdiff(ictv_tax_cols, names(user_meta))
if (length(missing_cols) > 0) {
  for (col in missing_cols) user_meta[[col]] <- NA_character_
}

user_annot <- user_meta %>%
  filter(vOTU_clean %in% user_tree_ids) %>%
  group_by(vOTU_clean) %>%
  summarise(
    Order     = first(na.omit(ictv_Order)),
    Family    = first(na.omit(ictv_Family)),
    Subfamily = first(na.omit(ictv_Subfamily)),
    Genus     = first(na.omit(ictv_Genus)),

    Total_Genomes = n(),
    Log10_Genomes = log10(n()),

    is_active = if_else(
      any(!is.na(Activity_Score) & Activity_Score >= 0.8),
      "active", "dormant"
    ),
    .groups = "drop"
  ) %>%
  mutate(
    across(c(Order, Family, Subfamily, Genus), ~replace_na(.x, "Unclassified")),
    is_new = if_else(
      Order == "Unclassified" & Family == "Unclassified" &
        Subfamily == "Unclassified" & Genus == "Unclassified",
      "Yes", "No"
    ),
    Source = "User_vOTU"
  ) %>%
  rename(node_id = vOTU_clean)

ictv_annot <- tibble(node_id = ictv_tree_ids) %>%
  mutate(
    Order         = "Unclassified",
    Family        = "Unclassified",
    Subfamily     = "Unclassified",
    Genus         = "Unclassified",
    Total_Genomes = 1,
    Log10_Genomes = 0,
    is_active     = "dormant",
    is_new        = "No",
    Source        = "ICTV"
  )

final_annotation <- tibble(node_id = c(user_tree_ids, ictv_tree_ids)) %>%
  distinct(node_id) %>%
  left_join(bind_rows(user_annot, ictv_annot), by = "node_id") %>%
  mutate(
    Source        = replace_na(Source, "Unknown"),
    across(c(Order, Family, Subfamily, Genus), ~replace_na(.x, "Unclassified")),
    Total_Genomes = replace_na(Total_Genomes, 1),
    Log10_Genomes = replace_na(Log10_Genomes, 0),
    is_new        = replace_na(is_new,    "No"),
    is_active     = replace_na(is_active, "dormant")
  )

write_tsv(final_annotation, "terL_tree_metadata_annotation.tsv")