library(data.table)
library(ggplot2)

setDTthreads(threads = 20)

dist_dir <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/genome_similarity/bindash"
metadata_path <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"
genome_to_votu_path <- "~/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/taxonomy/vOTU/genome_to_vOTU.tsv"

votu_dist_files <- list(
  inphared   = file.path(dist_dir, "vOTU-inphared_dist.txt"),
  prophagedb = file.path(dist_dir, "vOTU-prophagedb_dist.txt"),
  uhgv       = file.path(dist_dir, "vOTU-uhgv_votu_dist.txt")
)

normalize_phage_id <- function(x) {
  x <- as.character(x); x <- basename(x)
  x <- gsub("^allpp\\.part_|^activepp\\.part_|^phage_depth_", "", x)
  x <- gsub("\\.fasta$|\\.fa$|\\.fna$|\\.txt$", "", x, ignore.case = TRUE)
  x <- gsub("\\s.*$", "", x); x <- gsub("-", "_", x); x
}
normalize_votu <- function(x) gsub("-", "_", trimws(as.character(x)))

metadata <- fread(metadata_path, sep = "\t", quote = "")
stopifnot(c("vOTU","vGENUS","vSUBFAM","vFAM") %in% names(metadata))
metadata[, vOTU_norm := normalize_votu(vOTU)]
metadata[, vGENUS    := trimws(as.character(vGENUS))]
metadata[, vSUBFAM   := trimws(as.character(vSUBFAM))]
metadata[, vFAM      := trimws(as.character(vFAM))]

g2v <- fread(genome_to_votu_path, header = FALSE,
             col.names = c("Genome_Contig","vOTU","Rep_Contig"))
g2v[, vOTU_norm    := normalize_votu(vOTU)]
g2v[, rep_id_norm := normalize_phage_id(Rep_Contig)]

get_votus <- function(col, val) {
  unique(metadata[!is.na(get(col)) & get(col) == val &
                  !is.na(vOTU_norm) & vOTU_norm != "", vOTU_norm])
}

votus_g15    <- get_votus("vGENUS",  "vGENUS_15")
votus_g441   <- get_votus("vGENUS",  "vGENUS_441")
votus_s254   <- get_votus("vSUBFAM", "vSUBFAM_254")
votus_f6_all <- get_votus("vFAM",    "vFAM_6")

exclude_votus   <- unique(c(votus_g15, votus_g441, votus_s254))
votus_f6_others <- setdiff(votus_f6_all, exclude_votus)

get_rep_ids <- function(votus) {
  unique(g2v[vOTU_norm %in% votus & !is.na(rep_id_norm), rep_id_norm])
}

rep_ids <- list(
  "vGENUS_15"     = get_rep_ids(votus_g15),
  "vGENUS_441"    = get_rep_ids(votus_g441),
  "vSUBFAM_254"   = get_rep_ids(votus_s254),
  "vFAM_6_others" = get_rep_ids(votus_f6_others)
)

process_dist_file <- function(filepath, db_name) {
  if (!file.exists(filepath)) stop("File not found: ", filepath)
  dt <- fread(filepath, header = FALSE, select = c(1,3),
              col.names = c("query_path","distance"))
  dt[, query_id := normalize_phage_id(query_path)]
  dt[, distance := suppressWarnings(as.numeric(distance))]
  dt <- dt[!is.na(query_id) & query_id != "" & !is.na(distance) & is.finite(distance)]
  setnames(dt[, .(min_dist = min(distance)), by = query_id], "min_dist", db_name)
}

read_dist_matrix <- function(files) {
  Reduce(function(x, y) merge(x, y, by = "query_id", all = TRUE),
         lapply(names(files), function(db) process_dist_file(files[[db]], db)))
}

votu_dist <- read_dist_matrix(votu_dist_files)

melt_with_group <- function(dt, group_label, ids) {
  sub <- dt[query_id %in% ids]
  long <- melt(sub, id.vars = "query_id",
               measure.vars = c("inphared","prophagedb","uhgv"),
               variable.name = "Database", value.name = "Genetic_Distance")
  long <- long[!is.na(Genetic_Distance) & is.finite(Genetic_Distance)]
  long[, Group := group_label]; long
}

plot_df <- rbindlist(
  lapply(names(rep_ids), function(g) melt_with_group(votu_dist, g, rep_ids[[g]])),
  use.names = TRUE
)

group_levels <- c("vGENUS_15","vGENUS_441","vSUBFAM_254","vFAM_6_others")
plot_df[, Group        := factor(Group, levels = group_levels)]
plot_df[, Database_fct := factor(Database, levels = c("inphared","prophagedb","uhgv"))]

db_levels <- c("inphared","prophagedb","uhgv")

kw_df <- rbindlist(lapply(db_levels, function(db) {
  sub <- plot_df[Database == db]
  kt  <- kruskal.test(Genetic_Distance ~ Group, data = sub)
  data.table(Database = db,
             chi2 = as.numeric(kt$statistic),
             df   = as.numeric(kt$parameter),
             p_value = kt$p.value)
}))
kw_df[, p_adj := p.adjust(p_value, "BH")]
fwrite(kw_df, file.path(dist_dir, "four_groups_kruskal.tsv"), sep = "\t")

pw_list <- list(); k <- 1
for (db in db_levels) {
  for (i in 1:(length(group_levels) - 1)) {
    for (j in (i + 1):length(group_levels)) {
      g1 <- group_levels[i]; g2 <- group_levels[j]
      x1 <- plot_df[Group == g1 & Database == db, Genetic_Distance]
      x2 <- plot_df[Group == g2 & Database == db, Genetic_Distance]
      if (length(x1) < 2 || length(x2) < 2) next
      wt <- wilcox.test(x1, x2, exact = FALSE)
      pw_list[[k]] <- data.table(
        Database = db, Group1 = g1, Group2 = g2,
        n1 = length(x1), n2 = length(x2),
        median1 = median(x1), median2 = median(x2),
        W = as.numeric(wt$statistic), p_value = wt$p.value
      )
      k <- k + 1
    }
  }
}
pw_df <- rbindlist(pw_list)
pw_df[, p_adj := p.adjust(p_value, method = "BH")]
fwrite(pw_df, file.path(dist_dir, "four_groups_pairwise_wilcox.tsv"), sep = "\t")

print(kw_df)
print(pw_df)

n_map <- plot_df[, .(n = uniqueN(query_id)), by = Group]

color_palette <- c(
  "vGENUS_15"     = "#E71D36",
  "vGENUS_441"    = "#F4A261",
  "vSUBFAM_254"   = "#2A9D8F",
  "vFAM_6_others" = "#264653"
)

format_p <- function(p) {
  ifelse(is.na(p), "p = NA",
         ifelse(p < 0.001, "p < 0.001",
                paste0("p = ", formatC(p, format = "f", digits = 3))))
}

annot <- kw_df[, .(Database_ref = Database,
                   label = paste0("KW ", format_p(p_adj)))]
annot[, x_pos := match(Database_ref, db_levels)]
max_y <- plot_df[, .(max_y = max(Genetic_Distance)), by = Database]
annot <- merge(annot, max_y, by.x = "Database_ref", by.y = "Database",
               all.x = TRUE)
annot[, y_pos := max_y + 0.03]

p <- ggplot(plot_df, aes(x = Database_fct, y = Genetic_Distance, fill = Group)) +
  geom_boxplot(position = position_dodge(width = 0.85), width = 0.65,
               alpha = 0.85, outlier.shape = NA,
               color = "black", linewidth = 0.5) +
  geom_text(data = annot, aes(x = x_pos, y = y_pos, label = label),
            inherit.aes = FALSE, size = 3, fontface = "bold.italic") +
  scale_x_discrete(labels = c(inphared = "INPHARED",
                              prophagedb = "ProphageDB",
                              uhgv = "UHGV")) +
  scale_fill_manual(values = color_palette) +
  scale_y_continuous(expand = expansion(mult = c(0.04, 0.14))) +
  theme_bw(base_size = 12) +
  labs(
    title = "Reference Database Genetic Distance Comparison (Four Groups)",
    subtitle = paste0(
      "vGENUS_15 (n = ", n_map[Group == "vGENUS_15",     n], ") | ",
      "vGENUS_441 (n = ", n_map[Group == "vGENUS_441",   n], ") | ",
      "vSUBFAM_254 (n = ", n_map[Group == "vSUBFAM_254", n], ") | ",
      "vFAM_6 others (n = ", n_map[Group == "vFAM_6_others", n], ")\n",
      "*KW labels = Kruskal-Wallis global test, BH-adjusted p. ",
      "Pairwise Wilcoxon results in TSV."
    ),
    x = "Reference Database", y = "Min bindash Distance",
    fill = "Taxonomic Group"
  ) +
  theme(
    axis.text.x     = element_text(size = 12, face = "bold"),
    axis.text.y     = element_text(size = 11),
    axis.title      = element_text(size = 13, face = "bold"),
    plot.title      = element_text(size = 14, face = "bold"),
    plot.subtitle   = element_text(size = 9.5, color = "grey25", lineheight = 1.15),
    legend.position = "top",
    legend.title    = element_text(size = 11, face = "bold"),
    legend.text     = element_text(size = 10.5),
    panel.grid.major.x = element_blank(),
    panel.grid.minor   = element_blank()
  )

out_pdf <- file.path(dist_dir, "four_groups_fam6_others_mindist.pdf")
ggsave(out_pdf, p, width = 9.5, height = 6.2, dpi = 300)