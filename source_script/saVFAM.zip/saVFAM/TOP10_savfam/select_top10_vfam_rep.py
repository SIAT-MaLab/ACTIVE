#!/usr/bin/env python3

from pathlib import Path
from copy import deepcopy
import subprocess
import shutil
import sys

import pandas as pd
from Bio import SeqIO


METADATA_FILE = Path("../../../metadata/allpp_metadata.tsv")
MAPPING_FILE = Path("../../../taxonomy/vOTU/genome_to_vOTU.tsv")
STATS_FILE = Path("../../sa_prophage_results/stats_baseline_vFAM.tsv")
ALL_FASTA = Path("../../../metadata/allpp.fasta")

OUTDIR = Path(".")
BY_VFAM_DIR = OUTDIR / "by_vFAM"
COMBINED_FASTA = OUTDIR / "TOP10fam.fasta"
ANNOT_DIR = OUTDIR / "annot"

PHAROKKA_DB = Path("/home/huangyan/databaseHY/pharokka_v1.8.0_databases")
PHAROKKA_THREADS = 18

TOP_N = 10
RUN_PHAROKKA = True

FORCE_OVERWRITE = False

HIERARCHY_COLS = ["vFAM", "vSUBFAM", "vGENUS", "vSUBGEN"]


def die(message):
    raise SystemExit(message)


def clean_text(value):
    if pd.isna(value):
        return ""
    return str(value).strip()


def normalize_phage(value):
    text = clean_text(value)
    return text.split()[0].replace("-", "_") if text else ""


def require_columns(df, columns, filename):
    missing = [col for col in columns if col not in df.columns]
    if missing:
        die(f"{filename} missing columns: {', '.join(missing)}")


def choose_largest(df, column):
    counts = (
        df.groupby(column)["norm_phage"]
        .nunique()
        .rename("Member_Count")
        .reset_index()
        .sort_values(
            ["Member_Count", column],
            ascending=[False, True],
        )
    )

    if counts.empty:
        die(f"No selectable {column}")

    selected_id = counts.iloc[0][column]
    count = int(counts.iloc[0]["Member_Count"])

    return selected_id, count, df[df[column] == selected_id].copy()


for path in [METADATA_FILE, MAPPING_FILE, STATS_FILE, ALL_FASTA]:
    if not path.is_file():
        die(f"Input file not found: {path.resolve()}")

OUTDIR.mkdir(parents=True, exist_ok=True)

stats = pd.read_csv(STATS_FILE, sep="\t", dtype=str)

require_columns(
    stats,
    ["vFAM", "Genome_Count", "Significance_Type"],
    STATS_FILE,
)

for col in ["vFAM", "Genome_Count", "Significance_Type"]:
    stats[col] = stats[col].map(clean_text)

sig = stats[stats["Significance_Type"] == "Significant"].copy()

if sig.empty:
    die("No Significant records")

if (sig["vFAM"] == "").any():
    die("Empty vFAM")

if sig["vFAM"].duplicated().any():
    duplicated = sig.loc[
        sig["vFAM"].duplicated(keep=False), "vFAM"
    ].unique()
    die(
        "Duplicated vFAM: "
        + ", ".join(duplicated)
    )

sig["Genome_Count_num"] = pd.to_numeric(
    sig["Genome_Count"], errors="coerce"
)

if sig["Genome_Count_num"].isna().any():
    die("Non-numeric Genome_Count")

top = (
    sig.sort_values(
        ["Genome_Count_num", "vFAM"],
        ascending=[False, True],
    )
    .head(TOP_N)
    .reset_index(drop=True)
)

top.insert(0, "Rank", range(1, len(top) + 1))

top.drop(columns="Genome_Count_num").to_csv(
    OUTDIR / "TOP10_significant_vFAM.tsv",
    sep="\t",
    index=False,
)

meta = pd.read_csv(METADATA_FILE, sep="\t", dtype=str)

require_columns(
    meta,
    ["phage_id", "vOTU"] + HIERARCHY_COLS,
    METADATA_FILE,
)

for col in ["phage_id", "vOTU"] + HIERARCHY_COLS:
    meta[col] = meta[col].map(clean_text)

meta["norm_phage"] = meta["phage_id"].map(normalize_phage)

mapping = pd.read_csv(
    MAPPING_FILE,
    sep="\t",
    header=None,
    dtype=str,
)

if mapping.shape[1] != 3:
    die("genome_to_vOTU.tsv must have three columns")

mapping.columns = ["genome_id", "mapped_vOTU", "rep_genome"]

mapping["norm_phage"] = mapping["genome_id"].map(normalize_phage)
mapping["mapped_vOTU"] = mapping["mapped_vOTU"].map(clean_text)
mapping["rep_genome"] = mapping["rep_genome"].map(normalize_phage)

if (
    mapping[["norm_phage", "mapped_vOTU", "rep_genome"]]
    .eq("")
    .any()
    .any()
):
    die("Empty genome ID, vOTU, or representative ID")

mapping = mapping[
    ["norm_phage", "mapped_vOTU", "rep_genome"]
].drop_duplicates()

if mapping["norm_phage"].duplicated().any():
    die("Duplicated normalized phage ID")

rep_counts = mapping.groupby("mapped_vOTU")["rep_genome"].nunique()
bad_votus = rep_counts[rep_counts > 1]

if not bad_votus.empty:
    die(
        "Multiple representatives for vOTU: "
        + ", ".join(bad_votus.index[:10])
    )

rep_by_votu = (
    mapping.drop_duplicates("mapped_vOTU")
    .set_index("mapped_vOTU")["rep_genome"]
    .to_dict()
)

target = meta[meta["vFAM"].isin(top["vFAM"])].copy()

if target.empty:
    die("No metadata for TOP10 vFAM")

required = ["norm_phage", "vOTU"] + HIERARCHY_COLS

if target[required].eq("").any().any():
    bad_cols = [
        col for col in required if target[col].eq("").any()
    ]
    die(
        "Missing metadata fields: "
        + ", ".join(bad_cols)
    )

target = target[
    ["norm_phage", "vOTU"] + HIERARCHY_COLS
].drop_duplicates()

if target["norm_phage"].duplicated().any():
    die("Conflicting taxonomy for normalized phage ID")

target = target.merge(
    mapping,
    on="norm_phage",
    how="left",
    validate="one_to_one",
)

missing = target["mapped_vOTU"].isna()
if missing.any():
    examples = target.loc[missing, "norm_phage"].head(10).tolist()
    die(
        f"{missing.sum()} TOP10 members absent from mapping, e.g.: "
        + ", ".join(examples)
    )

mismatch = target["vOTU"] != target["mapped_vOTU"]

if mismatch.any():
    die("vOTU mismatch between metadata and genome_to_vOTU")

selections = []

for _, fam_row in top.iterrows():
    vfam = fam_row["vFAM"]
    sub = target[target["vFAM"] == vfam].copy()

    if sub.empty:
        die(f"{vfam} has no metadata members")

    result = {
        "Rank": int(fam_row["Rank"]),
        "vFAM": vfam,
        "Stats_Genome_Count": fam_row["Genome_Count"],
        "Metadata_vFAM_Member_Count": int(sub["norm_phage"].nunique()),
    }

    for column in ["vSUBFAM", "vGENUS", "vSUBGEN", "vOTU"]:
        selected_id, count, sub = choose_largest(sub, column)
        result[column] = selected_id
        result[f"{column}_Member_Count"] = count

    votu = result["vOTU"]
    result["Representative_Genome"] = rep_by_votu[votu]
    selections.append(result)

selected = pd.DataFrame(selections)

if selected["Representative_Genome"].duplicated().any():
    die("Duplicate representative genome selected")

wanted = set(selected["Representative_Genome"])
found = {}

for record in SeqIO.parse(str(ALL_FASTA), "fasta"):
    norm_id = normalize_phage(record.id)

    if norm_id in wanted:
        if norm_id in found:
            die(f"Duplicated representative ID in allpp.fasta: {norm_id}")
        found[norm_id] = record

missing_reps = wanted - set(found)

if missing_reps:
    die(
        "Representative(s) not found in allpp.fasta:\n"
        + "\n".join(sorted(missing_reps))
    )

BY_VFAM_DIR.mkdir(parents=True, exist_ok=True)
combined_records = []
sequence_lengths = []
output_ids = []

for _, row in selected.iterrows():
    rep_id = row["Representative_Genome"]
    record = deepcopy(found[rep_id])

    new_id = f"{row['vFAM']}__{row['vOTU']}__{rep_id}"

    record.id = new_id
    record.name = new_id
    record.description = (
        f"vFAM={row['vFAM']} "
        f"vSUBFAM={row['vSUBFAM']} "
        f"vGENUS={row['vGENUS']} "
        f"vSUBGEN={row['vSUBGEN']} "
        f"vOTU={row['vOTU']} "
        f"representative={rep_id} "
        f"length={len(record.seq)}"
    )

    combined_records.append(record)
    sequence_lengths.append(len(record.seq))
    output_ids.append(new_id)

    SeqIO.write(
        [record],
        str(BY_VFAM_DIR / f"{row['vFAM']}_rep.fasta"),
        "fasta",
    )

SeqIO.write(combined_records, str(COMBINED_FASTA), "fasta")

selected["Sequence_Length"] = sequence_lengths
selected["Output_FASTA_ID"] = output_ids

selected.to_csv(
    OUTDIR / "TOP10fam_selection.tsv",
    sep="\t",
    index=False,
)

if not RUN_PHAROKKA:
    sys.exit(0)

pharokka = shutil.which("pharokka.py")

if pharokka is None:
    die("pharokka.py not found")

if not PHAROKKA_DB.is_dir():
    die(f"Pharokka database not found: {PHAROKKA_DB}")

if ANNOT_DIR.exists() and not FORCE_OVERWRITE:
    die(
        f"{ANNOT_DIR} exists; set FORCE_OVERWRITE=True to overwrite"
    )

cmd = [
    pharokka,
    "-i", str(COMBINED_FASTA),
    "-o", str(ANNOT_DIR),
    "-d", str(PHAROKKA_DB),
    "-t", str(PHAROKKA_THREADS),
    "-p", "TOP10fam",
    "-m",
    "-s",
    "--meta_hmm",
    "--skip_mash",
]

if FORCE_OVERWRITE:
    cmd.append("-f")

log_file = OUTDIR / "pharokka.log"

with log_file.open("w") as handle:
    result = subprocess.run(
        cmd,
        stdout=handle,
        stderr=subprocess.STDOUT,
        check=False,
    )

if result.returncode != 0:
    die(
        f"Pharokka failed with exit code {result.returncode}; see {log_file}"
    )