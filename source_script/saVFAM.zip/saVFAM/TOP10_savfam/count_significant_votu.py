#!/usr/bin/env python3

from pathlib import Path
import pandas as pd

METADATA_FILE = Path("../../../metadata/allpp_metadata.tsv")
VOTU_STATS_FILE = Path("../../sa_prophage_results/stats_baseline_vOTU.tsv")

TOP_FAM_FILE = Path("TOP10_significant_vFAM.tsv")
SELECTION_FILE = Path("TOP10fam_selection.tsv")


def read_table(path, required):
    df = pd.read_csv(path, sep="\t", dtype=str)
    missing = set(required) - set(df.columns)
    if missing:
        raise SystemExit(f"Missing columns in {path}: {sorted(missing)}")

    for col in required:
        df[col] = df[col].fillna("").str.strip()

    return df


top = read_table(TOP_FAM_FILE, ["Rank", "vFAM"])
selected = read_table(SELECTION_FILE, ["vFAM", "vOTU"])
meta = read_table(METADATA_FILE, ["vFAM", "vOTU"])
stats = read_table(VOTU_STATS_FILE, ["vOTU", "Significance_Type"])

if stats["vOTU"].eq("").any():
    raise SystemExit("Empty vOTU in vOTU stats")

if stats["vOTU"].duplicated().any():
    raise SystemExit("Duplicated vOTU in vOTU stats")

if stats["Significance_Type"].eq("").any():
    raise SystemExit("Empty Significance_Type in vOTU stats")

stat_cols = [
    col for col in [
        "vOTU",
        "Significance_Type",
        "Genome_Count",
        "Count_Active",
        "OR",
        "p_value",
        "p.adj",
    ]
    if col in stats.columns
]

stat_info = stats[stat_cols].rename(
    columns={
        col: f"vOTU_stats_{col}"
        for col in stat_cols
        if col != "vOTU"
    }
)

status_col = "vOTU_stats_Significance_Type"


def attach_stats(df):
    result = df.merge(
        stat_info,
        on="vOTU",
        how="left",
        validate="many_to_one",
        indicator="_stats_match",
    )

    result["In_vOTU_stats"] = result["_stats_match"].eq("both")
    result[status_col] = result[status_col].fillna("Not_in_stats")
    result["Is_Significant"] = result[status_col].eq("Significant")

    return result.drop(columns="_stats_match")


representatives = attach_stats(selected)

representatives.to_csv(
    "TOP10fam_representative_vOTU_significance.tsv",
    sep="\t",
    index=False,
)

unique_reps = representatives.drop_duplicates("vOTU")

rep_total = len(unique_reps)
rep_tested = int(unique_reps["In_vOTU_stats"].sum())
rep_significant = int(unique_reps["Is_Significant"].sum())

members = meta[
    meta["vFAM"].isin(top["vFAM"])
].copy()

missing_votu_rows = int(members["vOTU"].eq("").sum())

pairs = (
    members.loc[members["vOTU"] != "", ["vFAM", "vOTU"]]
    .drop_duplicates()
)

details = attach_stats(pairs)

details.to_csv(
    "TOP10fam_all_vOTU_significance.tsv",
    sep="\t",
    index=False,
)

counts = (
    details.groupby("vFAM")
    .agg(
        Total_vOTU=("vOTU", "nunique"),
        In_stats_vOTU=("In_vOTU_stats", "sum"),
        Significant_vOTU=("Is_Significant", "sum"),
    )
    .reset_index()
)

summary = top[["Rank", "vFAM"]].merge(
    counts,
    on="vFAM",
    how="left",
    validate="one_to_one",
)

for col in ["Total_vOTU", "In_stats_vOTU", "Significant_vOTU"]:
    summary[col] = summary[col].fillna(0).astype(int)

summary["Non_significant_in_stats_vOTU"] = (
    summary["In_stats_vOTU"] - summary["Significant_vOTU"]
)
summary["Not_in_stats_vOTU"] = (
    summary["Total_vOTU"] - summary["In_stats_vOTU"]
)

summary["Significant_pct_all"] = (
    100 * summary["Significant_vOTU"]
    / summary["Total_vOTU"].replace(0, float("nan"))
).round(2)

summary["Significant_pct_in_stats"] = (
    100 * summary["Significant_vOTU"]
    / summary["In_stats_vOTU"].replace(0, float("nan"))
).round(2)

summary["Rank"] = pd.to_numeric(summary["Rank"], errors="raise")
summary = summary.sort_values("Rank")

summary.to_csv(
    "TOP10fam_vOTU_significance_summary.tsv",
    sep="\t",
    index=False,
)

all_unique = details.drop_duplicates("vOTU")
total = len(all_unique)
tested = int(all_unique["In_vOTU_stats"].sum())
significant = int(all_unique["Is_Significant"].sum())