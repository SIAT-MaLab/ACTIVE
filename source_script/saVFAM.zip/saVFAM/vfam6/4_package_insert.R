#!/usr/bin/env Rscript
required_packages <- c("tidyverse", "ggstatsplot", "patchwork", "purrr", "scales")
new_packages <- required_packages[!(required_packages %in% installed.packages()[, "Package"])]
if (length(new_packages)) install.packages(new_packages)

library(tidyverse)
library(ggstatsplot)
library(patchwork)
library(purrr)
library(scales)

ANNOT_FILE <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/activity/rep_sataxon/6_vfam/3_phylo_tree/pharokka_annot/pharokka_cds_final_merged_output.tsv"
META_FILE  <- "/home/huangyan/experiment/SPA/3/gut_isolate/new_analysis_260529/prophage/metadata/allpp_metadata.tsv"

OUT_DIR <- "4_analysis_package"
TSV_OUT <- file.path(OUT_DIR, "packaging_module_structure_integrated.tsv")

COLLAPSE_THRESHOLD   <- 10
MIN_GENOME_PER_SUBFAM <- 3
MAX_AB_DIST          <- 17
PORTAL_WINDOW        <- 5

PHYLUM_COLORS <- c(
  "Bacillota_A" = "#dce8ef", "Bacillota_C" = "#add2e5", "Bacillota_I" = "#34666b", "Bacillota" = "#7abbce",
  "Bacillota_B" = "#769499", "Actinomycetota" = "#f5cfa6", "Bacteroidota" = "#efe3ef", "Verrucomicrobiota" = "#d4d68a",
  "Pseudomonadota" = "#e68f9f", "Desulfobacterota" = "#d5d5d6", "Fusobacteriota" = "#b7a3c9", "Synergistota" = "#414141"
)

if (!dir.exists(OUT_DIR)) dir.create(OUT_DIR, recursive = TRUE)

normalize_id <- function(x) {
  x %>%
    as.character() %>%
    str_replace_all("-", "_") %>%
    str_remove_all("^phage_depth_") %>%
    str_remove_all("\\.txt$|\\.fasta$|\\.fna$|\\.fa$")
}

df_annot <- read_tsv(ANNOT_FILE, show_col_types = FALSE) %>%
  arrange(contig, start)

extract_module <- function(df) {
  df <- df %>% mutate(idx = row_number())
  
  idx_A <- df$idx[grepl("HNH endonuclease|HNH", df$annot, ignore.case = TRUE)]
  idx_B <- df$idx[grepl("terminase small subunit", df$annot, ignore.case = TRUE)]
  idx_C <- df$idx[grepl("terminase large subunit", df$annot, ignore.case = TRUE)]
  idx_P <- df$idx[grepl("portal protein", df$annot, ignore.case = TRUE)]
  
  if (length(idx_B) == 0) return(NULL)
  
  results <- list()
  for (b in idx_B) {
    strand_b <- df$strand[b]
    
    valid_a <- NA
    cands_a <- if (strand_b == "+") idx_A[idx_A < b & df$strand[idx_A] == "+"] else idx_A[idx_A > b & df$strand[idx_A] == "-"]
    if (length(cands_a) > 0) valid_a <- if (strand_b == "+") max(cands_a) else min(cands_a)
    has_a <- !is.na(valid_a) && abs(valid_a - b) <= MAX_AB_DIST
    if (!has_a) valid_a <- NA
    
    valid_c <- NA
    cands_c <- if (strand_b == "+") idx_C[idx_C > b & df$strand[idx_C] == "+"] else idx_C[idx_C < b & df$strand[idx_C] == "-"]
    if (length(cands_c) > 0) valid_c <- if (strand_b == "+") min(cands_c) else max(cands_c)
    
    has_c <- FALSE
    if (!is.na(valid_c)) {
      p_cands <- if (strand_b == "+") idx_P[idx_P > valid_c & idx_P <= (valid_c + PORTAL_WINDOW) & df$strand[idx_P] == "+"] 
                 else idx_P[idx_P < valid_c & idx_P >= (valid_c - PORTAL_WINDOW) & df$strand[idx_P] == "-"]
      if (length(p_cands) > 0) has_c <- TRUE
    }
    if (!has_c) valid_c <- NA
    
    if (!has_a && !has_c) next
    
    dist_ab <- if (has_a) abs(valid_a - b) - 1 else 9999
    score <- (if (has_a && has_c) 20000 else 10000) - dist_ab
    results[[length(results) + 1]] <- list(a = valid_a, b = b, c = valid_c, score = score, strand = strand_b)
  }
  
  if (length(results) == 0) return(NULL)
  
  best <- results[[which.max(sapply(results, function(x) x$score))]]
  
  get_gap <- function(start_i, end_i) {
    if (is.na(start_i) || is.na(end_i)) return(list(cnt = NA, annot = NA, cat = NA))
    mn <- min(start_i, end_i); mx <- max(start_i, end_i)
    if (mn + 1 >= mx) return(list(cnt = 0, annot = "None", cat = "None"))
    sub <- df[(mn + 1):(mx - 1), ]
    list(
      cnt = nrow(sub),
      annot = paste(replace_na(sub$annot, "Unknown"), collapse = ";"),
      cat   = paste(replace_na(sub$category, "Unknown"), collapse = ";")
    )
  }
  
  gap_ab <- get_gap(best$a, best$b)
  gap_bc <- get_gap(best$b, best$c)
  
  tibble(
    Genome = df$contig[1], Module_Strand = best$strand,
    Gene_A_ID = if (is.na(best$a)) NA else df$gene[best$a],
    Gene_B_ID = df$gene[best$b],
    Gene_C_ID = if (is.na(best$c)) NA else df$gene[best$c],
    Gap_HNH_TerS_Count = gap_ab$cnt, Gap_TerS_TerL_Count = gap_bc$cnt,
    Gap_HNH_TerS_Annot = gap_ab$annot, Gap_HNH_TerS_Category = gap_ab$cat,
    Gap_TerS_TerL_Annot = gap_bc$annot, Gap_TerS_TerL_Category = gap_bc$cat
  )
}

df_res <- df_annot %>% split(.$contig) %>% map_dfr(extract_module) %>% mutate(Norm_ID = normalize_id(Genome))

df_meta <- read_tsv(META_FILE, show_col_types = FALSE) %>%
  mutate(Norm_ID = normalize_id(phage_id))

df_final <- left_join(df_res, df_meta %>% select(Norm_ID, vFAM, vSUBFAM, vGENUS, vOTU, host_Phylum), by = "Norm_ID") %>%
  select(-Norm_ID)

write_tsv(df_final, TSV_OUT)

df_base <- df_final %>%
  mutate(
    Gap_HNH_TerS_Count = as.numeric(Gap_HNH_TerS_Count),
    Gap_TerS_TerL_Count = as.numeric(Gap_TerS_TerL_Count)
  ) %>%
  filter(!is.na(Gap_HNH_TerS_Count) & !is.na(Gap_TerS_TerL_Count))

extract_features <- function(data_column, collapse_below = NULL, top_n = 20) {
  exclude <- c("hypothetical protein", "unknown function", "None", "Unknown", "Missing_A", "Missing_C", "", "NA")
  if (is.null(data_column) || all(is.na(data_column))) return(data.frame(Feature = character(0), Count = integer(0)))
  
  raw_counts <- data_column %>%
    as.character() %>%
    str_split(";") %>%
    unlist() %>%
    str_trim() %>%
    .[!(. %in% exclude)] %>%
    table() %>%
    as.data.frame() %>%
    rename(Feature = 1, Count = 2) %>%
    mutate(Feature = as.character(Feature), Count = as.numeric(Count))
  
  if (nrow(raw_counts) == 0) return(raw_counts)
  
  if (!is.null(collapse_below)) {
    kept <- raw_counts %>% filter(Count >= collapse_below)
    others_cnt <- sum(raw_counts$Count[raw_counts$Count < collapse_below])
    if (others_cnt > 0) {
      kept <- bind_rows(kept, tibble(Feature = paste0("Others (<", collapse_below, ")"), Count = others_cnt))
    }
    return(kept %>% arrange(desc(Count)) %>% head(top_n))
  }
  
  raw_counts %>% arrange(desc(Count)) %>% head(top_n)
}

plot_freq_bar_log <- function(data, title, fill_color) {
  if (nrow(data) == 0) return(ggplot() + labs(title = paste(title, "(No data)")))
  
  max_val <- max(data$Count, na.rm = TRUE)
  breaks_val <- unique(c(1, 2, 5, 10, 20, 50, 100, 200, 500, 1000)[c(1, 2, 5, 10, 20, 50, 100, 200, 500, 1000) <= max_val * 1.5])
  if (length(breaks_val) < 2) breaks_val <- c(1, max_val)

  ggplot(data, aes(x = reorder(Feature, Count), y = Count)) +
    geom_bar(stat = "identity", fill = fill_color, alpha = 0.85, width = 0.7) +
    geom_text(aes(label = Count), hjust = -0.2, size = 3.2, color = "black") +
    coord_flip() +
    scale_y_continuous(
      trans = "pseudo_log",
      breaks = breaks_val,
      expand = expansion(mult = c(0, 0.2))
    ) +
    theme_minimal(base_size = 10) +
    labs(title = title, x = "", y = "Count (Pseudo-Log Scale)") +
    theme(
      plot.title = element_text(size = 11, face = "bold"),
      axis.text.y = element_text(size = 9, color = "black"),
      axis.text.x = element_text(size = 8, color = "black")
    )
}

plot_kruskal_wallis <- function(data, group_col, y_col,
                                title_main, palette_name) {
  ggbetweenstats(
    data  = data,
    x     = !!rlang::sym(group_col),
    y     = !!rlang::sym(y_col),
    type  = "nonparametric",
    title = title_main,
    xlab  = group_col,
    ylab  = "Inserted CDS Count",
    package = "ggthemes",
    palette = palette_name,
    plot.type = "violin",
    centrality.plotting = FALSE,
    point.args = list(
      color    = "black",
      alpha    = 0.6,
      size     = 1.8,
      position = ggplot2::position_jitter(width = 0.15, seed = 123)
    ),
    results.subtitle = TRUE,
    pairwise.display = "none",
    p.adjust.method  = "fdr"
  ) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1,
                                     size = 9, face = "bold"))
}

ab_annot_g <- extract_features(df_base$Gap_HNH_TerS_Annot, collapse_below = COLLAPSE_THRESHOLD)
ab_cat_g   <- extract_features(df_base$Gap_HNH_TerS_Category, collapse_below = NULL)

p_g_ab <- plot_freq_bar_log(ab_annot_g, "Top Annotations (AB Gap; <10 merged)", "steelblue") +
          plot_freq_bar_log(ab_cat_g,   "Top Categories (AB Gap)", "darkblue") +
          plot_annotation(title = "Global Functional Content in HNH - TerS Intergenic Region")

bc_annot_g <- extract_features(df_base$Gap_TerS_TerL_Annot, collapse_below = COLLAPSE_THRESHOLD)
bc_cat_g   <- extract_features(df_base$Gap_TerS_TerL_Category, collapse_below = NULL)

p_g_bc <- plot_freq_bar_log(bc_annot_g, "Top Annotations (BC Gap; <10 merged)", "darkorange") +
          plot_freq_bar_log(bc_cat_g,   "Top Categories (BC Gap)", "darkred") +
          plot_annotation(title = "Global Functional Content in TerS - TerL Intergenic Region")

ggsave(file.path(OUT_DIR, "1_Global_Freq_AB_Content.pdf"), p_g_ab, width = 12, height = 6)
ggsave(file.path(OUT_DIR, "2_Global_Freq_BC_Content.pdf"), p_g_bc, width = 12, height = 6)

df_subfam <- df_base %>%
  filter(!is.na(vSUBFAM) & vSUBFAM != "") %>%
  group_by(vSUBFAM) %>%
  filter(n() >= MIN_GENOME_PER_SUBFAM) %>%
  ungroup()

if (length(unique(df_subfam$vSUBFAM)) > 1) {
  p_subfam_ab <- plot_kruskal_wallis(df_subfam, "vSUBFAM", "Gap_HNH_TerS_Count", "CDS between HNH & TerS (AB) across vSUBFAM", "Tableau_10")
  p_subfam_bc <- plot_kruskal_wallis(df_subfam, "vSUBFAM", "Gap_TerS_TerL_Count", "CDS between TerS & TerL (BC) across vSUBFAM", "Classic_10")
  
  ggsave(file.path(OUT_DIR, "5_vSUBFAM_Gap_Count_Comparison.pdf"), p_subfam_ab / p_subfam_bc, width = 14, height = 12)
} else {
}