#!/bin/bash
set -e

usage() {
    echo "Usage: $0 -f <vFAM_fasta> -m <genome_to_vOTU.tsv> -d <database_fasta> -o <output_fasta>"
    echo "  -f : input vFAM FASTA (e.g., vFAM_9_genomes.fasta)"
    echo "  -m : genome_to_vOTU.tsv mapping"
    echo "  -d : reference database FASTA"
    echo "  -o : output representative genome FASTA"
    exit 1
}

while getopts "f:m:d:o:h" opt; do
    case $opt in
        f) VFAM_FASTA=$OPTARG ;;
        m) MAP_TSV=$OPTARG ;;
        d) DB_FASTA=$OPTARG ;;
        o) OUTPUT_FASTA=$OPTARG ;;
        h) usage ;;
        *) usage ;;
    esac
done

if [ -z "$VFAM_FASTA" ] || [ -z "$MAP_TSV" ] || [ -z "$DB_FASTA" ] || [ -z "$OUTPUT_FASTA" ]; then
    usage
fi

grep '^>' "$VFAM_FASTA" | awk '{print $1}' | sed 's/>//' > .tmp_vfam_ids.txt

awk 'FNR==NR {vfam[$1]; next} ($1 in vfam) {print $3}' .tmp_vfam_ids.txt "$MAP_TSV" | sort -u > .tmp_rep_ids.txt

seqkit grep -f .tmp_rep_ids.txt "$DB_FASTA" -o "$OUTPUT_FASTA"

rm -f .tmp_vfam_ids.txt .tmp_rep_ids.txt