#!/usr/bin/env python3

from pathlib import Path
import pandas as pd
from Bio import SeqIO

DIR = Path(".")

QUERY_LABEL = "vFAM_6"
ACTIVITY_CUTOFF = 0.8

FASTA_SOURCES = [
    (DIR / "Heliusvirales_1032_genomes.fna", "Heliusvirales"),
    (DIR / "VFC1.fasta", "VFC1"),
    (DIR / "vFAM_6_genomes.fasta", QUERY_LABEL),
]

VC2_OVERVIEW = (
    DIR / "2_vcontact2/vfam6_genome_by_genome_overview.csv"
)

ALLPP_META_TSV = DIR / "../../../metadata/allpp_metadata.tsv"

BASELINE_STAT_TSV = (
    DIR / "../../sa_prophage_results/stats_baseline_vOTU.tsv"
)

OUT_GENOME_ANNOT = DIR / "2_vcontact2/vfam6_genome_annotated.tsv"


def clean(x):
    if pd.isna(x):
        return None
    s = str(x).strip()
    return None if s in {"", "NA", "N/A", "<NA>", "NaN"} else s


def norm_id(x):
    s = clean(x)
    return s.replace("-", "_") if s is not None else None


def unique_map(keys, values, label):
    result = {}

    for key, value in zip(keys, values):
        key, value = clean(key), clean(value)

        if key is None or value is None:
            continue

        if key in result and result[key] != value:
            raise ValueError(
                f"{label} conflict: {key} -> "
                f"{result[key]} / {value}"
            )

        result[key] = value

    return result


genome_source_map = {}
query_ids = set()

for fasta_file, label in FASTA_SOURCES:
    if not fasta_file.exists():
        raise FileNotFoundError(f"Missing FASTA: {fasta_file}")

    local_ids = set()

    for record in SeqIO.parse(str(fasta_file), "fasta"):
        nid = norm_id(record.id)

        if nid in local_ids:
            raise ValueError(
                f"{fasta_file} has duplicate/conflicting IDs: {nid}"
            )
        local_ids.add(nid)

        if nid in genome_source_map:
            raise ValueError(
                f"Overlapping ID across FASTA files: {nid}"
            )

        genome_source_map[nid] = label

        if label == QUERY_LABEL:
            query_ids.add(nid)


for path in [ALLPP_META_TSV, BASELINE_STAT_TSV, VC2_OVERVIEW]:
    if not path.exists():
        raise FileNotFoundError(f"Missing input file: {path}")

allpp = pd.read_csv(ALLPP_META_TSV, sep="\t", dtype=str)

required_cols = [
    "phage_id", "vOTU", "vFAM", "vSUBFAM", "vGENUS",
    "Activity_Score"
]
missing_cols = set(required_cols) - set(allpp.columns)
if missing_cols:
    raise ValueError(f"metadata missing columns: {sorted(missing_cols)}")

allpp["norm_phage_id"] = allpp["phage_id"].map(norm_id)

for col in ["vOTU", "vFAM", "vSUBFAM", "vGENUS"]:
    allpp[col] = allpp[col].map(clean)

allpp["Activity_Score"] = pd.to_numeric(
    allpp["Activity_Score"], errors="coerce"
)

id_maps = {}
for col in ["vOTU", "vFAM", "vSUBFAM", "vGENUS"]:
    id_maps[col] = unique_map(
        allpp["norm_phage_id"],
        allpp[col],
        f"phage_id -> {col}"
    )

votu_max_act = (
    allpp.dropna(subset=["vOTU"])
    .groupby("vOTU")["Activity_Score"]
    .max()
    .to_dict()
)

baseline = pd.read_csv(
    BASELINE_STAT_TSV, sep="\t", dtype=str
)

for col in ["vOTU", "Significance_Type"]:
    if col not in baseline.columns:
        raise ValueError(f"baseline missing column: {col}")
    baseline[col] = baseline[col].map(clean)

sig_active_votus = set(
    baseline.loc[
        baseline["Significance_Type"] == "Significant",
        "vOTU"
    ].dropna()
)

unmapped = sorted(query_ids - set(id_maps["vOTU"]))
if unmapped:
    raise ValueError(
        f"{len(unmapped)} query genomes cannot match metadata vOTU.\n"
        f"Examples: {', '.join(unmapped[:10])}\n"
        "Check FASTA content and phage_id."
    )

wrong_family = [
    nid for nid in query_ids
    if id_maps["vFAM"].get(nid) not in {None, QUERY_LABEL}
]
if wrong_family:
    examples = [
        f"{nid}: {id_maps['vFAM'][nid]}"
        for nid in sorted(wrong_family)[:10]
    ]
    raise ValueError(
        f"{len(wrong_family)} query genomes are not classified "
        f"as {QUERY_LABEL}:\n" + "\n".join(examples)
    )

vc2_df = pd.read_csv(VC2_OVERVIEW, dtype=str)
annot_rows = []

for _, row in vc2_df.iterrows():
    nid = norm_id(row["Genome"])
    source_origin = genome_source_map.get(nid, "Unknown")

    annotation = {
        "Source_Origin": source_origin,
        "Source_Category": "Unknown",
        "vOTU": None,
        "vFAM": None,
        "vSUBFAM": None,
        "vGENUS": None,
        "vOTU_Max_Activity_Score": None,
        "Is_Active": False,
        "Is_Significantly_Active": False,
    }

    if source_origin == QUERY_LABEL:
        votu = id_maps["vOTU"][nid]
        score = votu_max_act.get(votu)

        annotation.update({
            "Source_Category": QUERY_LABEL,
            "vOTU": votu,
            "vFAM": id_maps["vFAM"].get(nid),
            "vSUBFAM": id_maps["vSUBFAM"].get(nid),
            "vGENUS": id_maps["vGENUS"].get(nid),
            "vOTU_Max_Activity_Score": score,
            "Is_Active": (
                pd.notna(score) and score >= ACTIVITY_CUTOFF
            ),
            "Is_Significantly_Active": votu in sig_active_votus,
        })

    elif source_origin in {"Heliusvirales", "VFC1"}:
        annotation["Source_Category"] = "Reference"

    result = row.to_dict()
    result.update(annotation)
    annot_rows.append(result)

annot_df = pd.DataFrame(annot_rows)

front_cols = [
    "Genome", "Source_Origin", "Source_Category",
    "vOTU", "vFAM", "vSUBFAM", "vGENUS",
    "vOTU_Max_Activity_Score",
    "Is_Active", "Is_Significantly_Active",
    "VC Status", "VC"
]
other_cols = [
    col for col in annot_df.columns if col not in front_cols
]
annot_df = annot_df[front_cols + other_cols]

OUT_GENOME_ANNOT.parent.mkdir(parents=True, exist_ok=True)
annot_df.to_csv(
    OUT_GENOME_ANNOT,
    sep="\t",
    index=False,
    na_rep="NA"
)