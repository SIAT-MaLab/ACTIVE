library(dplyr)
library(ggplot2)

input_file <- "../../../metadata/allpp_metadata.tsv"

target_vfam <- "vFAM_6"
top_n <- 5

output_image <- paste0(target_vfam, "_host_stacked_bar.pdf")
output_table <- paste0(target_vfam, "_host_stacked_bar.tsv")

PHYLUM_COLORS <- c(
  "Bacillota_A"       = "#dce8ef",
  "Bacillota_C"       = "#add2e5",
  "Bacillota_I"       = "#34666b",
  "Bacillota"         = "#7abbce",
  "Bacillota_B"       = "#769499",
  "Actinomycetota"    = "#f5cfa6",
  "Bacteroidota"      = "#efe3ef",
  "Verrucomicrobiota" = "#d4d68a",
  "Pseudomonadota"    = "#e68f9f",
  "Desulfobacterota"  = "#d5d5d6",
  "Fusobacteriota"    = "#b7a3c9",
  "Synergistota"      = "#414141"
)

metadata <- read.delim(
  input_file,
  sep = "\t",
  stringsAsFactors = FALSE,
  check.names = FALSE,
  header = TRUE
)

required_cols <- c("vFAM", "host_Family", "host_Phylum")
if (!all(required_cols %in% names(metadata))) {
  stop("Missing columns: ",
       paste(setdiff(required_cols, names(metadata)), collapse = ", "))
}

prophages <- metadata %>%
  filter(vFAM == target_vfam)

host_info <- prophages %>%
  transmute(
    host_Family = trimws(host_Family),
    host_Phylum = trimws(host_Phylum)
  ) %>%
  filter(
    !is.na(host_Family), host_Family != "",
    !is.na(host_Phylum), host_Phylum != ""
  )

if (nrow(host_info) == 0) {
  stop("No valid host family and phylum records for target vFAM.")
}

family_counts <- host_info %>%
  count(host_Family, name = "count") %>%
  arrange(desc(count), host_Family)

top_families <- head(family_counts$host_Family, top_n)

final_df <- host_info %>%
  mutate(
    family = if_else(
      host_Family %in% top_families,
      host_Family,
      "other"
    ),
    phylum = host_Phylum
  ) %>%
  count(phylum, family, name = "count")

phylum_counts <- final_df %>%
  group_by(phylum) %>%
  summarise(total = sum(count), .groups = "drop") %>%
  arrange(desc(total), phylum)

phylum_levels <- phylum_counts$phylum

final_df <- final_df %>%
  mutate(phylum = factor(phylum, levels = phylum_levels)) %>%
  arrange(phylum, family == "other", desc(count), family) %>%
  mutate(
    percentage = count / sum(count) * 100,
    segment = factor(
      seq_len(n()),
      levels = seq_len(n())
    ),
    label = paste0(family, "\n(n=", count, ")")
  )

phylum_color <- setNames(
  vapply(phylum_levels, function(p) {
    if (p %in% names(PHYLUM_COLORS)) {
      unname(PHYLUM_COLORS[p])
    } else {
      "grey50"
    }
  }, character(1)),
  phylum_levels
)

legend_labels <- setNames(
  paste0(phylum_counts$phylum,
         " (n=", phylum_counts$total, ")"),
  phylum_counts$phylum
)

dark_phyla <- c("Bacillota_I", "Synergistota")

final_df <- final_df %>%
  mutate(
    text_color = if_else(
      as.character(phylum) %in% dark_phyla,
      "white",
      "black"
    )
  )

p <- ggplot(
  final_df,
  aes(
    x = target_vfam,
    y = count,
    fill = phylum,
    group = segment
  )
) +
  geom_col(
    width = 0.6,
    color = "black",
    linewidth = 0.3,
    position = position_stack(reverse = TRUE)
  ) +
  geom_text(
    aes(label = label, color = text_color),
    position = position_stack(vjust = 0.5, reverse = TRUE),
    size = 3.2,
    lineheight = 0.95,
    show.legend = FALSE
  ) +
  coord_flip() +
  scale_fill_manual(
    values = phylum_color,
    breaks = phylum_levels,
    labels = legend_labels,
    name = "Host phylum"
  ) +
  scale_color_identity() +
  scale_y_continuous(
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = paste("Host source of", target_vfam),
    subtitle = paste0(
      "Global TOP", top_n,
      " families; remaining families pooled within each phylum"
    ),
    x = NULL,
    y = "Number of prophage records"
  ) +
  theme_classic(base_size = 12) +
  theme(
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid.major.x = element_line(
      color = "grey90",
      linewidth = 0.3
    ),
    legend.position = "bottom",
    plot.title = element_text(
      hjust = 0.5,
      size = 16,
      face = "bold"
    ),
    plot.subtitle = element_text(hjust = 0.5)
  ) +
  guides(
    fill = guide_legend(nrow = 2, byrow = TRUE)
  )

ggsave(
  output_image,
  plot = p,
  width = 12,
  height = 4.5
)

write.table(
  final_df %>% select(phylum, family, count, percentage),
  output_table,
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)