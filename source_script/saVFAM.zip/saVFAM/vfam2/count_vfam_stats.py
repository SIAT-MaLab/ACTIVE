#!/usr/bin/env python3
import sys
import pandas as pd


def summarize_vfam(
    tsv_path="../../../metadata/allpp_metadata.tsv", target_fam="vFAM_2"
):
    df = pd.read_csv(tsv_path, sep="\t", low_memory=False)

    sub_df = df[df["vFAM"] == target_fam]

    if sub_df.empty:
        print("Target not found")
        return

    active_df = sub_df[sub_df["Activity_Score"] >= 0.8]

    n_total = len(sub_df)
    n_act = len(active_df)

    vsubfam_tot = sub_df["vSUBFAM"].dropna().nunique()
    vsubfam_act = active_df["vSUBFAM"].dropna().nunique()

    vgenus_tot = sub_df["vGENUS"].dropna().nunique()
    vgenus_act = active_df["vGENUS"].dropna().nunique()

    votu_tot = sub_df["vOTU"].dropna().nunique()
    votu_act = active_df["vOTU"].dropna().nunique()

    print("\n" + "=" * 55)
    print(f"Statistics: {target_fam}")
    print("=" * 55)
    print(
        f"• Prophages (Members) : {n_act} / {n_total} active ({n_act/n_total*100:.2f}%)"
    )
    print(
        f"• vSUBFAM (Subfamilies): {vsubfam_act} / {vsubfam_tot} active ({vsubfam_act/vsubfam_tot*100:.2f}%)"
    )
    print(
        f"• vGENUS  (Genera)     : {vgenus_act} / {vgenus_tot} active ({vgenus_act/vgenus_tot*100:.2f}%)"
    )
    print(
        f"• vOTU    (Species)    : {votu_act} / {votu_tot} AvOTUs ({votu_act/votu_tot*100:.2f}%)"
    )
    print("=" * 55)


if __name__ == "__main__":
    fam = sys.argv[1] if len(sys.argv) > 1 else "vFAM_2"
    summarize_vfam(target_fam=fam)