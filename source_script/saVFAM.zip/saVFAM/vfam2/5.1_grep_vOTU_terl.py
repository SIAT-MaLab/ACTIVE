import pandas as pd
import os

metadata_file = "4_hanky-like/vFAM2_metadata_annotated_with_source.tsv"
summary_file = "../../../taxonomy/vOTU_tree/vOTU_selection_summary.tsv"
faa_file = "../../../metadata/allpp_proteins.faa"
output_faa = "5_vOTU_tree/vFAM2_All_vOTU_TerL_sequences.faa"

df_meta = pd.read_csv(metadata_file, sep='\t')
all_votus = df_meta['vOTU'].unique()
total_votu_count = len(all_votus)

df_summary = pd.read_csv(summary_file, sep='\t')
df_votu_status = df_summary[df_summary['vOTU'].isin(all_votus)].copy()

def normalize_gene_id(gene_id):
    if pd.isna(gene_id) or str(gene_id).strip() in ['None', '']:
        return None

    gene_id = str(gene_id)
    gene_id = gene_id.replace('-', '_')

    if "_CDS_" in gene_id:
        prefix, suffix = gene_id.split("_CDS_")
        try:
            return f"{prefix}_CDS_{int(suffix)}"
        except ValueError:
            return gene_id
    return gene_id

df_votu_status['Normalized_ID'] = df_votu_status['Selected_Gene'].apply(normalize_gene_id)

terl_positive = df_votu_status[df_votu_status['Status'] == 'Selected']
pos_count = len(terl_positive)
neg_count = total_votu_count - pos_count

print("\n" + "="*40)
print("vFAM2 vOTU TerL summary")
print("-"*40)
print(f"{'Metric':<20} | {'Count':<10} | {'Percent':<10}")
print(f"{'Total vOTU':<20} | {total_votu_count:<10} | 100%")
print(f"{'vOTU with TerL':<20} | {pos_count:<10} | {pos_count/total_votu_count:.1%}")
print(f"{'vOTU without TerL':<20} | {neg_count:<10} | {neg_count/total_votu_count:.1%}")
print("="*40 + "\n")

target_ids = set(terl_positive['Normalized_ID'].dropna().unique())

extracted_count = 0
with open(faa_file, 'r') as f_in, open(output_faa, 'w') as f_out:
    can_write = False
    for line in f_in:
        if line.startswith('>'):
            current_id_raw = line.split()[0].lstrip('>')
            current_id = normalize_gene_id(current_id_raw)

            if current_id in target_ids:
                can_write = True
                f_out.write(line)
                extracted_count += 1
            else:
                can_write = False
        else:
            if can_write:
                f_out.write(line)

print(f"Extracted {extracted_count} TerL sequences to: {output_faa}")

terl_positive.drop(columns=['Normalized_ID']).to_csv("TerL_All_vOTU_Table.tsv", sep='\t', index=False)
print("Table saved: TerL_All_vOTU_Table.tsv")