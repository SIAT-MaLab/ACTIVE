library(tidyverse)

tree_file     <- "5_vOTU_tree/vFAM2_votu_terL.tree"
metadata_file <- "4_hanky-like/vFAM2_metadata_annotated_with_source.tsv"
sa_file       <- "../../sa_prophage_results/stats_baseline_vOTU.tsv"
cross_file    <- "../../sa_prophage_results/Detailed_Cross_Host_vOTUs.csv"
ref_fasta     <- "5_vOTU_tree/BK010464_terL.fasta"
terl_table    <- c("5_vOTU_tree/TerL_All_vOTU_Table.tsv", "TerL_All_vOTU_Table.tsv")
out_file      <- "5_vOTU_tree/vFAM2_terL_tree_annotation.tsv"

na_vals <- c("", "NA", "na", "Unclassified", "NULL", "None")

modal <- function(x) {
  x <- as.character(x)
  x <- x[!is.na(x) & !x %in% c("", "NA", "Unclassified", "NULL")]
  if (length(x) == 0) return("Unclassified")
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

norm_hyphen <- function(x) str_replace_all(as.character(x), "-", "_")

norm_gene <- function(x) {
  x <- norm_hyphen(x)
  cds <- str_match(x, "^(.*)_CDS_0*([0-9]+)$")
  ifelse(!is.na(cds[, 1]), paste0(cds[, 2], "_CDS_", as.integer(cds[, 3])), x)
}

phage_key_from_tip <- function(x) str_remove(norm_gene(x), "_CDS_[0-9]+$")

extract_tips <- function(path) {
  tips <- tryCatch(ape::read.tree(path)$tip.label, error = function(e) NULL)
  if (!is.null(tips) && length(tips) > 0) return(tips)
  txt <- paste(readLines(path), collapse = "")
  str_match_all(txt, "[,(]([^:(),]+):")[[1]][, 2]
}

read_fasta_ids <- function(path) {
  if (!file.exists(path)) return(character())
  readLines(path) %>%
    keep(~str_starts(.x, ">")) %>%
    str_remove("^>") %>%
    str_split("\\s+") %>%
    map_chr(1)
}

meta <- read_tsv(metadata_file, na = na_vals, show_col_types = FALSE) %>%
  mutate(
    vOTU = norm_hyphen(vOTU),
    Activity_Score = as.numeric(Activity_Score),
    hanky_blastn = str_to_lower(as.character(hanky_blastn))
  )

votu_annot <- meta %>%
  group_by(vOTU) %>%
  summarise(
    Total_Genomes   = n(),
    Log10_Genomes   = log10(n()),
    is_AvOTU        = if_else(any(!is.na(Activity_Score) & Activity_Score >= 0.8), "Yes", "No"),
    is_hanky_like   = if_else(any(hanky_blastn == "yes", na.rm = TRUE), "Yes", "No"),
    host_Family     = modal(host_Family),
    vGENUS          = coalesce(first(na.omit(as.character(vGENUS))), "Unclassified"),
    vSUBFAM         = coalesce(first(na.omit(as.character(vSUBFAM))), "Unclassified"),
    .groups = "drop"
  )

sa_annot <- read_tsv(sa_file, na = na_vals, show_col_types = FALSE) %>%
  mutate(
    vOTU = norm_hyphen(vOTU),
    is_SAvOTU = if_else(Significance_Type == "Significant", "Yes", "No")
  ) %>%
  distinct(vOTU, .keep_all = TRUE) %>%
  select(vOTU, is_SAvOTU)

cross_annot <- read_csv(cross_file, na = na_vals, show_col_types = FALSE) %>%
  mutate(vOTU = norm_hyphen(vOTU)) %>%
  distinct(vOTU, .keep_all = TRUE) %>%
  transmute(vOTU, is_cross_host = "Yes", Cross_Category)

votu_annot <- votu_annot %>%
  left_join(sa_annot, by = "vOTU") %>%
  left_join(cross_annot, by = "vOTU") %>%
  mutate(
    is_SAvOTU      = replace_na(is_SAvOTU, "No"),
    is_cross_host  = replace_na(is_cross_host, "No"),
    Cross_Category = replace_na(as.character(Cross_Category), "Not_cross")
  )

phage_map <- meta %>%
  transmute(key = str_replace_all(phage_id, "-", "_"), vOTU) %>%
  distinct(key, .keep_all = TRUE)

gene_map <- tibble(key = character(), vOTU = character())
terl_hit <- terl_table[file.exists(terl_table)]
if (length(terl_hit) > 0) {
  terl <- read_tsv(terl_hit[[1]], show_col_types = FALSE)
  gene_col <- intersect(names(terl), c("Selected_Gene", "gene_id", "Gene", "TerL"))
  if ("vOTU" %in% names(terl) && length(gene_col) > 0) {
    gene_map <- terl %>%
      transmute(key = norm_gene(.data[[gene_col[[1]]]]), vOTU = norm_hyphen(vOTU)) %>%
      filter(!is.na(key), key != "None", key != "") %>%
      distinct(key, .keep_all = TRUE)
  }
}

ref_ids <- unique(c(read_fasta_ids(ref_fasta), "DAC76685.1", "BK010464"))
tips    <- extract_tips(tree_file)

tip_map <- tibble(node_id = tips) %>%
  mutate(
    gene_key  = norm_gene(node_id),
    phage_key = phage_key_from_tip(node_id)
  ) %>%
  left_join(gene_map  %>% rename(gene_key  = key, vOTU_gene  = vOTU), by = "gene_key") %>%
  left_join(phage_map %>% rename(phage_key = key, vOTU_phage = vOTU), by = "phage_key") %>%
  mutate(
    vOTU = case_when(
      str_starts(node_id, "vOTU_") ~ norm_hyphen(node_id),
      node_id %in% ref_ids | gene_key %in% norm_gene(ref_ids) ~ "ref",
      !is.na(vOTU_gene)  ~ vOTU_gene,
      !is.na(vOTU_phage) ~ vOTU_phage,
      TRUE ~ NA_character_
    ),
    Source = case_when(
      vOTU == "ref" ~ "ref",
      is.na(vOTU)   ~ "Unknown",
      TRUE          ~ "User_vOTU"
    )
  )

final_annotation <- tip_map %>%
  select(node_id, vOTU, Source) %>%
  left_join(votu_annot, by = "vOTU") %>%
  mutate(
    is_AvOTU = case_when(
      Source == "ref"     ~ "ref",
      Source == "Unknown" ~ "Unknown",
      TRUE                ~ coalesce(is_AvOTU, "No")
    ),
    is_SAvOTU = case_when(
      Source == "ref"     ~ "ref",
      Source == "Unknown" ~ "Unknown",
      TRUE                ~ coalesce(is_SAvOTU, "No")
    ),
    is_hanky_like = case_when(
      Source == "ref"     ~ "ref",
      Source == "Unknown" ~ "Unknown",
      TRUE                ~ coalesce(is_hanky_like, "No")
    ),
    is_cross_host = case_when(
      Source == "ref"     ~ "ref",
      Source == "Unknown" ~ "Unknown",
      TRUE                ~ coalesce(is_cross_host, "No")
    ),
    host_Family = case_when(
      Source == "ref"     ~ "ref",
      Source == "Unknown" ~ "Unknown",
      TRUE                ~ coalesce(host_Family, "Unclassified")
    ),
    Cross_Category = case_when(
      Source == "ref"     ~ "ref",
      Source == "Unknown" ~ "Unknown",
      TRUE                ~ coalesce(as.character(Cross_Category), "Not_cross")
    ),
    vSUBFAM = case_when(
      Source == "ref"     ~ "ref",
      Source == "Unknown" ~ "Unknown",
      TRUE                ~ coalesce(vSUBFAM, "Unclassified")
    ),
    vGENUS = case_when(
      Source == "ref"     ~ "ref",
      Source == "Unknown" ~ "Unknown",
      TRUE                ~ coalesce(vGENUS, "Unclassified")
    ),
    Total_Genomes = if_else(Source == "User_vOTU", Total_Genomes, NA_integer_),
    Log10_Genomes = if_else(Source == "User_vOTU", Log10_Genomes, NA_real_),
    vOTU = if_else(Source == "ref", "ref", vOTU)
  ) %>%
  select(node_id, vOTU, Source, is_AvOTU, is_SAvOTU, Total_Genomes, Log10_Genomes,
         is_hanky_like, host_Family, is_cross_host, Cross_Category, vSUBFAM, vGENUS)

write_tsv(final_annotation, out_file)

user <- final_annotation %>% filter(Source == "User_vOTU")
cat("\n", strrep("=", 44), "\n", sep = "")
cat("vFAM2 TerL tree annotation QC\n")
cat(strrep("-", 44), "\n")
cat(sprintf("%-22s %d\n", "tips", nrow(final_annotation)))
cat(sprintf("%-22s %d\n", "User_vOTU", nrow(user)))
cat(sprintf("%-22s %d\n", "ref", sum(final_annotation$Source == "ref")))
cat(sprintf("%-22s %d\n", "Unknown", sum(final_annotation$Source == "Unknown")))
cat(sprintf("%-22s %d / %d\n", "AvOTU", sum(user$is_AvOTU == "Yes"), nrow(user)))
cat(sprintf("%-22s %d / %d\n", "SAvOTU", sum(user$is_SAvOTU == "Yes"), nrow(user)))
cat(sprintf("%-22s %d / %d\n", "hanky-like", sum(user$is_hanky_like == "Yes"), nrow(user)))
cat(sprintf("%-22s %d / %d\n", "cross-host", sum(user$is_cross_host == "Yes"), nrow(user)))
cat(strrep("=", 44), "\n")
cat("written:", out_file, "\n")
if (any(final_annotation$Source == "Unknown")) {
  cat("Unmapped tips:\n")
  print(final_annotation$node_id[final_annotation$Source == "Unknown"])
}