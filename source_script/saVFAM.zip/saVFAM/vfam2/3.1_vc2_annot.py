from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

SOURCE_LABEL = "vFAM2"
ACTIVITY_CUTOFF = 0.8

VC_FILE = Path("3_vcontact2/genome_by_genome_overview.csv")
METADATA_FILE = Path("4_hanky-like/vFAM2_metadata_annotated_with_source.tsv")
SA_FILE = Path("../../sa_prophage_results/stats_baseline_vOTU.tsv")
GENOME_TO_VOTU_FILE = Path("../../../taxonomy/vOTU/genome_to_vOTU.tsv")

VFAM_FA = Path("vFAM2_vOTU_rep.fasta")
REF_FA = Path("INPHARED_GTDBr220_Bacteroidales.fa")

OUT_FILE = Path("3_vcontact2/genome_by_genome_annotated.csv")

NA_VALS = ["", "NA", "na", "Unclassified", "NULL", "None", "<NA>", "NaN"]
NEW_COLS = ["Source", "vOTU", "vSUBFAM", "vGENUS", "is_active", "is_SAvOTU", "is_hanky_like"]


def log(msg: str) -> None:
    print(msg, flush=True)


def die(msg: str) -> None:
    sys.exit(f"ERROR: {msg}")


def norm_id(x) -> str:
    if pd.isna(x):
        return ""
    s = str(x).strip()
    return "" if s in NA_VALS else s.replace("-", "_")


def file_key(x) -> str:
    s = "" if pd.isna(x) else str(x).strip()
    if s.startswith("phage_depth_"):
        s = s[len("phage_depth_") :]
    if s.endswith(".txt"):
        s = s[:-4]
    return norm_id(s)


def read_fasta_ids(path: Path) -> list[str]:
    if not path.exists():
        die(f"missing fasta: {path}")
    ids = []
    with path.open() as f:
        for line in f:
            if line.startswith(">"):
                ids.append(line[1:].split()[0])
    return ids


def pick_taxon(series: pd.Series) -> str:
    vals = [str(v).strip() for v in series.dropna() if str(v).strip() not in NA_VALS]
    if not vals:
        return "Unclassified"
    return pd.Series(vals).mode().iloc[0]


def fill_by_source(source: pd.Series, value: pd.Series, default_val: str) -> pd.Series:
    cleaned = value.astype("string")
    cleaned = cleaned.where(cleaned.notna() & (cleaned != ""), default_val)
    return pd.Series(
        ["REF" if s == "REF" else "Unknown" if s == "Unknown" else v for s, v in zip(source, cleaned)],
        index=source.index,
        dtype="string",
    )


def main() -> None:
    for p in (VC_FILE, METADATA_FILE, SA_FILE, GENOME_TO_VOTU_FILE, VFAM_FA, REF_FA):
        if not p.exists():
            die(f"missing file: {p}")

    vfam_ids = read_fasta_ids(VFAM_FA)
    ref_ids = read_fasta_ids(REF_FA)
    vfam_key = set(map(norm_id, vfam_ids))
    ref_key = set(map(norm_id, ref_ids))

    if vfam_key & ref_key:
        die(f"overlapping genome IDs between {VFAM_FA} and {REF_FA}")

    vc = pd.read_csv(VC_FILE)
    if "Genome" not in vc.columns:
        die(f"no Genome column in {VC_FILE}; columns={list(vc.columns)}")

    meta = pd.read_csv(METADATA_FILE, sep="\t", na_values=NA_VALS, keep_default_na=True)
    need = {"phage_id", "File", "vOTU", "vSUBFAM", "vGENUS", "Activity_Score", "hanky_blastn"}
    missing = need - set(meta.columns)
    if missing:
        die(f"metadata missing columns: {missing}")

    meta = meta.copy()
    meta["vOTU"] = meta["vOTU"].map(norm_id)
    meta = meta[meta["vOTU"] != ""].copy()

    meta["Activity_Score"] = pd.to_numeric(meta["Activity_Score"], errors="coerce")
    meta["hanky_yes"] = meta["hanky_blastn"].astype("string").str.lower() == "yes"
    meta["key_phage"] = meta["phage_id"].map(norm_id)
    meta["key_file"] = meta["File"].map(file_key)

    votu_annot = (
        meta.groupby("vOTU", as_index=False)
        .agg(
            vSUBFAM=("vSUBFAM", pick_taxon),
            vGENUS=("vGENUS", pick_taxon),
            max_act=("Activity_Score", "max"),
            any_hanky=("hanky_yes", "any"),
        )
    )
    votu_annot["is_active"] = (
        votu_annot["max_act"].notna() & (votu_annot["max_act"] >= ACTIVITY_CUTOFF)
    ).map({True: "Yes", False: "No"})
    votu_annot["is_hanky_like"] = votu_annot["any_hanky"].map({True: "Yes", False: "No"})

    sa = pd.read_csv(SA_FILE, sep="\t", na_values=NA_VALS)
    sa["vOTU"] = sa["vOTU"].map(norm_id)
    sa["is_SAvOTU"] = (sa["Significance_Type"] == "Significant").map({True: "Yes", False: "No"})
    sa = sa[sa["vOTU"] != ""].drop_duplicates("vOTU")[["vOTU", "is_SAvOTU"]]

    votu_annot = votu_annot.merge(sa, on="vOTU", how="left")
    votu_annot["is_SAvOTU"] = votu_annot["is_SAvOTU"].fillna("No")
    votu_annot = votu_annot[["vOTU", "vSUBFAM", "vGENUS", "is_active", "is_SAvOTU", "is_hanky_like"]]

    g2v = pd.read_csv(GENOME_TO_VOTU_FILE, sep="\t", header=None, dtype=str)
    if g2v.shape[1] < 3:
        die(f"{GENOME_TO_VOTU_FILE} must have at least 3 columns (member, vOTU, rep)")
    g2v = g2v.iloc[:, :3].copy()
    g2v.columns = ["member_id", "vOTU", "rep_id"]
    g2v["vOTU"] = g2v["vOTU"].map(norm_id)
    g2v = g2v[g2v["vOTU"].str.startswith("vOTU_")].copy()

    id_to_votu: dict[str, str] = {}
    for k_series, v_series in (
        (meta["key_file"], meta["vOTU"]),
        (meta["key_phage"], meta["vOTU"]),
        (g2v["member_id"].map(norm_id), g2v["vOTU"]),
        (g2v["rep_id"].map(norm_id), g2v["vOTU"]),
    ):
        for k, v in zip(k_series, v_series):
            if k and v:
                id_to_votu[k] = v

    out = vc.copy()
    out["genome_key"] = out["Genome"].map(norm_id)
    out["vOTU"] = out["genome_key"].map(id_to_votu)

    out = out.merge(votu_annot, on="vOTU", how="left")

    in_vfam = out["genome_key"].isin(vfam_key)
    in_ref = out["genome_key"].isin(ref_key)
    out["Source"] = "Unknown"
    out.loc[in_vfam, "Source"] = SOURCE_LABEL
    out.loc[in_ref & ~in_vfam, "Source"] = "REF"

    out["vOTU"] = fill_by_source(out["Source"], out["vOTU"], "Unclassified")
    out["vSUBFAM"] = fill_by_source(out["Source"], out["vSUBFAM"], "Unclassified")
    out["vGENUS"] = fill_by_source(out["Source"], out["vGENUS"], "Unclassified")
    out["is_active"] = fill_by_source(out["Source"], out["is_active"], "No")
    out["is_SAvOTU"] = fill_by_source(out["Source"], out["is_SAvOTU"], "No")
    out["is_hanky_like"] = fill_by_source(out["Source"], out["is_hanky_like"], "No")

    out = out.drop(columns=["genome_key"])
    rest = [c for c in out.columns if c not in (["Genome"] + NEW_COLS)]
    out = out[["Genome"] + NEW_COLS + rest]

    OUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(OUT_FILE, index=False)

    vfam = out[out["Source"] == SOURCE_LABEL]
    unknown = out[out["Source"] == "Unknown"]
    unmatched = vfam[vfam["vOTU"] == "Unclassified"]
    matched_votus = vfam.loc[vfam["vOTU"] != "Unclassified", "vOTU"]

    log(
        f"{SOURCE_LABEL}: {len(vfam)} genomes, {matched_votus.nunique()} vOTUs, "
        f"unmatched {len(unmatched)} | "
        f"active {(vfam['is_active'] == 'Yes').sum()}, "
        f"SAvOTU {(vfam['is_SAvOTU'] == 'Yes').sum()}, "
        f"hanky-like {(vfam['is_hanky_like'] == 'Yes').sum()} | "
        f"REF {(out['Source'] == 'REF').sum()}, Unknown {len(unknown)} | "
        f"written: {OUT_FILE}"
    )

    if len(matched_votus) != matched_votus.nunique():
        log("WARNING: multiple genomes map to the same vOTU")

    if len(unknown):
        log("Unmapped Genome IDs:")
        for g in unknown["Genome"].head(50):
            log(f"  {g}")

    if len(unmatched):
        log(f"{SOURCE_LABEL} genomes with no metadata hit:")
        for g in unmatched["Genome"].head(50):
            log(f"  {g}")


if __name__ == "__main__":
    main()