#!/usr/bin/env python3

from pathlib import Path
import pandas as pd
from Bio import SeqIO

DIR = Path(".")

QUERY_FASTA = DIR / "vFAM11_vOTU_rep.fasta"
REF_FASTA = DIR / "INPHARED_GTDBr220_Bacteroidales.fa"

VC2_OVERVIEW = DIR / "vcontact2/genome_by_genome_overview.csv"

ALLPP_META_TSV = DIR / "../../../../metadata/allpp_metadata.tsv"
GENOME_TO_VOTU_TSV = (
    DIR / "../../../../taxonomy/vOTU/genome_to_vOTU.tsv"
)
BASELINE_STAT_TSV = (
    DIR / "../../../sa_prophage_results/stats_baseline_vOTU.tsv"
)

OUT_ANNOT = DIR / "vcontact2/vfam11_genome_annotated.tsv"

ACTIVITY_CUTOFF = 0.8

def clean(x):
    if pd.isna(x):
        return None
    s = str(x).strip()
    return None if s in {"", "NA", "N/A", "<NA>", "NaN"} else s

def norm_id(x):
    s = clean(x)
    return s.replace("-", "_") if s is not None else None

def unique_mapping(keys, values, label):
    result = {}
    for key, value in zip(keys, values):
        key, value = clean(key), clean(value)
        if key is None or value is None:
            continue
        if key in result and result[key] != value:
            raise ValueError(
                f"{label} conflict: {key} -> "
                f"{result[key]} / {value}"
            )
        result[key] = value
    return result

def read_fasta_ids(path):
    ids = [
        norm_id(record.id)
        for record in SeqIO.parse(str(path), "fasta")
    ]
    if len(ids) != len(set(ids)):
        raise ValueError(f"Duplicate or conflicting IDs in FASTA: {path}")
    return set(ids)

for path in [
    QUERY_FASTA, REF_FASTA, VC2_OVERVIEW,
    ALLPP_META_TSV, GENOME_TO_VOTU_TSV, BASELINE_STAT_TSV
]:
    if not path.exists():
        raise FileNotFoundError(f"Missing input file: {path}")

query_ids = read_fasta_ids(QUERY_FASTA)
ref_ids = read_fasta_ids(REF_FASTA)

if query_ids & ref_ids:
    raise ValueError("Query and reference FASTA IDs overlap")

meta = pd.read_csv(ALLPP_META_TSV, sep="\t", dtype=str)

required = [
    "phage_id", "vOTU", "vFAM", "vSUBFAM", "vGENUS",
    "Activity_Score"
]
missing = set(required) - set(meta.columns)
if missing:
    raise ValueError(f"Missing metadata columns: {sorted(missing)}")

for col in ["vOTU", "vFAM", "vSUBFAM", "vGENUS"]:
    meta[col] = meta[col].map(clean)

meta["norm_id"] = meta["phage_id"].map(norm_id)
meta["Activity_Score"] = pd.to_numeric(
    meta["Activity_Score"], errors="coerce"
)

metadata_id_to_votu = unique_mapping(
    meta["norm_id"], meta["vOTU"], "metadata ID -> vOTU"
)

taxonomy_maps = {}
for col in ["vFAM", "vSUBFAM", "vGENUS"]:
    taxonomy_maps[col] = unique_mapping(
        meta["vOTU"], meta[col], f"vOTU -> {col}"
    )

votu_max_activity = (
    meta.dropna(subset=["vOTU"])
    .groupby("vOTU")["Activity_Score"]
    .max()
    .to_dict()
)

mapping = pd.read_csv(
    GENOME_TO_VOTU_TSV,
    sep="\t",
    header=None,
    dtype=str
)

if mapping.shape[1] != 3:
    raise ValueError("genome_to_vOTU.tsv must have three columns")

mapping.columns = ["member_id", "vOTU", "rep_id"]

mapping["vOTU"] = mapping["vOTU"].map(clean)
mapping = mapping[
    mapping["vOTU"].str.match(r"^vOTU_\d+$", na=False)
].copy()

rep_to_votu = unique_mapping(
    mapping["rep_id"].map(norm_id),
    mapping["vOTU"],
    "representative ID -> vOTU"
)

member_to_votu = unique_mapping(
    mapping["member_id"].map(norm_id),
    mapping["vOTU"],
    "member ID -> vOTU"
)

id_to_votu = {}
for lookup in [metadata_id_to_votu, member_to_votu, rep_to_votu]:
    for nid, votu in lookup.items():
        if nid in id_to_votu and id_to_votu[nid] != votu:
            raise ValueError(
                f"Metadata and mapping conflict: {nid} -> "
                f"{id_to_votu[nid]} / {votu}"
            )
        id_to_votu[nid] = votu

unmapped = sorted(query_ids - set(id_to_votu))
if unmapped:
    raise ValueError(
        f"{len(unmapped)} query sequences cannot be mapped to vOTU; examples: "
        + ", ".join(unmapped[:10])
    )

query_votus = [id_to_votu[nid] for nid in query_ids]
if len(query_votus) != len(set(query_votus)):
    raise ValueError("Multiple query sequences map to the same vOTU")

baseline = pd.read_csv(
    BASELINE_STAT_TSV, sep="\t", dtype=str
)

baseline["vOTU"] = baseline["vOTU"].map(clean)
baseline["Significance_Type"] = (
    baseline["Significance_Type"].map(clean)
)

significant_votus = set(
    baseline.loc[
        baseline["Significance_Type"] == "Significant",
        "vOTU"
    ].dropna()
)

overview = pd.read_csv(VC2_OVERVIEW, dtype=str)
rows = []

for _, row in overview.iterrows():
    genome = clean(row["Genome"])
    nid = norm_id(genome)

    annotation = {
        "Source_Origin": "Unknown",
        "Source_Category": "Unknown",
        "vOTU": None,
        "vFAM": None,
        "vSUBFAM": None,
        "vGENUS": None,
        "vOTU_Max_Activity_Score": None,
        "Is_Active": False,
        "Is_Significantly_Active": False,
    }

    if nid in query_ids:
        votu = id_to_votu[nid]
        family = taxonomy_maps["vFAM"].get(votu)
        score = votu_max_activity.get(votu)

        annotation.update({
            "Source_Origin": family or "Query",
            "Source_Category": "Query",
            "vOTU": votu,
            "vFAM": family,
            "vSUBFAM": taxonomy_maps["vSUBFAM"].get(votu),
            "vGENUS": taxonomy_maps["vGENUS"].get(votu),
            "vOTU_Max_Activity_Score": score,
            "Is_Active": (
                pd.notna(score) and score >= ACTIVITY_CUTOFF
            ),
            "Is_Significantly_Active": votu in significant_votus,
        })

    elif nid in ref_ids:
        annotation.update({
            "Source_Origin": "Ref_Bacteroidales",
            "Source_Category": "Reference",
        })

    result = row.to_dict()
    result.update(annotation)
    rows.append(result)

annot = pd.DataFrame(rows)

front_cols = [
    "Genome", "Source_Origin", "Source_Category",
    "vOTU", "vFAM", "vSUBFAM", "vGENUS",
    "vOTU_Max_Activity_Score",
    "Is_Active", "Is_Significantly_Active",
    "VC Status", "VC"
]
other_cols = [col for col in annot.columns if col not in front_cols]
annot = annot[front_cols + other_cols]

OUT_ANNOT.parent.mkdir(parents=True, exist_ok=True)
annot.to_csv(OUT_ANNOT, sep="\t", index=False, na_rep="NA")